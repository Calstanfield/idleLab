import React, { useState, useEffect } from 'react';
import {
  Layers,
  Armchair,
  Users,
  Eye,
  ArrowUpDown,
  Monitor,
  Mic,
  MicOff,
  Video,
  VideoOff,
  Volume2,
  Tv,
  Check,
  ChevronDown,
  ChevronRight,
  Sliders,
  Sparkles,
  Search,
  X,
  Music,
  Cloud,
  Radio,
} from 'lucide-react';
import { UserState, DeskData } from '../types';
import { chloeAgentClient } from '../lib/chloeAgentClient';
import { audioManager } from '../lib/audioManager';

interface FigmaInspectorPanelProps {
  isLayersOpen: boolean;
  isInspectorOpen: boolean;
  onCloseLayers: () => void;
  onCloseInspector: () => void;
  currentUser: UserState | null;
  remoteUsers: Map<string, UserState>;
  desks: DeskData[];
  cameraMode: 'third_person' | 'first_person' | 'isometric';
  onChangeCameraMode: () => void;
  onTeleportDesk: () => void;
  onTeleportMeetingRoom: () => void;
  onTeleportSushiBar: () => void;
  onTeleportBasementTheater?: () => void;
  onTeleportTennisCourt?: () => void;
  onToggleElevator: () => void;
  currentFloor: number | string;
  isMuted: boolean;
  isCameraOn: boolean;
  isScreenSharing: boolean;
  onToggleMic: () => void;
  onToggleCamera: () => void;
  onStartScreenShareWithOptions: (options: { includeAudio: boolean; preferTab: boolean }) => void;
  onStopScreenShare: () => void;
  onOpenWhiteboard: () => void;
  onOpenChecklist: () => void;
  onOpenSavedContacts: () => void;
  onOpenCoffeeRobot?: () => void;
  onOpenLibrary?: () => void;
  onOpenDataCenter?: () => void;
  onOpenSwiftNote?: () => void;
  onOpenPresentationModal?: () => void;
  onOpenLabGuide?: () => void;
  onOpenPomodoro?: () => void;
}

export const FigmaInspectorPanel: React.FC<FigmaInspectorPanelProps> = ({
  isLayersOpen,
  isInspectorOpen,
  onCloseLayers,
  onCloseInspector,
  currentUser,
  remoteUsers,
  desks,
  cameraMode,
  onChangeCameraMode,
  onTeleportDesk,
  onTeleportMeetingRoom,
  onTeleportSushiBar,
  onTeleportBasementTheater,
  onTeleportTennisCourt,
  onToggleElevator,
  currentFloor,
  isMuted,
  isCameraOn,
  isScreenSharing,
  onToggleMic,
  onToggleCamera,
  onStartScreenShareWithOptions,
  onStopScreenShare,
  onOpenWhiteboard,
  onOpenChecklist,
  onOpenSavedContacts,
  onOpenCoffeeRobot,
  onOpenLibrary,
  onOpenDataCenter,
  onOpenSwiftNote,
  onOpenPresentationModal,
  onOpenLabGuide,
  onOpenPomodoro,
}) => {
  const [activeTab, setActiveTab] = useState<'design' | 'prototype'>('design');
  const [tabAudioEnabled, setTabAudioEnabled] = useState(true);
  const [searchFilter, setSearchFilter] = useState('');
  const [openAccordion, setOpenAccordion] = useState<string | null>('3d');
  const [isOrchestratorOn, setIsOrchestratorOn] = useState<boolean>(() => chloeAgentClient.isOrchestratorEnabled());

  const toggleOrchestrator = () => {
    const nextState = !isOrchestratorOn;
    setIsOrchestratorOn(nextState);
    chloeAgentClient.setOrchestratorEnabled(nextState);
  };

  const toggleAccordion = (sectionId: string) => {
    setOpenAccordion(openAccordion === sectionId ? null : sectionId);
  };

  const allUsers: UserState[] = (Array.from(remoteUsers.values()) as UserState[]).concat(currentUser ? [currentUser] : []);

  return (
    <>
      {/* Left Figma Layers & Pages Sidebar Panel */}
      {isLayersOpen && (
        <aside className="fixed top-0 bottom-0 left-0 w-64 bg-[#121216]/90 backdrop-blur-2xl border-r border-white/10 z-30 flex flex-col text-neutral-300 text-xs shadow-2xl select-none animate-in slide-in-from-left duration-200 pt-12 pb-20">
          {/* Sidebar Header */}
          <div className="p-2.5 border-b border-[#2c2c2c] flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Layers className="w-4 h-4 text-sky-400" />
              <span className="font-bold text-white tracking-wide">Pages & Layers</span>
            </div>
            <button
              onClick={onCloseLayers}
              className="p-1 hover:bg-[#2c2c2c] rounded text-neutral-400 hover:text-white"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Search Input */}
          <div className="p-2 border-b border-[#2c2c2c]">
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-neutral-500 absolute left-2.5 top-2" />
              <input
                type="text"
                placeholder="Search layers..."
                value={searchFilter}
                onChange={(e) => setSearchFilter(e.target.value)}
                className="w-full bg-[#141414] border border-[#2c2c2c] rounded-lg pl-8 pr-2 py-1 text-[11px] text-white placeholder-neutral-500 focus:outline-none focus:border-[#0c8ce9]"
              />
            </div>
          </div>

          {/* Pages List */}
          <div className="p-2 border-b border-[#2c2c2c]">
            <div className="text-[10px] font-bold text-neutral-500 uppercase tracking-wider mb-1 px-1">
              Building Floors (Pages)
            </div>
            <div className="space-y-0.5">
              <button
                onClick={onTeleportDesk}
                className={`w-full text-left px-2 py-1.5 rounded-md flex items-center justify-between hover:bg-[#2c2c2c] transition-colors ${
                  currentFloor === 1 ? 'bg-[#2c2c2c] text-white font-semibold' : 'text-neutral-400'
                }`}
              >
                <span className="flex items-center space-x-2">
                  <span className="text-sky-400">#</span>
                  <span>1F Open Workstations</span>
                </span>
                <span className="text-[10px] bg-[#141414] px-1.5 py-0.5 rounded text-neutral-400">Main</span>
              </button>

              <button
                onClick={onTeleportMeetingRoom}
                className={`w-full text-left px-2 py-1.5 rounded-md flex items-center justify-between hover:bg-[#2c2c2c] transition-colors ${
                  currentFloor === 2 ? 'bg-[#2c2c2c] text-white font-semibold' : 'text-neutral-400'
                }`}
              >
                <span className="flex items-center space-x-2">
                  <span className="text-purple-400">#</span>
                  <span>2F Executive Boardroom</span>
                </span>
                <span className="text-[10px] bg-[#141414] px-1.5 py-0.5 rounded text-neutral-400">Meeting</span>
              </button>

              <button
                onClick={onTeleportSushiBar}
                className={`w-full text-left px-2 py-1.5 rounded-md flex items-center justify-between hover:bg-[#2c2c2c] transition-colors ${
                  currentFloor === 3 ? 'bg-[#2c2c2c] text-white font-semibold' : 'text-neutral-400'
                }`}
              >
                <span className="flex items-center space-x-2">
                  <span className="text-amber-400">#</span>
                  <span>3F Visitor Center Cafe</span>
                </span>
                <span className="text-[10px] bg-[#141414] px-1.5 py-0.5 rounded text-neutral-400">Lounge</span>
              </button>

              <button
                onClick={onTeleportBasementTheater}
                className={`w-full text-left px-2 py-1.5 rounded-md flex items-center justify-between hover:bg-[#2c2c2c] transition-colors ${
                  currentFloor === 'B1' || currentFloor === -1 ? 'bg-[#2c2c2c] text-white font-semibold' : 'text-neutral-400'
                }`}
              >
                <span className="flex items-center space-x-2">
                  <span className="text-emerald-400">#</span>
                  <span>B1 Corporate Office</span>
                </span>
                <span className="text-[10px] bg-[#141414] px-1.5 py-0.5 rounded text-neutral-400">Workspace</span>
              </button>

              {onTeleportTennisCourt && (
                <button
                  onClick={onTeleportTennisCourt}
                  className="w-full text-left px-2 py-1.5 rounded-md flex items-center justify-between hover:bg-[#2c2c2c] transition-colors text-emerald-300 hover:text-emerald-200"
                >
                  <span className="flex items-center space-x-2">
                    <span>🎾</span>
                    <span className="font-semibold">B1 Indoor Tennis Arena</span>
                  </span>
                  <span className="text-[10px] bg-emerald-950/80 border border-emerald-500/30 px-1.5 py-0.5 rounded text-emerald-400">Tesla Match</span>
                </button>
              )}
            </div>
          </div>

          {/* Active Office Apps & Integrations */}
          <div className="flex-1 overflow-y-auto p-2 space-y-3 no-scrollbar">
            <div>
              <div className="text-[10px] font-bold text-neutral-500 uppercase tracking-wider mb-1 px-1">
                Workspace & Integrations
              </div>
              <div className="space-y-1">
                {/* MultiAgent Workspace */}
                {onOpenDataCenter && (
                  <button
                    onClick={onOpenDataCenter}
                    className="w-full text-left px-2.5 py-1.5 rounded-lg hover:bg-sky-500/10 flex items-center justify-between text-neutral-200 group bg-sky-950/40 border border-sky-500/30 transition-all cursor-pointer shadow-sm"
                  >
                    <div className="flex items-center space-x-2">
                      <span className="text-sm">🌷</span>
                      <span className="font-bold text-white group-hover:text-sky-300 transition-colors">
                        MultiAgent Workspace
                      </span>
                    </div>
                    <span className="text-[9px] uppercase font-bold px-1.5 py-0.5 rounded bg-sky-500/20 text-sky-300 border border-sky-500/30">
                      Gemini
                    </span>
                  </button>
                )}

                {/* Google Doc */}
                <button
                  onClick={() => window.open('https://docs.google.com', '_blank')}
                  className="w-full text-left px-2.5 py-1.5 rounded-lg hover:bg-[#2c2c2c] flex items-center justify-between text-neutral-300 group transition-colors cursor-pointer"
                >
                  <div className="flex items-center space-x-2">
                    <span>📄</span>
                    <span className="font-medium text-white group-hover:text-sky-300 transition-colors">Google Doc</span>
                  </div>
                  <span className="text-[9px] uppercase px-1.5 py-0.5 rounded bg-blue-500/20 text-blue-300">Docs</span>
                </button>

                {/* Gmail */}
                <button
                  onClick={() => window.open('https://mail.google.com', '_blank')}
                  className="w-full text-left px-2.5 py-1.5 rounded-lg hover:bg-[#2c2c2c] flex items-center justify-between text-neutral-300 group transition-colors cursor-pointer"
                >
                  <div className="flex items-center space-x-2">
                    <span>✉️</span>
                    <span className="font-medium text-white group-hover:text-rose-300 transition-colors">Gmail</span>
                  </div>
                  <span className="text-[9px] uppercase px-1.5 py-0.5 rounded bg-rose-500/20 text-rose-300">Mail</span>
                </button>

                {/* Spreadsheet */}
                <button
                  onClick={() => window.open('https://sheets.google.com', '_blank')}
                  className="w-full text-left px-2.5 py-1.5 rounded-lg hover:bg-[#2c2c2c] flex items-center justify-between text-neutral-300 group transition-colors cursor-pointer"
                >
                  <div className="flex items-center space-x-2">
                    <span>📊</span>
                    <span className="font-medium text-white group-hover:text-emerald-300 transition-colors">Spreadsheet</span>
                  </div>
                  <span className="text-[9px] uppercase px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-300">Sheets</span>
                </button>

                {/* Google Cloud */}
                <button
                  onClick={() => window.open('https://console.cloud.google.com', '_blank')}
                  className="w-full text-left px-2.5 py-1.5 rounded-lg hover:bg-[#2c2c2c] flex items-center justify-between text-neutral-300 group transition-colors cursor-pointer"
                >
                  <div className="flex items-center space-x-2">
                    <span>☁️</span>
                    <span className="font-medium text-white group-hover:text-sky-300 transition-colors">Google Cloud</span>
                  </div>
                  <span className="text-[9px] uppercase px-1.5 py-0.5 rounded bg-sky-500/20 text-sky-300">Cloud</span>
                </button>

                {/* Google Survey */}
                <button
                  onClick={() => window.open('https://forms.google.com', '_blank')}
                  className="w-full text-left px-2.5 py-1.5 rounded-lg hover:bg-[#2c2c2c] flex items-center justify-between text-neutral-300 group transition-colors cursor-pointer"
                >
                  <div className="flex items-center space-x-2">
                    <span>📋</span>
                    <span className="font-medium text-white group-hover:text-purple-300 transition-colors">Google Survey</span>
                  </div>
                  <span className="text-[9px] uppercase px-1.5 py-0.5 rounded bg-purple-500/20 text-purple-300">Survey</span>
                </button>

                {/* Google Presenter */}
                <button
                  onClick={() => window.open('https://slides.google.com', '_blank')}
                  className="w-full text-left px-2.5 py-1.5 rounded-lg hover:bg-[#2c2c2c] flex items-center justify-between text-neutral-300 group transition-colors cursor-pointer"
                >
                  <div className="flex items-center space-x-2">
                    <span>📽️</span>
                    <span className="font-medium text-white group-hover:text-amber-300 transition-colors">Google Presenter</span>
                  </div>
                  <span className="text-[9px] uppercase px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-300">Slides</span>
                </button>

                {/* YouTube with Screen Share Cast */}
                <button
                  onClick={() => {
                    window.open('https://www.youtube.com', '_blank');
                    onStartScreenShareWithOptions({ includeAudio: true, preferTab: true });
                  }}
                  className="w-full text-left px-2.5 py-1.5 rounded-lg hover:bg-rose-500/10 flex items-center justify-between text-neutral-200 group bg-rose-950/20 border border-rose-500/20 transition-all cursor-pointer"
                >
                  <div className="flex items-center space-x-2">
                    <span>▶️</span>
                    <span className="font-medium text-white group-hover:text-rose-300 transition-colors">YouTube</span>
                  </div>
                  <span className="text-[9px] font-semibold uppercase px-1.5 py-0.5 rounded bg-red-500/20 text-red-300 border border-red-500/30 flex items-center space-x-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-red-400 animate-pulse inline-block mr-1" />
                    Cast Screen
                  </span>
                </button>

                {/* SwiftNote */}
                <button
                  onClick={onOpenSwiftNote}
                  className="w-full text-left px-2.5 py-1.5 rounded-lg hover:bg-amber-500/10 flex items-center justify-between text-neutral-200 group bg-amber-950/20 border border-amber-500/20 transition-all cursor-pointer"
                >
                  <div className="flex items-center space-x-2">
                    <span className="text-amber-400">✏️</span>
                    <span className="font-medium text-white group-hover:text-amber-300 transition-colors">SwiftNote</span>
                  </div>
                  <span className="text-[9px] font-semibold uppercase px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30 flex items-center space-x-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-pulse inline-block mr-1" />
                    AI Notebook
                  </span>
                </button>

                {/* NotebookLM */}
                <button
                  onClick={() => {
                    window.open('https://notebooklm.google.com', '_blank');
                  }}
                  className="w-full text-left px-2.5 py-1.5 rounded-lg hover:bg-orange-500/10 flex items-center justify-between text-neutral-200 group bg-orange-950/20 border border-orange-500/20 transition-all cursor-pointer"
                >
                  <div className="flex items-center space-x-2">
                    <span>📓</span>
                    <span className="font-medium text-white group-hover:text-orange-300 transition-colors">NotebookLM</span>
                  </div>
                  <span className="text-[9px] font-semibold uppercase px-1.5 py-0.5 rounded bg-orange-500/20 text-orange-300 border border-orange-500/30 flex items-center space-x-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-orange-400 animate-pulse inline-block mr-1" />
                    AI Notes
                  </span>
                </button>

                {/* Twitch with Screen Share Cast */}
                <button
                  onClick={() => {
                    window.open('https://www.twitch.tv', '_blank');
                    onStartScreenShareWithOptions({ includeAudio: true, preferTab: true });
                  }}
                  className="w-full text-left px-2.5 py-1.5 rounded-lg hover:bg-violet-500/10 flex items-center justify-between text-neutral-200 group bg-violet-950/20 border border-violet-500/20 transition-all cursor-pointer"
                >
                  <div className="flex items-center space-x-2">
                    <span>📺</span>
                    <span className="font-medium text-white group-hover:text-violet-300 transition-colors">Twitch</span>
                  </div>
                  <span className="text-[9px] font-semibold uppercase px-1.5 py-0.5 rounded bg-violet-500/20 text-violet-300 border border-violet-500/30 flex items-center space-x-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-purple-400 animate-pulse inline-block mr-1" />
                    Cast Screen
                  </span>
                </button>
              </div>
            </div>

            <div>
              <div className="text-[10px] font-bold text-neutral-500 uppercase tracking-wider mb-1 px-1 flex items-center justify-between">
                <span>Online Colleague Layers</span>
                <span className="text-[#0c8ce9]">{allUsers.length}</span>
              </div>
              <div className="space-y-0.5">
                {allUsers.map((user) => (
                  <div
                    key={user.id}
                    className="px-2 py-1 rounded-md hover:bg-[#2c2c2c] flex items-center justify-between text-neutral-300"
                  >
                    <div className="flex items-center space-x-2 truncate">
                      <div className="w-2 h-2 rounded-full bg-emerald-400 shrink-0" />
                      <span className="truncate font-medium">{user.name}</span>
                      {user.id === currentUser?.id && (
                        <span className="text-[9px] bg-[#0c8ce9]/20 text-sky-400 px-1 rounded">You</span>
                      )}
                    </div>
                    <div className="flex items-center space-x-1 text-neutral-500">
                      {user.isMuted ? <MicOff className="w-3 h-3 text-rose-400" /> : <Mic className="w-3 h-3 text-emerald-400" />}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </aside>
      )}

      {/* Right Figma Design & Property Inspector Panel */}
      {isInspectorOpen && (
        <aside className="fixed top-0 bottom-0 right-0 w-80 bg-[#121216]/90 backdrop-blur-2xl border-l border-white/10 z-30 flex flex-col text-neutral-300 text-xs shadow-2xl select-none animate-in slide-in-from-right duration-200 pt-12 pb-20">
          {/* Header Tabs */}
          <div className="p-2.5 border-b border-white/10 flex items-center justify-between bg-white/5">
            <div className="flex space-x-1.5 items-center">
              <span className="px-2.5 py-1 rounded-lg font-bold bg-[#0c8ce9] text-white shadow-sm text-[11px]">
                Inspector
              </span>
            </div>
            <button
              onClick={onCloseInspector}
              className="p-1 hover:bg-white/10 rounded-lg text-neutral-400 hover:text-white transition-colors cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Inspector Content Accordion Body */}
          <div className="flex-1 overflow-y-auto p-3 space-y-2.5 no-scrollbar">
            
            {/* Accordion Item 1: 3D Camera & Viewport Mode */}
            <div className="border border-white/10 bg-white/5 rounded-2xl overflow-hidden transition-all">
              <button
                onClick={() => toggleAccordion('3d')}
                className="w-full p-3 flex items-center justify-between font-bold text-white text-xs text-left cursor-pointer hover:bg-white/5 transition-colors"
              >
                <div className="flex items-center space-x-2">
                  <Eye className="w-4 h-4 text-sky-400" />
                  <span>3D Viewport Alignment</span>
                </div>
                <div className="flex items-center space-x-2">
                  <span className="text-[10px] text-[#0c8ce9] font-mono uppercase bg-sky-950/80 px-1.5 py-0.5 rounded border border-sky-500/30">
                    {cameraMode.replace('_', ' ')}
                  </span>
                  {openAccordion === '3d' ? <ChevronDown className="w-4 h-4 text-neutral-400" /> : <ChevronRight className="w-4 h-4 text-neutral-400" />}
                </div>
              </button>

              {openAccordion === '3d' && (
                <div className="p-3 pt-0 border-t border-white/5 space-y-2">
                  <div className="grid grid-cols-3 gap-1.5 pt-2">
                    <button
                      onClick={onChangeCameraMode}
                      className={`p-2 rounded-xl border text-[11px] font-medium flex flex-col items-center justify-center space-y-1 transition-all cursor-pointer ${
                        cameraMode === 'third_person'
                          ? 'bg-[#0c8ce9]/20 border-[#0c8ce9] text-sky-300 font-bold'
                          : 'bg-white/5 border-white/5 text-neutral-400 hover:bg-white/10'
                      }`}
                    >
                      <Eye className="w-3.5 h-3.5 text-sky-400" />
                      <span>3rd Person</span>
                    </button>
                    <button
                      onClick={onChangeCameraMode}
                      className={`p-2 rounded-xl border text-[11px] font-medium flex flex-col items-center justify-center space-y-1 transition-all cursor-pointer ${
                        cameraMode === 'first_person'
                          ? 'bg-[#0c8ce9]/20 border-[#0c8ce9] text-sky-300 font-bold'
                          : 'bg-white/5 border-white/5 text-neutral-400 hover:bg-white/10'
                      }`}
                    >
                      <Eye className="w-3.5 h-3.5 text-sky-400" />
                      <span>1st Person</span>
                    </button>
                    <button
                      onClick={onChangeCameraMode}
                      className={`p-2 rounded-xl border text-[11px] font-medium flex flex-col items-center justify-center space-y-1 transition-all cursor-pointer ${
                        cameraMode === 'isometric'
                          ? 'bg-[#0c8ce9]/20 border-[#0c8ce9] text-sky-300 font-bold'
                          : 'bg-white/5 border-white/5 text-neutral-400 hover:bg-white/10'
                      }`}
                    >
                      <Eye className="w-3.5 h-3.5 text-sky-400" />
                      <span>Isometric</span>
                    </button>
                  </div>
                </div>
              )}
            </div>

            {/* Accordion Item 2: Native Multi-Agent Orchestrator ON/OFF Switch */}
            <div className="border border-sky-500/30 bg-gradient-to-br from-[#161c27]/90 to-[#12141c]/90 rounded-2xl overflow-hidden transition-all">
              <button
                onClick={() => toggleAccordion('agent')}
                className="w-full p-3 flex items-center justify-between font-bold text-white text-xs text-left cursor-pointer hover:bg-white/5 transition-colors"
              >
                <div className="flex items-center space-x-2">
                  <Cloud className="w-4 h-4 text-sky-400" />
                  <span>Chloe Multi-Agent Orchestrator</span>
                </div>
                <div className="flex items-center space-x-2">
                  <span
                    className={`px-2 py-0.5 rounded text-[10px] font-bold border flex items-center space-x-1.5 ${
                      isOrchestratorOn
                        ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                        : 'bg-neutral-800 text-neutral-400 border-neutral-700'
                    }`}
                  >
                    <span
                      className={`w-1.5 h-1.5 rounded-full ${
                        isOrchestratorOn ? 'bg-emerald-400 animate-pulse' : 'bg-neutral-500'
                      }`}
                    />
                    <span>{isOrchestratorOn ? 'ON' : 'OFF'}</span>
                  </span>
                  {openAccordion === 'agent' ? <ChevronDown className="w-4 h-4 text-neutral-400" /> : <ChevronRight className="w-4 h-4 text-neutral-400" />}
                </div>
              </button>

              {openAccordion === 'agent' && (
                <div className="p-3 pt-0 border-t border-sky-500/20 space-y-3">
                  <p className="text-[11px] text-slate-300 leading-snug pt-2">
                    Natively orchestrates 5 specialized sub-agents: <span className="text-sky-300 font-semibold">TaskGov</span>, <span className="text-amber-300 font-semibold">CultureMatch</span>, <span className="text-emerald-300 font-semibold">TechFix</span>, <span className="text-purple-300 font-semibold">WisdomWell</span>, and <span className="text-rose-300 font-semibold">WorkspaceAutomator</span>.
                  </p>

                  {/* On/Off Switch Control */}
                  <div className="p-3 bg-[#0d0f17] border border-white/10 rounded-xl flex items-center justify-between">
                    <div className="flex flex-col">
                      <span className="text-xs font-bold text-white">Multi-Agent Engine</span>
                      <span className="text-[10px] text-neutral-400">
                        {isOrchestratorOn ? 'Sub-agents active & evaluating' : 'Orchestrator is disabled'}
                      </span>
                    </div>

                    <button
                      type="button"
                      onClick={toggleOrchestrator}
                      className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors cursor-pointer focus:outline-none ${
                        isOrchestratorOn ? 'bg-emerald-500' : 'bg-neutral-700'
                      }`}
                      title={isOrchestratorOn ? 'Turn Orchestrator OFF' : 'Turn Orchestrator ON'}
                    >
                      <span
                        className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                          isOrchestratorOn ? 'translate-x-6' : 'translate-x-1'
                        }`}
                      />
                    </button>
                  </div>

                  {/* Active Sub-Agents Overview */}
                  {isOrchestratorOn && (
                    <div className="grid grid-cols-2 gap-1.5 pt-1">
                      <div className="p-2 rounded-lg bg-sky-950/30 border border-sky-500/20 text-[10px]">
                        <span className="font-bold text-sky-300 block">TaskGov</span>
                        <span className="text-neutral-400">Task routing & sync</span>
                      </div>
                      <div className="p-2 rounded-lg bg-amber-950/30 border border-amber-500/20 text-[10px]">
                        <span className="font-bold text-amber-300 block">CultureMatch</span>
                        <span className="text-neutral-400">Team alignment</span>
                      </div>
                      <div className="p-2 rounded-lg bg-emerald-950/30 border border-emerald-500/20 text-[10px]">
                        <span className="font-bold text-emerald-300 block">TechFix</span>
                        <span className="text-neutral-400">Code diagnostics</span>
                      </div>
                      <div className="p-2 rounded-lg bg-purple-950/30 border border-purple-500/20 text-[10px]">
                        <span className="font-bold text-purple-300 block">WisdomWell</span>
                        <span className="text-neutral-400">Knowledge engine</span>
                      </div>
                    </div>
                  )}

                  {/* Automated Screen Stream */}
                  <div className="pt-2 border-t border-sky-500/20 space-y-1.5">
                    <div className="flex items-center justify-between text-[10px]">
                      <span className="text-slate-300 font-semibold flex items-center space-x-1">
                        <Monitor className="w-3 h-3 text-sky-400" />
                        <span>Automated Screen Stream</span>
                      </span>
                    </div>
                    <button
                      type="button"
                      onClick={async () => {
                        if (audioManager.isChloeSharing) {
                          audioManager.stopChloeScreenShare();
                        } else {
                          await audioManager.startChloeScreenShare({ preferTab: true });
                        }
                      }}
                      className={`w-full py-1.5 px-2.5 rounded-xl border text-[11px] font-semibold flex items-center justify-center space-x-1.5 transition-all cursor-pointer ${
                        audioManager.isChloeSharing
                          ? 'bg-rose-500/20 hover:bg-rose-500/30 border-rose-500/40 text-rose-300'
                          : 'bg-sky-500/20 hover:bg-sky-500/30 border-sky-500/40 text-sky-200'
                      }`}
                    >
                      <Tv className="w-3.5 h-3.5" />
                      <span>{audioManager.isChloeSharing ? 'Stop Chloe Screen Share' : 'Simulate Agent Screen Stream'}</span>
                    </button>
                  </div>
                </div>
              )}
            </div>

            {/* Accordion Item 3: Screen Presentation & Audio */}
            <div className="border border-white/10 bg-white/5 rounded-2xl overflow-hidden transition-all">
              <button
                onClick={() => toggleAccordion('presentation')}
                className="w-full p-3 flex items-center justify-between font-bold text-white text-xs text-left cursor-pointer hover:bg-white/5 transition-colors"
              >
                <div className="flex items-center space-x-2">
                  <Monitor className="w-4 h-4 text-emerald-400" />
                  <span>Screen Presentation</span>
                </div>
                <div className="flex items-center space-x-2">
                  {isScreenSharing && <span className="text-amber-400 text-[9px] font-bold">LIVE</span>}
                  {openAccordion === 'presentation' ? <ChevronDown className="w-4 h-4 text-neutral-400" /> : <ChevronRight className="w-4 h-4 text-neutral-400" />}
                </div>
              </button>

              {openAccordion === 'presentation' && (
                <div className="p-3 pt-0 border-t border-white/5 space-y-2.5 pt-2">
                  <div className="p-2.5 bg-white/5 border border-white/10 rounded-xl flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <Music className="w-4 h-4 text-emerald-400 shrink-0" />
                      <div>
                        <div className="font-semibold text-white text-[11px]">Share Tab Audio</div>
                        <div className="text-[10px] text-neutral-400">Stream audio with tab presentation</div>
                      </div>
                    </div>
                    <button
                      onClick={() => setTabAudioEnabled(!tabAudioEnabled)}
                      className={`w-9 h-5 rounded-full transition-colors relative cursor-pointer ${
                        tabAudioEnabled ? 'bg-[#0c8ce9]' : 'bg-neutral-700'
                      }`}
                    >
                      <div
                        className={`w-3.5 h-3.5 bg-white rounded-full absolute top-0.75 transition-transform ${
                          tabAudioEnabled ? 'left-4.5' : 'left-0.75'
                        }`}
                      />
                    </button>
                  </div>

                  {!isScreenSharing ? (
                    <div className="space-y-1.5">
                      <button
                        onClick={() => onStartScreenShareWithOptions({ includeAudio: tabAudioEnabled, preferTab: true })}
                        className="w-full py-2 px-3 rounded-xl bg-[#0c8ce9] hover:bg-[#007be5] text-white font-bold text-xs flex items-center justify-center space-x-2 transition-all shadow-md shadow-sky-900/30 cursor-pointer"
                      >
                        <Tv className="w-3.5 h-3.5" />
                        <span>Share Chrome / Browser Tab</span>
                      </button>
                      <button
                        onClick={() => onStartScreenShareWithOptions({ includeAudio: false, preferTab: false })}
                        className="w-full py-2 px-3 rounded-xl bg-white/5 hover:bg-white/10 text-neutral-200 font-medium text-xs flex items-center justify-center space-x-2 transition-all cursor-pointer border border-white/10"
                      >
                        <Monitor className="w-3.5 h-3.5 text-neutral-400" />
                        <span>Share Entire Display / Window</span>
                      </button>
                    </div>
                  ) : (
                    <button
                      onClick={onStopScreenShare}
                      className="w-full py-2 px-3 rounded-xl bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 font-bold border border-rose-500/30 text-xs flex items-center justify-center space-x-2 transition-all cursor-pointer"
                    >
                      <X className="w-3.5 h-3.5" />
                      <span>Stop Screen Sharing</span>
                    </button>
                  )}
                </div>
              )}
            </div>

            {/* Accordion Item 5: Floor & Seat Teleport Locations */}
            <div className="border border-white/10 bg-white/5 rounded-2xl overflow-hidden transition-all">
              <button
                onClick={() => toggleAccordion('teleport')}
                className="w-full p-3 flex items-center justify-between font-bold text-white text-xs text-left cursor-pointer hover:bg-white/5 transition-colors"
              >
                <div className="flex items-center space-x-2">
                  <Armchair className="w-4 h-4 text-amber-400" />
                  <span>Floor & Teleport Locations</span>
                </div>
                {openAccordion === 'teleport' ? <ChevronDown className="w-4 h-4 text-neutral-400" /> : <ChevronRight className="w-4 h-4 text-neutral-400" />}
              </button>

              {openAccordion === 'teleport' && (
                <div className="p-3 pt-0 border-t border-white/5 space-y-1.5 pt-2">
                  <button
                    onClick={onTeleportDesk}
                    className="w-full p-2 bg-white/5 hover:bg-white/10 border border-white/5 rounded-xl flex items-center justify-between text-neutral-200 transition-colors cursor-pointer"
                  >
                    <div className="flex items-center space-x-2">
                      <Armchair className="w-4 h-4 text-emerald-400" />
                      <span>Teleport to My Desk</span>
                    </div>
                    <span className="text-[10px] text-neutral-400">1F</span>
                  </button>

                  <button
                    onClick={onTeleportMeetingRoom}
                    className="w-full p-2 bg-white/5 hover:bg-white/10 border border-white/5 rounded-xl flex items-center justify-between text-neutral-200 transition-colors cursor-pointer"
                  >
                    <div className="flex items-center space-x-2">
                      <Users className="w-4 h-4 text-sky-400" />
                      <span>Executive Boardroom</span>
                    </div>
                    <span className="text-[10px] text-neutral-400">2F</span>
                  </button>

                  <button
                    onClick={onTeleportSushiBar}
                    className="w-full p-2 bg-white/5 hover:bg-white/10 border border-white/5 rounded-xl flex items-center justify-between text-neutral-200 transition-colors cursor-pointer"
                  >
                    <div className="flex items-center space-x-2">
                      <span>☕</span>
                      <span>Visitor Center Cafe</span>
                    </div>
                    <span className="text-[10px] text-neutral-400">3F</span>
                  </button>

                  {onTeleportBasementTheater && (
                    <button
                      onClick={onTeleportBasementTheater}
                      className="w-full p-2 bg-white/5 hover:bg-white/10 border border-white/5 rounded-xl flex items-center justify-between text-neutral-200 transition-colors cursor-pointer"
                    >
                      <div className="flex items-center space-x-2">
                        <span>⚡</span>
                        <span>B1 Corporate Office</span>
                      </div>
                      <span className="text-[10px] text-amber-400 font-bold">B1</span>
                    </button>
                  )}
                </div>
              )}
            </div>

            {/* Accordion Item 6: Spatial Voice & Hardware */}
            <div className="border border-white/10 bg-white/5 rounded-2xl overflow-hidden transition-all">
              <button
                onClick={() => toggleAccordion('hardware')}
                className="w-full p-3 flex items-center justify-between font-bold text-white text-xs text-left cursor-pointer hover:bg-white/5 transition-colors"
              >
                <div className="flex items-center space-x-2">
                  <Sliders className="w-4 h-4 text-purple-400" />
                  <span>Spatial Voice & Hardware</span>
                </div>
                {openAccordion === 'hardware' ? <ChevronDown className="w-4 h-4 text-neutral-400" /> : <ChevronRight className="w-4 h-4 text-neutral-400" />}
              </button>

              {openAccordion === 'hardware' && (
                <div className="p-3 pt-0 border-t border-white/5 space-y-2 pt-2">
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      onClick={onToggleMic}
                      className={`p-2 rounded-xl border flex items-center space-x-2 transition-all cursor-pointer ${
                        isMuted
                          ? 'bg-rose-500/10 border-rose-500/30 text-rose-400'
                          : 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400'
                      }`}
                    >
                      {isMuted ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
                      <span className="font-semibold text-xs">{isMuted ? 'Muted' : 'Mic On'}</span>
                    </button>

                    <button
                      onClick={onToggleCamera}
                      className={`p-2 rounded-xl border flex items-center space-x-2 transition-all cursor-pointer ${
                        isCameraOn
                          ? 'bg-sky-500/10 border-sky-500/30 text-sky-400'
                          : 'bg-white/5 border-white/5 text-neutral-400'
                      }`}
                    >
                      {isCameraOn ? <Video className="w-4 h-4" /> : <VideoOff className="w-4 h-4" />}
                      <span className="font-semibold text-xs">{isCameraOn ? 'Cam On' : 'Cam Off'}</span>
                    </button>
                  </div>
                </div>
              )}
            </div>

          </div>
        </aside>
      )}
    </>
  );
};
