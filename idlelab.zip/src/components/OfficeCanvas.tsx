import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { DeskData, Position3D, UserState, WhiteboardStroke, GestureType, ScooterConfig } from '../types';
import { buildVoxelOffice, OfficeMeshes } from '../game/officeBuilder';
import { createVoxelAvatarMesh, AvatarMeshGroup } from '../game/avatarBuilder';
import {
  getFloorColliders,
  resolveAvatarCollisions,
  adjustClickDestinationForPersonalSpace,
  isSeatOccupied,
  AVATAR_COLLISION_RADIUS,
  RESPECTFUL_PERSONAL_SPACE,
} from '../game/collisionSystem';
import { stepAutoRide, getFloorCircuitKey } from '../game/autoRideNavigator';
import { audioManager } from '../lib/audioManager';
import { notificationManager } from '../lib/notificationManager';
import { soundEffects } from '../lib/soundEffects';
import { chloeVoice } from '../lib/chloeVoice';
import { ProximityCameraOverlay } from './ProximityCameraOverlay';
import { MinimalChatInputBar } from './MinimalChatInputBar';
import { GESTURE_CONFIGS } from '../lib/gestureDetector';
import { drawArtistPortraits } from '../game/artistPortraits';

function ensureVideoInDOM(vid: HTMLVideoElement) {
  if (typeof document === 'undefined') return;
  let container = document.getElementById('webrtc-video-container');
  if (!container) {
    container = document.createElement('div');
    container.id = 'webrtc-video-container';
    container.style.cssText =
      'position:fixed;bottom:0;right:0;width:1px;height:1px;opacity:0.01;pointer-events:none;z-index:-1000;overflow:hidden;';
    document.body.appendChild(container);
  }
  if (vid && !vid.parentNode) {
    container.appendChild(vid);
  }
}

interface OfficeCanvasProps {
  currentUser: UserState | null;
  remoteUsers: Map<string, UserState>;
  desks: DeskData[];
  whiteboardStrokes: WhiteboardStroke[];
  cameraMode: 'third_person' | 'first_person' | 'isometric';
  screenShareStream: MediaStream | null;
  isMuted?: boolean;
  isCameraOn?: boolean;
  onToggleMic?: () => void;
  onToggleCamera?: () => void;
  onSendChat?: (text: string, isProximity: boolean) => void;
  onMove: (pos: Position3D, rotY: number, isMoving: boolean) => void;
  onSelectDesk: (desk: DeskData) => void;
  onOpenWhiteboard: () => void;
  onOpenPingPong?: () => void;
  onOpenElevatorModal?: () => void;
  elevatorTargetFloor?: { targetY: number; reqId: number } | null;
  onElevatorArrived?: (finalY: number) => void;
  onElevatorMovingChange?: (isMoving: boolean) => void;
  onOpenCoffeeRobot?: () => void;
  onOpenLibrary?: () => void;
  onOpenDataCenter?: () => void;
  onOpenPresentationModal?: () => void;
  onOpenPomodoro?: () => void;
  onOpenAtmModal?: () => void;
  onPerformGesture?: (gesture: GestureType) => void;
  onSendEmojiReaction?: (emoji: string, gesture?: GestureType) => void;
  onStartScreenShare?: () => void;
  onOpenChloeModal?: () => void;
  onOpenEmoteWheel?: () => void;
  onToggleScooter?: (isRiding: boolean) => void;
  onUpdateScooterConfig?: (config: ScooterConfig) => void;
  lastGestureEvent?: { userId: string; gesture: GestureType; id: number } | null;
  lastEmojiEvent?: { userId: string; emoji: string; gesture?: GestureType; id: number } | null;
}

export const OfficeCanvas: React.FC<OfficeCanvasProps> = ({
  currentUser,
  remoteUsers,
  desks,
  whiteboardStrokes,
  cameraMode,
  screenShareStream,
  isMuted = false,
  isCameraOn = false,
  onToggleMic,
  onToggleCamera,
  onSendChat,
  onMove,
  onSelectDesk,
  onOpenWhiteboard,
  onOpenPingPong,
  onOpenElevatorModal,
  elevatorTargetFloor,
  onElevatorArrived,
  onElevatorMovingChange,
  onOpenCoffeeRobot,
  onOpenLibrary,
  onOpenDataCenter,
  onOpenPresentationModal,
  onOpenPomodoro,
  onOpenAtmModal,
  onPerformGesture,
  onSendEmojiReaction,
  onStartScreenShare,
  onOpenChloeModal,
  onOpenEmoteWheel,
  onToggleScooter,
  onUpdateScooterConfig,
  lastGestureEvent,
  lastEmojiEvent,
}) => {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const officeMeshesRef = useRef<OfficeMeshes | null>(null);
  const avatarMeshesRef = useRef<Map<string, AvatarMeshGroup>>(new Map());
  const myAvatarGroupRef = useRef<AvatarMeshGroup | null>(null);

  const onOpenChloeModalRef = useRef(onOpenChloeModal);
  onOpenChloeModalRef.current = onOpenChloeModal;

  const onOpenAtmModalRef = useRef(onOpenAtmModal);
  onOpenAtmModalRef.current = onOpenAtmModal;

  const onOpenEmoteWheelRef = useRef(onOpenEmoteWheel);
  onOpenEmoteWheelRef.current = onOpenEmoteWheel;

  const lastLocalAvatarClickTimeRef = useRef<number>(0);

  const onElevatorArrivedRef = useRef(onElevatorArrived);
  onElevatorArrivedRef.current = onElevatorArrived;

  const onElevatorMovingChangeRef = useRef(onElevatorMovingChange);
  onElevatorMovingChangeRef.current = onElevatorMovingChange;

  const [proximityPartner, setProximityPartner] = useState<{ user: UserState; distance: number } | null>(null);
  const [isNearElevator, setIsNearElevator] = useState(false);
  const [isElevatorMoving, setIsElevatorMoving] = useState(false);
  const isElevatorMovingRef = useRef(false);
  const elevatorRideRef = useRef<{
    startY: number;
    targetY: number;
    startTime: number;
    duration: number;
  } | null>(null);

  const [isNearChloe, setIsNearChloe] = useState(false);
  const [chloeDist, setChloeDist] = useState(0);
  const isNearChloeRef = useRef(false);
  const [isNearAtm, setIsNearAtm] = useState(false);
  const isNearAtmRef = useRef(false);
  const [isOnTennisCourt, setIsOnTennisCourt] = useState(false);
  const [tennisMatch, setTennisMatch] = useState<{
    playerScore: number;
    botScore: number;
    playerGames: number;
    botGames: number;
    playerSets: number;
    botSets: number;
    rallyCount: number;
    lastCallText: string;
    gameMode?: 'training' | 'competition';
    ballSpeedKmh?: number;
    tacticalTactic?: string;
    lastHitType?: 'smash' | 'forehand' | 'backhand' | 'serve' | 'slice' | 'fireball';
    isFireballActive?: boolean;
  } | null>(null);
  const isChloeSpeakingRef = useRef(false);
  const isPlayerSwingingRef = useRef(false);
  const playerSwingTypeRef = useRef<'forehand' | 'backhand' | 'smash' | 'serve'>('forehand');
  const tennisAutoPosRef = useRef<{
    x: number;
    z: number;
    swingAction?: 'forehand' | 'backhand' | 'smash' | null;
    isFireball?: boolean;
  } | null>(null);
  const isNearElevatorRef = useRef(false);
  const lastProximityPartnerRef = useRef<{ user: UserState; distance: number } | null>(null);

  // Synchronized prop refs to eliminate stale closure bugs inside render loop
  const currentUserRef = useRef<UserState | null>(currentUser);
  currentUserRef.current = currentUser;

  const remoteUsersRef = useRef<Map<string, UserState>>(remoteUsers);
  remoteUsersRef.current = remoteUsers;

  const desksRef = useRef<DeskData[]>(desks);
  desksRef.current = desks;

  const cameraModeRef = useRef<'third_person' | 'first_person' | 'isometric'>(cameraMode);
  cameraModeRef.current = cameraMode;

  const whiteboardStrokesRef = useRef<WhiteboardStroke[]>(whiteboardStrokes);
  whiteboardStrokesRef.current = whiteboardStrokes;

  const screenShareStreamRef = useRef<MediaStream | null>(screenShareStream);
  screenShareStreamRef.current = screenShareStream;

  const onMoveRef = useRef(onMove);
  onMoveRef.current = onMove;

  const onSelectDeskRef = useRef(onSelectDesk);
  onSelectDeskRef.current = onSelectDesk;

  const onOpenWhiteboardRef = useRef(onOpenWhiteboard);
  onOpenWhiteboardRef.current = onOpenWhiteboard;

  const onOpenPingPongRef = useRef(onOpenPingPong);
  onOpenPingPongRef.current = onOpenPingPong;

  const onOpenElevatorModalRef = useRef(onOpenElevatorModal);
  onOpenElevatorModalRef.current = onOpenElevatorModal;

  const onOpenCoffeeRobotRef = useRef(onOpenCoffeeRobot);
  onOpenCoffeeRobotRef.current = onOpenCoffeeRobot;

  const onOpenLibraryRef = useRef(onOpenLibrary);
  onOpenLibraryRef.current = onOpenLibrary;

  const onOpenDataCenterRef = useRef(onOpenDataCenter);
  onOpenDataCenterRef.current = onOpenDataCenter;

  const onOpenPresentationModalRef = useRef(onOpenPresentationModal);
  onOpenPresentationModalRef.current = onOpenPresentationModal;

  const onOpenPomodoroRef = useRef(onOpenPomodoro);
  onOpenPomodoroRef.current = onOpenPomodoro;

  const onPerformGestureRef = useRef(onPerformGesture);
  onPerformGestureRef.current = onPerformGesture;

  const onSendEmojiReactionRef = useRef(onSendEmojiReaction);
  onSendEmojiReactionRef.current = onSendEmojiReaction;

  const onStartScreenShareRef = useRef(onStartScreenShare);
  onStartScreenShareRef.current = onStartScreenShare;

  const onToggleScooterRef = useRef(onToggleScooter);
  onToggleScooterRef.current = onToggleScooter;

  const onUpdateScooterConfigRef = useRef(onUpdateScooterConfig);
  onUpdateScooterConfigRef.current = onUpdateScooterConfig;

  // E-Scooter & Autonomous Waypoint Cruising States
  const [isRidingScooter, setIsRidingScooter] = useState<boolean>(currentUser?.isRidingScooter ?? false);
  const [isAutoRiding, setIsAutoRiding] = useState<boolean>(false);
  const [autoRideLabel, setAutoRideLabel] = useState<string>('');
  const isRidingScooterRef = useRef<boolean>(currentUser?.isRidingScooter ?? false);
  const isAutoRidingRef = useRef<boolean>(false);
  const autoRideWaypointIdxRef = useRef<number>(0);
  const scooterTurnAngleRef = useRef<number>(0);

  // Sync external scooter state if changed remotely or in customizer
  useEffect(() => {
    if (currentUser?.isRidingScooter !== undefined) {
      isRidingScooterRef.current = currentUser.isRidingScooter;
      setIsRidingScooter(currentUser.isRidingScooter);
      if (!currentUser.isRidingScooter) {
        isAutoRidingRef.current = false;
        setIsAutoRiding(false);
      }
    }
  }, [currentUser?.isRidingScooter]);

  // Start smooth elevator ride and attach avatar to cabin
  const startElevatorRide = (targetY: number) => {
    const currentY = myPosRef.current.y || 0;
    if (Math.abs(currentY - targetY) < 0.2) {
      // Already on this floor: align precisely inside cab bounds
      myPosRef.current.x = 8.5;
      myPosRef.current.z = -8.0;
      myRotYRef.current = 0;
      if (myAvatarGroupRef.current) {
        myAvatarGroupRef.current.group.position.set(8.5, currentY, -8.0);
        myAvatarGroupRef.current.group.rotation.y = 0;
      }
      onMoveRef.current(myPosRef.current, 0, false);
      return;
    }

    // Auto-center and align avatar inside elevator cab bounds before vertical motion
    myPosRef.current.x = 8.5;
    myPosRef.current.z = -8.0;
    myRotYRef.current = 0;
    clickTargetPosRef.current = null;
    clickTargetDeskRef.current = null;
    isSeatedRef.current = false;
    if (clickMarkerRef.current) clickMarkerRef.current.visible = false;

    if (myAvatarGroupRef.current) {
      myAvatarGroupRef.current.group.position.set(8.5, currentY, -8.0);
      myAvatarGroupRef.current.group.rotation.y = 0;
    }

    const travelDist = Math.abs(targetY - currentY);
    const duration = Math.max(1.2, Math.min(2.6, 0.8 + travelDist * 0.1));

    setIsElevatorMoving(true);
    isElevatorMovingRef.current = true;
    if (onElevatorMovingChangeRef.current) {
      onElevatorMovingChangeRef.current(true);
    }

    elevatorRideRef.current = {
      startY: currentY,
      targetY,
      startTime: performance.now(),
      duration,
    };
  };

  useEffect(() => {
    if (elevatorTargetFloor) {
      startElevatorRide(elevatorTargetFloor.targetY);
    }
  }, [elevatorTargetFloor?.reqId]);

  // React to incoming WebSocket gesture events
  useEffect(() => {
    if (!lastGestureEvent) return;
    const { userId, gesture } = lastGestureEvent;

    let targetAvatar: AvatarMeshGroup | undefined;
    if (currentUserRef.current && userId === currentUserRef.current.id) {
      targetAvatar = myAvatarGroupRef.current || undefined;
    } else {
      targetAvatar = avatarMeshesRef.current.get(userId) || myAvatarGroupRef.current || undefined;
    }

    if (targetAvatar) {
      targetAvatar.triggerGesture(gesture);
    }
  }, [lastGestureEvent]);

  // React to incoming WebSocket emoji reaction events
  useEffect(() => {
    if (!lastEmojiEvent) return;
    const { userId, emoji, gesture } = lastEmojiEvent;

    let targetAvatar: AvatarMeshGroup | undefined;
    if (currentUserRef.current && userId === currentUserRef.current.id) {
      targetAvatar = myAvatarGroupRef.current || undefined;
    } else {
      targetAvatar = avatarMeshesRef.current.get(userId) || myAvatarGroupRef.current || undefined;
    }

    if (targetAvatar) {
      targetAvatar.triggerEmojiParticle(emoji);
      if (gesture) {
        targetAvatar.triggerGesture(gesture);
      }
    }
  }, [lastEmojiEvent]);

  // Hidden smart autoreact when speaking over microphone
  useEffect(() => {
    audioManager.onSmartAutoreact = () => {
      if (myAvatarGroupRef.current) {
        const smartEmojis = ['💬', '✨', '💡', '🔥', '🚀'];
        const randomEmoji = smartEmojis[Math.floor(Math.random() * smartEmojis.length)];
        myAvatarGroupRef.current.triggerEmojiParticle(randomEmoji);
      }
    };
    return () => {
      audioManager.onSmartAutoreact = undefined;
    };
  }, []);

  // Local avatar position & rotation refs
  const myPosRef = useRef<Position3D>({ x: 0, y: 0, z: 2 });
  const myRotYRef = useRef<number>(0);
  const orbitAngleRef = useRef<number>(0); // 360-degree camera orbit angle
  const pitchAngleRef = useRef<number>(0.55); // Camera elevation pitch angle
  const camDistanceRef = useRef<number>(6.2); // Smooth scroll & pinch camera distance (2.2m to 18m)
  const camPanRef = useRef<{ x: number; y: number; z: number }>({ x: 0, y: 0, z: 0 }); // Camera pan offset
  const isPointerDraggingRef = useRef<boolean>(false);
  const isPanDraggingRef = useRef<boolean>(false);
  const lastPointerXRef = useRef<number>(0);
  const lastPointerYRef = useRef<number>(0);
  const touchPinchDistRef = useRef<number | null>(null);
  const touchPrevCenterRef = useRef<{ x: number; y: number } | null>(null);
  const keysPressedRef = useRef<{ [key: string]: boolean }>({});

  // Mouse Click Navigation & Seating Refs
  const clickTargetPosRef = useRef<Position3D | null>(null);
  const clickTargetDeskRef = useRef<DeskData | null>(null);
  const playerVelYRef = useRef(0);
  const isSeatedRef = useRef<boolean>(false);
  const seatedSeatPosRef = useRef<Position3D | undefined>(undefined);
  const currentRoomTypeRef = useRef<string | null>(null);
  const clickMarkerRef = useRef<THREE.Mesh | null>(null);
  const pointerDownPosRef = useRef<{ x: number; y: number }>({ x: 0, y: 0 });
  const mouseScreenPosRef = useRef<{ x: number; y: number } | null>(null);

  // WebCam Video Texture Refs for 3D Spatial Avatar Displays
  const localVideoTextureRef = useRef<THREE.VideoTexture | null>(null);
  const remoteVideoElementsRef = useRef<
    Map<string, { videoEl: HTMLVideoElement; texture: THREE.VideoTexture; streamId: string }>
  >(new Map());
  const remoteFrameTexturesRef = useRef<
    Map<
      string,
      { img: HTMLImageElement; canvas: HTMLCanvasElement; ctx: CanvasRenderingContext2D; texture: THREE.CanvasTexture; lastSrc: string }
    >
  >(new Map());

  // Room Presentation Screen Share Texture Refs
  const roomScreenVideoRef = useRef<{ videoEl: HTMLVideoElement; texture: THREE.VideoTexture; streamId: string } | null>(null);
  const roomScreenFrameRef = useRef<{ img: HTMLImageElement; canvas: HTMLCanvasElement; ctx: CanvasRenderingContext2D; texture: THREE.CanvasTexture; lastSrc: string } | null>(null);

  // Sync position whenever currentUser or teleport position changes
  useEffect(() => {
    if (currentUser) {
      myPosRef.current = { ...currentUser.position };
      myRotYRef.current = currentUser.rotationY;
    }
  }, [currentUser?.position.x, currentUser?.position.z, currentUser?.id]);

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    // 1. THREE.JS SCENE SETUP
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x0f172a);
    scene.fog = new THREE.FogExp2(0x0f172a, 0.015);

    const camera = new THREE.PerspectiveCamera(60, container.clientWidth / container.clientHeight, 0.1, 100);
    const renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' });
    renderer.setSize(container.clientWidth, container.clientHeight);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    container.appendChild(renderer.domElement);

    // 2. BUILD VOXEL OFFICE MAP
    const officeMeshes = buildVoxelOffice(desksRef.current);
    scene.add(officeMeshes.sceneGroup);
    officeMeshesRef.current = officeMeshes;

    // Attach Video Stream handler to portray user's camera on avatar screen
    audioManager.onVideoStreamUpdated = (stream, videoElement) => {
      if (myAvatarGroupRef.current) {
        if (stream && videoElement) {
          const vidTex = new THREE.VideoTexture(videoElement);
          vidTex.minFilter = THREE.LinearFilter;
          vidTex.magFilter = THREE.LinearFilter;
          myAvatarGroupRef.current.setVideoTexture(vidTex);
        } else {
          myAvatarGroupRef.current.setVideoTexture(null);
        }
      }
    };

    // 3. KEYBOARD EVENT LISTENERS (Ignore if typing in chat/modal inputs)
    const handleKeyDown = (e: KeyboardEvent) => {
      if (
        document.activeElement?.tagName === 'INPUT' ||
        document.activeElement?.tagName === 'TEXTAREA'
      ) {
        return;
      }
      keysPressedRef.current[e.code] = true;

      // Tennis Swing & Jump Shortcuts
      if (e.code === 'KeyZ' || e.code === 'KeyX' || e.code === 'KeyF' || e.code === 'Space' || e.code === 'KeyR') {
        const curY = myPosRef.current.y || 0;
        const isNearTennis = curY <= -4.0 && myPosRef.current.x >= 15.0 && myPosRef.current.x <= 44.0 && Math.abs(myPosRef.current.z) <= 8.5;
        if (isNearTennis) {
          if (e.code === 'Space') {
            e.preventDefault();
            if ((myPosRef.current.y || 0) <= -5.99) {
              if (playerVelYRef.current === 0) {
                playerVelYRef.current = 6.8;
              }
            }
            if (officeMeshesRef.current?.triggerTennisFireballSmash) {
              officeMeshesRef.current.triggerTennisFireballSmash();
            }
            isPlayerSwingingRef.current = true;
            playerSwingTypeRef.current = 'smash';
            myAvatarGroupRef.current?.triggerTennisSwing('smash');
            myAvatarGroupRef.current?.triggerEmojiParticle('🔥');
          } else if (e.code === 'KeyZ') {
            isPlayerSwingingRef.current = true;
            playerSwingTypeRef.current = 'smash';
            myAvatarGroupRef.current?.triggerTennisSwing('smash');
          } else if (e.code === 'KeyR') {
            if (officeMeshesRef.current?.resetTennisServe) {
              officeMeshesRef.current.resetTennisServe();
            } else if (officeMeshesRef.current?.resetServe) {
              officeMeshesRef.current.resetServe();
            }
          } else {
            isPlayerSwingingRef.current = true;
            playerSwingTypeRef.current = 'forehand';
            myAvatarGroupRef.current?.triggerTennisSwing('forehand');
          }
        }
      }

      // E-Scooter Toggle: KeyE (when not near Chloe, ATM or Elevator)
      if (e.code === 'KeyE') {
        if (isNearAtmRef.current && onOpenAtmModalRef.current) {
          onOpenAtmModalRef.current();
          return;
        }
        if (isNearChloeRef.current && onOpenChloeModalRef.current) {
          onOpenChloeModalRef.current();
          return;
        }
        if (isNearElevatorRef.current && onOpenElevatorModalRef.current) {
          onOpenElevatorModalRef.current();
          return;
        }

        // Toggle E-Scooter Mount / Dismount
        const nextRiding = !isRidingScooterRef.current;
        isRidingScooterRef.current = nextRiding;
        setIsRidingScooter(nextRiding);
        if (nextRiding) {
          soundEffects.playScooterMount();
        } else {
          isAutoRidingRef.current = false;
          setIsAutoRiding(false);
          soundEffects.playScooterDismount();
        }
        if (onToggleScooterRef.current) {
          onToggleScooterRef.current(nextRiding);
        }
        return;
      }

      // Autonomous Office Tour: KeyR (Cruise Control)
      if (e.code === 'KeyR') {
        if (!isRidingScooterRef.current) {
          // Mount scooter automatically when pressing R
          isRidingScooterRef.current = true;
          setIsRidingScooter(true);
          soundEffects.playScooterMount();
          if (onToggleScooterRef.current) {
            onToggleScooterRef.current(true);
          }
        }
        const nextAuto = !isAutoRidingRef.current;
        isAutoRidingRef.current = nextAuto;
        setIsAutoRiding(nextAuto);
        soundEffects.playScooterCruise(nextAuto);
        if (nextAuto) {
          autoRideWaypointIdxRef.current = 0;
        }
        return;
      }

      // Scooter Bell Horn: KeyH or KeyB (when riding scooter)
      if ((e.code === 'KeyH' || e.code === 'KeyB') && isRidingScooterRef.current) {
        soundEffects.playScooterBell();
        myAvatarGroupRef.current?.triggerEmojiParticle('🛴');
        return;
      }

      // Scooter Color Presets by Number keys (1-6) when riding
      if (isRidingScooterRef.current) {
        let selectedColor = '';
        if (e.code === 'Digit1') selectedColor = '#ef4444'; // Red
        else if (e.code === 'Digit2') selectedColor = '#f97316'; // Orange
        else if (e.code === 'Digit3') selectedColor = '#a855f7'; // Purple
        else if (e.code === 'Digit4') selectedColor = '#06b6d4'; // Lightblue
        else if (e.code === 'Digit5') selectedColor = '#84cc16'; // Light Green
        else if (e.code === 'Digit6') selectedColor = '#18181b'; // Black

        if (selectedColor) {
          e.preventDefault();
          const newConfig = { ...(currentUserRef.current?.scooterConfig || {}), frameColor: selectedColor };
          if (onUpdateScooterConfigRef.current) {
            onUpdateScooterConfigRef.current(newConfig);
          }
          if (myAvatarGroupRef.current && 'updateScooterConfig' in myAvatarGroupRef.current) {
            (myAvatarGroupRef.current as any).updateScooterConfig(newConfig);
          }
          soundEffects.playPop();
          return;
        }
      }
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      keysPressedRef.current[e.code] = false;
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);

    // 4. MOUSE RAYCASTING & CLICK NAVIGATION ENGINE
    const raycaster = new THREE.Raycaster();
    const mouse = new THREE.Vector2();
    const floorPlane = new THREE.Plane(new THREE.Vector3(0, 1, 0), 0);

    // Glowing 3D ground target destination marker
    const markerRingGeo = new THREE.RingGeometry(0.22, 0.38, 24);
    markerRingGeo.rotateX(-Math.PI / 2);
    const markerRingMat = new THREE.MeshBasicMaterial({ color: 0x38bdf8, transparent: true, opacity: 0.85, side: THREE.DoubleSide });
    const clickMarkerMesh = new THREE.Mesh(markerRingGeo, markerRingMat);
    clickMarkerMesh.visible = false;
    scene.add(clickMarkerMesh);
    clickMarkerRef.current = clickMarkerMesh;

    const getPointerCoords = (e: MouseEvent | TouchEvent) => {
      if ('touches' in e && e.touches.length > 0) {
        return { x: e.touches[0].clientX, y: e.touches[0].clientY };
      }
      if ('changedTouches' in e && e.changedTouches.length > 0) {
        return { x: e.changedTouches[0].clientX, y: e.changedTouches[0].clientY };
      }
      const me = e as MouseEvent;
      return { x: me.clientX ?? 0, y: me.clientY ?? 0 };
    };

    const handlePointerDown = (e: MouseEvent) => {
      if (
        document.activeElement?.tagName === 'INPUT' ||
        document.activeElement?.tagName === 'TEXTAREA'
      ) {
        return;
      }

      const coords = { x: e.clientX, y: e.clientY };
      pointerDownPosRef.current = { x: coords.x, y: coords.y };
      lastPointerXRef.current = coords.x;
      lastPointerYRef.current = coords.y;

      if (e.button === 2) {
        // Right click: Serve & Hit on Tennis Court!
        const curY = myPosRef.current.y || 0;
        const isNearTennis = curY <= -4.0 && myPosRef.current.x >= 15.0 && myPosRef.current.x <= 44.0 && Math.abs(myPosRef.current.z) <= 8.5;
        if (isNearTennis) {
          isPlayerSwingingRef.current = true;
          playerSwingTypeRef.current = 'forehand';
          myAvatarGroupRef.current?.triggerTennisSwing('forehand');
          soundEffects.playPop();
          return;
        }
        // Pan camera outside tennis court
        isPanDraggingRef.current = true;
        isPointerDraggingRef.current = false;
      } else if (e.button === 1) {
        // Middle click: pan camera
        isPanDraggingRef.current = true;
        isPointerDraggingRef.current = false;
      } else {
        // Left click: orbit / pitch or tap to navigate
        isPointerDraggingRef.current = true;
        isPanDraggingRef.current = false;
      }
    };

    const handlePointerMove = (e: MouseEvent) => {
      mouseScreenPosRef.current = { x: e.clientX, y: e.clientY };
      if (isPointerDraggingRef.current) {
        const deltaX = e.clientX - lastPointerXRef.current;
        const deltaY = e.clientY - lastPointerYRef.current;

        orbitAngleRef.current += deltaX * 0.008;
        pitchAngleRef.current = Math.max(0.12, Math.min(1.3, pitchAngleRef.current - deltaY * 0.005));

        lastPointerXRef.current = e.clientX;
        lastPointerYRef.current = e.clientY;
      } else if (isPanDraggingRef.current) {
        const deltaX = e.clientX - lastPointerXRef.current;
        const deltaY = e.clientY - lastPointerYRef.current;

        const orbit = orbitAngleRef.current;
        const panSpeed = 0.015;
        camPanRef.current.x -= (deltaX * Math.cos(orbit) - deltaY * Math.sin(orbit)) * panSpeed;
        camPanRef.current.z -= (deltaX * Math.sin(orbit) + deltaY * Math.cos(orbit)) * panSpeed;

        lastPointerXRef.current = e.clientX;
        lastPointerYRef.current = e.clientY;
      }
    };

    const performClickRaycast = (clientX: number, clientY: number) => {
      const rect = renderer.domElement.getBoundingClientRect();
      mouse.x = ((clientX - rect.left) / rect.width) * 2 - 1;
      mouse.y = -((clientY - rect.top) / rect.height) * 2 + 1;
      raycaster.setFromCamera(mouse, camera);

      const currentY = myPosRef.current.y || 0;
      const colliders = getFloorColliders(
        currentY,
        remoteUsersRef.current,
        currentUserRef.current?.id,
        desksRef.current
      );

      // 1. Raycast against all interactive objects and avatars in the scene
      const interactiveHits = raycaster.intersectObjects(officeMeshes.interactiveObjects, true);

      if (interactiveHits.length > 0) {
        const hit = interactiveHits[0].object;

        // Check if hit object belongs to an Avatar or NPC
        let curObj: THREE.Object3D | null = hit;
        let avatarData: any = null;
        let avatarGroupPos: THREE.Vector3 | null = null;
        while (curObj) {
          if (curObj.userData && (curObj.userData.isAvatar || curObj.userData.userId || curObj.userData.isChloe)) {
            avatarData = curObj.userData;
            avatarGroupPos = curObj.position;
            break;
          }
          curObj = curObj.parent;
        }

        if (avatarData) {
          const isLocalPlayer =
            avatarData.isLocalPlayer ||
            (currentUserRef.current && avatarData.userId === currentUserRef.current.id);

          if (isLocalPlayer) {
            const now = Date.now();
            if (now - lastLocalAvatarClickTimeRef.current < 450) {
              // DOUBLE-TAP / DOUBLE-CLICK DETECTED ON LOCAL PLAYER 3D AVATAR MESH!
              lastLocalAvatarClickTimeRef.current = 0;
              soundEffects.playPop();
              if (onOpenEmoteWheelRef.current) {
                onOpenEmoteWheelRef.current();
              }
              return;
            }
            lastLocalAvatarClickTimeRef.current = now;
            return;
          }

          if (avatarData.isChloe || avatarData.userId === 'npc_b1_chloe') {
            // Sit user directly in front of Chloe's desk (B1: X = 2.1, Y = -6.0, Z = -1.95) facing Chloe
            myPosRef.current = { x: 2.1, y: -6.0, z: -1.95 };
            myRotYRef.current = Math.PI;
            isSeatedRef.current = true;
            seatedSeatPosRef.current = { x: 2.1, y: -5.9, z: -1.95 };
            clickTargetPosRef.current = null;
            if (clickMarkerRef.current) clickMarkerRef.current.visible = false;
            return;
          }

          // Clicked on a Colleague or NPC Avatar!
          const targetPos = avatarGroupPos
            ? { x: avatarGroupPos.x, y: currentY, z: avatarGroupPos.z }
            : { x: hit.position.x, y: currentY, z: hit.position.z };
          const approach = adjustClickDestinationForPersonalSpace(
            myPosRef.current,
            targetPos,
            colliders,
            RESPECTFUL_PERSONAL_SPACE
          );
          clickTargetDeskRef.current = null;
          clickTargetPosRef.current = approach.safeTarget;
          if (clickMarkerRef.current) {
            clickMarkerRef.current.position.set(approach.safeTarget.x, currentY + 0.03, approach.safeTarget.z);
            clickMarkerRef.current.visible = true;
          }
          isSeatedRef.current = false;
          return;
        }

        if (hit.userData) {
          if (hit.userData.isTeslaTennisBot) {
            const curX = myPosRef.current.x || 0;
            const curY = myPosRef.current.y || 0;
            if (curY > -3.0 || curX < 18) {
              // Walk player right onto the tennis court baseline
              myPosRef.current.y = -6.0;
              clickTargetPosRef.current = { x: 22.0, y: -6.0, z: 0.0 };
              if (clickMarkerRef.current) {
                clickMarkerRef.current.position.set(22.0, -5.97, 0.0);
                clickMarkerRef.current.visible = true;
              }
            } else {
              isPlayerSwingingRef.current = true;
            }
            return;
          } else if (hit.userData.isCoffeeRobot) {
            if (onOpenCoffeeRobotRef.current) onOpenCoffeeRobotRef.current();
            return;
          } else if (hit.userData.isPomodoro || hit.name === 'HealthcarePomodoro') {
            if (onOpenPomodoroRef.current) onOpenPomodoroRef.current();
            return;
          } else if (hit.userData.isLibrary) {
            if (onOpenLibraryRef.current) onOpenLibraryRef.current();
            return;
          } else if (hit.userData.isDataCenter) {
            if (onOpenDataCenterRef.current) onOpenDataCenterRef.current();
            return;
          } else if (hit.userData.isPresentationScreen) {
            if (onOpenPresentationModalRef.current) {
              onOpenPresentationModalRef.current();
            } else if (onStartScreenShareRef.current) {
              onStartScreenShareRef.current();
            }
            return;
          } else if (
            hit.userData.isScreen ||
            hit.userData.isB1Screen ||
            hit.name === 'B1CorporateOfficeScreen' ||
            hit.name === 'ScreenShareTV' ||
            (hit.name && hit.name.includes('Screen'))
          ) {
            if (onStartScreenShareRef.current) {
              onStartScreenShareRef.current();
            } else {
              audioManager.startScreenShare();
            }
            return;
          } else if (hit.userData.isPingPong) {
            if (onOpenPingPongRef.current) onOpenPingPongRef.current();
            return;
          } else if (hit.userData.isElevator) {
            // Open Executive Elevator Panel with Up/Down Buttons & B1, 1F, 2F, 3F Floor Selectors!
            if (onOpenElevatorModalRef.current) {
              onOpenElevatorModalRef.current();
            }
            return;
          } else if (
            hit.userData.isAtmSubmissionBox ||
            hit.userData.isMitari ||
            hit.name === 'AtmSubmissionBox' ||
            hit.name === 'MitariMachine' ||
            (hit.name && (hit.name.includes('Atm') || hit.name.includes('Mitari')))
          ) {
            // Open Chloe Becker Mitari Machine Submission & Payroll Modal
            if (onOpenAtmModalRef.current) {
              onOpenAtmModalRef.current();
            }
            return;
          } else if (hit.userData.isChloe) {
            myPosRef.current = { x: 2.1, y: -6.0, z: -1.95 };
            myRotYRef.current = Math.PI;
            isSeatedRef.current = true;
            seatedSeatPosRef.current = { x: 2.1, y: -5.9, z: -1.95 };
            clickTargetPosRef.current = null;
            if (clickMarkerRef.current) clickMarkerRef.current.visible = false;
            return;
          } else if (
            hit.userData.isTeslaTennisBot ||
            hit.name === 'TennisCourtGroundPlane' ||
            (hit.name && hit.name.includes('Tennis'))
          ) {
            const curY = myPosRef.current.y || 0;
            const isNearTennis = curY <= -4.0 && myPosRef.current.x >= 15.0 && myPosRef.current.x <= 44.0 && Math.abs(myPosRef.current.z) <= 8.5;
            if (isNearTennis) {
              isPlayerSwingingRef.current = true;
              myAvatarGroupRef.current?.triggerTennisSwing('smash');
            }
            return;
          } else if (hit.userData.isMeetingChair) {
            const seat = hit.userData.seatPos;
            const occupiedCheck = isSeatOccupied(seat, colliders);

            if (occupiedCheck.occupied) {
              // Chair is occupied: navigate respectfully to the side of the chair
              const approach = adjustClickDestinationForPersonalSpace(
                myPosRef.current,
                seat,
                colliders,
                RESPECTFUL_PERSONAL_SPACE
              );
              clickTargetDeskRef.current = null;
              clickTargetPosRef.current = approach.safeTarget;
              if (clickMarkerRef.current) {
                clickMarkerRef.current.position.set(approach.safeTarget.x, currentY + 0.03, approach.safeTarget.z);
                clickMarkerRef.current.visible = true;
              }
              isSeatedRef.current = false;
              return;
            }

            // Sit directly on the clicked unoccupied boardroom chair!
            myPosRef.current = { x: seat.x, y: seat.y, z: seat.z };
            myRotYRef.current = hit.userData.rotY;
            isSeatedRef.current = true;
            seatedSeatPosRef.current = seat;
            clickTargetPosRef.current = null;
            if (clickMarkerRef.current) clickMarkerRef.current.visible = false;
            onMoveRef.current(myPosRef.current, myRotYRef.current, false);
            return;
          }
        }
        if (hit.name === 'InteractiveWhiteboard') {
          onOpenWhiteboardRef.current();
          return;
        }
      }

      // 2. Raycast onto current floor plane for mouse-click avatar walk & seating
      const currentFloorPlane = new THREE.Plane(new THREE.Vector3(0, 1, 0), -currentY);
      const intersectionPoint = new THREE.Vector3();

      if (raycaster.ray.intersectPlane(currentFloorPlane, intersectionPoint)) {
        let targetX = intersectionPoint.x;
        let targetZ = intersectionPoint.z;

        // Floor bounds (B1 extends seamlessly to X = 42.0 for tennis arena)
        if (currentY <= -3.0) {
          targetX = Math.max(-11.5, Math.min(42.5, targetX));
        } else {
          targetX = Math.max(-11, Math.min(11, targetX));
        }
        targetZ = Math.max(-8.5, Math.min(8.5, targetZ));

        isSeatedRef.current = false; // Stand up on click navigation

        // Check if clicked workstation or chair on 1F
        const targetDesk =
          currentY < 3
            ? desksRef.current.find((d) => Math.hypot(d.x - targetX, d.z - targetZ) < 1.6)
            : null;

        if (targetDesk) {
          const chairPos = { x: targetDesk.x, y: currentY, z: targetDesk.z + 0.8 };
          const occupiedCheck = isSeatOccupied(chairPos, colliders);

          if (occupiedCheck.occupied) {
            // Desk chair occupied by colleague: stand respectfully beside desk
            const sidePos = { x: targetDesk.x + 1.1, y: currentY, z: targetDesk.z + 0.8 };
            clickTargetDeskRef.current = null;
            clickTargetPosRef.current = sidePos;
            if (clickMarkerRef.current) {
              clickMarkerRef.current.position.set(sidePos.x, currentY + 0.03, sidePos.z);
              clickMarkerRef.current.visible = true;
            }
          } else {
            clickTargetDeskRef.current = targetDesk;
            clickTargetPosRef.current = chairPos;
            if (clickMarkerRef.current) {
              clickMarkerRef.current.position.set(targetDesk.x, currentY + 0.03, chairPos.z);
              clickMarkerRef.current.visible = true;
            }
          }
        } else {
          clickTargetDeskRef.current = null;
          // Apply personal space protection to clicked floor coordinates
          const safeCheck = adjustClickDestinationForPersonalSpace(
            myPosRef.current,
            { x: targetX, y: currentY, z: targetZ },
            colliders,
            RESPECTFUL_PERSONAL_SPACE
          );
          clickTargetPosRef.current = safeCheck.safeTarget;
          if (clickMarkerRef.current) {
            clickMarkerRef.current.position.set(safeCheck.safeTarget.x, currentY + 0.03, safeCheck.safeTarget.z);
            clickMarkerRef.current.visible = true;
          }
        }
      }
    };

    const handlePointerUp = (e: MouseEvent) => {
      if (isPanDraggingRef.current) {
        isPanDraggingRef.current = false;
        return;
      }
      if (!isPointerDraggingRef.current) return;
      isPointerDraggingRef.current = false;

      const coords = { x: e.clientX, y: e.clientY };

      // Check if user clicked/tapped (not dragged camera view)
      const distDragged = Math.hypot(
        coords.x - pointerDownPosRef.current.x,
        coords.y - pointerDownPosRef.current.y
      );

      if (distDragged < 8) {
        performClickRaycast(coords.x, coords.y);
      }
    };

    const handleWheel = (e: WheelEvent) => {
      e.preventDefault();
      const zoomFactor = e.deltaY * 0.006;
      camDistanceRef.current = Math.max(2.2, Math.min(18.0, camDistanceRef.current + zoomFactor));
    };

    // Multi-touch gestures for mobile/touchscreen (1-finger orbit/tap, 2-finger pinch zoom & pan)
    const handleTouchStart = (e: TouchEvent) => {
      if (
        document.activeElement?.tagName === 'INPUT' ||
        document.activeElement?.tagName === 'TEXTAREA'
      ) {
        return;
      }

      if (e.touches.length === 1) {
        const t = e.touches[0];
        pointerDownPosRef.current = { x: t.clientX, y: t.clientY };
        lastPointerXRef.current = t.clientX;
        lastPointerYRef.current = t.clientY;
        isPointerDraggingRef.current = true;
        touchPinchDistRef.current = null;
        touchPrevCenterRef.current = null;
      } else if (e.touches.length >= 2) {
        isPointerDraggingRef.current = false;
        const t1 = e.touches[0];
        const t2 = e.touches[1];
        touchPinchDistRef.current = Math.hypot(t1.clientX - t2.clientX, t1.clientY - t2.clientY);
        touchPrevCenterRef.current = {
          x: (t1.clientX + t2.clientX) / 2,
          y: (t1.clientY + t2.clientY) / 2,
        };
      }
    };

    const handleTouchMove = (e: TouchEvent) => {
      if (e.touches.length === 1 && isPointerDraggingRef.current) {
        const t = e.touches[0];
        const deltaX = t.clientX - lastPointerXRef.current;
        const deltaY = t.clientY - lastPointerYRef.current;

        orbitAngleRef.current += deltaX * 0.008;
        pitchAngleRef.current = Math.max(0.12, Math.min(1.3, pitchAngleRef.current - deltaY * 0.005));

        lastPointerXRef.current = t.clientX;
        lastPointerYRef.current = t.clientY;
      } else if (e.touches.length >= 2 && touchPinchDistRef.current !== null) {
        const t1 = e.touches[0];
        const t2 = e.touches[1];
        const curDist = Math.hypot(t1.clientX - t2.clientX, t1.clientY - t2.clientY);
        const distDelta = touchPinchDistRef.current - curDist;

        // Pinch to zoom
        camDistanceRef.current = Math.max(2.2, Math.min(18.0, camDistanceRef.current + distDelta * 0.015));
        touchPinchDistRef.current = curDist;

        // 2-finger pan
        if (touchPrevCenterRef.current) {
          const curCenterX = (t1.clientX + t2.clientX) / 2;
          const curCenterY = (t1.clientY + t2.clientY) / 2;
          const panDx = (curCenterX - touchPrevCenterRef.current.x) * 0.012;
          const panDy = (curCenterY - touchPrevCenterRef.current.y) * 0.012;

          const orbit = orbitAngleRef.current;
          camPanRef.current.x -= (panDx * Math.cos(orbit) - panDy * Math.sin(orbit));
          camPanRef.current.z -= (panDx * Math.sin(orbit) + panDy * Math.cos(orbit));

          touchPrevCenterRef.current = { x: curCenterX, y: curCenterY };
        }
      }
    };

    const handleTouchEnd = (e: TouchEvent) => {
      if (e.touches.length === 0) {
        touchPinchDistRef.current = null;
        touchPrevCenterRef.current = null;
        if (isPointerDraggingRef.current) {
          isPointerDraggingRef.current = false;
          if (e.changedTouches.length > 0) {
            const t = e.changedTouches[0];
            const distDragged = Math.hypot(
              t.clientX - pointerDownPosRef.current.x,
              t.clientY - pointerDownPosRef.current.y
            );
            if (distDragged < 12) {
              performClickRaycast(t.clientX, t.clientY);
            }
          }
        }
      } else if (e.touches.length === 1) {
        const t = e.touches[0];
        isPointerDraggingRef.current = true;
        lastPointerXRef.current = t.clientX;
        lastPointerYRef.current = t.clientY;
        touchPinchDistRef.current = null;
        touchPrevCenterRef.current = null;
      }
    };

    const handleContextMenu = (e: MouseEvent) => {
      e.preventDefault(); // Prevent context menu on right click pan
    };

    const handleMouseLeaveCanvas = () => {
      mouseScreenPosRef.current = null;
    };

    renderer.domElement.addEventListener('mousedown', handlePointerDown);
    renderer.domElement.addEventListener('mouseleave', handleMouseLeaveCanvas);
    window.addEventListener('mousemove', handlePointerMove);
    window.addEventListener('mouseup', handlePointerUp);
    renderer.domElement.addEventListener('wheel', handleWheel, { passive: false });
    renderer.domElement.addEventListener('contextmenu', handleContextMenu);

    renderer.domElement.addEventListener('touchstart', handleTouchStart, { passive: true });
    window.addEventListener('touchmove', handleTouchMove, { passive: true });
    window.addEventListener('touchend', handleTouchEnd, { passive: true });

    // 5. RESIZE OBSERVER
    const resizeObserver = new ResizeObserver(() => {
      if (!container) return;
      camera.aspect = container.clientWidth / container.clientHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(container.clientWidth, container.clientHeight);
    });
    resizeObserver.observe(container);

    // 6. RENDER & MOVEMENT ANIMATION LOOP
    let animationFrameId: number;
    let lastMoveEmitTime = 0;
    const clock = new THREE.Clock();

    const animate = () => {
      animationFrameId = requestAnimationFrame(animate);
      const delta = clock.getDelta();
      const time = clock.getElapsedTime();

      const activeUser = currentUserRef.current;
      const currentRemotes = remoteUsersRef.current;
      const currentCamMode = cameraModeRef.current;

      // Check Elevator Transit State & Avatar Attachment
      if (elevatorRideRef.current) {
        const ride = elevatorRideRef.current;
        const now = performance.now();
        const elapsed = (now - ride.startTime) / 1000;
        const progress = Math.min(1.0, elapsed / ride.duration);

        // Smooth cubic ease in out
        const ease = progress < 0.5 ? 4 * progress * progress * progress : 1 - Math.pow(-2 * progress + 2, 3) / 2;
        const currentCabinY = THREE.MathUtils.lerp(ride.startY, ride.targetY, ease);

        // Dynamic Attachment & Precision Bounding Alignment (Fixes clipping and jitter)
        myPosRef.current.x = 8.5;
        myPosRef.current.z = -8.0;
        myPosRef.current.y = currentCabinY;
        myRotYRef.current = 0; // Face outward (+Z) towards elevator doors

        if (myAvatarGroupRef.current) {
          myAvatarGroupRef.current.group.position.set(8.5, currentCabinY, -8.0);
          myAvatarGroupRef.current.group.rotation.y = 0;
          myAvatarGroupRef.current.updateAnimation(time, false, false, false, false, false);
        }

        if (officeMeshesRef.current?.elevatorCabinGroup) {
          officeMeshesRef.current.elevatorCabinGroup.position.y = currentCabinY;
        }

        // Throttled sync during ride
        const nowMs = Date.now();
        if (nowMs - lastMoveEmitTime > 60) {
          lastMoveEmitTime = nowMs;
          onMoveRef.current(myPosRef.current, 0, false);
        }

        if (progress >= 1.0) {
          const finalY = ride.targetY;
          elevatorRideRef.current = null;
          setIsElevatorMoving(false);
          isElevatorMovingRef.current = false;
          if (onElevatorMovingChangeRef.current) {
            onElevatorMovingChangeRef.current(false);
          }
          myPosRef.current.y = finalY;
          onMoveRef.current(myPosRef.current, 0, false);
          if (onElevatorArrivedRef.current) {
            onElevatorArrivedRef.current(finalY);
          }
        }
      } else if (activeUser) {
        let isMoving = false;
        // Check if Autonomous Waypoint Auto-Ride is active
        if (isAutoRidingRef.current) {
          // Manual input cancels auto-ride seamlessly
          const keys = keysPressedRef.current;
          if (
            keys['KeyW'] || keys['KeyS'] || keys['KeyA'] || keys['KeyD'] ||
            keys['ArrowUp'] || keys['ArrowDown'] || keys['ArrowLeft'] || keys['ArrowRight']
          ) {
            isAutoRidingRef.current = false;
            setIsAutoRiding(false);
            soundEffects.playScooterCruise(false);
          } else {
            // Execute autonomous waypoint navigation step with collision avoidance
            const currentFloorColliders = getFloorColliders(myPosRef.current.y || 0, remoteUsers, currentUser?.id, desks);
            const autoResult = stepAutoRide(
              myPosRef.current,
              myRotYRef.current,
              autoRideWaypointIdxRef.current,
              delta,
              4.5,
              currentFloorColliders
            );
            myPosRef.current.x = autoResult.nextPos.x;
            myPosRef.current.z = autoResult.nextPos.z;
            myRotYRef.current = autoResult.targetRotationY;
            autoRideWaypointIdxRef.current = autoResult.currentWaypointIdx;
            scooterTurnAngleRef.current = autoResult.turnAngle;
            isMoving = true;
            isSeatedRef.current = false;
            clickTargetPosRef.current = null;
            if (clickMarkerRef.current) clickMarkerRef.current.visible = false;

            const now = Date.now();
            if (now - lastMoveEmitTime > 40) {
              lastMoveEmitTime = now;
              onMoveRef.current(myPosRef.current, myRotYRef.current, true);
            }
            if (autoResult.currentLabel !== autoRideLabel) {
              setAutoRideLabel(autoResult.currentLabel);
            }
          }
        }

        if (!isAutoRidingRef.current) {
          // Local User WASD Movement Engine
          let dx = 0;
          let dz = 0;
          const keys = keysPressedRef.current;
          const riding = isRidingScooterRef.current;
          let baseSpeed = riding ? (keys['ShiftLeft'] || keys['ShiftRight'] ? 12.0 : 8.0) : (keys['ShiftLeft'] || keys['ShiftRight'] ? 6.5 : 3.8);
          
          const curY = myPosRef.current.y || 0;
          // Strictly detect when player is in the active tennis playing court lane
          const isInTennisLane = curY <= -4.0 && myPosRef.current.x >= 16.2 && myPosRef.current.x <= 28.5 && Math.abs(myPosRef.current.z) <= 7.0;
          const isNearTennisCourt = curY <= -4.0 && myPosRef.current.x >= 15.0 && myPosRef.current.x <= 44.0 && Math.abs(myPosRef.current.z) <= 8.5;

          if (isInTennisLane) {
            // Fixed WASD buttons on tennis court player lane:
            // W: left (-Z direction)
            // A: forward (+X direction towards opponent/net)
            // S: backward (-X direction towards baseline)
            // D: right (+Z direction)
            baseSpeed = 11.5;
            if (keys['KeyW'] || keys['ArrowLeft']) dz -= 1;  // Left (-Z)
            if (keys['KeyD'] || keys['ArrowRight']) dz += 1; // Right (+Z)
            if (keys['KeyA'] || keys['ArrowUp']) dx += 1;    // Forward (+X towards net)
            if (keys['KeyS'] || keys['ArrowDown']) dx -= 1;  // Backward (-X towards baseline)
          } else {
            // Standard free-roam WASD (camera orbit relative) across office and entrance portal
            if (keys['KeyW'] || keys['ArrowUp']) dz -= 1;
            if (keys['KeyS'] || keys['ArrowDown']) dz += 1;
            if (keys['KeyA'] || keys['ArrowLeft']) dx -= 1;
            if (keys['KeyD'] || keys['ArrowRight']) dx += 1;
          }

          if (isNearTennisCourt) {
            if (playerVelYRef.current !== 0 || (myPosRef.current.y || 0) > -6.0) {
              playerVelYRef.current -= 16.0 * delta; // Gravity
              let updatedY = (myPosRef.current.y || 0) + playerVelYRef.current * delta;
              if (updatedY <= -6.0) {
                updatedY = -6.0;
                playerVelYRef.current = 0;
              }
              myPosRef.current.y = updatedY;
            }
          }

          const speed = baseSpeed * delta;
          const isKeyMoving = dx !== 0 || dz !== 0;

          if (isKeyMoving) {
            isMoving = true;
            // WASD key movement overrides click target path
            clickTargetPosRef.current = null;
            clickTargetDeskRef.current = null;
            isSeatedRef.current = false;
            if (clickMarkerRef.current) clickMarkerRef.current.visible = false;

            const length = Math.hypot(dx, dz);
            dx = (dx / length) * speed;
            dz = (dz / length) * speed;

            let rotDx = dx;
            let rotDz = dz;
            if (isInTennisLane) {
              // Specific tennis lane controls
              rotDx = dx;
              rotDz = dz;
            } else {
              // Fixed world-direction WASD (W: Forward/-Z, S: Backward/+Z, A: Left/-X, D: Right/+X)
              rotDx = dx;
              rotDz = dz;
            }

            let candX = myPosRef.current.x + rotDx;
            let candZ = myPosRef.current.z + rotDz;

            if (isInTennisLane) {
              // NET SAFE BARRIER: Strictly prevent player from walking through or passing the net at X = 29.0
              candX = Math.min(28.4, Math.max(16.2, candX));
              candZ = Math.min(6.5, Math.max(-6.5, candZ));
            } else {
              if (curY <= -3.0) {
                candX = Math.max(-11.5, Math.min(42.5, candX));
              } else {
                candX = Math.max(-11, Math.min(11, candX));
              }
              candZ = Math.max(-8.5, Math.min(8.5, candZ));
            }

            // Elevator approach and cab boundary handling
            const isInsideCab = candX >= 7.6 && candX <= 9.4 && candZ >= -8.85 && candZ <= -7.05;
            if (isInsideCab) {
              candX = Math.max(7.85, Math.min(9.15, candX));
              candZ = Math.max(-8.65, Math.min(-7.15, candZ));
            }

            // Avatar-to-Avatar and Avatar-to-NPC Strict Collision Prevention with Sliding
            const currentFloorColliders = getFloorColliders(
              curY,
              remoteUsersRef.current,
              currentUserRef.current?.id,
              desksRef.current
            );
            const resolved = resolveAvatarCollisions(
              myPosRef.current.x,
              myPosRef.current.z,
              candX,
              candZ,
              currentFloorColliders,
              AVATAR_COLLISION_RADIUS
            );

            const targetHeading = Math.atan2(rotDx, rotDz);
            let angleDelta = targetHeading - myRotYRef.current;
            while (angleDelta > Math.PI) angleDelta -= Math.PI * 2;
            while (angleDelta < -Math.PI) angleDelta += Math.PI * 2;

            if (riding) {
              // Smooth banking and handlebar turning angle
              scooterTurnAngleRef.current = THREE.MathUtils.lerp(
                scooterTurnAngleRef.current,
                Math.max(-0.65, Math.min(0.65, angleDelta * 2.0)),
                0.2
              );
              myRotYRef.current = THREE.MathUtils.lerp(myRotYRef.current, myRotYRef.current + angleDelta, 0.22);
            } else {
              scooterTurnAngleRef.current = 0;
              myRotYRef.current = targetHeading;
            }

            myPosRef.current.x = resolved.x;
            myPosRef.current.z = resolved.z;

            const now = Date.now();
            if (now - lastMoveEmitTime > 40) {
              lastMoveEmitTime = now;
              onMoveRef.current(myPosRef.current, myRotYRef.current, true);
            }
            keysPressedRef.current['wasMoving'] = true;
          } else if (clickTargetPosRef.current) {
            // Mouse Click Movement Pathfinding Engine
            const targetX = clickTargetPosRef.current.x;
            const targetZ = clickTargetPosRef.current.z;
            const targetDx = targetX - myPosRef.current.x;
            const targetDz = targetZ - myPosRef.current.z;
            const dist = Math.hypot(targetDx, targetDz);
            const clickSpeed = riding ? 8.0 : 3.8;

            if (dist > 0.15) {
              isMoving = true;
              const moveStep = Math.min(clickSpeed * delta, dist);
              const candX = myPosRef.current.x + (targetDx / dist) * moveStep;
              const candZ = myPosRef.current.z + (targetDz / dist) * moveStep;
              const curY = myPosRef.current.y || 0;

              const currentFloorColliders = getFloorColliders(
                curY,
                remoteUsersRef.current,
                currentUserRef.current?.id,
                desksRef.current
              );
              const resolved = resolveAvatarCollisions(
                myPosRef.current.x,
                myPosRef.current.z,
                candX,
                candZ,
                currentFloorColliders,
                AVATAR_COLLISION_RADIUS
              );

              const actualMoved = Math.hypot(
                resolved.x - myPosRef.current.x,
                resolved.z - myPosRef.current.z
              );
              if (actualMoved < moveStep * 0.05 && dist < 0.8) {
                // Path blocked by collider, complete path early at personal boundary
                clickTargetPosRef.current = null;
                if (clickMarkerRef.current) clickMarkerRef.current.visible = false;
              }

              myPosRef.current.x = resolved.x;
              myPosRef.current.z = resolved.z;
              const targetRot = Math.atan2(targetDx, targetDz);
              if (riding) {
                let rotDiff = targetRot - myRotYRef.current;
                while (rotDiff > Math.PI) rotDiff -= Math.PI * 2;
                while (rotDiff < -Math.PI) rotDiff += Math.PI * 2;
                scooterTurnAngleRef.current = THREE.MathUtils.lerp(scooterTurnAngleRef.current, Math.max(-0.6, Math.min(0.6, rotDiff * 1.8)), 0.2);
                myRotYRef.current = THREE.MathUtils.lerp(myRotYRef.current, myRotYRef.current + rotDiff, 0.2);
              } else {
                scooterTurnAngleRef.current = 0;
                myRotYRef.current = targetRot;
              }

              const now = Date.now();
              if (now - lastMoveEmitTime > 40) {
                lastMoveEmitTime = now;
                onMoveRef.current(myPosRef.current, myRotYRef.current, true);
              }
            } else {
              isMoving = false;
              scooterTurnAngleRef.current = THREE.MathUtils.lerp(scooterTurnAngleRef.current, 0, 0.2);
              clickTargetPosRef.current = null;
              if (clickMarkerRef.current) clickMarkerRef.current.visible = false;

              if (clickTargetDeskRef.current) {
                const desk = clickTargetDeskRef.current;
                isSeatedRef.current = true;
                myPosRef.current.x = desk.x;
                myPosRef.current.z = desk.z + 0.8;
                myRotYRef.current = Math.PI; // Face North (-Z) directly toward the desk & monitor
                onSelectDeskRef.current(desk);
                clickTargetDeskRef.current = null;
              }

              const now = Date.now();
              if (now - lastMoveEmitTime > 40) {
                lastMoveEmitTime = now;
                onMoveRef.current(myPosRef.current, myRotYRef.current, false);
              }
            }
          } else if (isInTennisLane && !riding && tennisAutoPosRef.current) {
            // Intelligent Auto-Play Locomotion (Mimicking Dolly Bot when on court hands-free!)
            const targetX = THREE.MathUtils.clamp(tennisAutoPosRef.current.x, 16.5, 28.2);
            const targetZ = THREE.MathUtils.clamp(tennisAutoPosRef.current.z, -6.2, 6.2);
            const diffX = targetX - myPosRef.current.x;
            const diffZ = targetZ - myPosRef.current.z;
            const distToTarget = Math.hypot(diffX, diffZ);

            if (distToTarget > 0.08) {
              isMoving = true;
              const trackSpeed = 11.5 * delta;
              const step = Math.min(trackSpeed, distToTarget);
              myPosRef.current.x += (diffX / distToTarget) * step;
              myPosRef.current.z += (diffZ / distToTarget) * step;
            } else {
              isMoving = false;
            }

            // Always face towards the net (+X direction, angle Math.PI / 2)
            const targetRot = Math.PI / 2;
            let rotDiff = targetRot - myRotYRef.current;
            while (rotDiff > Math.PI) rotDiff -= Math.PI * 2;
            while (rotDiff < -Math.PI) rotDiff += Math.PI * 2;
            myRotYRef.current = THREE.MathUtils.lerp(myRotYRef.current, myRotYRef.current + rotDiff, 0.25);

            const now = Date.now();
            if (now - lastMoveEmitTime > 40) {
              lastMoveEmitTime = now;
              onMoveRef.current(myPosRef.current, myRotYRef.current, isMoving);
            }
          } else {
            isMoving = false;
            scooterTurnAngleRef.current = THREE.MathUtils.lerp(scooterTurnAngleRef.current, 0, 0.15);
            if (keysPressedRef.current['wasMoving']) {
              keysPressedRef.current['wasMoving'] = false;
              onMoveRef.current(myPosRef.current, myRotYRef.current, false);
            }
          }
        }

          // Subtle idle boundary separation when not seated
          if (!isSeatedRef.current) {
            const curY = myPosRef.current.y || 0;
            const currentFloorColliders = getFloorColliders(
              curY,
              remoteUsersRef.current,
              currentUserRef.current?.id,
              desksRef.current
            );
            const separated = resolveAvatarCollisions(
              myPosRef.current.x,
              myPosRef.current.z,
              myPosRef.current.x,
              myPosRef.current.z,
              currentFloorColliders,
              AVATAR_COLLISION_RADIUS
            );
            if (Math.hypot(separated.x - myPosRef.current.x, separated.z - myPosRef.current.z) > 0.001) {
              myPosRef.current.x = separated.x;
              myPosRef.current.z = separated.z;
            }
          }

        // Pulsing click destination target ring animation
        if (clickMarkerRef.current && clickMarkerRef.current.visible) {
          const pulse = 1 + Math.sin(time * 10) * 0.18;
          clickMarkerRef.current.scale.set(pulse, pulse, pulse);
        }

        // Animate 3D Ping Pong Match, Robot Arm, Barista, & Executive Meeting Room
        let isAtTable = false;
        if (officeMeshesRef.current) {
          if (officeMeshesRef.current.updatePingPongMatch) {
            isAtTable = officeMeshesRef.current.updatePingPongMatch(delta, time, myPosRef.current);
          }
          if (officeMeshesRef.current.updateTrafficScenery) {
            officeMeshesRef.current.updateTrafficScenery(time);
          }
          if (officeMeshesRef.current.updateSushiBar) {
            officeMeshesRef.current.updateSushiBar(time, delta);
          }
          if (officeMeshesRef.current.updateBasementTheater) {
            officeMeshesRef.current.updateBasementTheater(
              time,
              delta,
              myPosRef.current,
              isChloeSpeakingRef.current
            );
          }
          if (officeMeshesRef.current.updateTennisMatch) {
            const isJumping = (myPosRef.current.y || 0) > -5.9;
            const tState = officeMeshesRef.current.updateTennisMatch(
              delta,
              time,
              myPosRef.current,
              isPlayerSwingingRef.current,
              playerSwingTypeRef.current,
              isJumping
            );
            if (isPlayerSwingingRef.current) {
              isPlayerSwingingRef.current = false;
            }

            const onCourt =
              Math.hypot(myPosRef.current.x - 29.0, myPosRef.current.z) < 22.0 &&
              Math.abs((myPosRef.current.y || 0) - (-6.0)) < 3.5;

            if (tState && tState.autoPlayerPos) {
              tennisAutoPosRef.current = tState.autoPlayerPos;
              // If auto-play triggered a racquet swing action, animate the avatar ONLY on court
              if (tState.autoPlayerPos.swingAction && onCourt) {
                myAvatarGroupRef.current?.triggerTennisSwing(tState.autoPlayerPos.swingAction);
                if (tState.autoPlayerPos.isFireball) {
                  myAvatarGroupRef.current?.triggerEmojiParticle('🔥');
                }
              }
            }

            if (onCourt) {
              setTennisMatch((prev) => {
                if (
                  !prev ||
                  prev.playerScore !== tState.playerScore ||
                  prev.botScore !== tState.botScore ||
                  prev.playerGames !== tState.playerGames ||
                  prev.botGames !== tState.botGames ||
                  prev.playerSets !== tState.playerSets ||
                  prev.botSets !== tState.botSets ||
                  prev.rallyCount !== tState.rallyCount ||
                  prev.lastCallText !== tState.lastCallText ||
                  prev.gameMode !== tState.gameMode ||
                  prev.ballSpeedKmh !== tState.ballSpeedKmh ||
                  prev.tacticalTactic !== tState.tacticalTactic ||
                  prev.isFireballActive !== tState.isFireballActive
                ) {
                  return { ...tState };
                }
                return prev;
              });
              setIsOnTennisCourt(true);
            } else {
              setIsOnTennisCourt(false);
            }
          }
        }

        // Proximity detection to Executive Elevator shaft
        // Only show contextual prompt when player steps inside or directly in front of elevator doors
        const curX = myPosRef.current.x;
        const curZ = myPosRef.current.z;
        const curY = myPosRef.current.y || 0;
        const isAtElevatorLanding = [-6.0, 0.0, 5.5, 11.0].some((floorY) => Math.abs(curY - floorY) < 1.8);
        const inElevatorZone = isAtElevatorLanding && curX >= 7.3 && curX <= 9.7 && curZ >= -8.85 && curZ <= -5.6;

        if (inElevatorZone && !isElevatorMovingRef.current && !isNearElevatorRef.current) {
          setIsNearElevator(true);
          isNearElevatorRef.current = true;
        } else if ((!inElevatorZone || isElevatorMovingRef.current) && isNearElevatorRef.current) {
          setIsNearElevator(false);
          isNearElevatorRef.current = false;
        }

        // Proximity detection to Chloe Becker (Dynamic position)
        let chloePos = { x: 2.1, y: -6.0, z: -4.15 };
        const chloeUser = currentRemotes.get('npc_b1_chloe');
        if (chloeUser) {
          chloePos = chloeUser.position;
        } else {
          for (const u of currentRemotes.values()) {
            if (u.name && u.name.toLowerCase().includes('chloe')) {
              chloePos = u.position;
              break;
            }
          }
        }
        
        const myCurY = myPosRef.current.y || 0;
        const isSameFloor = Math.abs(myCurY - (chloePos.y || 0)) < 1.5;
        const distToChloe = Math.hypot(myPosRef.current.x - chloePos.x, myPosRef.current.z - chloePos.z);
        const isNearChloeDynamic = isSameFloor && distToChloe < 4.0;

        if (isNearChloeDynamic) {
          if (!isNearChloeRef.current) {
            setIsNearChloe(true);
            isNearChloeRef.current = true;
            const uname = currentUserRef.current?.name || activeUser?.name || 'there';
            chloeVoice.speak(`Hey ${uname}, good to see you down here, what should we do today?`, 'chloe_proximity_greeting');
            const chloeAvatar = avatarMeshesRef.current.get('npc_b1_chloe');
            if (chloeAvatar) {
              chloeAvatar.triggerGesture('wave');
            }
          }
          setChloeDist(distToChloe);
        } else if (isNearChloeRef.current) {
          setIsNearChloe(false);
          isNearChloeRef.current = false;
        }

        // Proximity detection to Chloe Becker ATM Submission Kiosk (Manager's Office Corner: x=-4.7, z=4.5, y=-6.0)
        const isNearAtmDynamic =
          myCurY < -2 && Math.hypot(myPosRef.current.x - (-4.7), myPosRef.current.z - 4.5) < 3.2;
        if (isNearAtmDynamic && !isNearAtmRef.current) {
          setIsNearAtm(true);
          isNearAtmRef.current = true;
          // Auto face avatar towards Mitari machine kiosk at (-4.7, 4.5)
          myRotYRef.current = Math.atan2((-4.7) - myPosRef.current.x, 4.5 - myPosRef.current.z);
        } else if (!isNearAtmDynamic && isNearAtmRef.current) {
          setIsNearAtm(false);
          isNearAtmRef.current = false;
        }

      // Helper to detect avatar style/hoodie/pants/shoes/cap/scarf/scooter changes
      const getAvatarSig = (u: UserState) =>
        `${u.skin}_${u.hoodieColor || ''}_${u.hairColor || ''}_${u.ethnicity || ''}_${u.skinTone || ''}_${u.pantsColor || ''}_${u.shoesColor || ''}_${u.capColor || ''}_${u.scarfColor || ''}_scooter_${u.isRidingScooter ? '1' : '0'}_${u.scooterConfig ? JSON.stringify(u.scooterConfig) : ''}`;

      // Initialize or Update Local Avatar Mesh
        const activeUserWithScooter = {
          ...activeUser,
          isRidingScooter: isRidingScooterRef.current,
        };
        const mySig = getAvatarSig(activeUserWithScooter);
        if (!myAvatarGroupRef.current || (myAvatarGroupRef.current as any)._avatarSig !== mySig) {
          if (myAvatarGroupRef.current) {
            scene.remove(myAvatarGroupRef.current.group);
          }
          const localAvatar = createVoxelAvatarMesh(activeUserWithScooter);
          (localAvatar as any)._avatarSig = mySig;
          localAvatar.group.userData = { isAvatar: true, isLocalPlayer: true, userId: activeUser.id };
          scene.add(localAvatar.group);
          myAvatarGroupRef.current = localAvatar;
        }

        if (
          myAvatarGroupRef.current &&
          officeMeshes?.interactiveObjects &&
          !officeMeshes.interactiveObjects.includes(myAvatarGroupRef.current.group)
        ) {
          myAvatarGroupRef.current.group.userData = { isAvatar: true, isLocalPlayer: true, userId: activeUser.id };
          officeMeshes.interactiveObjects.push(myAvatarGroupRef.current.group);
        }

        const myAvatar = myAvatarGroupRef.current;
        const myY = myPosRef.current.y || 0;
        myAvatar.group.position.set(myPosRef.current.x, myY, myPosRef.current.z);
        myAvatar.group.rotation.y = myRotYRef.current;
        const isNearTennisCourt =
          Math.hypot(myPosRef.current.x - 29.0, myPosRef.current.z) < 22.0 &&
          Math.abs((myPosRef.current.y || 0) - (-6.0)) < 3.5;
        
        const effectiveSpeed = isRidingScooterRef.current
          ? (isMoving ? 8.5 : 0)
          : 0;

        myAvatar.updateAnimation(
          time,
          isMoving,
          isAtTable,
          isSeatedRef.current,
          isNearTennisCourt,
          isPlayerSwingingRef.current,
          'smash',
          activeUser.isSpeaking,
          undefined,
          isRidingScooterRef.current,
          scooterTurnAngleRef.current,
          effectiveSpeed,
          delta
        );
        myAvatar.updateBadge(activeUser);

        // Update Local Webcam Video Texture on 3D Avatar
        const localVidEl = audioManager.getLocalVideoElement();
        if (audioManager.getIsCameraOn() && localVidEl) {
          ensureVideoInDOM(localVidEl);
          if (!localVideoTextureRef.current || localVideoTextureRef.current.image !== localVidEl) {
            localVideoTextureRef.current = new THREE.VideoTexture(localVidEl);
            localVideoTextureRef.current.minFilter = THREE.LinearFilter;
            localVideoTextureRef.current.magFilter = THREE.LinearFilter;
          }
          localVideoTextureRef.current.needsUpdate = true;
          myAvatar.setVideoTexture(localVideoTextureRef.current);
        } else {
          myAvatar.setVideoTexture(null);
        }
      }

      // Sync Remote Peer Avatars
      currentRemotes.forEach((remoteUser, userId) => {
        const getAvatarSig = (u: UserState) =>
          `${u.skin}_${u.hoodieColor || ''}_${u.hairColor || ''}_${u.ethnicity || ''}_${u.skinTone || ''}_${u.pantsColor || ''}_${u.shoesColor || ''}_${u.capColor || ''}_${u.scarfColor || ''}_scooter_${u.isRidingScooter ? '1' : '0'}_${u.scooterConfig ? JSON.stringify(u.scooterConfig) : ''}`;
        const remoteSig = getAvatarSig(remoteUser);
        let remoteMeshObj = avatarMeshesRef.current.get(userId);
        if (!remoteMeshObj || (remoteMeshObj as any)._avatarSig !== remoteSig) {
          if (remoteMeshObj) {
            scene.remove(remoteMeshObj.group);
          }
          remoteMeshObj = createVoxelAvatarMesh(remoteUser);
          (remoteMeshObj as any)._avatarSig = remoteSig;
          scene.add(remoteMeshObj.group);
          avatarMeshesRef.current.set(userId, remoteMeshObj);
        }

        const isChloe =
          userId === 'npc_b1_chloe' ||
          (remoteUser.name && remoteUser.name.toLowerCase().includes('chloe'));

        if (isChloe) {
          remoteMeshObj.group.name = 'ChloeBeckerB1Avatar';
          remoteMeshObj.group.userData = {
            isChloe: true,
            name: 'Chloe Becker',
            title: 'Chloe Becker (AI Agent & Colleague)',
          };
          remoteMeshObj.group.traverse((child) => {
            child.userData = {
              isChloe: true,
              name: 'Chloe Becker',
              title: 'Chloe Becker (AI Agent & Colleague)',
            };
          });
          if (
            officeMeshes?.interactiveObjects &&
            !officeMeshes.interactiveObjects.includes(remoteMeshObj.group)
          ) {
            officeMeshes.interactiveObjects.push(remoteMeshObj.group);
          }
        }

        const remoteY = remoteUser.position.y || 0;
        remoteMeshObj.group.position.lerp(
          new THREE.Vector3(remoteUser.position.x, remoteY, remoteUser.position.z),
          0.25
        );
        remoteMeshObj.group.rotation.y = remoteUser.rotationY;
        const remoteOnCourt =
          Math.hypot(remoteUser.position.x - 29.0, remoteUser.position.z) < 22.0 &&
          Math.abs((remoteUser.position.y || 0) - (-6.0)) < 3.5;

        const isSeated = isChloe || (!!remoteUser.claimedDeskId && !remoteUser.isMoving);
        const isTalking = isChloe ? isChloeSpeakingRef.current : (remoteUser.isSpeaking || false);

        remoteMeshObj.updateAnimation(
          time,
          remoteUser.isMoving,
          false,
          isSeated,
          remoteOnCourt,
          false,
          undefined,
          isTalking,
          myPosRef.current,
          !!remoteUser.isRidingScooter,
          0,
          remoteUser.isMoving ? 8.0 : 0,
          delta
        );
        remoteMeshObj.updateBadge(remoteUser);

        // Chloe Proximity Head-Tracking, eye contact & ambient glances
        if (isChloe) {
          const chloePos = remoteUser.position;
          const pPos = myPosRef.current;
          const distToPlayer = pPos ? Math.hypot(pPos.x - chloePos.x, pPos.z - chloePos.z) : 999;
          const isPlayerOnSameFloor = pPos && Math.abs(pPos.y - (chloePos.y || 0)) < 2.5;

          if (isPlayerOnSameFloor && distToPlayer < 5.0) {
            const dx = pPos.x - chloePos.x;
            const dz = pPos.z - chloePos.z;
            const dy = (pPos.y + 1.2) - ((chloePos.y || 0) + 1.35); // relative eye level
            const targetAngleY = Math.atan2(dx, dz); // Chloe sits facing +Z
            const targetAngleX = Math.atan2(-dy, Math.max(0.5, distToPlayer));
            const clampedAngleY = Math.max(-1.15, Math.min(1.15, targetAngleY));
            const clampedAngleX = Math.max(-0.35, Math.min(0.35, targetAngleX));
            const curiosityTiltZ = Math.sin(time * 2.0) * 0.04 - (clampedAngleY * 0.08);

            remoteMeshObj.headMesh.rotation.y = THREE.MathUtils.lerp(
              remoteMeshObj.headMesh.rotation.y,
              clampedAngleY,
              0.12
            );
            remoteMeshObj.headMesh.rotation.x = THREE.MathUtils.lerp(
              remoteMeshObj.headMesh.rotation.x,
              clampedAngleX,
              0.1
            );
            remoteMeshObj.headMesh.rotation.z = THREE.MathUtils.lerp(
              remoteMeshObj.headMesh.rotation.z,
              curiosityTiltZ,
              0.08
            );
          } else {
            // Ambient idle glance between desk monitor and office room
            const ambientGlance = Math.sin(time * 0.6) > 0.4 ? Math.sin(time * 0.8) * 0.18 : 0;
            remoteMeshObj.headMesh.rotation.y = THREE.MathUtils.lerp(
              remoteMeshObj.headMesh.rotation.y,
              ambientGlance,
              0.04
            );
            remoteMeshObj.headMesh.rotation.x = THREE.MathUtils.lerp(
              remoteMeshObj.headMesh.rotation.x,
              0.08 + Math.sin(time * 1.4) * 0.03,
              0.05
            );
            remoteMeshObj.headMesh.rotation.z = THREE.MathUtils.lerp(
              remoteMeshObj.headMesh.rotation.z,
              Math.sin(time * 0.7) * 0.03,
              0.05
            );
          }
        }

        // Update Remote Video Texture on Avatar Webcam Screen
        const remoteStream = audioManager.getRemoteVideoStream(userId);
        const remoteFrame = audioManager.getRemoteVideoFrame(userId);
        let entry = remoteVideoElementsRef.current.get(userId);

        if (remoteStream) {
          if (!entry || entry.streamId !== remoteStream.id) {
            if (entry) {
              entry.videoEl.pause();
              if (entry.videoEl.parentNode) entry.videoEl.parentNode.removeChild(entry.videoEl);
              entry.texture.dispose();
            }
            const vidEl = document.createElement('video');
            vidEl.autoplay = true;
            vidEl.muted = true;
            vidEl.playsInline = true;
            vidEl.srcObject = remoteStream;
            ensureVideoInDOM(vidEl);
            vidEl.play().catch(() => {});

            const tex = new THREE.VideoTexture(vidEl);
            tex.minFilter = THREE.LinearFilter;
            tex.magFilter = THREE.LinearFilter;
            entry = { videoEl: vidEl, texture: tex, streamId: remoteStream.id };
            remoteVideoElementsRef.current.set(userId, entry);
          }
          entry.texture.needsUpdate = true;
          remoteMeshObj.setVideoTexture(entry.texture);
        } else if (remoteFrame) {
          let frameEntry = remoteFrameTexturesRef.current.get(userId);
          if (!frameEntry) {
            const img = new Image();
            const canvas = document.createElement('canvas');
            canvas.width = 320;
            canvas.height = 180;
            const ctx = canvas.getContext('2d')!;
            const tex = new THREE.CanvasTexture(canvas);
            tex.minFilter = THREE.LinearFilter;

            img.onload = () => {
              ctx.drawImage(img, 0, 0, 320, 180);
              tex.needsUpdate = true;
            };

            frameEntry = { img, canvas, ctx, texture: tex, lastSrc: '' };
            remoteFrameTexturesRef.current.set(userId, frameEntry);
          }

          if (frameEntry.lastSrc !== remoteFrame) {
            frameEntry.lastSrc = remoteFrame;
            frameEntry.img.src = remoteFrame;
          }
          remoteMeshObj.setVideoTexture(frameEntry.texture);
        } else {
          if (entry) {
            entry.videoEl.pause();
            if (entry.videoEl.parentNode) entry.videoEl.parentNode.removeChild(entry.videoEl);
            entry.texture.dispose();
            remoteVideoElementsRef.current.delete(userId);
          }
          const frameEntry = remoteFrameTexturesRef.current.get(userId);
          if (frameEntry) {
            frameEntry.texture.dispose();
            remoteFrameTexturesRef.current.delete(userId);
          }
          remoteMeshObj.setVideoTexture(null);
        }
      });

      // Cleanup disconnected remote peer meshes & video textures
      avatarMeshesRef.current.forEach((meshObj, userId) => {
        if (!currentRemotes.has(userId)) {
          scene.remove(meshObj.group);
          avatarMeshesRef.current.delete(userId);

          const entry = remoteVideoElementsRef.current.get(userId);
          if (entry) {
            entry.videoEl.pause();
            if (entry.videoEl.parentNode) entry.videoEl.parentNode.removeChild(entry.videoEl);
            entry.texture.dispose();
            remoteVideoElementsRef.current.delete(userId);
          }
          const frameEntry = remoteFrameTexturesRef.current.get(userId);
          if (frameEntry) {
            frameEntry.texture.dispose();
            remoteFrameTexturesRef.current.delete(userId);
          }
        }
      });

      // 3D Raycast Hover Interaction for Floating Video Screens (Temporary Hide / Fade Out)
      if (mouseScreenPosRef.current) {
        const rect = renderer.domElement.getBoundingClientRect();
        const hoverMouse = new THREE.Vector2(
          ((mouseScreenPosRef.current.x - rect.left) / rect.width) * 2 - 1,
          -((mouseScreenPosRef.current.y - rect.top) / rect.height) * 2 + 1
        );

        scene.updateMatrixWorld(true);
        raycaster.setFromCamera(hoverMouse, camera);

        const screenTargets: THREE.Object3D[] = [];
        if (myAvatarGroupRef.current?.videoScreenGroup) {
          myAvatarGroupRef.current.videoScreenGroup.traverse((child) => {
            if ((child as THREE.Mesh).isMesh) {
              screenTargets.push(child);
            }
          });
        }
        avatarMeshesRef.current.forEach((remoteAvatar) => {
          if (remoteAvatar.videoScreenGroup) {
            remoteAvatar.videoScreenGroup.traverse((child) => {
              if ((child as THREE.Mesh).isMesh) {
                screenTargets.push(child);
              }
            });
          }
        });

        let hitMesh: THREE.Object3D | null = null;
        if (screenTargets.length > 0) {
          const hits = raycaster.intersectObjects(screenTargets, false);
          if (hits.length > 0) {
            hitMesh = hits[0].object;
          }
        }

        const isAnyScreenHovered = !!hitMesh;

        if (myAvatarGroupRef.current?.videoScreenGroup) {
          let isMyHovered = false;
          if (hitMesh) {
            myAvatarGroupRef.current.videoScreenGroup.traverse((child) => {
              if (child === hitMesh) isMyHovered = true;
            });
          }
          myAvatarGroupRef.current.setScreenHovered(isMyHovered);
        }

        avatarMeshesRef.current.forEach((remoteAvatar) => {
          let isRemoteHovered = false;
          if (hitMesh && remoteAvatar.videoScreenGroup) {
            remoteAvatar.videoScreenGroup.traverse((child) => {
              if (child === hitMesh) isRemoteHovered = true;
            });
          }
          remoteAvatar.setScreenHovered(isRemoteHovered);
        });

        // Requirement 3: Change mouse cursor style to pointer on hover for clear visual feedback
        if (isAnyScreenHovered) {
          renderer.domElement.style.cursor = 'pointer';
        } else {
          if (renderer.domElement.style.cursor === 'pointer') {
            renderer.domElement.style.cursor = 'default';
          }
        }
      } else {
        if (myAvatarGroupRef.current) {
          myAvatarGroupRef.current.setScreenHovered(false);
        }
        avatarMeshesRef.current.forEach((remoteAvatar) => {
          remoteAvatar.setScreenHovered(false);
        });
        if (renderer.domElement.style.cursor === 'pointer') {
          renderer.domElement.style.cursor = 'default';
        }
      }

      // Update 3D Room Presentation Screens (ScreenShareTV & Boardroom Monitors)
      const activeScreenStream = audioManager.getScreenStream() || audioManager.getRemoteScreenStream();
      const activeScreenFrame = audioManager.getRemoteScreenFrame();

      if (activeScreenStream) {
        if (!roomScreenVideoRef.current || roomScreenVideoRef.current.streamId !== activeScreenStream.id) {
          if (roomScreenVideoRef.current) {
            roomScreenVideoRef.current.videoEl.pause();
            if (roomScreenVideoRef.current.videoEl.parentNode) {
              roomScreenVideoRef.current.videoEl.parentNode.removeChild(roomScreenVideoRef.current.videoEl);
            }
            roomScreenVideoRef.current.texture.dispose();
          }
          const vidEl = document.createElement('video');
          vidEl.autoplay = true;
          vidEl.muted = true;
          vidEl.playsInline = true;
          vidEl.srcObject = activeScreenStream;
          ensureVideoInDOM(vidEl);
          vidEl.play().catch(() => {});

          const tex = new THREE.VideoTexture(vidEl);
          tex.minFilter = THREE.LinearFilter;
          tex.magFilter = THREE.LinearFilter;
          roomScreenVideoRef.current = { videoEl: vidEl, texture: tex, streamId: activeScreenStream.id };
        }
        roomScreenVideoRef.current.texture.needsUpdate = true;
        if (officeMeshesRef.current?.updateTvTexture) {
          officeMeshesRef.current.updateTvTexture(roomScreenVideoRef.current.texture);
        }
      } else if (activeScreenFrame) {
        if (!roomScreenFrameRef.current) {
          const img = new Image();
          const canvas = document.createElement('canvas');
          canvas.width = 960;
          canvas.height = 540;
          const ctx = canvas.getContext('2d')!;
          const tex = new THREE.CanvasTexture(canvas);
          tex.minFilter = THREE.LinearFilter;

          img.onload = () => {
            ctx.drawImage(img, 0, 0, 960, 540);
            tex.needsUpdate = true;
          };

          roomScreenFrameRef.current = { img, canvas, ctx, texture: tex, lastSrc: '' };
        }

        if (roomScreenFrameRef.current.lastSrc !== activeScreenFrame) {
          roomScreenFrameRef.current.lastSrc = activeScreenFrame;
          roomScreenFrameRef.current.img.src = activeScreenFrame;
        }
        if (officeMeshesRef.current?.updateTvTexture) {
          officeMeshesRef.current.updateTvTexture(roomScreenFrameRef.current.texture);
        }
      } else {
        if (roomScreenVideoRef.current) {
          roomScreenVideoRef.current.videoEl.pause();
          if (roomScreenVideoRef.current.videoEl.parentNode) {
            roomScreenVideoRef.current.videoEl.parentNode.removeChild(roomScreenVideoRef.current.videoEl);
          }
          roomScreenVideoRef.current.texture.dispose();
          roomScreenVideoRef.current = null;
        }
        if (roomScreenFrameRef.current) {
          roomScreenFrameRef.current.texture.dispose();
          roomScreenFrameRef.current = null;
        }
        if (officeMeshesRef.current?.updateTvTexture) {
          officeMeshesRef.current.updateTvTexture(null);
        }
      }

      // Update Spatial Audio
      const remotePosMap = new Map<string, Position3D>();
      currentRemotes.forEach((u, id) => remotePosMap.set(id, u.position));
      audioManager.updateSpatialPositions(myPosRef.current, myRotYRef.current, remotePosMap);

      // Detect Proximity Face-to-Face Interaction (<= 1.5 units and facing each other)
      let currentProximityUser: UserState | null = null;
      let currentProximityDist = 0;

      if (activeUser) {
        const posA = myPosRef.current;
        const rotA = myRotYRef.current;
        const yA = posA.y || 0;

        // 1. Check connected remote user peers
        currentRemotes.forEach((remoteUser) => {
          const posB = remoteUser.position;
          const rotB = remoteUser.rotationY;
          const yB = posB.y || 0;

          if (Math.abs(yA - yB) < 1.0) {
            const dx = posB.x - posA.x;
            const dz = posB.z - posA.z;
            const dist = Math.hypot(dx, dz);

            if (dist <= 1.5 && dist > 0.05) {
              const dirAB_x = dx / dist;
              const dirAB_z = dz / dist;

              const fA_x = Math.sin(rotA);
              const fA_z = -Math.cos(rotA);
              const dotA = fA_x * dirAB_x + fA_z * dirAB_z;

              const fB_x = Math.sin(rotB);
              const fB_z = -Math.cos(rotB);
              const dotB = fB_x * (-dirAB_x) + fB_z * (-dirAB_z);

              if (dotA > 0.25 && dotB > 0.25) {
                currentProximityUser = remoteUser;
                currentProximityDist = dist;
              }
            }
          }
        });

        // 2. Check NPCs (Lofi Girl, Barista Alex, Mei, Wei, etc.) if no remote user is nearby
        if (!currentProximityUser) {
          const npcs: Array<{ id: string; name: string; skin: any; department: any; pos: Position3D; rotY: number; statusText: string }> = [
            { id: 'npc_lofi_girl', name: 'Lofi Girl', skin: 'college_dev_f', department: 'Design', pos: { x: -8.4, y: 11.0, z: 0 }, rotY: Math.PI / 2, statusText: 'Studying 24/7 Lofi Beats 🎧' },
            { id: 'npc_barista_alex', name: 'Barista Alex', skin: 'human_dev', department: 'Operations', pos: { x: 9.4, y: 11.0, z: 0 }, rotY: -Math.PI / 2, statusText: 'Specialty Coffee Artisan ☕' },
            { id: 'npc_mei', name: 'Mei', skin: 'pumpkin_suit', department: 'Design', pos: { x: -0.6, y: 11.0, z: -5.5 }, rotY: -Math.PI / 2, statusText: 'Pumpkin Cosplay 🎃' },
            { id: 'npc_wei', name: 'Wei', skin: 'wizard_robe', department: 'Engineering', pos: { x: 1.6, y: 11.0, z: -5.5 }, rotY: Math.PI / 2, statusText: 'Sorcerer Wizard 🧙‍♂️' },
            // B1 Corporate Workspace Employees
            { id: 'npc_b1_liam', name: 'Liam', skin: 'college_dev_m', department: 'Engineering', pos: { x: 2.1, y: -6.0, z: -4.35 }, rotY: 0, statusText: 'Frontend Lead 🚀' },
            { id: 'npc_b1_sophia', name: 'Sophia', skin: 'college_dev_f', department: 'Design', pos: { x: 4.3, y: -6.0, z: -2.05 }, rotY: Math.PI, statusText: 'Product Designer 🎨' },
            { id: 'npc_b1_alex', name: 'Alex', skin: 'cyber_robot', department: 'Engineering', pos: { x: 4.3, y: -6.0, z: 2.05 }, rotY: 0, statusText: 'Cloud Infrastructure ⚡' },
            { id: 'npc_b1_marcus', name: 'Marcus', skin: 'fox_suit', department: 'Engineering', pos: { x: 6.5, y: -6.0, z: 4.35 }, rotY: Math.PI, statusText: 'AI Research Lead 🧠' },
          ];

          for (const npc of npcs) {
            if (Math.abs(yA - npc.pos.y) < 1.0) {
              const dx = npc.pos.x - posA.x;
              const dz = npc.pos.z - posA.z;
              const dist = Math.hypot(dx, dz);

              if (dist <= 1.5 && dist > 0.05) {
                const dirAB_x = dx / dist;
                const dirAB_z = dz / dist;

                const fA_x = Math.sin(rotA);
                const fA_z = -Math.cos(rotA);
                const dotA = fA_x * dirAB_x + fA_z * dirAB_z;

                const fB_x = Math.sin(npc.rotY);
                const fB_z = -Math.cos(npc.rotY);
                const dotB = fB_x * (-dirAB_x) + fB_z * (-dirAB_z);

                if (dotA > 0.25 && dotB > 0.25) {
                  currentProximityUser = {
                    id: npc.id,
                    name: npc.name,
                    skin: npc.skin,
                    department: npc.department,
                    position: npc.pos,
                    rotationY: npc.rotY,
                    isMoving: false,
                    isSpeaking: false,
                    isMuted: true,
                    isScreenSharing: false,
                    claimedDeskId: null,
                    statusText: npc.statusText,
                    color: '#38bdf8',
                  };
                  currentProximityDist = dist;
                  break;
                }
              }
            }
          }
        }
      }

      // Throttled React state update for Proximity Overlay
      const lastPartnerId = lastProximityPartnerRef.current?.user.id;
      const lastDist = lastProximityPartnerRef.current?.distance || 0;

      if (currentProximityUser) {
        if (
          lastPartnerId !== (currentProximityUser as UserState).id ||
          Math.abs(lastDist - currentProximityDist) > 0.08
        ) {
          const nextVal = { user: currentProximityUser, distance: currentProximityDist };
          lastProximityPartnerRef.current = nextVal;
          setProximityPartner(nextVal);
        }
      } else if (lastPartnerId) {
        lastProximityPartnerRef.current = null;
        setProximityPartner(null);
      }

      // Update Smooth Elevator Cabin Level (only when not in scripted vertical transit)
      if (!elevatorRideRef.current && officeMeshes && officeMeshes.updateElevatorCabin) {
        officeMeshes.updateElevatorCabin(myPosRef.current.y || 0, delta);
      }

      // Camera Positioning Strategy with Height Y Offset, Pan, Distance, Occlusion Prevention & First Person Eye POV support
      const myY = myPosRef.current.y || 0;
      const pan = camPanRef.current;
      const targetLookY = isNearChloeRef.current ? myY + 1.45 : myY + 1.4;
      const targetPos = new THREE.Vector3(myPosRef.current.x + pan.x, targetLookY + pan.y, myPosRef.current.z + pan.z);
      const orbit = orbitAngleRef.current;

      if (currentCamMode === 'first_person') {
        // Hide local avatar mesh in first person for 100% unobstructed eye POV
        if (myAvatarGroupRef.current) {
          myAvatarGroupRef.current.group.visible = false;
        }

        const pitch = pitchAngleRef.current || 0.55;
        const pitchOffset = pitch - 0.55;
        const cosPitch = Math.cos(-pitchOffset);
        const sinPitch = Math.sin(-pitchOffset);

        const forwardX = Math.sin(myRotYRef.current) * cosPitch;
        const forwardY = sinPitch;
        const forwardZ = -Math.cos(myRotYRef.current) * cosPitch;

        camera.position.set(myPosRef.current.x + pan.x, myY + 1.55 + pan.y, myPosRef.current.z + pan.z);
        camera.lookAt(
          myPosRef.current.x + pan.x + forwardX * 10,
          myY + 1.55 + pan.y + forwardY * 10,
          myPosRef.current.z + pan.z + forwardZ * 10
        );
      } else {
        // Restore local avatar mesh visibility in third_person and isometric views
        if (myAvatarGroupRef.current) {
          myAvatarGroupRef.current.group.visible = true;
        }

        if (currentCamMode === 'isometric') {
          const isB1 = myY < -2.0;
          const isoDist = isB1 ? Math.min(4.8, Math.max(3.0, camDistanceRef.current)) : Math.max(5.5, camDistanceRef.current * 1.5);
          const rawY = myY + pan.y + (isB1 ? 2.6 : isoDist * 0.95);
          const clampedY = isB1 ? Math.min(-2.85, rawY) : (myY >= 8.0 ? Math.max(12.0, rawY) : (myY >= 3.0 ? Math.min(9.7, rawY) : Math.min(4.3, rawY)));
          
          camera.position.set(
            myPosRef.current.x + pan.x + Math.sin(orbit) * isoDist,
            clampedY,
            myPosRef.current.z + pan.z + Math.cos(orbit) * isoDist
          );
          camera.lookAt(targetPos);
        } else {
          // Third Person Camera - 360 Rotatable Orbit & Pitch Elevation with dynamic scroll/pinch distance and ceiling occlusion protection
          const isB1 = myY < -2.0;
          const is1F = myY >= -2.0 && myY < 3.0;
          const is2F = myY >= 3.0 && myY < 8.0;
          const is3F = myY >= 8.0;

          // When near Chloe, clamp distance and pitch for conversational over-the-shoulder framing without hitting B1 ceiling or back walls
          const camDist = isNearChloeRef.current
            ? Math.min(3.4, Math.max(2.2, camDistanceRef.current * 0.75))
            : (isB1 ? Math.min(5.2, Math.max(2.4, camDistanceRef.current)) : camDistanceRef.current);
          
          const pitch = isNearChloeRef.current
            ? Math.min(0.32, Math.max(0.08, pitchAngleRef.current || 0.22))
            : (pitchAngleRef.current || 0.55);

          const horizDist = camDist * Math.cos(pitch);
          const vertHeight = camDist * Math.sin(pitch);
          const baseHeight = isNearChloeRef.current ? 1.25 : 1.2;

          let rawCamX = myPosRef.current.x + pan.x + Math.sin(orbit) * horizDist;
          let rawCamY = myY + pan.y + baseHeight + vertHeight;
          let rawCamZ = myPosRef.current.z + pan.z + Math.cos(orbit) * horizDist;

          // Intelligent Floor-Specific Bounds Clamping (Prevents camera from entering solid ceilings, floors, or back concrete slabs)
          if (isB1) {
            // B1 Floor: Floor Y = -6.0, Ceiling slab starts at Y = -2.4
            rawCamY = Math.max(-5.4, Math.min(-2.85, rawCamY));
            const isOnTennisCourtArea = (myPosRef.current.x || 0) > 13.0;
            if (isOnTennisCourtArea) {
              rawCamX = Math.max(14.0, Math.min(38.0, rawCamX));
              rawCamZ = Math.max(-8.5, Math.min(8.5, rawCamZ));
            } else {
              rawCamX = Math.max(-10.8, Math.min(10.8, rawCamX));
              rawCamZ = Math.max(-5.2, Math.min(5.4, rawCamZ));
            }
          } else if (is1F) {
            // 1F Floor: Floor Y = 0.0, Ceiling slab at Y = 4.8
            rawCamY = Math.max(0.6, Math.min(4.35, rawCamY));
            rawCamX = Math.max(-11.5, Math.min(11.5, rawCamX));
            rawCamZ = Math.max(-9.2, Math.min(9.2, rawCamZ));
          } else if (is2F) {
            // 2F Floor: Floor Y = 5.5, Ceiling slab at Y = 10.3
            rawCamY = Math.max(6.1, Math.min(9.8, rawCamY));
            rawCamX = Math.max(-11.5, Math.min(11.5, rawCamX));
            rawCamZ = Math.max(-9.2, Math.min(9.2, rawCamZ));
          } else if (is3F) {
            // 3F Floor: Floor Y = 11.0, Open Terrace Roof
            rawCamY = Math.max(11.6, rawCamY);
            rawCamX = Math.max(-12.0, Math.min(12.0, rawCamX));
            rawCamZ = Math.max(-10.0, Math.min(10.0, rawCamZ));
          }

          camera.position.set(rawCamX, rawCamY, rawCamZ);
          camera.lookAt(targetPos);
        }
      }

      renderer.render(scene, camera);
    };

    animate();

    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
      window.removeEventListener('mousemove', handlePointerMove);
      window.removeEventListener('mouseup', handlePointerUp);
      renderer.domElement.removeEventListener('mousedown', handlePointerDown);
      renderer.domElement.removeEventListener('mouseleave', handleMouseLeaveCanvas);
      renderer.domElement.removeEventListener('wheel', handleWheel);
      renderer.domElement.removeEventListener('contextmenu', handleContextMenu);
      renderer.domElement.removeEventListener('touchstart', handleTouchStart);
      window.removeEventListener('touchmove', handleTouchMove);
      window.removeEventListener('touchend', handleTouchEnd);
      resizeObserver.disconnect();
      if (container && renderer.domElement) {
        container.removeChild(renderer.domElement);
      }
    };
  }, []);

  // Update desks in 3D scene
  useEffect(() => {
    if (officeMeshesRef.current) {
      desks.forEach((d) => officeMeshesRef.current?.updateDeskMesh(d));
    }
  }, [desks]);

  // Render Whiteboard strokes onto the 3D Whiteboard wall canvas texture!
  useEffect(() => {
    if (!officeMeshesRef.current) return;

    const wbCanvas = document.createElement('canvas');
    wbCanvas.width = 512;
    wbCanvas.height = 384;
    const ctx = wbCanvas.getContext('2d')!;

    // Render 4 popular artist portraits (Taylor Swift, Sabrina Carpenter, Coldplay, Billie Eilish)
    drawArtistPortraits(ctx, 512, 384);

    // Draw all synchronized strokes
    whiteboardStrokes.forEach((stroke) => {
      if (stroke.points.length < 2) return;
      const scaleX = 512 / 800;
      const scaleY = 384 / 500;

      ctx.strokeStyle = stroke.color;
      ctx.lineWidth = stroke.width * scaleX;
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';

      ctx.beginPath();
      ctx.moveTo(stroke.points[0].x * scaleX, stroke.points[0].y * scaleY);
      for (let i = 1; i < stroke.points.length; i++) {
        ctx.lineTo(stroke.points[i].x * scaleX, stroke.points[i].y * scaleY);
      }
      ctx.stroke();
    });

    const tex = new THREE.CanvasTexture(wbCanvas);
    tex.magFilter = THREE.NearestFilter;
    officeMeshesRef.current.updateWhiteboardTexture(tex);
  }, [whiteboardStrokes]);

  // Update Screen Share displays across all building screens when screen stream is active
  useEffect(() => {
    if (!officeMeshesRef.current) return;

    if (!screenShareStream) {
      officeMeshesRef.current.updateTvTexture(null);
      return;
    }

    const videoEl = document.createElement('video');
    videoEl.srcObject = screenShareStream;
    videoEl.muted = true;
    videoEl.playsInline = true;
    videoEl.autoplay = true;

    // Create 2D canvas buffer to continuously copy video frames to 3D texture
    const canvas = document.createElement('canvas');
    canvas.width = 1280;
    canvas.height = 720;
    const ctx = canvas.getContext('2d', { alpha: false, desynchronized: true });

    const texture = new THREE.CanvasTexture(canvas);
    texture.minFilter = THREE.LinearFilter;
    texture.magFilter = THREE.LinearFilter;
    texture.generateMipmaps = false;

    let animId: number;
    let lastDrawTime = 0;
    const TARGET_FPS_INTERVAL = 1000 / 30; // 30 FPS ceiling to prevent GPU VRAM saturation & stream stutter

    const updateFrame = (currentTime: number) => {
      if (ctx && videoEl.readyState >= videoEl.HAVE_CURRENT_DATA) {
        if (currentTime - lastDrawTime >= TARGET_FPS_INTERVAL) {
          ctx.drawImage(videoEl, 0, 0, canvas.width, canvas.height);
          texture.needsUpdate = true;
          lastDrawTime = currentTime;
        }
      }
      animId = requestAnimationFrame(updateFrame);
    };

    videoEl
      .play()
      .then(() => {
        animId = requestAnimationFrame(updateFrame);
      })
      .catch((err) => {
        console.warn('Video play deferred:', err);
        animId = requestAnimationFrame(updateFrame);
      });

    officeMeshesRef.current.updateTvTexture(texture);

    return () => {
      cancelAnimationFrame(animId);
      videoEl.pause();
      videoEl.srcObject = null;
      texture.dispose();
      if (officeMeshesRef.current) {
        officeMeshesRef.current.updateTvTexture(null);
      }
    };
  }, [screenShareStream]);

  return (
    <div className="relative w-full h-full overflow-hidden select-none bg-slate-950 touch-none">
      <div ref={containerRef} className="w-full h-full cursor-default touch-none" style={{ touchAction: 'none' }} />

      {/* Split Screen FaceTime Proximity Camera Overlay */}
      {proximityPartner && (
        <ProximityCameraOverlay
          currentUser={currentUser}
          proximityUser={proximityPartner.user}
          distance={proximityPartner.distance}
          isMuted={isMuted}
          isCameraOn={isCameraOn}
          remoteVideoStream={audioManager.getRemoteVideoStream(proximityPartner.user.id)}
          onToggleMic={onToggleMic || (() => {})}
          onToggleCamera={onToggleCamera || (() => {})}
          onSendChat={(text) => onSendChat && onSendChat(text, true)}
          onClose={() => setProximityPartner(null)}
        />
      )}
      {/* Unobtrusive Minimalist Game Mode Selector (Scoreboard & Instructions are on the 3D Wall behind Dolly Bot) */}
      {isOnTennisCourt && (
        <div className="absolute top-4 right-4 z-40 pointer-events-auto flex items-center p-1 bg-slate-900/80 border border-slate-700/60 rounded-xl shadow-lg backdrop-blur-md text-xs font-semibold">
          <button
            type="button"
            onClick={() => {
              if (officeMeshesRef.current?.setTennisGameMode) {
                officeMeshesRef.current.setTennisGameMode('training');
              }
            }}
            className={`px-2.5 py-1 rounded-lg transition-all cursor-pointer flex items-center space-x-1 ${
              (tennisMatch?.gameMode ?? 'training') === 'training'
                ? 'bg-emerald-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
            title="Battle with AI Dolly Bot"
          >
            <span>🤖 Training</span>
          </button>
          <button
            type="button"
            onClick={() => {
              if (officeMeshesRef.current?.setTennisGameMode) {
                officeMeshesRef.current.setTennisGameMode('competition');
              }
            }}
            className={`px-2.5 py-1 rounded-lg transition-all cursor-pointer flex items-center space-x-1 ${
              tennisMatch?.gameMode === 'competition'
                ? 'bg-sky-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
            title="Multiplayer Competition with Friends"
          >
            <span>👥 Competition</span>
          </button>
        </div>
      )}

      {/* Contextual Proximity Elevator Prompt (Streamlined [E] Elevator Prompt) */}
      {isNearElevator && !isElevatorMoving && (
        <div className="absolute bottom-20 left-1/2 -translate-x-1/2 z-40 pointer-events-auto">
          <button
            type="button"
            onClick={() => onOpenElevatorModalRef.current && onOpenElevatorModalRef.current()}
            className="flex items-center space-x-2.5 px-3.5 py-2 bg-slate-900/90 hover:bg-slate-800 border border-sky-500/70 hover:border-sky-400 rounded-xl text-slate-100 shadow-[0_10px_30px_rgba(0,0,0,0.6)] backdrop-blur-md transition-all cursor-pointer group"
          >
            <span className="p-1 rounded-lg bg-sky-500/20 text-sky-400 text-xs font-bold">🛗</span>
            <span className="text-xs font-bold text-slate-100 group-hover:text-sky-300 transition-colors">
              Elevator
            </span>
            <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-sky-500/20 text-sky-300 border border-sky-500/40 font-mono">
              [E]
            </span>
            <span className="text-[10px] text-slate-400 font-semibold pl-1.5 border-l border-slate-700 font-mono">
              {(currentUser?.position.y || 0) < -2 ? 'B1' : (currentUser?.position.y || 0) >= 8 ? '3F' : (currentUser?.position.y || 0) >= 3 ? '2F' : '1F'}
            </span>
          </button>
        </div>
      )}

      {/* Elevator In-Motion Transit Banner */}
      {isElevatorMoving && (
        <div className="absolute top-20 left-1/2 -translate-x-1/2 z-40 pointer-events-none">
          <div className="flex items-center space-x-2.5 px-4 py-2 bg-slate-950/90 border border-sky-500/70 rounded-2xl shadow-[0_12px_36px_rgba(0,0,0,0.8)] backdrop-blur-xl text-slate-100">
            <span className="p-1 rounded-xl bg-sky-500/20 text-sky-400 text-sm font-black animate-bounce">
              🛗
            </span>
            <div>
              <div className="text-xs font-bold text-sky-300 flex items-center gap-1.5">
                <span>Elevator In Transit</span>
                <span className="w-1.5 h-1.5 rounded-full bg-sky-400 animate-ping" />
              </div>
              <p className="text-[10px] text-slate-400 font-medium">Controls locked until arrival</p>
            </div>
          </div>
        </div>
      )}

      {/* Minimal Chat Input Bar - Only appears when near Chloe */}
      {isNearChloe && (
        <MinimalChatInputBar
          currentUserName={currentUser?.name || 'there'}
          onOpenAgentFlow={() => {
            if (onOpenDataCenter) onOpenDataCenter();
          }}
          onChloeSpeakingChange={(speaking) => {
            isChloeSpeakingRef.current = speaking;
          }}
          onChloeWave={() => {
            const chloeAvatar = avatarMeshesRef.current.get('npc_b1_chloe');
            if (chloeAvatar) {
              chloeAvatar.triggerGesture('wave');
            }
          }}
        />
      )}

      {/* Unobstructed Clean Viewport - Top Left blocking component removed */}
    </div>
  );
};
