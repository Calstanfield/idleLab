import React, { useState, useEffect, useRef } from 'react';
import ReactMarkdown from 'react-markdown';
import {
  Mic,
  MicOff,
  Volume2,
  VolumeX,
  Send,
  Wand2,
  Sparkles,
  ShieldCheck,
  Cpu,
  Database,
  Terminal,
  Activity,
  CheckCircle2,
  AlertCircle,
  Clock,
  Key,
  Maximize2,
  Minimize2,
  X,
  ChevronRight,
  Layers,
  RefreshCw,
  Copy,
  Check,
  Radio,
  Sliders,
  Share2,
  ChevronDown,
} from 'lucide-react';
import { chloeVoice } from '../lib/chloeVoice';
import { chloeAgentClient, ChloeAgentResponse } from '../lib/chloeAgentClient';
import {
  simulatorEngine,
  ActiveToolTrace,
  SessionMemoryStore,
} from '../lib/simulatorEngine';
import { soundEffects } from '../lib/soundEffects';
import { socketClient } from '../lib/socketClient';
import { parseChloeIntent } from '../lib/speechCommandListener';

interface ChloeProximityHUDProps {
  isNear: boolean;
  distance: number;
  currentUserName?: string;
  onSendChat?: (text: string, isProximity: boolean) => void;
  onChloeSpeakingChange?: (speaking: boolean) => void;
  onChloeWave?: () => void;
}

const SUPPORTED_LANGUAGES = [
  { code: 'auto', label: 'Auto Detect', flag: '🌐', speechLang: 'en-US' },
  { code: 'en', label: 'English', flag: '🇺🇸', speechLang: 'en-US' },
  { code: 'es', label: 'Español', flag: '🇪🇸', speechLang: 'es-ES' },
  { code: 'fr', label: 'Français', flag: '🇫🇷', speechLang: 'fr-FR' },
  { code: 'ja', label: '日本語', flag: '🇯🇵', speechLang: 'ja-JP' },
  { code: 'zh', label: '中文', flag: '🇨🇳', speechLang: 'zh-CN' },
  { code: 'de', label: 'Deutsch', flag: '🇩🇪', speechLang: 'de-DE' },
];

export const ChloeProximityHUD: React.FC<ChloeProximityHUDProps> = ({
  isNear,
  currentUserName,
  onSendChat,
  onChloeSpeakingChange,
  onChloeWave,
}) => {
  const displayName =
    currentUserName && currentUserName !== 'there' && currentUserName.trim()
      ? currentUserName.trim()
      : 'Colleague';

  // State Management
  const [isExpanded, setIsExpanded] = useState<boolean>(false);
  const [isDismissed, setIsDismissed] = useState<boolean>(false);
  const [isVoiceMuted, setIsVoiceMuted] = useState<boolean>(false);
  const [isSpeaking, setIsSpeaking] = useState<boolean>(false);
  const [isListening, setIsListening] = useState<boolean>(false);
  const [isExecuting, setIsExecuting] = useState<boolean>(false);
  const [isRefining, setIsRefining] = useState<boolean>(false);
  const [inputText, setInputText] = useState<string>('');
  const [selectedLanguage, setSelectedLanguage] = useState<string>('auto');
  const [showLanguageMenu, setShowLanguageMenu] = useState<boolean>(false);
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  // New Key/Value in Memory Bank
  const [newMemKey, setNewMemKey] = useState<string>('');
  const [newMemVal, setNewMemVal] = useState<string>('');
  const [showAddMemModal, setShowAddMemModal] = useState<boolean>(false);

  // Chat Transcripts
  const [chatLog, setChatLog] = useState<
    Array<{ id: string; role: 'user' | 'chloe' | 'system'; text: string; timestamp: string }>
  >([
    {
      id: 'init-1',
      role: 'chloe',
      text: `Hey ${displayName}, good to see you down here, what should we do today?`,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    },
  ]);

  // Simulator Engine Subscriptions
  const [currentTrace, setCurrentTrace] = useState<ActiveToolTrace | null>(() => simulatorEngine.getCurrentTrace());
  const [memoryStore, setMemoryStore] = useState<SessionMemoryStore>(() => simulatorEngine.getMemory());

  const transcriptEndRef = useRef<HTMLDivElement>(null);
  const hasGreetedRef = useRef<boolean>(false);
  const speechRecognitionRef = useRef<any>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // Subscribe to simulatorEngine updates
  useEffect(() => {
    const unsub = simulatorEngine.subscribe((trace, memory) => {
      setCurrentTrace(trace);
      setMemoryStore(memory);
    });
    return () => unsub();
  }, []);

  // Waveform Visualizer on Canvas
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId: number;
    let phase = 0;

    const renderWave = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      const width = canvas.width;
      const height = canvas.height;
      const midY = height / 2;

      // Base bars
      const numBars = 24;
      const barWidth = width / numBars;

      for (let i = 0; i < numBars; i++) {
        const factor = isSpeaking
          ? Math.sin(phase + i * 0.4) * 0.5 + 0.5
          : isListening
          ? Math.cos(phase * 1.5 + i * 0.3) * 0.4 + 0.3
          : 0.15;

        const barHeight = Math.max(3, factor * (height * 0.85));
        const x = i * barWidth + barWidth * 0.2;
        const y = midY - barHeight / 2;

        const grad = ctx.createLinearGradient(0, y, 0, y + barHeight);
        if (isSpeaking) {
          grad.addColorStop(0, '#38bdf8');
          grad.addColorStop(1, '#6366f1');
        } else if (isListening) {
          grad.addColorStop(0, '#f43f5e');
          grad.addColorStop(1, '#fb923c');
        } else {
          grad.addColorStop(0, '#475569');
          grad.addColorStop(1, '#334155');
        }

        ctx.fillStyle = grad;
        ctx.beginPath();
        ctx.roundRect(x, y, barWidth * 0.6, barHeight, 2);
        ctx.fill();
      }

      phase += isSpeaking ? 0.18 : isListening ? 0.25 : 0.03;
      animId = requestAnimationFrame(renderWave);
    };

    renderWave();
    return () => cancelAnimationFrame(animId);
  }, [isSpeaking, isListening]);

  // Handle Proximity Entrance Greeting
  useEffect(() => {
    if (isNear) {
      setIsDismissed(false);
      if (!hasGreetedRef.current) {
        hasGreetedRef.current = true;
        const greeting = `Hey ${displayName}, good to see you down here, what should we do today?`;
        if (!isVoiceMuted) {
          setIsSpeaking(true);
          if (onChloeSpeakingChange) onChloeSpeakingChange(true);
          simulatorEngine.ttsAudioStreamer(
            greeting,
            () => {
              setIsSpeaking(true);
              if (onChloeSpeakingChange) onChloeSpeakingChange(true);
            },
            () => {
              setIsSpeaking(false);
              if (onChloeSpeakingChange) onChloeSpeakingChange(false);
            }
          );
        }
        if (onChloeWave) onChloeWave();
      }
    } else {
      chloeVoice.stop();
      setIsSpeaking(false);
      if (onChloeSpeakingChange) onChloeSpeakingChange(false);
    }
  }, [isNear, isVoiceMuted, displayName]);

  // Auto-scroll chat transcript
  useEffect(() => {
    transcriptEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [chatLog]);

  // Trigger Execution
  const handleExecutePrompt = async (promptToRun: string) => {
    const text = promptToRun.trim();
    if (!text || isExecuting) return;

    setInputText('');
    setIsExecuting(true);
    soundEffects.play('confirm');

    // Append to Chat log
    const nowTime = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    setChatLog((prev) => [
      ...prev,
      { id: `user-${Date.now()}`, role: 'user', text, timestamp: nowTime },
    ]);

    const intent = parseChloeIntent(text);

    // Spatial zone navigation via FSM
    if (intent.spatialZone) {
      socketClient.send({
        type: 'CHLOE_NAVIGATE_ZONE',
        targetZone: intent.spatialZone,
      });
      simulatorEngine.logFsmStateChange('NAVIGATING_TO_DESK', intent.spatialZone, undefined, `HUD: "${text}"`);
    }

    // Office object trigger via FSM
    if (intent.interactiveObject) {
      socketClient.send({
        type: 'CHLOE_TRIGGER_OBJECT',
        objectId: intent.interactiveObject,
        action: intent.action || 'open',
      });
      simulatorEngine.logFsmStateChange('EXECUTING_WORKFLOW', undefined, intent.interactiveObject, `HUD: "${text}"`);
    }

    if (onSendChat) {
      onSendChat(`[To Chloe]: ${text}`, true);
    }

    try {
      const response = await simulatorEngine.executeAutonomousCommand(
        text,
        displayName,
        () => {
          setIsSpeaking(true);
          if (onChloeSpeakingChange) onChloeSpeakingChange(true);
        },
        () => {
          setIsSpeaking(false);
          if (onChloeSpeakingChange) onChloeSpeakingChange(false);
        }
      );

      const replyText = response.text || 'Workflow executed and verified.';
      setChatLog((prev) => [
        ...prev,
        { id: `chloe-${Date.now()}`, role: 'chloe', text: replyText, timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) },
      ]);
    } catch (err: any) {
      setChatLog((prev) => [
        ...prev,
        { id: `sys-${Date.now()}`, role: 'system', text: `Execution Exception: ${err.message || 'Unknown error'}`, timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) },
      ]);
    } finally {
      setIsExecuting(false);
    }
  };

  // AI Prompt Refiner
  const handleRefineInput = async () => {
    const raw = inputText.trim();
    if (!raw || isRefining) return;
    setIsRefining(true);
    try {
      const res = await chloeAgentClient.refinePrompt(raw, displayName, selectedLanguage);
      if (res.success && res.refinedPrompt) {
        setInputText(res.refinedPrompt);
      }
    } finally {
      setIsRefining(false);
    }
  };

  // Voice Recognition (Speech-to-Text)
  const toggleSpeechRecognition = () => {
    if (typeof window === 'undefined') return;
    const SpeechRec = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRec) {
      alert('Speech recognition is not supported in this browser. Please use Chrome, Edge, or Safari.');
      return;
    }

    if (isListening) {
      if (speechRecognitionRef.current) {
        speechRecognitionRef.current.stop();
      }
      setIsListening(false);
      return;
    }

    try {
      const rec = new SpeechRec();
      const currentLang = SUPPORTED_LANGUAGES.find((l) => l.code === selectedLanguage);
      rec.lang = currentLang?.speechLang || 'en-US';
      rec.continuous = false;
      rec.interimResults = true;

      rec.onstart = () => {
        setIsListening(true);
        setInputText('');
      };

      rec.onresult = (event: any) => {
        let transcript = '';
        for (let i = event.resultIndex; i < event.results.length; ++i) {
          transcript += event.results[i][0].transcript;
        }
        if (transcript.trim()) {
          setInputText(transcript.trim());
        }
      };

      rec.onerror = () => setIsListening(false);
      rec.onend = () => setIsListening(false);

      speechRecognitionRef.current = rec;
      rec.start();
    } catch {
      setIsListening(false);
    }
  };

  const handleCopyJSON = (data: any, keyName: string) => {
    if (typeof navigator !== 'undefined' && navigator.clipboard) {
      navigator.clipboard.writeText(JSON.stringify(data, null, 2));
      setCopiedKey(keyName);
      setTimeout(() => setCopiedKey(null), 1800);
    }
  };

  if (!isNear || isDismissed) return null;

  return (
    <div
      id="idlelab-simulator-dashboard"
      className={`fixed transition-all duration-300 z-50 pointer-events-auto select-none ${
        isExpanded
          ? 'inset-3 sm:inset-6 max-w-7xl mx-auto flex flex-col'
          : 'bottom-20 left-1/2 -translate-x-1/2 w-[95vw] sm:w-[680px] max-w-2xl'
      }`}
    >
      <div className="bg-[#0b0f19]/95 backdrop-blur-2xl border border-sky-500/30 rounded-2xl shadow-[0_25px_60px_rgba(0,0,0,0.85)] flex flex-col text-slate-100 overflow-hidden h-full">
        {/* HEADER: idleLab Simulator Interface (Active Session: #9948-Live) */}
        <div className="flex items-center justify-between px-3.5 py-2.5 bg-slate-900/90 border-b border-white/10 shrink-0">
          <div className="flex items-center space-x-2.5 min-w-0">
            {/* Chloe / Avatar Pill */}
            <div className="relative flex items-center justify-center w-8 h-8 rounded-xl bg-gradient-to-tr from-sky-500 via-indigo-500 to-amber-300 text-white font-black text-xs shadow-md border border-white/20 shrink-0">
              <span>CB</span>
              <span
                className={`absolute -top-1 -right-1 w-2.5 h-2.5 rounded-full ${
                  isSpeaking ? 'bg-emerald-400 animate-ping' : isListening ? 'bg-rose-500 animate-pulse' : 'bg-sky-400'
                }`}
              />
            </div>

            <div className="min-w-0">
              <div className="flex items-center space-x-2">
                <span className="font-bold text-xs sm:text-sm text-white tracking-tight truncate">
                  idleLab Simulator Interface
                </span>
                <span className="px-1.5 py-0.5 rounded-md bg-emerald-500/15 text-emerald-300 border border-emerald-500/30 text-[10px] font-mono font-semibold flex items-center space-x-1 shrink-0">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                  <span>#9948-Live</span>
                </span>
              </div>
              <div className="text-[10px] text-slate-400 flex items-center space-x-2 font-mono">
                <span>Autonomous Engine • B1 Executive Stage</span>
                <span className="text-slate-600">•</span>
                <span className="text-sky-400">Zero-Trust Verified</span>
              </div>
            </div>
          </div>

          {/* Controls: Audio Mute, Expand/Collapse, Dismiss */}
          <div className="flex items-center space-x-1.5 shrink-0">
            {/* Audio Streamer Mute Toggle */}
            <button
              type="button"
              onClick={() => {
                const next = !isVoiceMuted;
                setIsVoiceMuted(next);
                if (next) {
                  chloeVoice.stop();
                  setIsSpeaking(false);
                }
              }}
              className={`p-1.5 rounded-lg border text-xs transition-colors cursor-pointer ${
                isVoiceMuted
                  ? 'bg-rose-500/20 text-rose-300 border-rose-500/40'
                  : 'bg-white/5 hover:bg-white/10 border-white/10 text-sky-300'
              }`}
              title={isVoiceMuted ? 'Unmute ElevenLabs Neural Audio' : 'Mute ElevenLabs Audio Streamer'}
            >
              {isVoiceMuted ? <VolumeX className="w-3.5 h-3.5" /> : <Volume2 className="w-3.5 h-3.5" />}
            </button>

            {/* Expand / Matrix Mode Toggle */}
            <button
              type="button"
              onClick={() => setIsExpanded(!isExpanded)}
              className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 border border-white/10 text-slate-300 hover:text-white transition-colors cursor-pointer hidden sm:flex items-center space-x-1"
              title={isExpanded ? 'Docked HUD View' : 'Full 3-Column Simulator Matrix View'}
            >
              {isExpanded ? <Minimize2 className="w-3.5 h-3.5" /> : <Maximize2 className="w-3.5 h-3.5" />}
              <span className="text-[10px] font-medium">{isExpanded ? 'Dock' : 'Matrix'}</span>
            </button>

            {/* Close Button */}
            <button
              type="button"
              onClick={() => {
                setIsDismissed(true);
                chloeVoice.stop();
              }}
              className="p-1.5 rounded-lg bg-white/5 hover:bg-rose-500/20 text-slate-400 hover:text-rose-300 border border-white/10 transition-colors cursor-pointer"
              title="Close Simulator HUD"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* BODY CONTAINER (3-COLUMN MATRIX LAYOUT) */}
        <div
          className={`grid gap-2.5 p-2.5 overflow-hidden ${
            isExpanded
              ? 'grid-cols-1 md:grid-cols-3 flex-1 min-h-0'
              : 'grid-cols-1 max-h-[460px] overflow-y-auto'
          }`}
        >
          {/* COLUMN 1: CONVERSATIONAL / VOICE STAGE */}
          <div className="flex flex-col bg-slate-950/60 border border-white/10 rounded-xl p-2.5 min-h-[220px] overflow-hidden">
            <div className="flex items-center justify-between pb-1.5 border-b border-white/10 text-xs font-semibold text-slate-300 mb-2">
              <div className="flex items-center space-x-1.5">
                <Radio className="w-3.5 h-3.5 text-sky-400" />
                <span>1. Voice & Conversational Stage</span>
              </div>
              <span className="text-[10px] font-mono text-slate-500">ElevenLabs TTS</span>
            </div>

            {/* Audio Waveform Visualizer & Status */}
            <div className="bg-slate-900/80 border border-white/5 rounded-lg p-2 mb-2 flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <canvas ref={canvasRef} width={90} height={24} className="rounded" />
                <span className="text-[11px] text-slate-300 font-medium">
                  {isSpeaking ? (
                    <span className="text-sky-300 animate-pulse">Streaming Neural Voice...</span>
                  ) : isListening ? (
                    <span className="text-rose-300 animate-pulse">Listening to user mic...</span>
                  ) : isExecuting ? (
                    <span className="text-amber-300">Executing autonomous tool...</span>
                  ) : (
                    <span className="text-slate-400">Ready • Standby</span>
                  )}
                </span>
              </div>
              <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-sky-500/10 text-sky-300 border border-sky-500/20">
                128 kbps
              </span>
            </div>

            {/* Chat Transcript Feed */}
            <div className="flex-1 overflow-y-auto space-y-2 pr-1 min-h-[100px] max-h-[240px] text-xs font-normal">
              {chatLog.map((msg) => (
                <div
                  key={msg.id}
                  className={`p-2 rounded-xl border text-xs leading-relaxed ${
                    msg.role === 'user'
                      ? 'bg-sky-600/15 border-sky-500/30 text-sky-100 ml-4'
                      : msg.role === 'system'
                      ? 'bg-rose-950/30 border-rose-500/30 text-rose-200'
                      : 'bg-white/5 border-white/10 text-slate-200 mr-4'
                  }`}
                >
                  <div className="flex items-center justify-between text-[10px] font-bold mb-1 opacity-70">
                    <span className={msg.role === 'user' ? 'text-sky-300' : 'text-amber-300'}>
                      {msg.role === 'user' ? displayName : 'Chloe Becker'}
                    </span>
                    <span className="font-mono">{msg.timestamp}</span>
                  </div>
                  <div className="prose prose-invert max-w-none text-xs [&>p]:mb-0.5 [&>strong]:text-amber-300">
                    <ReactMarkdown>{msg.text}</ReactMarkdown>
                  </div>
                </div>
              ))}
              <div ref={transcriptEndRef} />
            </div>

            {/* Input Bar with Speech-to-Text & Prompt Refiner */}
            <form
              onSubmit={(e) => {
                e.preventDefault();
                handleExecutePrompt(inputText);
              }}
              className="mt-2 pt-2 border-t border-white/10 flex items-center space-x-1.5"
            >
              <div className="relative flex-1">
                <input
                  type="text"
                  value={inputText}
                  onChange={(e) => setInputText(e.target.value)}
                  placeholder={isListening ? 'Listening...' : 'Speak or type autonomous command...'}
                  disabled={isExecuting || isRefining}
                  className={`w-full border rounded-xl px-2.5 py-1.5 text-xs placeholder-slate-500 outline-none transition-all pr-7 ${
                    isListening
                      ? 'bg-rose-950/40 border-rose-500/60 text-white'
                      : 'bg-white/5 border-white/10 focus:border-sky-500/50 text-slate-100'
                  }`}
                />
                {inputText.trim().length > 3 && !isListening && (
                  <button
                    type="button"
                    onClick={handleRefineInput}
                    disabled={isRefining}
                    className="absolute right-1.5 top-1/2 -translate-y-1/2 p-1 text-amber-300 hover:text-amber-200 cursor-pointer"
                    title="✨ AI Prompt Refiner"
                  >
                    <Wand2 className={`w-3.5 h-3.5 ${isRefining ? 'animate-spin' : ''}`} />
                  </button>
                )}
              </div>

              <button
                type="button"
                onClick={toggleSpeechRecognition}
                className={`p-1.5 rounded-xl border transition-all cursor-pointer ${
                  isListening
                    ? 'bg-rose-600 border-rose-500 text-white animate-pulse'
                    : 'bg-white/5 hover:bg-white/10 border-white/10 text-slate-300'
                }`}
                title="Toggle Mic Voice Input"
              >
                {isListening ? <MicOff className="w-3.5 h-3.5" /> : <Mic className="w-3.5 h-3.5" />}
              </button>

              <button
                type="submit"
                disabled={!inputText.trim() || isExecuting}
                className="px-2.5 py-1.5 bg-sky-600 hover:bg-sky-500 disabled:opacity-40 text-white rounded-xl text-xs font-semibold shadow transition-all cursor-pointer shrink-0"
              >
                <Send className="w-3.5 h-3.5" />
              </button>
            </form>
          </div>

          {/* COLUMN 2: LIVE TOOL EXECUTION DRAWER */}
          <div className="flex flex-col bg-slate-950/60 border border-white/10 rounded-xl p-2.5 min-h-[220px] overflow-hidden">
            <div className="flex items-center justify-between pb-1.5 border-b border-white/10 text-xs font-semibold text-slate-300 mb-2">
              <div className="flex items-center space-x-1.5">
                <Terminal className="w-3.5 h-3.5 text-amber-400" />
                <span>2. Live Tool Execution Drawer</span>
              </div>
              <span
                className={`px-1.5 py-0.5 rounded text-[9px] font-bold font-mono ${
                  currentTrace?.status === 'SUCCESS'
                    ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                    : currentTrace?.status === 'RUNNING'
                    ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30 animate-pulse'
                    : 'bg-slate-800 text-slate-400 border border-white/5'
                }`}
              >
                {currentTrace?.status || 'IDLE'}
              </span>
            </div>

            {/* Active Tool Banner */}
            <div className="bg-slate-900/90 border border-white/10 rounded-lg p-2 mb-2">
              <div className="text-[10px] text-slate-400 uppercase font-mono tracking-wider mb-0.5">
                ⚡ Active Tool Invocation
              </div>
              <div className="text-xs font-mono font-bold text-amber-300 flex items-center justify-between">
                <span>{currentTrace?.toolName || 'execute_workflow_action'}</span>
                <span className="text-[10px] text-slate-400">
                  {currentTrace?.durationMs ? `${currentTrace.durationMs}ms` : '0ms'}
                </span>
              </div>
            </div>

            {/* Step-by-Step Thought / Action / Observation Trace */}
            <div className="flex-1 overflow-y-auto space-y-1.5 pr-1 min-h-[100px] max-h-[160px] text-xs">
              {currentTrace?.steps && currentTrace.steps.length > 0 ? (
                currentTrace.steps.map((st) => (
                  <div
                    key={st.id}
                    className="p-1.5 rounded-lg bg-white/5 border border-white/5 text-[11px] leading-snug"
                  >
                    <div className="flex items-center space-x-1.5 text-[10px] font-bold mb-0.5">
                      {st.type === 'thought' && <Sparkles className="w-3 h-3 text-purple-400" />}
                      {st.type === 'action' && <Cpu className="w-3 h-3 text-sky-400" />}
                      {st.type === 'observation' && <CheckCircle2 className="w-3 h-3 text-emerald-400" />}
                      <span className="text-slate-300 uppercase tracking-wide font-mono">{st.title}</span>
                      <span className="text-slate-500 text-[9px] ml-auto">
                        {st.status === 'running' ? '⏳' : '✓'}
                      </span>
                    </div>
                    <p className="text-slate-300">{st.detail}</p>
                  </div>
                ))
              ) : (
                <div className="text-center py-6 text-slate-500 text-xs italic">
                  Autonomous loop idle. Trigger a quick prompt below to inspect real-time tool execution.
                </div>
              )}
            </div>

            {/* JSON Payload Inspector */}
            {currentTrace?.inputPayload && (
              <div className="mt-2 pt-2 border-t border-white/10">
                <div className="flex items-center justify-between text-[10px] font-mono text-slate-400 mb-1">
                  <span>[JSON PAYLOAD]</span>
                  <button
                    type="button"
                    onClick={() => handleCopyJSON(currentTrace.inputPayload, 'payload')}
                    className="text-sky-400 hover:text-sky-300 flex items-center space-x-0.5 cursor-pointer"
                  >
                    {copiedKey === 'payload' ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                    <span>{copiedKey === 'payload' ? 'Copied' : 'Copy'}</span>
                  </button>
                </div>
                <pre className="p-1.5 bg-black/60 rounded-lg text-[10px] font-mono text-emerald-400 overflow-x-auto max-h-20 no-scrollbar">
                  {JSON.stringify(currentTrace.inputPayload, null, 2)}
                </pre>
              </div>
            )}
          </div>

          {/* COLUMN 3: SYSTEM STATE & MEMORY BANK */}
          <div className="flex flex-col bg-slate-950/60 border border-white/10 rounded-xl p-2.5 min-h-[220px] overflow-hidden">
            <div className="flex items-center justify-between pb-1.5 border-b border-white/10 text-xs font-semibold text-slate-300 mb-2">
              <div className="flex items-center space-x-1.5">
                <Database className="w-3.5 h-3.5 text-indigo-400" />
                <span>3. System State & Memory Bank</span>
              </div>
              <span className="text-[10px] font-mono text-emerald-400 flex items-center space-x-1">
                <ShieldCheck className="w-3 h-3" />
                <span>IAM Verified</span>
              </span>
            </div>

            {/* Active Context Card */}
            <div className="bg-slate-900/80 border border-white/10 rounded-lg p-2 mb-2">
              <div className="text-[10px] text-slate-400 uppercase font-mono tracking-wider mb-0.5">
                Active Context
              </div>
              <div className="text-xs font-semibold text-sky-200 truncate">{memoryStore.activeContext}</div>
            </div>

            {/* Cross-Session Persistent Memory Tags */}
            <div className="flex-1 overflow-y-auto space-y-1.5 pr-1 min-h-[100px] max-h-[180px]">
              <div className="flex items-center justify-between text-[10px] font-bold text-slate-400 uppercase font-mono">
                <span>Cross-Session Memory ({Object.keys(memoryStore.memoryBank).length})</span>
                <button
                  type="button"
                  onClick={() => setShowAddMemModal(!showAddMemModal)}
                  className="text-sky-400 hover:text-sky-300 cursor-pointer"
                >
                  + Add Key
                </button>
              </div>

              {/* Add Key Form */}
              {showAddMemModal && (
                <div className="p-2 bg-slate-900 border border-sky-500/40 rounded-lg space-y-1.5 animate-in fade-in">
                  <input
                    type="text"
                    value={newMemKey}
                    onChange={(e) => setNewMemKey(e.target.value)}
                    placeholder="Memory Key (e.g. preferred_format)"
                    className="w-full bg-black/50 border border-white/10 rounded px-2 py-1 text-xs text-white"
                  />
                  <input
                    type="text"
                    value={newMemVal}
                    onChange={(e) => setNewMemVal(e.target.value)}
                    placeholder="Value (e.g. Markdown Tables)"
                    className="w-full bg-black/50 border border-white/10 rounded px-2 py-1 text-xs text-white"
                  />
                  <div className="flex justify-end space-x-1 pt-1">
                    <button
                      type="button"
                      onClick={() => setShowAddMemModal(false)}
                      className="px-2 py-0.5 rounded text-[10px] text-slate-400 hover:text-white"
                    >
                      Cancel
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        if (newMemKey.trim() && newMemVal.trim()) {
                          simulatorEngine.updateMemoryKey(newMemKey.trim(), newMemVal.trim());
                          setNewMemKey('');
                          setNewMemVal('');
                          setShowAddMemModal(false);
                        }
                      }}
                      className="px-2 py-0.5 rounded bg-sky-600 text-white text-[10px] font-semibold"
                    >
                      Save Memory
                    </button>
                  </div>
                </div>
              )}

              {Object.entries(memoryStore.memoryBank).map(([k, v]) => (
                <div
                  key={k}
                  className="p-1.5 rounded-lg bg-white/5 border border-white/5 flex items-center justify-between text-[11px] gap-2"
                >
                  <div className="min-w-0">
                    <span className="font-mono text-purple-300 font-semibold text-[10px] block truncate">
                      {k}
                    </span>
                    <span className="text-slate-300 text-[10px] truncate block">
                      {typeof v === 'object' ? JSON.stringify(v) : String(v)}
                    </span>
                  </div>
                  <button
                    type="button"
                    onClick={() => simulatorEngine.removeMemoryKey(k)}
                    className="text-slate-500 hover:text-rose-400 p-0.5 cursor-pointer shrink-0"
                    title="Remove Memory Key"
                  >
                    <X className="w-3 h-3" />
                  </button>
                </div>
              ))}
            </div>

            {/* Zero-Trust Token Verification Info */}
            <div className="mt-2 pt-2 border-t border-white/10 flex items-center justify-between text-[10px] font-mono text-slate-400">
              <span className="flex items-center space-x-1 text-emerald-300">
                <Key className="w-3 h-3 text-emerald-400" />
                <span>Zero-Trust Token: #9948</span>
              </span>
              <span>Level-3 Governance</span>
            </div>
          </div>
        </div>

        {/* FOOTER: Prompt Chips / Quick Actions */}
        <div className="p-2.5 bg-slate-900/90 border-t border-white/10 flex items-center gap-1.5 overflow-x-auto no-scrollbar shrink-0">
          <span className="text-[10px] font-bold text-slate-400 uppercase font-mono whitespace-nowrap pl-1 pr-1">
            Quick Workflows:
          </span>

          <button
            type="button"
            onClick={() => handleExecutePrompt('Resolve inventory SKU desync for warehouse cluster #4')}
            disabled={isExecuting}
            className="px-2.5 py-1 rounded-lg bg-white/5 hover:bg-sky-500/20 active:bg-sky-500/30 text-slate-200 hover:text-sky-300 border border-white/10 hover:border-sky-500/40 text-[11px] font-medium whitespace-nowrap transition-all cursor-pointer flex items-center space-x-1"
          >
            <span>📦 Fix SKU Desync</span>
          </button>

          <button
            type="button"
            onClick={() => handleExecutePrompt('Run PM release pipeline and resolve sprint blockers')}
            disabled={isExecuting}
            className="px-2.5 py-1 rounded-lg bg-white/5 hover:bg-indigo-500/20 active:bg-indigo-500/30 text-slate-200 hover:text-indigo-300 border border-white/10 hover:border-indigo-500/40 text-[11px] font-medium whitespace-nowrap transition-all cursor-pointer flex items-center space-x-1"
          >
            <span>🔄 Run PM Pipeline</span>
          </button>

          <button
            type="button"
            onClick={() => handleExecutePrompt('Validate gateway policy for zero-trust IAM tokens')}
            disabled={isExecuting}
            className="px-2.5 py-1 rounded-lg bg-white/5 hover:bg-emerald-500/20 active:bg-emerald-500/30 text-slate-200 hover:text-emerald-300 border border-white/10 hover:border-emerald-500/40 text-[11px] font-medium whitespace-nowrap transition-all cursor-pointer flex items-center space-x-1"
          >
            <span>🛡️ Validate Gateway Policy</span>
          </button>

          <button
            type="button"
            onClick={() => handleExecutePrompt('Query session memory bank and sync cross-session variables')}
            disabled={isExecuting}
            className="px-2.5 py-1 rounded-lg bg-white/5 hover:bg-purple-500/20 active:bg-purple-500/30 text-slate-200 hover:text-purple-300 border border-white/10 hover:border-purple-500/40 text-[11px] font-medium whitespace-nowrap transition-all cursor-pointer flex items-center space-x-1"
          >
            <span>🧠 Sync Memory Bank</span>
          </button>

          <button
            type="button"
            onClick={() => handleExecutePrompt('Audit project roadmap for single points of failure')}
            disabled={isExecuting}
            className="px-2.5 py-1 rounded-lg bg-white/5 hover:bg-amber-500/20 active:bg-amber-500/30 text-slate-200 hover:text-amber-300 border border-white/10 hover:border-amber-500/40 text-[11px] font-medium whitespace-nowrap transition-all cursor-pointer flex items-center space-x-1"
          >
            <span>📊 Audit Blindspots</span>
          </button>
        </div>
      </div>
    </div>
  );
};
