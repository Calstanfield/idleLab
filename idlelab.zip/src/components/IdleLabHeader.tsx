import React, { useState } from 'react';
import {
  ChevronDown,
  Play,
  Share2,
  Users,
  PanelLeft,
  PanelRight,
  Layers,
  Sparkles,
  Sliders,
  Check,
  Tv,
  Palette,
  Music,
} from 'lucide-react';
import { UserState } from '../types';
import { AudioPlayerPlugin } from './AudioPlayerPlugin';

interface FigmaHeaderProps {
  currentUser: UserState | null;
  onlineCount: number;
  isLayersPanelOpen: boolean;
  isInspectorPanelOpen: boolean;
  onToggleLayersPanel: () => void;
  onToggleInspectorPanel: () => void;
  onStartScreenShare: () => void;
  isScreenSharing: boolean;
  onOpenAvatarCustomizer?: () => void;
  onOpenWebShare?: () => void;
  onOpenChloeModal?: () => void;
  onOpenLabGuide?: () => void;
}

export const FigmaHeader: React.FC<FigmaHeaderProps> = ({
  currentUser,
  onlineCount,
  isLayersPanelOpen,
  isInspectorPanelOpen,
  onToggleLayersPanel,
  onToggleInspectorPanel,
  onStartScreenShare,
  isScreenSharing,
  onOpenAvatarCustomizer,
  onOpenWebShare,
  onOpenChloeModal,
  onOpenLabGuide,
}) => {
  const [isFileMenuOpen, setIsFileMenuOpen] = useState(false);
  return (
    <header className="fixed top-0 left-0 right-0 h-10 bg-[#1e1e1e]/95 backdrop-blur-md border-b border-white/10 z-40 px-3 flex items-center justify-between text-neutral-200 select-none text-xs">
      {/* Left Branding & Unified File Dropdown */}
      <div className="flex items-center space-x-2">
        {/* Figma / App Logo */}
        <button
          onClick={() => setIsFileMenuOpen(!isFileMenuOpen)}
          className="p-1 hover:bg-white/10 rounded-md transition-all cursor-pointer text-white flex items-center space-x-1"
          title="Main Menu"
        >
          <div className="w-3.5 h-3.5 grid grid-cols-2 gap-0.5">
            <div className="w-1.5 h-1.5 rounded-full bg-rose-500" />
            <div className="w-1.5 h-1.5 rounded-full bg-amber-500" />
            <div className="w-1.5 h-1.5 rounded-full bg-purple-500" />
            <div className="w-1.5 h-1.5 rounded-full bg-sky-500" />
          </div>
        </button>

        <div className="h-3.5 w-px bg-white/10" />

        {/* Unified Room Pill & Dropdown */}
        <div className="relative">
          <button
            onClick={() => setIsFileMenuOpen(!isFileMenuOpen)}
            className="flex items-center space-x-1.5 px-2 py-1 rounded-md bg-white/5 hover:bg-white/10 border border-white/5 transition-all cursor-pointer text-xs"
          >
            <span className="font-semibold text-white tracking-tight">IdleLab</span>
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
            <span className="text-[11px] text-neutral-400 font-mono hidden sm:inline">{onlineCount}</span>
            <ChevronDown className="w-3 h-3 text-neutral-400" />
          </button>

          {isFileMenuOpen && (
            <div className="absolute top-full left-0 mt-1.5 w-60 bg-[#1e1e1e]/98 backdrop-blur-xl border border-white/10 rounded-xl shadow-2xl p-2 z-50 text-xs text-neutral-200 animate-in fade-in zoom-in-95 duration-100">
              <div className="px-2 py-1 flex items-center justify-between border-b border-white/10 pb-1.5 mb-1.5">
                <div>
                  <div className="font-bold text-white text-[13px]">IdleLab Virtual Space</div>
                  <div className="text-[10px] text-neutral-400">Host: Benz-Carlton • Enterprise</div>
                </div>
                <span className="px-1.5 py-0.5 rounded text-[10px] bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 font-medium">
                  {onlineCount} Online
                </span>
              </div>

              <div className="space-y-0.5">
                {onOpenAvatarCustomizer && (
                  <button
                    onClick={() => {
                      onOpenAvatarCustomizer();
                      setIsFileMenuOpen(false);
                    }}
                    className="w-full text-left px-2.5 py-1.5 rounded-lg hover:bg-white/10 text-neutral-200 flex items-center space-x-2 transition-colors cursor-pointer"
                  >
                    <Palette className="w-3.5 h-3.5 text-amber-400" />
                    <span>Customize Avatar & Outfit</span>
                  </button>
                )}

                {onOpenWebShare && (
                  <button
                    onClick={() => {
                      onOpenWebShare();
                      setIsFileMenuOpen(false);
                    }}
                    className="w-full text-left px-2.5 py-1.5 rounded-lg hover:bg-white/10 text-neutral-200 flex items-center space-x-2 transition-colors cursor-pointer"
                  >
                    <Share2 className="w-3.5 h-3.5 text-sky-400" />
                    <span>Share & Embed Office</span>
                  </button>
                )}

                {onOpenLabGuide && (
                  <button
                    onClick={() => {
                      onOpenLabGuide();
                      setIsFileMenuOpen(false);
                    }}
                    className="w-full text-left px-2.5 py-1.5 rounded-lg hover:bg-white/10 text-sky-300 hover:text-white flex items-center space-x-2 transition-colors cursor-pointer"
                  >
                    <span>📖</span>
                    <span>Lab Guide / Readme</span>
                  </button>
                )}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Center Mode Switcher */}
      <div className="hidden md:flex items-center space-x-0.5 bg-white/5 p-0.5 rounded-lg border border-white/5">
        <button
          onClick={onToggleLayersPanel}
          className={`flex items-center space-x-1 px-2 py-0.5 rounded-md text-[11px] font-medium transition-all cursor-pointer ${
            isLayersPanelOpen ? 'bg-white/15 text-white shadow-sm' : 'text-neutral-400 hover:text-neutral-200'
          }`}
        >
          <PanelLeft className="w-3 h-3" />
          <span>Layers</span>
        </button>
        <button
          onClick={onToggleInspectorPanel}
          className={`flex items-center space-x-1 px-2 py-0.5 rounded-md text-[11px] font-medium transition-all cursor-pointer ${
            isInspectorPanelOpen ? 'bg-white/15 text-white shadow-sm' : 'text-neutral-400 hover:text-neutral-200'
          }`}
        >
          <PanelRight className="w-3 h-3" />
          <span>Inspector</span>
        </button>
      </div>

      {/* Right Streamlined Actions & Ambient Player */}
      <div className="flex items-center space-x-2">
        {/* Ambient Lo-Fi & Focus Music Player Plugin */}
        <AudioPlayerPlugin />

        {/* User Profile Pill */}
        {currentUser && (
          <button
            onClick={onOpenAvatarCustomizer}
            className="flex items-center space-x-1.5 px-1.5 py-0.5 rounded-lg bg-white/5 hover:bg-white/10 border border-white/5 transition-all cursor-pointer"
            title="Edit avatar & outfit"
          >
            <div
              className="w-4 h-4 rounded-full border border-white/30 flex items-center justify-center font-bold text-[9px] text-white shadow-inner"
              style={{ backgroundColor: currentUser.hoodieColor || '#ea580c' }}
            >
              {currentUser.name.charAt(0)}
            </div>
            <span className="font-medium text-neutral-200 text-[11px] hidden sm:inline">{currentUser.name}</span>
          </button>
        )}

        {/* Screen Present Button */}
        <button
          onClick={onStartScreenShare}
          className={`p-1 px-2 rounded-md transition-all cursor-pointer flex items-center space-x-1 ${
            isScreenSharing
              ? 'bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 border border-rose-500/40 font-bold'
              : 'hover:bg-white/10 text-neutral-300 hover:text-white'
          }`}
          title={isScreenSharing ? 'Click to Stop Screen Share' : 'Present / Share Screen'}
        >
          {isScreenSharing ? (
            <>
              <span className="w-1.5 h-1.5 rounded-full bg-rose-400 animate-ping shrink-0" />
              <span className="text-[10px]">Stop</span>
            </>
          ) : (
            <Play className="w-3 h-3 fill-current" />
          )}
        </button>

        {/* Blue Primary Share Button */}
        <button
          onClick={onOpenWebShare || onStartScreenShare}
          className="px-2.5 py-1 rounded-lg bg-[#0c8ce9] hover:bg-[#007be5] text-white font-semibold text-[11px] flex items-center space-x-1 shadow-sm transition-all cursor-pointer"
          title="Share Office Room"
        >
          <Share2 className="w-3 h-3" />
          <span>Share</span>
        </button>
      </div>
    </header>
  );
};
