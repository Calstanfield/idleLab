import * as THREE from 'three';
import { DeskData, UserState, Department } from '../types';
import { createVoxelAvatarMesh } from './avatarBuilder';
import { buildGoldenGateScenery } from './goldenGateScenery';
import { buildSushiBar } from './sushiBarBuilder';
import { buildBasementTheater } from './basementTheaterBuilder';
import { buildTennisCourt } from './tennisCourtBuilder';
import { drawArtistPortraits } from './artistPortraits';
import {
  getStoneTexture,
  getWoodTexture,
  getOaklandWoodFloorTilesTexture,
  getScandinavianWoodSlatTexture,
  getBookshelfTexture,
  getChalkboardTexture,
  getCeilingTexture,
  getGlassWindowTexture,
  getFineArtTexture,
} from './voxelTextures';

export interface OfficeMeshes {
  sceneGroup: THREE.Group;
  deskGroupMap: Map<string, THREE.Group>;
  interactiveObjects: THREE.Object3D[];
  screenTvMesh: THREE.Mesh;
  whiteboardMesh: THREE.Mesh;
  allScreenMeshes: THREE.Mesh[];
  elevatorCabinGroup?: THREE.Group;
  updateDeskMesh: (desk: DeskData) => void;
  updateTvTexture: (canvasTexture: THREE.CanvasTexture | THREE.VideoTexture | null) => void;
  updateWhiteboardTexture: (canvasTexture: THREE.CanvasTexture) => void;
  updatePingPongMatch: (delta: number, time: number, playerPos?: { x: number; y: number; z: number }) => boolean;
  resetServe?: () => void;
  updateTrafficScenery?: (time: number) => void;
  updateSushiBar?: (time: number, delta: number, isPlayerSeated?: boolean, seatedPos?: { x: number; y: number; z: number }) => void;
  updateMeetingRoom?: (time: number, delta: number) => void;
  updateBasementTheater?: (
    time: number,
    delta?: number,
    playerPos?: { x: number; y: number; z: number },
    isChloeTalking?: boolean
  ) => void;
  updateTennisMatch?: (
    delta: number,
    time: number,
    playerPos?: { x: number; y: number; z: number },
    isPlayerSwinging?: boolean,
    swingType?: 'forehand' | 'backhand' | 'smash' | 'serve',
    isJumping?: boolean
  ) => any;
  setTennisGameMode?: (mode: 'training' | 'competition') => void;
  resetTennisServe?: () => void;
  triggerTennisFireballSmash?: () => void;
  updateCoffeeRobotArm?: (time: number) => void;
  updateElevatorCabin?: (targetY: number, delta: number) => void;
}

export function buildVoxelOffice(desks: DeskData[]): OfficeMeshes {
  const sceneGroup = new THREE.Group();
  sceneGroup.name = 'VoxelOffice';

  const deskGroupMap = new Map<string, THREE.Group>();
  const interactiveObjects: THREE.Object3D[] = [];
  const allScreenMeshes: THREE.Mesh[] = [];

  // Materials with sharp nearest-neighbor textures
  const stoneTex = getStoneTexture();
  stoneTex.repeat.set(1, 1);
  const stoneMat = new THREE.MeshStandardMaterial({ map: stoneTex, roughness: 0.8 });

  // Oakland Oak Hardwood Floor Tiles for authentic warmth & craftsmanship
  const oaklandFloorTex = getOaklandWoodFloorTilesTexture();
  oaklandFloorTex.repeat.set(14, 12);
  const oaklandFloorMat = new THREE.MeshStandardMaterial({ map: oaklandFloorTex, roughness: 0.65 });

  const carpetTex = getWoodTexture('carpet');
  carpetTex.repeat.set(16, 16);
  const carpetMat = new THREE.MeshStandardMaterial({ map: carpetTex, roughness: 0.9 });

  const floorWoodTex = getWoodTexture('floor_wood');
  floorWoodTex.repeat.set(8, 8);
  const floorWoodMat = new THREE.MeshStandardMaterial({ map: floorWoodTex, roughness: 0.7 });

  const wallMat = new THREE.MeshStandardMaterial({ color: 0xf1f5f9, roughness: 0.9 });
  const darkWallMat = new THREE.MeshStandardMaterial({ color: 0x1e293b, roughness: 0.8 });

  const ceilingTex = getCeilingTexture();
  ceilingTex.repeat.set(12, 10);
  const ceilingMat = new THREE.MeshStandardMaterial({ map: ceilingTex, roughness: 0.9 });

  const windowTex = getGlassWindowTexture();
  windowTex.repeat.set(4, 6);
  const windowMat = new THREE.MeshStandardMaterial({ map: windowTex, transparent: true, opacity: 0.85 });

  const bookshelfTex = getBookshelfTexture();
  const bookshelfMat = new THREE.MeshStandardMaterial({ map: bookshelfTex });

  const chalkboardTex = getChalkboardTexture();
  const chalkboardMat = new THREE.MeshStandardMaterial({ map: chalkboardTex });

  const woodOakTex = getWoodTexture('dark_oak');
  const woodOakMat = new THREE.MeshStandardMaterial({ map: woodOakTex });

  // 1. FLOOR & CEILING (24m x 20m x 5m room)
  const ROOM_W = 24;
  const ROOM_D = 20;
  const ROOM_H = 5;

  // Main floor with Oakland Wood Floor Tiles
  const floorGeo = new THREE.PlaneGeometry(ROOM_W, ROOM_D);
  const floorMesh = new THREE.Mesh(floorGeo, oaklandFloorMat);
  floorMesh.rotation.x = -Math.PI / 2;
  floorMesh.receiveShadow = true;
  sceneGroup.add(floorMesh);

  // Boardroom Warm Oakland Hardwood Inset
  const boardroomOaklandTex = getOaklandWoodFloorTilesTexture();
  boardroomOaklandTex.repeat.set(6, 5);
  const boardroomFloorGeo = new THREE.PlaneGeometry(10, 8);
  const boardroomFloorMesh = new THREE.Mesh(boardroomFloorGeo, new THREE.MeshStandardMaterial({ map: boardroomOaklandTex, roughness: 0.55 }));
  boardroomFloorMesh.rotation.x = -Math.PI / 2;
  boardroomFloorMesh.position.set(0, 0.01, -5.5);
  boardroomFloorMesh.receiveShadow = true;
  sceneGroup.add(boardroomFloorMesh);

  // Ceiling
  const ceilingGeo = new THREE.PlaneGeometry(ROOM_W, ROOM_D);
  const ceilingMesh = new THREE.Mesh(ceilingGeo, ceilingMat);
  ceilingMesh.rotation.x = Math.PI / 2;
  ceilingMesh.position.y = ROOM_H;
  sceneGroup.add(ceilingMesh);

  // Initialize 3D Pixel Art Golden Gate Bridge Scenery & Traffic System
  const sceneryController = buildGoldenGateScenery(sceneGroup);

  // 2. WALLS
  // Back Wall (Z = -ROOM_D / 2 = -10) - Floor-to-Ceiling Golden Gate View Window
  const backWallGroup = new THREE.Group();
  const sidePillarGeo = new THREE.BoxGeometry(4.0, ROOM_H, 0.4);
  const pillarWest = new THREE.Mesh(sidePillarGeo, wallMat);
  pillarWest.position.set(-10.0, ROOM_H / 2, -ROOM_D / 2);

  const pillarEast = new THREE.Mesh(sidePillarGeo, wallMat);
  pillarEast.position.set(10.0, ROOM_H / 2, -ROOM_D / 2);

  // Expansive 16-meter wide Glass View Window
  const glassBackGeo = new THREE.BoxGeometry(16.0, ROOM_H - 0.4, 0.1);
  const glassBackWindow = new THREE.Mesh(
    glassBackGeo,
    new THREE.MeshStandardMaterial({ color: 0x38bdf8, transparent: true, opacity: 0.2, roughness: 0.1 })
  );
  glassBackWindow.position.set(0, ROOM_H / 2, -ROOM_D / 2);

  // Black Steel Structural Mullions
  const steelFrameMat = new THREE.MeshStandardMaterial({ color: 0x1e293b, roughness: 0.3 });
  for (let mx = -6; mx <= 6; mx += 3) {
    const mullion = new THREE.Mesh(new THREE.BoxGeometry(0.12, ROOM_H - 0.4, 0.15), steelFrameMat);
    mullion.position.set(mx, ROOM_H / 2, -ROOM_D / 2);
    backWallGroup.add(mullion);
  }

  backWallGroup.add(pillarWest, pillarEast, glassBackWindow);
  sceneGroup.add(backWallGroup);

  // Front Wall (Z = ROOM_D / 2)
  const frontWallGeo = new THREE.BoxGeometry(ROOM_W, ROOM_H, 0.4);
  const frontWall = new THREE.Mesh(frontWallGeo, wallMat);
  frontWall.position.set(0, ROOM_H / 2, ROOM_D / 2);
  sceneGroup.add(frontWall);

  // Right Wall (At X = ROOM_W / 2 = 12) with Large Glass View Windows
  const rightWallGeo = new THREE.BoxGeometry(0.4, ROOM_H, ROOM_D);
  const rightWall = new THREE.Mesh(rightWallGeo, wallMat);
  rightWall.position.set(ROOM_W / 2, ROOM_H / 2, 0);
  sceneGroup.add(rightWall);

  // Panoramic Glass Window insert on Right Wall
  const rightWindow = new THREE.Mesh(new THREE.BoxGeometry(0.1, 3.2, 12), windowMat);
  rightWindow.position.set(ROOM_W / 2 - 0.1, 2.5, 0);
  sceneGroup.add(rightWindow);

  // 3. EXECUTIVE GLASS & STEEL MULTI-FLOOR ELEVATOR SHAFT (Connecting B1, 1F, 2F, and 3F)
  // Positioned at X = 8.5, Z = -8.0 (Back Right corner)
  const ELEV_X = 8.5;
  const ELEV_Z = -8.0;

  const elevShaftGroup = new THREE.Group();
  elevShaftGroup.position.set(ELEV_X, 0, ELEV_Z);

  const steelMat = new THREE.MeshStandardMaterial({ color: 0x334155, metalness: 0.85, roughness: 0.2 });
  const chromeMat = new THREE.MeshStandardMaterial({ color: 0xe2e8f0, metalness: 0.95, roughness: 0.1 });
  const glassElevMat = new THREE.MeshStandardMaterial({ color: 0x38bdf8, transparent: true, opacity: 0.4, roughness: 0.1 });
  const elevAccentMat = new THREE.MeshStandardMaterial({ color: 0x0284c7, metalness: 0.7, roughness: 0.25 });
  const elevLightMat = new THREE.MeshStandardMaterial({ color: 0xfffbeb, emissive: 0xfde047, emissiveIntensity: 0.9 });

  // Continuous Shaft Columns (4 Vertical Steel Beams spanning B1 Y=-6.0m to 3F Ceiling Y=15.0m, total height = 21.5m)
  for (const sx of [-1.12, 1.12]) {
    for (const sz of [-1.12, 1.12]) {
      const col = new THREE.Mesh(new THREE.BoxGeometry(0.16, 22.0, 0.16), steelMat);
      col.position.set(sx, 4.5, sz);
      elevShaftGroup.add(col);
    }
  }

  // Horizontal Structural Floor Rings at B1 (-6.0), 1F (0.0), 2F (5.5), and 3F (11.0)
  [-6.0, 0.0, 5.5, 11.0, 14.5].forEach((floorY) => {
    const ringFront = new THREE.Mesh(new THREE.BoxGeometry(2.3, 0.14, 0.14), steelMat);
    ringFront.position.set(0, floorY, 1.12);
    const ringBack = new THREE.Mesh(new THREE.BoxGeometry(2.3, 0.14, 0.14), steelMat);
    ringBack.position.set(0, floorY, -1.12);
    const ringRight = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.14, 2.3), steelMat);
    ringRight.position.set(1.12, floorY, 0);
    elevShaftGroup.add(ringFront, ringBack, ringRight);
  });

  // Continuous Glass Enclosure Panels around shaft
  const glassBack = new THREE.Mesh(new THREE.BoxGeometry(2.1, 21.5, 0.05), glassElevMat);
  glassBack.position.set(0, 4.5, -1.1);
  const glassSideR = new THREE.Mesh(new THREE.BoxGeometry(0.05, 21.5, 2.1), glassElevMat);
  glassSideR.position.set(1.1, 4.5, 0);
  elevShaftGroup.add(glassBack, glassSideR);

  // Dynamic 3D Elevator Cabin / Car Group
  const elevatorCabinGroup = new THREE.Group();
  elevatorCabinGroup.position.set(0, 0, 0); // Position Y updated smoothly during travel

  const cabinFloor = new THREE.Mesh(new THREE.BoxGeometry(1.95, 0.08, 1.95), chromeMat);
  cabinFloor.position.set(0, 0.04, 0);
  const cabinCeiling = new THREE.Mesh(new THREE.BoxGeometry(1.95, 0.08, 1.95), steelMat);
  cabinCeiling.position.set(0, 2.4, 0);
  const cabinLight = new THREE.Mesh(new THREE.BoxGeometry(1.4, 0.02, 1.4), elevLightMat);
  cabinLight.position.set(0, 2.38, 0);
  
  // Cabin Glass Back & Side Panel
  const cabinGlassBack = new THREE.Mesh(new THREE.BoxGeometry(1.85, 2.2, 0.04), glassElevMat);
  cabinGlassBack.position.set(0, 1.2, -0.92);
  const cabinGlassSide = new THREE.Mesh(new THREE.BoxGeometry(0.04, 2.2, 1.85), glassElevMat);
  cabinGlassSide.position.set(0.92, 1.2, 0);

  // Chrome Handrails inside cabin
  const railBack = new THREE.Mesh(new THREE.CylinderGeometry(0.025, 0.025, 1.7, 12), chromeMat);
  railBack.rotation.z = Math.PI / 2;
  railBack.position.set(0, 0.95, -0.85);

  const railSide = new THREE.Mesh(new THREE.CylinderGeometry(0.025, 0.025, 1.7, 12), chromeMat);
  railSide.rotation.x = Math.PI / 2;
  railSide.position.set(0.85, 0.95, 0);

  // Internal Elevator Car Position Display Canvas
  const cabinDisplayCanvas = document.createElement('canvas');
  cabinDisplayCanvas.width = 128;
  cabinDisplayCanvas.height = 64;
  const cdcCtx = cabinDisplayCanvas.getContext('2d')!;
  cdcCtx.fillStyle = '#020617';
  cdcCtx.fillRect(0, 0, 128, 64);
  cdcCtx.fillStyle = '#38bdf8';
  cdcCtx.font = 'bold 24px monospace';
  cdcCtx.textAlign = 'center';
  cdcCtx.fillText('🛗 1F', 64, 42);

  const cabinDisplayTex = new THREE.CanvasTexture(cabinDisplayCanvas);
  const cabinDisplayMesh = new THREE.Mesh(new THREE.PlaneGeometry(0.5, 0.25), new THREE.MeshBasicMaterial({ map: cabinDisplayTex }));
  cabinDisplayMesh.position.set(-0.85, 1.7, 0);
  cabinDisplayMesh.rotation.y = Math.PI / 2;

  elevatorCabinGroup.add(cabinFloor, cabinCeiling, cabinLight, cabinGlassBack, cabinGlassSide, railBack, railSide, cabinDisplayMesh);
  elevShaftGroup.add(elevatorCabinGroup);

  // Helper to create 3D Elevator Wall Call Buttons (UP ▲ / DOWN ▼)
  const buildCallButtons = (yOffset: number, floorCode: string) => {
    const callPanelGroup = new THREE.Group();
    callPanelGroup.position.set(1.15, yOffset + 1.2, 1.05);

    const panelBack = new THREE.Mesh(
      new THREE.BoxGeometry(0.32, 0.75, 0.06),
      new THREE.MeshStandardMaterial({ color: 0x1e293b, metalness: 0.8, roughness: 0.2 })
    );
    callPanelGroup.add(panelBack);

    // UP Button (▲)
    const upButton = new THREE.Mesh(
      new THREE.BoxGeometry(0.18, 0.22, 0.08),
      new THREE.MeshStandardMaterial({ color: 0x10b981, emissive: 0x059669, emissiveIntensity: 0.7 })
    );
    upButton.position.set(0, 0.18, 0.02);
    upButton.userData = { isElevator: true, isUpButton: true, floor: floorCode };
    interactiveObjects.push(upButton);

    // DOWN Button (▼)
    const downButton = new THREE.Mesh(
      new THREE.BoxGeometry(0.18, 0.22, 0.08),
      new THREE.MeshStandardMaterial({ color: 0x0284c7, emissive: 0x0369a1, emissiveIntensity: 0.7 })
    );
    downButton.position.set(0, -0.18, 0.02);
    downButton.userData = { isElevator: true, isDownButton: true, floor: floorCode };
    interactiveObjects.push(downButton);

    callPanelGroup.add(upButton, downButton);
    return callPanelGroup;
  };

  // Helper to create glowing overhead digital floor indicator
  const buildFloorSign = (floorCode: string, titleText: string, yOffset: number) => {
    const canvas = document.createElement('canvas');
    canvas.width = 256;
    canvas.height = 128;
    const ctx = canvas.getContext('2d')!;
    ctx.fillStyle = '#0f172a';
    ctx.fillRect(0, 0, 256, 128);
    ctx.strokeStyle = '#38bdf8';
    ctx.lineWidth = 4;
    ctx.strokeRect(2, 2, 252, 124);
    ctx.fillStyle = '#f8fafc';
    ctx.font = 'bold 22px sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText(`🛗 ELEVATOR (${floorCode})`, 128, 38);
    ctx.fillStyle = '#38bdf8';
    ctx.font = 'bold 14px monospace';
    ctx.fillText(titleText, 128, 72);
    ctx.fillStyle = '#22c55e';
    ctx.font = 'bold 15px monospace';
    ctx.fillText('B1 • 1F • 2F • 3F', 128, 105);

    const tex = new THREE.CanvasTexture(canvas);
    const signMesh = new THREE.Mesh(new THREE.PlaneGeometry(1.6, 0.8), new THREE.MeshBasicMaterial({ map: tex }));
    signMesh.position.set(0, yOffset + 2.8, 1.11);
    signMesh.userData = { isElevator: true, floor: floorCode };
    interactiveObjects.push(signMesh);
    return signMesh;
  };

  // 1. B1 Elevator Landing (Y = -6.0)
  const elevDoorB1 = new THREE.Mesh(new THREE.BoxGeometry(1.8, 2.4, 0.1), elevAccentMat);
  elevDoorB1.position.set(0, -6.0 + 1.2, 1.05);
  elevDoorB1.userData = { isElevator: true, targetFloor: -6.0, floorName: 'B1 Corporate Workspace & Tennis' };
  interactiveObjects.push(elevDoorB1);
  elevShaftGroup.add(elevDoorB1, buildFloorSign('B1', 'Corporate & Tennis', -6.0), buildCallButtons(-6.0, 'B1'));

  // 2. 1F Elevator Landing (Y = 0.0)
  const elevDoor1F = new THREE.Mesh(new THREE.BoxGeometry(1.8, 2.4, 0.1), elevAccentMat);
  elevDoor1F.position.set(0, 1.2, 1.05);
  elevDoor1F.userData = { isElevator: true, targetFloor: 0.0, floorName: '1F Main Open Office' };
  interactiveObjects.push(elevDoor1F);
  elevShaftGroup.add(elevDoor1F, buildFloorSign('1F', 'Main Open Office', 0.0), buildCallButtons(0.0, '1F'));

  // 3. 2F Elevator Landing (Y = 5.5)
  const elevDoor2F = new THREE.Mesh(new THREE.BoxGeometry(1.8, 2.4, 0.1), elevAccentMat);
  elevDoor2F.position.set(0, 5.5 + 1.2, 1.05);
  elevDoor2F.userData = { isElevator: true, targetFloor: 5.5, floorName: '2F Executive Boardroom' };
  interactiveObjects.push(elevDoor2F);
  elevShaftGroup.add(elevDoor2F, buildFloorSign('2F', 'Executive Boardroom', 5.5), buildCallButtons(5.5, '2F'));

  // 4. 3F Elevator Landing (Y = 11.0)
  const elevDoor3F = new THREE.Mesh(new THREE.BoxGeometry(1.8, 2.4, 0.1), elevAccentMat);
  elevDoor3F.position.set(0, 11.0 + 1.2, 1.05);
  elevDoor3F.userData = { isElevator: true, targetFloor: 11.0, floorName: '3F Visitor Center Cafe' };
  interactiveObjects.push(elevDoor3F);
  elevShaftGroup.add(elevDoor3F, buildFloorSign('3F', 'Visitor Center Cafe', 11.0), buildCallButtons(11.0, '3F'));

  sceneGroup.add(elevShaftGroup);

  // Smooth Elevator Cabin position update
  const updateElevatorCabin = (targetY: number, delta: number) => {
    if (elevatorCabinGroup) {
      elevatorCabinGroup.position.y = THREE.MathUtils.lerp(
        elevatorCabinGroup.position.y,
        targetY,
        Math.min(1.0, delta * 3.5)
      );
    }
  };

  // Left Wall with Glass Window Bay (X = -ROOM_W / 2)
  const windowWallGroup = new THREE.Group();
  const wallSolidGeo = new THREE.BoxGeometry(0.4, ROOM_H, 6);
  const leftWallA = new THREE.Mesh(wallSolidGeo, wallMat);
  leftWallA.position.set(-ROOM_W / 2, ROOM_H / 2, -7);

  const leftWallB = new THREE.Mesh(wallSolidGeo, wallMat);
  leftWallB.position.set(-ROOM_W / 2, ROOM_H / 2, 7);

  const glassWindowGeo = new THREE.BoxGeometry(0.1, ROOM_H - 1, 8);
  const glassWindow = new THREE.Mesh(glassWindowGeo, windowMat);
  glassWindow.position.set(-ROOM_W / 2, ROOM_H / 2, 0);

  windowWallGroup.add(leftWallA, leftWallB, glassWindow);
  sceneGroup.add(windowWallGroup);

  // Pixel Green Trees outside Window
  for (let tz = -3; tz <= 3; tz += 2) {
    const treeTrunk = new THREE.Mesh(new THREE.BoxGeometry(0.6, 3, 0.6), woodOakMat);
    treeTrunk.position.set(-ROOM_W / 2 - 2, 1.5, tz * 1.2);

    const treeLeaves = new THREE.Mesh(
      new THREE.BoxGeometry(2, 2.5, 2),
      new THREE.MeshStandardMaterial({ color: 0x15803d, roughness: 0.9 })
    );
    treeLeaves.position.set(-ROOM_W / 2 - 2, 3.5, tz * 1.2);

    sceneGroup.add(treeTrunk, treeLeaves);
  }

  // 3. BOARDROOM AREA
  const boardroomGroup = new THREE.Group();

  // Stone Boardroom Table
  const stoneTableGeo = new THREE.BoxGeometry(7, 0.8, 2.2);
  const stoneTableMesh = new THREE.Mesh(stoneTableGeo, stoneMat);
  stoneTableMesh.position.set(0, 0.8, -5.5);
  stoneTableMesh.castShadow = true;
  stoneTableMesh.receiveShadow = true;
  boardroomGroup.add(stoneTableMesh);

  // Boardroom Table legs
  for (const lx of [-3, 3]) {
    for (const lz of [-5, -6]) {
      const leg = new THREE.Mesh(new THREE.BoxGeometry(0.6, 0.8, 0.6), stoneMat);
      leg.position.set(lx, 0.4, lz);
      boardroomGroup.add(leg);
    }
  }

  // Boardroom Executive Armchairs (Faced INWARD towards table)
  const chairMat = new THREE.MeshStandardMaterial({ color: 0x3b0764, roughness: 0.8 });
  const chairPositions = [
    { x: -2.5, z: -4.3, rotY: Math.PI }, // Facing +Z towards table at z=-5.5
    { x: 0, z: -4.3, rotY: Math.PI },
    { x: 2.5, z: -4.3, rotY: Math.PI },
    { x: -2.5, z: -6.7, rotY: 0 },       // Facing -Z towards table at z=-5.5
    { x: 0, z: -6.7, rotY: 0 },
    { x: 2.5, z: -6.7, rotY: 0 },
  ];

  chairPositions.forEach((cp) => {
    const chairGroup = new THREE.Group();
    const seat = new THREE.Mesh(new THREE.BoxGeometry(0.8, 0.4, 0.8), chairMat);
    seat.position.y = 0.4;
    const back = new THREE.Mesh(new THREE.BoxGeometry(0.8, 0.8, 0.2), chairMat);
    back.position.set(0, 0.8, -0.3); // Backrest relative to chair

    chairGroup.add(seat, back);
    chairGroup.position.set(cp.x, 0, cp.z);
    chairGroup.rotation.y = cp.rotY;
    boardroomGroup.add(chairGroup);
  });

  // Scandinavian Vertical Acoustic Wood Slat Feature Wall Accent Layer Behind 1F TV for contrast
  const scandiWoodSlatTex = getScandinavianWoodSlatTexture();
  scandiWoodSlatTex.repeat.set(8, 4);
  const scandiWoodMat = new THREE.MeshStandardMaterial({ map: scandiWoodSlatTex, roughness: 0.6 });

  const scandiWallPanel = new THREE.Mesh(
    new THREE.BoxGeometry(6.6, 3.6, 0.08),
    scandiWoodMat
  );
  scandiWallPanel.position.set(0, 2.8, -ROOM_D / 2 + 0.16);

  // Warm LED Perimeter Backlight behind TV & Wood paneling
  const scandiBacklight = new THREE.PointLight(0xfef08a, 0.9, 8);
  scandiBacklight.position.set(0, 2.8, -ROOM_D / 2 + 0.22);

  const scandiTrimMat = new THREE.MeshStandardMaterial({ color: 0x0f172a, metalness: 0.8, roughness: 0.2 });
  const scandiFrameTop = new THREE.Mesh(new THREE.BoxGeometry(6.64, 0.06, 0.1), scandiTrimMat);
  scandiFrameTop.position.set(0, 2.8 + 1.8, -ROOM_D / 2 + 0.16);
  const scandiFrameBottom = new THREE.Mesh(new THREE.BoxGeometry(6.64, 0.06, 0.1), scandiTrimMat);
  scandiFrameBottom.position.set(0, 2.8 - 1.8, -ROOM_D / 2 + 0.16);

  boardroomGroup.add(scandiWallPanel, scandiFrameTop, scandiFrameBottom, scandiBacklight);

  // Wall TV / Screen Share Display Monitor on Back Wall (Z = -9.7)
  const tvFrameGeo = new THREE.BoxGeometry(4.2, 2.4, 0.1);
  const tvFrameMesh = new THREE.Mesh(tvFrameGeo, darkWallMat);
  tvFrameMesh.position.set(0, 2.8, -ROOM_D / 2 + 0.25);

  const screenTvCanvas = document.createElement('canvas');
  screenTvCanvas.width = 512;
  screenTvCanvas.height = 288;
  const screenTvCtx = screenTvCanvas.getContext('2d')!;
  screenTvCtx.fillStyle = '#1e1b4b';
  screenTvCtx.fillRect(0, 0, 512, 288);
  screenTvCtx.fillStyle = '#818cf8';
  screenTvCtx.font = 'bold 22px sans-serif';
  screenTvCtx.textAlign = 'center';
  screenTvCtx.fillText('📺 VIRTUAL OFFICE SCREEN', 256, 120);
  screenTvCtx.font = '15px sans-serif';
  screenTvCtx.fillStyle = '#94a3b8';
  screenTvCtx.fillText('Click "Share Screen" below to project live screen!', 256, 160);

  const screenTvTex = new THREE.CanvasTexture(screenTvCanvas);
  screenTvTex.magFilter = THREE.NearestFilter;
  const screenTvMat = new THREE.MeshBasicMaterial({ map: screenTvTex });

  const screenTvMesh = new THREE.Mesh(new THREE.PlaneGeometry(4, 2.2), screenTvMat);
  screenTvMesh.userData = { idleTexture: screenTvTex, isScreen: true };
  screenTvMesh.position.set(0, 2.8, -ROOM_D / 2 + 0.31);
  screenTvMesh.name = 'ScreenShareTV';
  interactiveObjects.push(screenTvMesh);
  allScreenMeshes.push(screenTvMesh);

  boardroomGroup.add(tvFrameMesh, screenTvMesh);

  // Wall Chalkboard / Blackboard
  const chalkboardGeo = new THREE.PlaneGeometry(3.6, 2.2);
  const chalkboardMesh = new THREE.Mesh(chalkboardGeo, chalkboardMat);
  chalkboardMesh.position.set(5.5, 2.8, -ROOM_D / 2 + 0.25);
  boardroomGroup.add(chalkboardMesh);

  // Bookshelf Wall
  const bookshelfGroup = new THREE.Group();
  for (let bx = -7.5; bx <= -4.5; bx += 1.5) {
    for (let by = 0.8; by <= 2.3; by += 1.5) {
      const bsBlock = new THREE.Mesh(new THREE.BoxGeometry(1.4, 1.4, 0.6), bookshelfMat);
      bsBlock.position.set(bx, by, -ROOM_D / 2 + 0.5);
      bookshelfGroup.add(bsBlock);
    }
  }
  boardroomGroup.add(bookshelfGroup);

  sceneGroup.add(boardroomGroup);

  // 4. INTERACTIVE SHARED WHITEBOARD (On Right Wall: X = ROOM_W / 2 - 0.2)
  const whiteboardCanvas = document.createElement('canvas');
  whiteboardCanvas.width = 512;
  whiteboardCanvas.height = 384;
  const wbCtx = whiteboardCanvas.getContext('2d')!;
  drawArtistPortraits(wbCtx, 512, 384);

  const whiteboardTex = new THREE.CanvasTexture(whiteboardCanvas);
  whiteboardTex.magFilter = THREE.NearestFilter;

  const wbFrame = new THREE.Mesh(
    new THREE.BoxGeometry(0.1, 3.2, 4.2),
    new THREE.MeshStandardMaterial({ color: 0x475569 })
  );
  wbFrame.position.set(ROOM_W / 2 - 0.3, 2.5, 2);

  const whiteboardMesh = new THREE.Mesh(
    new THREE.PlaneGeometry(4, 3),
    new THREE.MeshBasicMaterial({ map: whiteboardTex })
  );
  whiteboardMesh.rotation.y = -Math.PI / 2;
  whiteboardMesh.position.set(ROOM_W / 2 - 0.36, 2.5, 2);
  whiteboardMesh.name = 'InteractiveWhiteboard';
  interactiveObjects.push(whiteboardMesh);

  sceneGroup.add(wbFrame, whiteboardMesh);

  // 5. RICH DECORATIONS & COLORFUL OFFICE PROPS (Lamps, Plants, Lounge, Coffee Bar)
  const decorGroup = new THREE.Group();

  // A. POTTED PLANTS (Lush Monstera & Ficus plants around room)
  const plantPositions = [
    { x: -10, z: -8.5 },
    { x: 10, z: -8.5 },
    { x: -10, z: 8.5 },
    { x: 10, z: 8.5 },
    { x: 4, z: -2 },
    { x: -4, z: -2 },
    { x: 11, z: 0 },
  ];

  plantPositions.forEach((p) => {
    const potMat = new THREE.MeshStandardMaterial({ color: 0xd97706 }); // Terracotta
    const leafMat = new THREE.MeshStandardMaterial({ color: 0x16a34a, roughness: 0.6 });

    const pot = new THREE.Mesh(new THREE.CylinderGeometry(0.35, 0.25, 0.6, 8), potMat);
    pot.position.set(p.x, 0.3, p.z);

    const foliage = new THREE.Group();
    for (let i = 0; i < 4; i++) {
      const leaf = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.05, 0.5), leafMat);
      leaf.position.set((Math.random() - 0.5) * 0.3, 0.6 + i * 0.2, (Math.random() - 0.5) * 0.3);
      leaf.rotation.set(Math.random() * 0.4, Math.random() * Math.PI, Math.random() * 0.4);
      foliage.add(leaf);
    }
    foliage.position.set(p.x, 0, p.z);
    decorGroup.add(pot, foliage);
  });

  // B. WARM FLOOR STANDING LAMPS
  const lampPositions = [
    { x: -10.5, z: -4 },
    { x: 10.5, z: -4 },
    { x: -8, z: 7 },
    { x: 8, z: 7 },
  ];

  lampPositions.forEach((lp) => {
    const poleMat = new THREE.MeshStandardMaterial({ color: 0x0f172a });
    const shadeMat = new THREE.MeshStandardMaterial({
      color: 0xfef08a,
      emissive: 0xfde047,
      emissiveIntensity: 0.6,
    });

    const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.08, 2.4, 8), poleMat);
    pole.position.set(lp.x, 1.2, lp.z);

    const shade = new THREE.Mesh(new THREE.CylinderGeometry(0.3, 0.45, 0.5, 8), shadeMat);
    shade.position.set(lp.x, 2.3, lp.z);

    // Warm point light source
    const lampLight = new THREE.PointLight(0xfde047, 0.8, 6);
    lampLight.position.set(lp.x, 2.2, lp.z);

    decorGroup.add(pole, shade, lampLight);
  });

  // C. BREAKROOM & COFFEE BAR (In back-right corner: X = 8, Z = 5)
  const breakroomGroup = new THREE.Group();

  // Coffee Counter
  const counterGeo = new THREE.BoxGeometry(3.5, 0.9, 1.2);
  const counterMat = new THREE.MeshStandardMaterial({ color: 0x334155 });
  const counterMesh = new THREE.Mesh(counterGeo, counterMat);
  counterMesh.position.set(8.5, 0.45, 5);
  breakroomGroup.add(counterMesh);

  // Water Cooler Dispenser
  const coolerBase = new THREE.Mesh(
    new THREE.BoxGeometry(0.5, 0.8, 0.5),
    new THREE.MeshStandardMaterial({ color: 0xf8fafc })
  );
  coolerBase.position.set(7.2, 0.4, 5);
  const waterBottle = new THREE.Mesh(
    new THREE.CylinderGeometry(0.2, 0.2, 0.5, 8),
    new THREE.MeshStandardMaterial({ color: 0x38bdf8, transparent: true, opacity: 0.8 })
  );
  waterBottle.position.set(7.2, 1.05, 5);
  breakroomGroup.add(coolerBase, waterBottle);

  // High-Tech Functional Interactive Robotic Coffee Barista Station
  const coffeeStationGroup = new THREE.Group();
  coffeeStationGroup.position.set(8.7, 0.9, 5);

  const espressoChassis = new THREE.Mesh(
    new THREE.BoxGeometry(0.9, 0.65, 0.55),
    new THREE.MeshStandardMaterial({ color: 0x0f172a, roughness: 0.3, metalness: 0.8 })
  );
  espressoChassis.position.y = 0.325;

  const chromeTrim = new THREE.Mesh(
    new THREE.BoxGeometry(0.92, 0.06, 0.57),
    new THREE.MeshStandardMaterial({ color: 0xe2e8f0, metalness: 0.9, roughness: 0.1 })
  );
  chromeTrim.position.y = 0.64;

  const beanHopper = new THREE.Mesh(
    new THREE.CylinderGeometry(0.12, 0.1, 0.22, 10),
    new THREE.MeshStandardMaterial({ color: 0x78350f, roughness: 0.5 })
  );
  beanHopper.position.set(-0.25, 0.75, 0);

  const steamNozzle = new THREE.Mesh(
    new THREE.CylinderGeometry(0.02, 0.02, 0.18, 8),
    new THREE.MeshStandardMaterial({ color: 0xe2e8f0, metalness: 0.9 })
  );
  steamNozzle.position.set(0.25, 0.25, 0.25);
  steamNozzle.rotation.x = 0.3;

  // Digital Brewing Screen on Coffee Robot
  const brewDisp = new THREE.Mesh(
    new THREE.PlaneGeometry(0.28, 0.14),
    new THREE.MeshBasicMaterial({ color: 0x00e5ff })
  );
  brewDisp.position.set(0, 0.42, 0.28);

  // Articulated Barista Robotic Arm
  const robotArmBase = new THREE.Mesh(
    new THREE.CylinderGeometry(0.08, 0.08, 0.1, 8),
    new THREE.MeshStandardMaterial({ color: 0x334155, metalness: 0.8 })
  );
  robotArmBase.position.set(-0.6, 0.05, 0);

  const armJoint1 = new THREE.Group();
  armJoint1.position.set(-0.6, 0.1, 0);
  const armSegment1 = new THREE.Mesh(
    new THREE.BoxGeometry(0.06, 0.3, 0.06),
    new THREE.MeshStandardMaterial({ color: 0xf59e0b, metalness: 0.7 })
  );
  armSegment1.position.y = 0.15;
  armSegment1.rotation.z = -0.3;

  const armJoint2 = new THREE.Group();
  armJoint2.position.set(0.08, 0.28, 0);
  const armSegment2 = new THREE.Mesh(
    new THREE.BoxGeometry(0.05, 0.25, 0.05),
    new THREE.MeshStandardMaterial({ color: 0x0f172a, metalness: 0.8 })
  );
  armSegment2.position.y = 0.12;
  armSegment2.rotation.z = 0.6;

  const gripper = new THREE.Mesh(
    new THREE.BoxGeometry(0.08, 0.04, 0.08),
    new THREE.MeshStandardMaterial({ color: 0x38bdf8, metalness: 0.9 })
  );
  gripper.position.set(0.05, 0.25, 0);

  armJoint2.add(armSegment2, gripper);
  armJoint1.add(armSegment1, armJoint2);

  // Status LED Ring
  const ledRing = new THREE.Mesh(
    new THREE.TorusGeometry(0.09, 0.02, 8, 16),
    new THREE.MeshBasicMaterial({ color: 0x22c55e })
  );
  ledRing.position.set(0, 0.2, 0.28);

  // Floating Status Badge
  const robotCanvas = document.createElement('canvas');
  robotCanvas.width = 256;
  robotCanvas.height = 64;
  const rcCtx = robotCanvas.getContext('2d')!;
  rcCtx.fillStyle = '#0f172a';
  rcCtx.fillRect(0, 0, 256, 64);
  rcCtx.strokeStyle = '#f59e0b';
  rcCtx.lineWidth = 4;
  rcCtx.strokeRect(2, 2, 252, 60);
  rcCtx.fillStyle = '#fbbf24';
  rcCtx.font = 'bold 20px sans-serif';
  rcCtx.textAlign = 'center';
  rcCtx.fillText('☕ ROBOT BARISTA', 128, 28);
  rcCtx.fillStyle = '#38bdf8';
  rcCtx.font = '14px monospace';
  rcCtx.fillText('Click to Brew & Buff!', 128, 50);

  const rTex = new THREE.CanvasTexture(robotCanvas);
  const rSprite = new THREE.Sprite(new THREE.SpriteMaterial({ map: rTex }));
  rSprite.scale.set(1.4, 0.35, 1);
  rSprite.position.set(0, 1.05, 0);

  coffeeStationGroup.add(espressoChassis, chromeTrim, beanHopper, steamNozzle, brewDisp, robotArmBase, armJoint1, ledRing, rSprite);

  // Clickable interactive target for the robot coffee machine
  const coffeeClickGeo = new THREE.BoxGeometry(1.8, 1.4, 1.4);
  const coffeeClickMat = new THREE.MeshBasicMaterial({ visible: false });
  const coffeeClickMesh = new THREE.Mesh(coffeeClickGeo, coffeeClickMat);
  coffeeClickMesh.position.set(8.7, 0.9, 5);
  coffeeClickMesh.name = 'RoboticCoffeeMachine';
  coffeeClickMesh.userData = { isCoffeeRobot: true };
  interactiveObjects.push(coffeeClickMesh);

  breakroomGroup.add(coffeeStationGroup, coffeeClickMesh);

  // Bar Stools
  [-0.8, 0.8].forEach((sx) => {
    const stoolMat = new THREE.MeshStandardMaterial({ color: 0x0284c7 });
    const stoolSeat = new THREE.Mesh(new THREE.CylinderGeometry(0.25, 0.25, 0.1, 8), stoolMat);
    stoolSeat.position.set(8.5 + sx, 0.55, 6.1);
    const stoolLeg = new THREE.Mesh(
      new THREE.CylinderGeometry(0.04, 0.04, 0.55, 8),
      new THREE.MeshStandardMaterial({ color: 0x0f172a })
    );
    stoolLeg.position.set(8.5 + sx, 0.27, 6.1);
    breakroomGroup.add(stoolSeat, stoolLeg);
  });

  decorGroup.add(breakroomGroup);

  // D. COZY LOUNGE AREA WITH COLORFUL BEANBAGS (In front-left: X = -7.5, Z = 5)
  const loungeGroup = new THREE.Group();

  // Patterned Rug
  const rugMat = new THREE.MeshStandardMaterial({ color: 0x0284c7, roughness: 0.9 });
  const rugGeo = new THREE.PlaneGeometry(4.5, 3.5);
  const rugMesh = new THREE.Mesh(rugGeo, rugMat);
  rugMesh.rotation.x = -Math.PI / 2;
  rugMesh.position.set(-7.5, 0.01, 5);
  loungeGroup.add(rugMesh);

  // Beanbag Chairs (Magenta, Cyan, Amber)
  const beanbagData = [
    { x: -8.8, z: 4.3, color: 0xec4899 },
    { x: -6.2, z: 4.3, color: 0x06b6d4 },
    { x: -7.5, z: 6.0, color: 0xf59e0b },
  ];

  beanbagData.forEach((bb) => {
    const bbMat = new THREE.MeshStandardMaterial({ color: bb.color, roughness: 0.7 });
    const bbMesh = new THREE.Mesh(new THREE.SphereGeometry(0.55, 8, 8), bbMat);
    bbMesh.scale.set(1.2, 0.7, 1.2);
    bbMesh.position.set(bb.x, 0.35, bb.z);
    loungeGroup.add(bbMesh);
  });

  // Low Coffee Table
  const coffeeTableGeo = new THREE.BoxGeometry(1.6, 0.3, 1.0);
  const coffeeTableMesh = new THREE.Mesh(
    coffeeTableGeo,
    new THREE.MeshStandardMaterial({ color: 0x78350f })
  );
  coffeeTableMesh.position.set(-7.5, 0.2, 5.0);
  loungeGroup.add(coffeeTableMesh);

  // HEALTHCARE POMODORO COMPANION 3D OBJECT (Wellness Desk Station)
  const pomodoroGroup = new THREE.Group();
  pomodoroGroup.position.set(-7.5, 0.35, 5.0);

  const pomodoroBody = new THREE.Mesh(
    new THREE.BoxGeometry(0.5, 0.36, 0.28),
    new THREE.MeshStandardMaterial({ color: 0x0f172a, roughness: 0.2, metalness: 0.8 })
  );
  pomodoroBody.position.y = 0.18;

  const pomodoroScreenBezel = new THREE.Mesh(
    new THREE.BoxGeometry(0.44, 0.28, 0.04),
    new THREE.MeshStandardMaterial({ color: 0x1e293b, metalness: 0.5 })
  );
  pomodoroScreenBezel.position.set(0, 0.18, 0.13);

  const pomodoroScreenCanvas = document.createElement('canvas');
  pomodoroScreenCanvas.width = 256;
  pomodoroScreenCanvas.height = 160;
  const psCtx = pomodoroScreenCanvas.getContext('2d')!;
  psCtx.fillStyle = '#090a0f';
  psCtx.fillRect(0, 0, 256, 160);
  psCtx.strokeStyle = '#38bdf8';
  psCtx.lineWidth = 4;
  psCtx.strokeRect(4, 4, 248, 152);
  psCtx.fillStyle = '#38bdf8';
  psCtx.font = 'bold 36px monospace';
  psCtx.textAlign = 'center';
  psCtx.fillText('25:00', 128, 70);
  psCtx.fillStyle = '#10b981';
  psCtx.font = 'bold 20px sans-serif';
  psCtx.fillText('❤️ HEALTH REST', 128, 115);
  psCtx.fillStyle = '#f43f5e';
  psCtx.font = '14px sans-serif';
  psCtx.fillText('💧 Hydrate & Stretch', 128, 142);

  const pomodoroScreenTex = new THREE.CanvasTexture(pomodoroScreenCanvas);
  pomodoroScreenTex.magFilter = THREE.NearestFilter;
  const pomodoroScreenMesh = new THREE.Mesh(
    new THREE.PlaneGeometry(0.4, 0.24),
    new THREE.MeshBasicMaterial({ map: pomodoroScreenTex })
  );
  pomodoroScreenMesh.position.set(0, 0.18, 0.155);

  const pomodoroDial = new THREE.Mesh(
    new THREE.CylinderGeometry(0.06, 0.06, 0.05, 12),
    new THREE.MeshStandardMaterial({ color: 0xf43f5e, metalness: 0.9 })
  );
  pomodoroDial.position.set(0.14, 0.38, 0);

  const pomodoroLed = new THREE.Mesh(
    new THREE.SphereGeometry(0.04, 8, 8),
    new THREE.MeshBasicMaterial({ color: 0x38bdf8 })
  );
  pomodoroLed.position.set(-0.14, 0.38, 0);

  const pomodoroLabelCanvas = document.createElement('canvas');
  pomodoroLabelCanvas.width = 256;
  pomodoroLabelCanvas.height = 64;
  const plCtx = pomodoroLabelCanvas.getContext('2d')!;
  plCtx.fillStyle = '#0f172a';
  plCtx.fillRect(0, 0, 256, 64);
  plCtx.strokeStyle = '#38bdf8';
  plCtx.lineWidth = 4;
  plCtx.strokeRect(2, 2, 252, 60);
  plCtx.fillStyle = '#38bdf8';
  plCtx.font = 'bold 18px sans-serif';
  plCtx.textAlign = 'center';
  plCtx.fillText('⏱️ HEALTH POMODORO', 128, 28);
  plCtx.fillStyle = '#10b981';
  plCtx.font = '13px monospace';
  plCtx.fillText('Click to Open Timer', 128, 50);

  const plTex = new THREE.CanvasTexture(pomodoroLabelCanvas);
  const plSprite = new THREE.Sprite(new THREE.SpriteMaterial({ map: plTex }));
  plSprite.scale.set(1.2, 0.3, 1);
  plSprite.position.set(0, 0.8, 0);

  pomodoroGroup.add(pomodoroBody, pomodoroScreenBezel, pomodoroScreenMesh, pomodoroDial, pomodoroLed, plSprite);

  const pomodoroClickGeo = new THREE.BoxGeometry(1.0, 0.9, 0.8);
  const pomodoroClickMat = new THREE.MeshBasicMaterial({ visible: false });
  const pomodoroClickMesh = new THREE.Mesh(pomodoroClickGeo, pomodoroClickMat);
  pomodoroClickMesh.position.set(-7.5, 0.35, 5.0);
  pomodoroClickMesh.name = 'HealthcarePomodoro';
  pomodoroClickMesh.userData = { isPomodoro: true };
  interactiveObjects.push(pomodoroClickMesh);

  loungeGroup.add(pomodoroGroup, pomodoroClickMesh);

  decorGroup.add(loungeGroup);

  // E. FINE ART GALLERY PAINTINGS ON CLEAN BLANK GREY WALLS (Mona Lisa, Starry Night, Great Wave, Girl with Pearl Earring)
  // All portraits are placed on unobstructed blank wall spaces clear of whiteboards, shelves, or furniture.
  const fineArtData: Array<{
    x: number;
    z: number;
    rotY: number;
    type: 'mona_lisa' | 'starry_night' | 'great_wave' | 'pearl_earring';
    title: string;
  }> = [
    { x: 9.2, z: -9.75, rotY: 0, type: 'mona_lisa', title: '🖼️ Mona Lisa (Leonardo da Vinci)' },
    { x: -10.2, z: -9.75, rotY: 0, type: 'starry_night', title: '🌌 The Starry Night (Van Gogh)' },
    { x: -11.75, z: 0, rotY: Math.PI / 2, type: 'pearl_earring', title: '💎 Girl with a Pearl Earring' },
    { x: 11.75, z: -4.5, rotY: -Math.PI / 2, type: 'great_wave', title: '🌊 The Great Wave off Kanagawa' },
  ];

  fineArtData.forEach((art) => {
    const artTex = getFineArtTexture(art.type);

    // Ornate Gold Frame
    const frameMesh = new THREE.Mesh(
      new THREE.BoxGeometry(1.8, 2.2, 0.1),
      new THREE.MeshStandardMaterial({ color: 0xd97706, roughness: 0.3, metalness: 0.7 })
    );
    const canvasMesh = new THREE.Mesh(
      new THREE.PlaneGeometry(1.6, 2.0),
      new THREE.MeshBasicMaterial({ map: artTex })
    );
    canvasMesh.position.z = 0.06;

    // Brass Spotlight mounted above painting
    const spotLight = new THREE.PointLight(0xfef08a, 0.5, 4);
    spotLight.position.set(0, 1.3, 0.3);

    const artGroup = new THREE.Group();
    artGroup.add(frameMesh, canvasMesh, spotLight);
    artGroup.position.set(art.x, 2.6, art.z);
    artGroup.rotation.y = art.rotY;

    decorGroup.add(artGroup);
  });

  // F. REAL-LIFE 3D ACTION: KUKA INDUSTRIAL ROBOT ARM & PING PONG MATCH
  const pingPongGroup = new THREE.Group();
  pingPongGroup.position.set(8.5, 0, 0); // Table centered at X = 8.5, Z = 0

  // 1. Ping Pong Table top
  const ppTableMat = new THREE.MeshStandardMaterial({ color: 0x1d4ed8, roughness: 0.4 });
  const ppTopGeo = new THREE.BoxGeometry(3.2, 0.1, 1.8);
  const ppTopMesh = new THREE.Mesh(ppTopGeo, ppTableMat);
  ppTopMesh.position.y = 0.75;
  ppTopMesh.castShadow = true;
  ppTopMesh.receiveShadow = true;
  pingPongGroup.add(ppTopMesh);

  // White perimeter line markings on table
  const lineMat = new THREE.MeshBasicMaterial({ color: 0xffffff });
  const centerLine = new THREE.Mesh(new THREE.BoxGeometry(3.18, 0.01, 0.03), lineMat);
  centerLine.position.set(0, 0.81, 0);
  pingPongGroup.add(centerLine);

  // Table center net
  const ppNetMat = new THREE.MeshBasicMaterial({ color: 0xf8fafc, transparent: true, opacity: 0.85 });
  const ppNetMesh = new THREE.Mesh(new THREE.BoxGeometry(0.04, 0.25, 1.8), ppNetMat);
  ppNetMesh.position.set(0, 0.9, 0);
  pingPongGroup.add(ppNetMesh);

  // Metallic Table legs
  for (const lx of [-1.3, 1.3]) {
    for (const lz of [-0.7, 0.7]) {
      const leg = new THREE.Mesh(
        new THREE.CylinderGeometry(0.05, 0.05, 0.7, 8),
        new THREE.MeshStandardMaterial({ color: 0x334155 })
      );
      leg.position.set(lx, 0.35, lz);
      pingPongGroup.add(leg);
    }
  }

  // 2. INDUSTRIAL ROBOTIC ARM FOR PING PONG (In Industrial Orange & Dark Metallic)
  const robotArmGroup = new THREE.Group();
  robotArmGroup.position.set(1.85, 0, 0); // Standing on right end of ping pong table

  const robotOrangeMat = new THREE.MeshStandardMaterial({ color: 0xea580c, metalness: 0.3, roughness: 0.4 });
  const robotDarkMat = new THREE.MeshStandardMaterial({ color: 0x1e293b, metalness: 0.8, roughness: 0.2 });
  const robotChromeMat = new THREE.MeshStandardMaterial({ color: 0xcbd5e1, metalness: 0.9, roughness: 0.1 });
  const robotLedMat = new THREE.MeshBasicMaterial({ color: 0x06b6d4 });

  // Heavy steel base plate bolted to floor
  const robotBase = new THREE.Mesh(new THREE.CylinderGeometry(0.4, 0.45, 0.3, 12), robotDarkMat);
  robotBase.position.y = 0.15;

  // Joint A1: Rotating Base Swivel Cylinder
  const robotJointA1 = new THREE.Group();
  robotJointA1.position.y = 0.3;
  const a1Body = new THREE.Mesh(new THREE.CylinderGeometry(0.32, 0.35, 0.4, 12), robotOrangeMat);
  a1Body.position.y = 0.2;
  robotJointA1.add(a1Body);

  // Joint A2: Shoulder & Upper Arm Boom Link
  const robotJointA2 = new THREE.Group();
  robotJointA2.position.set(0, 0.4, 0);

  const a2Shoulder = new THREE.Mesh(new THREE.CylinderGeometry(0.2, 0.2, 0.3, 12), robotDarkMat);
  a2Shoulder.rotation.x = Math.PI / 2;

  const a2Boom = new THREE.Mesh(new THREE.BoxGeometry(0.22, 0.75, 0.22), robotOrangeMat);
  a2Boom.position.set(-0.15, 0.35, 0);
  a2Boom.rotation.z = Math.PI / 6;

  // Pneumatic piston cylinder
  const pistonCylinder = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.06, 0.6, 8), robotChromeMat);
  pistonCylinder.position.set(0.12, 0.3, 0);

  robotJointA2.add(a2Shoulder, a2Boom, pistonCylinder);
  robotJointA1.add(robotJointA2);

  // Joint A3: Elbow Link
  const robotJointA3 = new THREE.Group();
  robotJointA3.position.set(-0.32, 0.7, 0);

  const a3Elbow = new THREE.Mesh(new THREE.CylinderGeometry(0.15, 0.15, 0.25, 12), robotDarkMat);
  a3Elbow.rotation.x = Math.PI / 2;

  const a3Forearm = new THREE.Mesh(new THREE.BoxGeometry(0.18, 0.65, 0.18), robotOrangeMat);
  a3Forearm.position.set(-0.25, 0.0, 0);
  a3Forearm.rotation.z = -Math.PI / 3;

  robotJointA3.add(a3Elbow, a3Forearm);
  robotJointA2.add(robotJointA3);

  // Wrist End-Effector holding Table Tennis Paddle
  const robotWrist = new THREE.Group();
  robotWrist.position.set(-0.55, -0.25, 0);

  const wristMount = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.08, 0.2, 8), robotDarkMat);
  wristMount.rotation.z = Math.PI / 2;

  const robotPaddleMat = new THREE.MeshStandardMaterial({ color: 0xdc2626 });
  const robotPaddleHandle = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.03, 0.2, 8), robotDarkMat);
  robotPaddleHandle.position.set(-0.1, 0, 0);
  robotPaddleHandle.rotation.z = Math.PI / 2;

  const robotPaddleFace = new THREE.Mesh(new THREE.CylinderGeometry(0.2, 0.2, 0.03, 16), robotPaddleMat);
  robotPaddleFace.position.set(-0.22, 0, 0);
  robotPaddleFace.rotation.z = Math.PI / 2;

  robotWrist.add(wristMount, robotPaddleHandle, robotPaddleFace);
  robotJointA3.add(robotWrist);

  // Robot Head Status LED Beacon
  const robotBeacon = new THREE.Mesh(new THREE.SphereGeometry(0.08, 8, 8), robotLedMat);
  robotBeacon.position.set(0, 0.8, 0);
  robotJointA1.add(robotBeacon);

  robotArmGroup.add(robotBase, robotJointA1);
  pingPongGroup.add(robotArmGroup);

  // 3. REAL 3D PING PONG BALL
  const ppBallMat = new THREE.MeshStandardMaterial({
    color: 0xffffff,
    roughness: 0.2,
    metalness: 0.1,
    emissive: 0xffffff,
    emissiveIntensity: 0.2,
  });
  const ppBallMesh = new THREE.Mesh(new THREE.SphereGeometry(0.06, 16, 16), ppBallMat);
  ppBallMesh.position.set(0, 0.9, 0);
  ppBallMesh.castShadow = true;
  pingPongGroup.add(ppBallMesh);

  // Interactive Click Area
  const ppClickGeo = new THREE.BoxGeometry(3.8, 2.2, 2.2);
  const ppClickMat = new THREE.MeshBasicMaterial({ visible: false });
  const ppClickMesh = new THREE.Mesh(ppClickGeo, ppClickMat);
  ppClickMesh.position.y = 1.0;
  ppClickMesh.name = 'PingPongTable';
  ppClickMesh.userData = { isPingPong: true };
  interactiveObjects.push(ppClickMesh);
  pingPongGroup.add(ppClickMesh);

  decorGroup.add(pingPongGroup);

  sceneGroup.add(decorGroup);

  // Real-time 3D Ping Pong Match Physics & Robotic Arm Motion State
  let ballPos = { x: 0, y: 0.85, z: 0 };
  let ballVel = { x: 3.5, y: 2.2, z: 0.2 };

  // Web Audio Synthesizer for Ping Pong Hit Sounds
  const playSound = (freq: number, duration: number, type: 'hit' | 'point' = 'hit') => {
    try {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioCtx) return;
      const ctx = new AudioCtx();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = type === 'point' ? 'square' : 'sine';
      osc.frequency.setValueAtTime(freq, ctx.currentTime);
      if (type === 'hit') {
        osc.frequency.exponentialRampToValueAtTime(freq * 0.5, ctx.currentTime + duration);
      }
      gain.gain.setValueAtTime(0.15, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + duration);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + duration);
    } catch {
      // Audio fallback silent
    }
  };

  const updatePingPongMatch = (delta: number, time: number, playerPos?: { x: number; y: number; z: number }): boolean => {
    // Check if player avatar is standing near ping pong table on the main floor (1st floor only)
    // Table is at world X = 8.5, Z = 0 (Player position near X = 6.8, Z = 0, Floor Y = 0.0)
    let isPlayerAtTable = false;
    if (playerPos) {
      const isMainFloor = Math.abs((playerPos.y || 0) - 0.0) < 1.5;
      const dist = Math.hypot(playerPos.x - 6.8, playerPos.z - 0);
      if (isMainFloor && dist < 3.2) isPlayerAtTable = true;
    }

    if (!isPlayerAtTable) {
      // ROBOT IDLE / STANDBY MODE when user is away from table
      robotLedMat.color.setHex(0x334155); // Dark standby LED
      robotJointA1.rotation.y += (0 - robotJointA1.rotation.y) * 0.1;
      robotJointA2.rotation.z += (Math.PI / 4 - robotJointA2.rotation.z) * 0.1;
      robotJointA3.rotation.z += (-Math.PI / 3 - robotJointA3.rotation.z) * 0.1;
      robotBeacon.scale.setScalar(1.0);

      // Ball rests on table center
      ballPos = { x: 0, y: 0.81, z: 0 };
      ballVel = { x: 3.5, y: 2.2, z: 0.2 };
      ppBallMesh.position.set(0, 0.81, 0);

      return false; // Player is not at table
    }

    // ACTIVE MATCH MODE when user approaches table
    robotLedMat.color.setHex(0x06b6d4); // Active bright cyan LED

    // Step 1: Ball 3D Physics
    const gravity = -9.8;
    ballVel.y += gravity * delta;
    ballPos.x += ballVel.x * delta;
    ballPos.y += ballVel.y * delta;
    ballPos.z += ballVel.z * delta;

    // Table surface bounce (Table top Y = 0.75, X bounds -1.6 to +1.6, Z bounds -0.9 to +0.9)
    if (ballPos.y <= 0.81 && Math.abs(ballPos.x) < 1.6 && Math.abs(ballPos.z) < 0.9) {
      ballPos.y = 0.81;
      ballVel.y = Math.abs(ballVel.y) * 0.88; // Bounce reflection
      playSound(380, 0.08, 'hit');
    }

    // Robot Side Return Hit (Local X ~ 1.45)
    if (ballPos.x >= 1.45) {
      ballPos.x = 1.45;
      ballVel.x = -(Math.abs(ballVel.x) + 0.1); // Hit back toward player
      ballVel.y = 2.2 + Math.random() * 0.8;
      ballVel.z = (Math.random() - 0.5) * 1.6;
      robotLedMat.color.setHex(0x38bdf8); // Flash cyan
      playSound(620, 0.1, 'hit');
    }

    // Player Side Return Hit (Local X ~ -1.45)
    if (ballPos.x <= -1.45) {
      ballPos.x = -1.45;
      ballVel.x = Math.abs(ballVel.x) + 0.1;
      ballVel.y = 2.2 + Math.random() * 0.8;
      ballVel.z = (Math.random() - 0.5) * 1.6;
      playSound(520, 0.1, 'hit');
    }

    // Clamp Z bounds
    if (Math.abs(ballPos.z) > 1.2) {
      ballVel.z = -ballVel.z;
    }

    // Update 3D Ball Mesh position
    ppBallMesh.position.set(ballPos.x, ballPos.y, ballPos.z);

    // Step 2: Animate Industrial Arm IK joint rotation to follow 3D ball
    const targetA1Rot = Math.atan2(ballPos.z, 2.0);
    robotJointA1.rotation.y += (targetA1Rot - robotJointA1.rotation.y) * 0.18;

    const heightFactor = Math.sin(time * 8) * 0.1;
    robotJointA2.rotation.z = Math.PI / 8 + Math.sin(time * 6) * 0.05 + heightFactor;
    robotJointA3.rotation.z = -Math.PI / 4 + Math.cos(time * 6) * 0.08;
    robotBeacon.scale.setScalar(1 + Math.sin(time * 12) * 0.25);

    return true; // Player is at table
  };


  // 6. CUSTOMIZABLE DESKS PODS
  desks.forEach((deskData) => {
    const deskGroup = createSingleDeskMesh(deskData, interactiveObjects, allScreenMeshes);
    sceneGroup.add(deskGroup);
    deskGroupMap.set(deskData.id, deskGroup);
  });

  // 7. BUILD EXECUTIVE MEETING ROOM
  const execScreens = buildExecutiveMeetingRoom(sceneGroup, interactiveObjects);
  if (execScreens?.screenMesh) allScreenMeshes.push(execScreens.screenMesh);
  if (execScreens?.consoleScreen) allScreenMeshes.push(execScreens.consoleScreen);

  // 8. BUILD 3F SUSHI BAR & STUDY LOUNGE
  const sushiController = buildSushiBar(sceneGroup, interactiveObjects);
  if (sushiController?.cafeScreenMesh) allScreenMeshes.push(sushiController.cafeScreenMesh);

  // 9. BUILD B1 CORPORATE OPEN WORKSPACE & EXECUTIVE SUITE (B1, Y = -6.0)
  const basementController = buildBasementTheater();
  sceneGroup.add(basementController.basementGroup);
  interactiveObjects.push(...basementController.interactiveObjects);
  if (basementController.basementScreenMesh) {
    basementController.basementScreenMesh.userData = {
      idleTexture: (basementController.basementScreenMesh.material as THREE.MeshBasicMaterial).map,
      isScreen: true,
      isB1Screen: true,
      title: 'Giant 8K Presentation Screen (Click to Share Screen)',
    };
    allScreenMeshes.push(basementController.basementScreenMesh);
  }

  // 10. BUILD CHAMPIONSHIP B1 ENCLOSED INDOOR TENNIS ARENA (East of B1: X = 16..42, Y = -6.0)
  const tennisController = buildTennisCourt(interactiveObjects);
  sceneGroup.add(tennisController.courtGroup);
  interactiveObjects.push(...tennisController.interactiveObjects);

  // Helper functions to update dynamic canvas textures
  const updateDeskMesh = (updatedDesk: DeskData) => {
    const oldGroup = deskGroupMap.get(updatedDesk.id);
    if (oldGroup) {
      sceneGroup.remove(oldGroup);
      const newGroup = createSingleDeskMesh(updatedDesk, interactiveObjects, allScreenMeshes);
      sceneGroup.add(newGroup);
      deskGroupMap.set(updatedDesk.id, newGroup);
    }
  };

  const updateTvTexture = (tex: THREE.CanvasTexture | THREE.VideoTexture | null) => {
    allScreenMeshes.forEach((mesh) => {
      if (!mesh || !mesh.material) return;
      const mat = mesh.material as THREE.MeshBasicMaterial;
      if (tex) {
        mat.map = tex;
      } else {
        mat.map = mesh.userData?.idleTexture || null;
      }
      mat.needsUpdate = true;
    });
  };

  const updateWhiteboardTexture = (tex: THREE.CanvasTexture) => {
    (whiteboardMesh.material as THREE.MeshBasicMaterial).map = tex;
    (whiteboardMesh.material as THREE.MeshBasicMaterial).needsUpdate = true;
  };

  // Ambient & Directional Lighting
  const ambientLight = new THREE.AmbientLight(0xffffff, 0.75);
  sceneGroup.add(ambientLight);

  const sunLight = new THREE.DirectionalLight(0xfffbeb, 0.85);
  sunLight.position.set(10, 15, 10);
  sunLight.castShadow = true;
  sceneGroup.add(sunLight);

  const resetServe = () => {
    ballPos = { x: 0, y: 0.81, z: 0 };
    ballVel = { x: 3.5, y: 2.2, z: 0.2 };
    ppBallMesh.position.set(0, 0.81, 0);
  };

  return {
    sceneGroup,
    deskGroupMap,
    interactiveObjects,
    screenTvMesh,
    whiteboardMesh,
    allScreenMeshes,
    elevatorCabinGroup,
    updateDeskMesh,
    updateTvTexture,
    updateWhiteboardTexture,
    updatePingPongMatch,
    resetServe,
    updateTrafficScenery: sceneryController.updateTraffic,
    updateSushiBar: sushiController.updateSushiBar,
    updateMeetingRoom: execScreens.updateMeetingRoom,
    updateBasementTheater: basementController.updateBasementTheater,
    updateTennisMatch: tennisController.updateTennisMatch,
    setTennisGameMode: tennisController.setGameMode,
    resetTennisServe: tennisController.resetServe,
    triggerTennisFireballSmash: tennisController.triggerFireballSmash,
    updateElevatorCabin,
  };
}

// Builds a single pixelated desk + chair + equipment
function createSingleDeskMesh(
  desk: DeskData,
  interactiveObjects: THREE.Object3D[],
  allScreenMeshes?: THREE.Mesh[]
): THREE.Group {
  const deskGroup = new THREE.Group();
  deskGroup.position.set(desk.x, 0, desk.z);
  deskGroup.name = `Desk_${desk.id}`;

  const deskWoodTex = getWoodTexture(desk.theme);
  const deskMat = new THREE.MeshStandardMaterial({ map: deskWoodTex });
  const metalMat = new THREE.MeshStandardMaterial({ color: 0x334155 });

  // Desk Surface
  const topGeo = new THREE.BoxGeometry(2.2, 0.15, 1.2);
  const topMesh = new THREE.Mesh(topGeo, deskMat);
  topMesh.position.y = 0.8;
  topMesh.castShadow = true;
  topMesh.receiveShadow = true;
  deskGroup.add(topMesh);

  // Hitbox for clicking to occupy/customize
  const clickBoxGeo = new THREE.BoxGeometry(2.4, 1.6, 1.6);
  const clickBoxMat = new THREE.MeshBasicMaterial({ visible: false });
  const clickBox = new THREE.Mesh(clickBoxGeo, clickBoxMat);
  clickBox.position.y = 0.8;
  clickBox.userData = { isDesk: true, deskId: desk.id };
  interactiveObjects.push(clickBox);
  deskGroup.add(clickBox);

  // Desk Legs
  const legPositions = [
    { x: -0.9, z: -0.4 },
    { x: 0.9, z: -0.4 },
    { x: -0.9, z: 0.4 },
    { x: 0.9, z: 0.4 },
  ];
  legPositions.forEach((p) => {
    const leg = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.8, 0.12), metalMat);
    leg.position.set(p.x, 0.4, p.z);
    deskGroup.add(leg);
  });

  // Chair
  const chairColor = desk.ownerId ? 0x0284c7 : 0x475569;
  const chairMat = new THREE.MeshStandardMaterial({ color: chairColor });
  const chairGroup = new THREE.Group();
  const seat = new THREE.Mesh(new THREE.BoxGeometry(0.7, 0.1, 0.7), chairMat);
  seat.position.y = 0.45;
  const back = new THREE.Mesh(new THREE.BoxGeometry(0.7, 0.6, 0.1), chairMat);
  back.position.set(0, 0.75, 0.3);
  chairGroup.add(seat, back);
  chairGroup.position.set(0, 0, 0.95);
  deskGroup.add(chairGroup);

  // Sleek Desk Lamp on left corner of every desk
  const deskLampGroup = new THREE.Group();
  const deskLampBase = new THREE.Mesh(
    new THREE.CylinderGeometry(0.08, 0.08, 0.02, 8),
    new THREE.MeshStandardMaterial({ color: 0x0284c7 })
  );
  deskLampBase.position.set(-0.8, 0.89, -0.4);
  const deskLampArm = new THREE.Mesh(
    new THREE.BoxGeometry(0.02, 0.3, 0.02),
    new THREE.MeshStandardMaterial({ color: 0x0f172a })
  );
  deskLampArm.position.set(-0.8, 1.04, -0.4);
  const deskLampShade = new THREE.Mesh(
    new THREE.ConeGeometry(0.1, 0.12, 8),
    new THREE.MeshStandardMaterial({ color: 0x0284c7, emissive: 0x38bdf8, emissiveIntensity: 0.4 })
  );
  deskLampShade.position.set(-0.8, 1.2, -0.35);
  deskLampShade.rotation.x = 0.3;
  deskLampGroup.add(deskLampBase, deskLampArm, deskLampShade);
  deskGroup.add(deskLampGroup);

  // Desk Gear / Equipment on top
  if (desk.gear === 'dual_monitors') {
    const scrMat = new THREE.MeshBasicMaterial({ color: 0x38bdf8 });
    const stand = new THREE.Mesh(new THREE.BoxGeometry(0.6, 0.1, 0.3), metalMat);
    stand.position.set(0, 0.9, -0.3);
    const mon1 = new THREE.Mesh(new THREE.BoxGeometry(0.8, 0.5, 0.05), scrMat);
    mon1.position.set(-0.45, 1.2, -0.25);
    mon1.rotation.y = 0.15; // Slightly angled inward facing the employee
    const mon2 = new THREE.Mesh(new THREE.BoxGeometry(0.8, 0.5, 0.05), scrMat);
    mon2.position.set(0.45, 1.2, -0.25);
    mon2.rotation.y = -0.15; // Slightly angled inward facing the employee
    mon1.userData = { idleTexture: null };
    mon2.userData = { idleTexture: null };
    if (allScreenMeshes) {
      allScreenMeshes.push(mon1, mon2);
    }
    deskGroup.add(stand, mon1, mon2);
  } else if (desk.gear === 'pixel_laptop') {
    // Laptop Base with Keyboard facing the employee at +Z
    const laptopBase = new THREE.Mesh(new THREE.BoxGeometry(0.52, 0.025, 0.36), metalMat);
    laptopBase.position.set(0, 0.89, -0.05);

    const keyboardMesh = new THREE.Mesh(
      new THREE.BoxGeometry(0.44, 0.005, 0.2),
      new THREE.MeshStandardMaterial({ color: 0x0f172a, roughness: 0.8 })
    );
    keyboardMesh.position.set(0, 0.905, 0.02);

    const trackpad = new THREE.Mesh(
      new THREE.BoxGeometry(0.18, 0.005, 0.09),
      new THREE.MeshStandardMaterial({ color: 0x1e293b, roughness: 0.5 })
    );
    trackpad.position.set(0, 0.905, 0.18);

    // Laptop Screen attached at -Z edge and tilted slightly backward, facing +Z directly at the employee!
    const laptopLid = new THREE.Mesh(
      new THREE.BoxGeometry(0.52, 0.36, 0.02),
      metalMat
    );
    laptopLid.position.set(0, 1.05, -0.22);
    laptopLid.rotation.x = -0.25;

    // Glowing Code IDE Display facing towards the seated employee (+Z)
    const codeCanvas = document.createElement('canvas');
    codeCanvas.width = 256;
    codeCanvas.height = 160;
    const cCtx = codeCanvas.getContext('2d')!;
    cCtx.fillStyle = '#0f172a';
    cCtx.fillRect(0, 0, 256, 160);
    // Editor syntax highlighted code lines
    const lineColors = ['#38bdf8', '#a855f7', '#22c55e', '#f59e0b', '#ec4899', '#38bdf8', '#f8fafc'];
    for (let l = 0; l < 9; l++) {
      cCtx.fillStyle = lineColors[l % lineColors.length];
      const lw = 40 + ((l * 29) % 150);
      cCtx.fillRect(20 + ((l % 3) * 12), 16 + l * 15, lw, 6);
    }
    const codeTex = new THREE.CanvasTexture(codeCanvas);
    const laptopScreenFace = new THREE.Mesh(
      new THREE.PlaneGeometry(0.48, 0.32),
      new THREE.MeshBasicMaterial({ map: codeTex })
    );
    laptopScreenFace.position.set(0, 1.05, -0.208);
    laptopScreenFace.rotation.x = -0.25;
    laptopScreenFace.userData = { idleTexture: codeTex };
    if (allScreenMeshes) {
      allScreenMeshes.push(laptopScreenFace);
    }

    deskGroup.add(laptopBase, keyboardMesh, trackpad, laptopLid, laptopScreenFace);
  } else if (desk.gear === 'designer_tablet') {
    const tabletMat = new THREE.MeshBasicMaterial({ color: 0x0f172a });
    const tablet = new THREE.Mesh(new THREE.BoxGeometry(0.6, 0.02, 0.4), tabletMat);
    tablet.position.set(0, 0.89, -0.1);
    tablet.userData = { idleTexture: null };
    if (allScreenMeshes) {
      allScreenMeshes.push(tablet);
    }
    deskGroup.add(tablet);
  } else {
    // Standard Workstation Monitor facing the employee (+Z)
    const scrMat = new THREE.MeshBasicMaterial({ color: 0x0284c7 });
    const stand = new THREE.Mesh(new THREE.BoxGeometry(0.3, 0.1, 0.2), metalMat);
    stand.position.set(0, 0.9, -0.3);
    const mon = new THREE.Mesh(new THREE.BoxGeometry(0.9, 0.55, 0.05), scrMat);
    mon.position.set(0, 1.2, -0.26); // Oriented with display facing towards the employee
    mon.userData = { idleTexture: null };
    if (allScreenMeshes) {
      allScreenMeshes.push(mon);
    }
    deskGroup.add(stand, mon);

    if (desk.gear === 'coffee_plant') {
      const mug = new THREE.Mesh(
        new THREE.CylinderGeometry(0.08, 0.08, 0.15, 8),
        new THREE.MeshStandardMaterial({ color: 0xef4444 })
      );
      mug.position.set(-0.5, 0.95, -0.1);
      const pot = new THREE.Mesh(
        new THREE.CylinderGeometry(0.15, 0.1, 0.25, 8),
        new THREE.MeshStandardMaterial({ color: 0xd97706 })
      );
      pot.position.set(0.5, 1.0, -0.2);
      const plant = new THREE.Mesh(
        new THREE.SphereGeometry(0.2, 8, 8),
        new THREE.MeshStandardMaterial({ color: 0x22c55e })
      );
      plant.position.set(0.5, 1.2, -0.2);
      deskGroup.add(mug, pot, plant);
    } else if (desk.gear === 'retro_arcade') {
      const arcade = new THREE.Mesh(
        new THREE.BoxGeometry(0.4, 0.6, 0.4),
        new THREE.MeshStandardMaterial({ color: 0xec4899 })
      );
      arcade.position.set(0.5, 1.2, -0.2);
      deskGroup.add(arcade);
    }
  }

  // Name plaque floating tag above desk
  const plaqueCanvas = document.createElement('canvas');
  plaqueCanvas.width = 256;
  plaqueCanvas.height = 64;
  const pCtx = plaqueCanvas.getContext('2d')!;
  pCtx.fillStyle = desk.ownerId ? '#0284c7' : '#334155';
  pCtx.fillRect(0, 0, 256, 64);
  pCtx.lineWidth = 4;
  pCtx.strokeStyle = '#ffffff';
  pCtx.strokeRect(2, 2, 252, 60);

  pCtx.fillStyle = '#ffffff';
  pCtx.font = 'bold 20px monospace';
  pCtx.textAlign = 'center';
  pCtx.fillText(desk.ownerName ? `👤 ${desk.ownerName}` : desk.label, 128, 28);
  pCtx.font = '14px monospace';
  pCtx.fillStyle = '#e0f2fe';
  pCtx.fillText(desk.customStatus || 'Click to claim desk', 128, 50);

  const plaqueTex = new THREE.CanvasTexture(plaqueCanvas);
  plaqueTex.magFilter = THREE.NearestFilter;
  const plaqueMat = new THREE.SpriteMaterial({ map: plaqueTex });
  const plaqueSprite = new THREE.Sprite(plaqueMat);
  plaqueSprite.scale.set(1.6, 0.4, 1);
  plaqueSprite.position.set(0, 1.85, 0);
  deskGroup.add(plaqueSprite);

  return deskGroup;
}

export function buildExecutiveMeetingRoom(sceneGroup: THREE.Group, interactiveObjects: THREE.Object3D[]) {
  const roomGroup = new THREE.Group();
  roomGroup.name = 'ExecutiveMeetingRoom';

  // Room Dimensions: Equal size to 1F Open Office & 3F Sushi Bar (24m x 20m x 5m at Y = 5.5m)
  const CENTER_X = 0;
  const CENTER_Z = 0;
  const FLOOR_Y = 5.5;
  const WIDTH = 24; // X dimension
  const DEPTH = 20; // Z dimension
  const HEIGHT = 5.0;

  // Modern Minimalist Materials
  const lightOakMat = new THREE.MeshStandardMaterial({ color: 0xf5dfbc, roughness: 0.4 });
  const beigeWallMat = new THREE.MeshStandardMaterial({ color: 0xe8d8c3, roughness: 0.6 });
  const floorMat = new THREE.MeshStandardMaterial({ color: 0xe2e8f0, roughness: 0.3 });
  const ceilingMat = new THREE.MeshStandardMaterial({ color: 0xf8fafc, roughness: 0.8 });
  const glassWhiteboardMat = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.1 });
  const silverTrimMat = new THREE.MeshStandardMaterial({ color: 0x94a3b8, metalness: 0.5, roughness: 0.3 });
  const chairCushionMat = new THREE.MeshStandardMaterial({ color: 0xf5f5f4, roughness: 0.8 });
  const darkBezelMat = new THREE.MeshStandardMaterial({ color: 0x0f172a, roughness: 0.3 });
  const ledLightMat = new THREE.MeshStandardMaterial({ color: 0xfffbeb, emissive: 0xfef08a, emissiveIntensity: 0.8 });

  // 1. SEAMLESS POLISHED FLOOR (20m x 14m at Y = 6.0)
  const floorMesh = new THREE.Mesh(new THREE.PlaneGeometry(WIDTH, DEPTH), floorMat);
  floorMesh.rotation.x = -Math.PI / 2;
  floorMesh.position.set(CENTER_X, FLOOR_Y, CENTER_Z);
  floorMesh.receiveShadow = true;
  roomGroup.add(floorMesh);

  // Floor border trims
  const floorBorderNorth = new THREE.Mesh(new THREE.BoxGeometry(WIDTH, 0.08, 0.15), silverTrimMat);
  floorBorderNorth.position.set(CENTER_X, FLOOR_Y + 0.04, -DEPTH / 2 + 0.08);
  const floorBorderSouth = new THREE.Mesh(new THREE.BoxGeometry(WIDTH, 0.08, 0.15), silverTrimMat);
  floorBorderSouth.position.set(CENTER_X, FLOOR_Y + 0.04, DEPTH / 2 - 0.08);
  roomGroup.add(floorBorderNorth, floorBorderSouth);

  // 2. CEILING & RECESSED LED LIGHT STRIPS
  const ceilingMesh = new THREE.Mesh(new THREE.PlaneGeometry(WIDTH, DEPTH), ceilingMat);
  ceilingMesh.rotation.x = Math.PI / 2;
  ceilingMesh.position.set(CENTER_X, FLOOR_Y + HEIGHT, CENTER_Z);
  roomGroup.add(ceilingMesh);

  // Perimeter Recessed LED Strip Light Channels along ceiling
  const ledNorth = new THREE.Mesh(new THREE.BoxGeometry(WIDTH - 0.4, 0.1, 0.2), ledLightMat);
  ledNorth.position.set(CENTER_X, FLOOR_Y + HEIGHT - 0.05, -DEPTH / 2 + 0.3);
  const ledSouth = new THREE.Mesh(new THREE.BoxGeometry(WIDTH - 0.4, 0.1, 0.2), ledLightMat);
  ledSouth.position.set(CENTER_X, FLOOR_Y + HEIGHT - 0.05, DEPTH / 2 - 0.3);
  roomGroup.add(ledNorth, ledSouth);

  // Suspended Linear Pendant Light directly over conference table (Y = 9.6m)
  const pendantGroup = new THREE.Group();
  pendantGroup.position.set(CENTER_X - 0.5, FLOOR_Y + 3.6, CENTER_Z);

  // Hanging wire cables
  for (const px of [-3.5, 3.5]) {
    const wire = new THREE.Mesh(new THREE.CylinderGeometry(0.015, 0.015, 0.9, 6), silverTrimMat);
    wire.position.set(px, 0.45, 0);
    pendantGroup.add(wire);
  }
  // Aluminum Linear Light Bar
  const lightBar = new THREE.Mesh(new THREE.BoxGeometry(8.5, 0.12, 0.25), silverTrimMat);
  lightBar.position.set(0, 0, 0);
  const lightEmitter = new THREE.Mesh(new THREE.BoxGeometry(8.3, 0.02, 0.21), ledLightMat);
  lightEmitter.position.set(0, -0.06, 0);
  pendantGroup.add(lightBar, lightEmitter);

  // Downlight Point Lights for soft warm illumination
  const pendantLight1 = new THREE.PointLight(0xfffbeb, 1.2, 12);
  pendantLight1.position.set(-2, -0.2, 0);
  const pendantLight2 = new THREE.PointLight(0xfffbeb, 1.2, 12);
  pendantLight2.position.set(2, -0.2, 0);
  pendantGroup.add(pendantLight1, pendantLight2);

  roomGroup.add(pendantGroup);

  // WEST WALL (X = -10): Floor-to-Ceiling Glass View Wall overlooking Golden Gate Bridge & Traffic
  const westWallGlass = new THREE.Mesh(
    new THREE.BoxGeometry(0.1, HEIGHT, DEPTH),
    new THREE.MeshStandardMaterial({ color: 0x38bdf8, transparent: true, opacity: 0.25, roughness: 0.1 })
  );
  westWallGlass.position.set(CENTER_X - WIDTH / 2, FLOOR_Y + HEIGHT / 2, CENTER_Z);

  for (let mz = -5; mz <= 5; mz += 2.5) {
    const mullion = new THREE.Mesh(new THREE.BoxGeometry(0.12, HEIGHT, 0.12), silverTrimMat);
    mullion.position.set(CENTER_X - WIDTH / 2 + 0.05, FLOOR_Y + HEIGHT / 2, mz);
    roomGroup.add(mullion);
  }
  roomGroup.add(westWallGlass);

  // 3. NORTH WALL (Z = -7): Backlit Warm Glass & Beige Paneling
  const northWall = new THREE.Mesh(new THREE.BoxGeometry(WIDTH, HEIGHT, 0.3), beigeWallMat);
  northWall.position.set(CENTER_X, FLOOR_Y + HEIGHT / 2, -DEPTH / 2);
  roomGroup.add(northWall);

  // Vertical Frosted Backlit Glass Panels
  for (let gx = -8; gx <= 8; gx += 4) {
    const glassPanel = new THREE.Mesh(
      new THREE.BoxGeometry(1.2, HEIGHT - 0.8, 0.08),
      new THREE.MeshStandardMaterial({ color: 0xfef3c7, emissive: 0xfde047, emissiveIntensity: 0.2, transparent: true, opacity: 0.85 })
    );
    glassPanel.position.set(gx, FLOOR_Y + HEIGHT / 2, -DEPTH / 2 + 0.18);
    roomGroup.add(glassPanel);
  }

  // 4. SOUTH WALL (Z = 7): Floor-to-Ceiling Whiteboard Wall
  const southWallBase = new THREE.Mesh(new THREE.BoxGeometry(WIDTH, HEIGHT, 0.3), beigeWallMat);
  southWallBase.position.set(CENTER_X, FLOOR_Y + HEIGHT / 2, DEPTH / 2);
  roomGroup.add(southWallBase);

  // Glass Whiteboard
  const whiteboardMesh = new THREE.Mesh(new THREE.BoxGeometry(16, 3.6, 0.05), glassWhiteboardMat);
  whiteboardMesh.position.set(CENTER_X, FLOOR_Y + HEIGHT / 2, DEPTH / 2 - 0.18);
  const whiteboardFrame = new THREE.Mesh(new THREE.BoxGeometry(16.2, 3.75, 0.04), silverTrimMat);
  whiteboardFrame.position.set(CENTER_X, FLOOR_Y + HEIGHT / 2, DEPTH / 2 - 0.16);

  // Whiteboard marker tray & floating notes diagram canvas texture
  const wbCanvas = document.createElement('canvas');
  wbCanvas.width = 1024;
  wbCanvas.height = 512;
  const wbCtx = wbCanvas.getContext('2d')!;
  drawArtistPortraits(wbCtx, 1024, 512);

  const wbTex = new THREE.CanvasTexture(wbCanvas);
  const wbDiagramMesh = new THREE.Mesh(
    new THREE.PlaneGeometry(15.8, 3.5),
    new THREE.MeshBasicMaterial({ map: wbTex })
  );
  wbDiagramMesh.position.set(CENTER_X, FLOOR_Y + HEIGHT / 2, DEPTH / 2 - 0.22);
  wbDiagramMesh.rotation.y = Math.PI;

  roomGroup.add(southWallBase, whiteboardFrame, whiteboardMesh, wbDiagramMesh);

  // 5. EAST / END WALL (X = 10): Presentation Screen & Video Conference Cam
  const eastWall = new THREE.Mesh(new THREE.BoxGeometry(0.3, HEIGHT, DEPTH), beigeWallMat);
  eastWall.position.set(CENTER_X + WIDTH / 2, FLOOR_Y + HEIGHT / 2, CENTER_Z);
  roomGroup.add(eastWall);

  // Scandinavian Vertical Acoustic Wood Slat Feature Wall Panel behind 2F Presentation Screen TV
  const scandiWoodSlatTex2F = getScandinavianWoodSlatTexture();
  scandiWoodSlatTex2F.repeat.set(8, 4);
  const scandiWoodMat2F = new THREE.MeshStandardMaterial({ map: scandiWoodSlatTex2F, roughness: 0.6 });

  const scandiWallPanel2F = new THREE.Mesh(
    new THREE.BoxGeometry(0.08, 4.4, 8.4),
    scandiWoodMat2F
  );
  scandiWallPanel2F.position.set(CENTER_X + WIDTH / 2 - 0.12, FLOOR_Y + 2.3, 0);

  // Warm LED Perimeter Backlight behind TV & Wood paneling
  const scandiBacklight2F = new THREE.PointLight(0xfde047, 1.2, 12);
  scandiBacklight2F.position.set(CENTER_X + WIDTH / 2 - 0.22, FLOOR_Y + 2.3, 0);

  const scandiTrimMat2F = new THREE.MeshStandardMaterial({ color: 0x0f172a, metalness: 0.8, roughness: 0.2 });
  const scandiFrameTop2F = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.08, 8.44), scandiTrimMat2F);
  scandiFrameTop2F.position.set(CENTER_X + WIDTH / 2 - 0.12, FLOOR_Y + 2.3 + 2.2, 0);
  const scandiFrameBottom2F = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.08, 8.44), scandiTrimMat2F);
  scandiFrameBottom2F.position.set(CENTER_X + WIDTH / 2 - 0.12, FLOOR_Y + 2.3 - 2.2, 0);

  roomGroup.add(scandiWallPanel2F, scandiFrameTop2F, scandiFrameBottom2F, scandiBacklight2F);

  // Presentation Screen Bezel
  const screenBezel = new THREE.Mesh(new THREE.BoxGeometry(0.12, 3.2, 5.6), darkBezelMat);
  screenBezel.position.set(CENTER_X + WIDTH / 2 - 0.18, FLOOR_Y + 2.3, 0);

  const screenSilverFrame = new THREE.Mesh(new THREE.BoxGeometry(0.14, 3.35, 5.75), silverTrimMat);
  screenSilverFrame.position.set(CENTER_X + WIDTH / 2 - 0.16, FLOOR_Y + 2.3, 0);

  // Screen Canvas Display
  const screenCanvas = document.createElement('canvas');
  screenCanvas.width = 1024;
  screenCanvas.height = 576;
  const sCtx = screenCanvas.getContext('2d')!;

  const grad = sCtx.createRadialGradient(512, 288, 50, 512, 288, 600);
  grad.addColorStop(0, '#38bdf8');
  grad.addColorStop(0.5, '#0284c7');
  grad.addColorStop(1, '#0f172a');
  sCtx.fillStyle = grad;
  sCtx.fillRect(0, 0, 1024, 576);

  sCtx.fillStyle = '#ffffff';
  sCtx.font = 'bold 80px sans-serif';
  sCtx.textAlign = 'center';
  sCtx.fillText('', 512, 270);

  sCtx.font = 'bold 28px sans-serif';
  sCtx.fillStyle = '#f0f9ff';
  sCtx.fillText('Executive Boardroom Sync (2F)', 512, 360);
  sCtx.font = '20px monospace';
  sCtx.fillStyle = '#38bdf8';
  sCtx.fillText('Screen Share Ready • 4K HDR', 512, 410);

  const screenTex = new THREE.CanvasTexture(screenCanvas);
  const screenMesh = new THREE.Mesh(
    new THREE.PlaneGeometry(5.4, 3.0),
    new THREE.MeshBasicMaterial({ map: screenTex })
  );
  screenMesh.userData = { idleTexture: screenTex };
  screenMesh.position.set(CENTER_X + WIDTH / 2 - 0.25, FLOOR_Y + 2.3, 0);
  screenMesh.rotation.y = -Math.PI / 2;

  // Video Conference Camera Module
  const camModule = new THREE.Mesh(new THREE.BoxGeometry(0.25, 0.35, 0.9), silverTrimMat);
  camModule.position.set(CENTER_X + WIDTH / 2 - 0.2, FLOOR_Y + 4.05, 0);
  const camLens = new THREE.Mesh(new THREE.CylinderGeometry(0.1, 0.1, 0.1, 16), darkBezelMat);
  camLens.rotation.z = Math.PI / 2;
  camLens.position.set(CENTER_X + WIDTH / 2 - 0.33, FLOOR_Y + 4.05, 0);

  roomGroup.add(eastWall, screenSilverFrame, screenBezel, screenMesh, camModule, camLens);

  // 6. EXECUTIVE LIGHT OAK CONFERENCE TABLE
  const TABLE_X = -0.5;
  const TABLE_Z = 0;
  const TABLE_W = 9.5; // along X
  const TABLE_D = 2.2; // along Z

  const tableTopMesh = new THREE.Mesh(new THREE.BoxGeometry(TABLE_W, 0.1, TABLE_D), lightOakMat);
  tableTopMesh.position.set(TABLE_X, FLOOR_Y + 0.72, TABLE_Z);
  tableTopMesh.castShadow = true;
  tableTopMesh.receiveShadow = true;

  const tableEdgeTrim = new THREE.Mesh(new THREE.BoxGeometry(TABLE_W + 0.08, 0.05, TABLE_D + 0.08), lightOakMat);
  tableEdgeTrim.position.set(TABLE_X, FLOOR_Y + 0.74, TABLE_Z);

  for (const px of [TABLE_X - 2.8, TABLE_X + 2.8]) {
    const ped = new THREE.Mesh(new THREE.BoxGeometry(1.2, 0.67, 1.2), lightOakMat);
    ped.position.set(px, FLOOR_Y + 0.335, TABLE_Z);
    roomGroup.add(ped);
  }

  // Tablet Control Console on center of table
  const consoleMesh = new THREE.Mesh(new THREE.BoxGeometry(0.45, 0.03, 0.35), silverTrimMat);
  consoleMesh.position.set(TABLE_X, FLOOR_Y + 0.78, TABLE_Z);
  consoleMesh.rotation.x = -0.2;

  const consoleCanvas = document.createElement('canvas');
  consoleCanvas.width = 256;
  consoleCanvas.height = 192;
  const cCtx = consoleCanvas.getContext('2d')!;
  cCtx.fillStyle = '#0f172a';
  cCtx.fillRect(0, 0, 256, 192);
  cCtx.fillStyle = '#38bdf8';
  cCtx.font = 'bold 28px sans-serif';
  cCtx.textAlign = 'center';
  cCtx.fillText('10:00 AM', 128, 70);
  cCtx.fillStyle = '#f8fafc';
  cCtx.font = '16px sans-serif';
  cCtx.fillText('Boardroom Sync', 128, 110);
  cCtx.fillStyle = '#22c55e';
  cCtx.fillText('• Microphones Active', 128, 150);

  const consoleTex = new THREE.CanvasTexture(consoleCanvas);
  const consoleScreen = new THREE.Mesh(
    new THREE.PlaneGeometry(0.4, 0.3),
    new THREE.MeshBasicMaterial({ map: consoleTex })
  );
  consoleScreen.userData = { idleTexture: consoleTex };
  consoleScreen.position.set(TABLE_X, FLOOR_Y + 0.796, TABLE_Z);
  consoleScreen.rotation.x = -Math.PI / 2 - 0.2;

  roomGroup.add(tableTopMesh, tableEdgeTrim, consoleMesh, consoleScreen);

  // 7. CURVED ERGONOMICS WOODEN CONFERENCE CHAIRS (8 Chairs total) with Interactive Raycasting
  const chairPositions: { x: number; z: number; rotY: number }[] = [];
  const chairXs = [TABLE_X - 3.2, TABLE_X - 1.1, TABLE_X + 1.1, TABLE_X + 3.2];

  // North Side Chairs (facing South / Z+)
  chairXs.forEach((cx) => chairPositions.push({ x: cx, z: -1.65, rotY: 0 }));
  // South Side Chairs (facing North / Z-)
  chairXs.forEach((cx) => chairPositions.push({ x: cx, z: 1.65, rotY: Math.PI }));

  chairPositions.forEach((cp, idx) => {
    const chairGroup = new THREE.Group();
    chairGroup.position.set(cp.x, FLOOR_Y, cp.z);
    chairGroup.rotation.y = cp.rotY;

    const seat = new THREE.Mesh(new THREE.BoxGeometry(0.6, 0.06, 0.55), lightOakMat);
    seat.position.y = 0.42;

    const cushion = new THREE.Mesh(new THREE.BoxGeometry(0.52, 0.05, 0.48), chairCushionMat);
    cushion.position.y = 0.46;

    const backrest = new THREE.Mesh(new THREE.BoxGeometry(0.56, 0.38, 0.06), lightOakMat);
    backrest.position.set(0, 0.65, -0.24);

    for (const side of [-0.28, 0.28]) {
      const arm = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.2, 0.42), lightOakMat);
      arm.position.set(side, 0.52, 0);
      chairGroup.add(arm);
    }

    for (const lx of [-0.24, 0.24]) {
      for (const lz of [-0.22, 0.22]) {
        const leg = new THREE.Mesh(new THREE.CylinderGeometry(0.025, 0.025, 0.42, 8), silverTrimMat);
        leg.position.set(lx, 0.21, lz);
        chairGroup.add(leg);
      }
    }

    // Interactive Invisible Hitbox for clicking to sit on chair
    const chairHitBox = new THREE.Mesh(
      new THREE.BoxGeometry(0.8, 1.0, 0.8),
      new THREE.MeshBasicMaterial({ visible: false })
    );
    chairHitBox.position.set(0, 0.5, 0);
    chairHitBox.userData = {
      isMeetingChair: true,
      chairIndex: idx,
      seatPos: { x: cp.x, y: FLOOR_Y, z: cp.z },
      rotY: cp.rotY,
    };
    interactiveObjects.push(chairHitBox);
    chairGroup.add(chairHitBox);

    chairGroup.add(seat, cushion, backrest);
    roomGroup.add(chairGroup);
  });

  // 8. NPC COLLEAGUES SEATED AT TABLE (4 Executive Professionals representing SF American Demographics)
  const npcConfigs = [
    {
      name: 'Claire Wang',
      role: 'VP Product Strategy',
      skin: 'college_dev_f' as const,
      ethnicity: 'east_asian_1',
      hairColor: '#0f0f11',
      badgeColor: '#ec4899',
      badgeIcon: '👩‍💼',
      x: TABLE_X - 1.1,
      z: -1.65,
      rotY: 0,
      dialogues: [
        '💬 "Q3 Product roadmap is ready! 🚀"',
        '📊 "User engagement up +48%!"',
        '💡 "Great design layout, Lisa!"',
      ],
    },
    {
      name: 'Lisa Morales',
      role: 'Chief Design Officer',
      skin: 'college_dev_f' as const,
      ethnicity: 'latino_1',
      hairColor: '#5c2b0e',
      badgeColor: '#a855f7',
      badgeIcon: '👩‍💼',
      x: TABLE_X + 1.1,
      z: 1.65,
      rotY: Math.PI,
      dialogues: [
        '🎨 "Figma design system polished! ✨"',
        '👏 "Love the AI features, Marcus!"',
        '😊 "Our office vibe is amazing!"',
      ],
    },
    {
      name: 'Marcus Washington',
      role: 'Chief Technology Officer',
      skin: 'college_dev_m' as const,
      ethnicity: 'black_1',
      hairColor: '#0f0f11',
      badgeColor: '#38bdf8',
      badgeIcon: '👨‍💼',
      x: TABLE_X - 3.2,
      z: -1.65,
      rotY: 0,
      dialogues: [
        '⚡ "WebGL 3D engine at 60 FPS!"',
        '🛡️ "Security audit passed 100%!"',
        '☕ "Let\'s grab Matcha at 3F cafe!"',
      ],
    },
    {
      name: 'Fortune Cookie',
      role: 'Head of AI Engineering',
      skin: 'college_dev_f' as const,
      ethnicity: 'caucasian_1',
      hairColor: '#c89849',
      badgeColor: '#22c55e',
      badgeIcon: '👩‍🔬',
      x: TABLE_X + 3.2,
      z: 1.65,
      rotY: Math.PI,
      dialogues: [
        '🤖 "Gemini models integrated!"',
        '📈 "Real-time sync latencies <20ms!"',
        '🎉 "Team sync was a total success!"',
      ],
    },
  ];

  const meetingAvatars: Array<{
    avatar: any;
    dialogueSprite: THREE.Sprite;
    dialogueCanvas: HTMLCanvasElement;
    dialogueCtx: CanvasRenderingContext2D;
    dialogueTex: THREE.CanvasTexture;
    dialogues: string[];
  }> = [];

  npcConfigs.forEach((npc, index) => {
    const dummyUser: UserState = {
      id: `npc_${index}`,
      name: npc.name,
      skin: npc.skin,
      ethnicity: npc.ethnicity,
      hairColor: npc.hairColor,
      department: (npc.role.includes('Product') ? 'Product' : npc.role.includes('Architect') || npc.role.includes('Technology') || npc.role.includes('AI') ? 'Engineering' : 'Design') as Department,
      position: { x: npc.x, y: FLOOR_Y, z: npc.z },
      rotationY: npc.rotY,
      isMoving: false,
      isSpeaking: false,
      isMuted: true,
      isScreenSharing: false,
      claimedDeskId: null,
      statusText: npc.role,
      color: npc.badgeColor,
    };

    const npcAvatar = createVoxelAvatarMesh(dummyUser);
    npcAvatar.group.position.set(npc.x, FLOOR_Y, npc.z);
    npcAvatar.group.rotation.y = npc.rotY;

    // Apply natural seated desk/table kinematics
    npcAvatar.updateAnimation(index * 1.7, false, false, true);

    npcAvatar.headMesh.rotation.y = index % 2 === 0 ? 0.15 : -0.15;

    // Single unified badge already handled inside createVoxelAvatarMesh(dummyUser)
    roomGroup.add(npcAvatar.group);
  });

  sceneGroup.add(roomGroup);

  const updateMeetingRoom = (_time: number, _delta: number) => {
    // Meeting discussion interactions removed per user request
  };

  return { screenMesh, consoleScreen, updateMeetingRoom };
}
