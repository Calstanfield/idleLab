import { useState, useEffect, useRef } from 'react';
import {
  UserState,
  DeskData,
  WhiteboardStroke,
  ChatMessage,
  AvatarSkin,
  Department,
  Position3D,
  DeskTheme,
  DeskGear,
  ServerEvent,
  ChecklistItem,
  SavedContactNote,
  GestureType,
  OfficeProjectionState,
  SpatialZone,
  ScooterConfig,
} from './types';
import { socketClient } from './lib/socketClient';
import { audioManager } from './lib/audioManager';
import { notificationManager } from './lib/notificationManager';
import { soundEffects } from './lib/soundEffects';
import { JoinModal } from './components/JoinModal';
import { OfficeCanvas } from './components/OfficeCanvas';
import { ControlBar } from './components/ControlBar';
import { ChatOverlay } from './components/ChatOverlay';
import { ScreenShareOverlay } from './components/ScreenShareOverlay';
import { SavedContactsModal } from './components/SavedContactsModal';
import { ChecklistModal } from './components/ChecklistModal';
import { GestureEmojiBar } from './components/GestureEmojiBar';
import { ElevatorModal } from './components/ElevatorModal';
import { CoffeeRobotModal } from './components/CoffeeRobotModal';
import { LibraryModal } from './components/LibraryModal';
import { AgentFlowModal } from './components/AgentFlowModal';
import { PresentationAnnouncementModal } from './components/PresentationAnnouncementModal';
import { AvatarCustomizerModal } from './components/AvatarCustomizerModal';
import { WebShareModal } from './components/WebShareModal';
import { SettingsModal } from './components/SettingsModal';
import { EmoteWheelModal } from './components/EmoteWheelModal';
import { PomodoroModal } from './components/PomodoroModal';
import { ATMSubmissionModal } from './components/ATMSubmissionModal';
import { HydrationReminderToast } from './components/HydrationReminderToast';
import { DataCenterBookmark } from './types';
import { chloeAgentClient } from './lib/chloeAgentClient';

import { FigmaHeader } from './components/IdleLabHeader';
import { FigmaInspectorPanel } from './components/IdleLabInspector';
import { B1ChloeGradingModal, SubmissionPayload } from './components/B1ChloeGradingModal';
import { AgentFacilitatorModal } from './components/AgentFacilitatorModal';
import { speechCommandListener, parseChloeIntent } from './lib/speechCommandListener';
import { simulatorEngine } from './lib/simulatorEngine';
import { chloeVoice } from './lib/chloeVoice';

import { SwiftNoteModal } from './components/SwiftNoteModal';

export default function App() {
  const [currentUser, setCurrentUser] = useState<UserState | null>(null);
  const [remoteUsers, setRemoteUsers] = useState<Map<string, UserState>>(new Map());
  const [desks, setDesks] = useState<DeskData[]>([]);
  const [whiteboardStrokes, setWhiteboardStrokes] = useState<WhiteboardStroke[]>([]);
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([]);
  const [presenterUserId, setPresenterUserId] = useState<string | null>(null);
  const [sharedChecklist, setSharedChecklist] = useState<ChecklistItem[]>([]);
  const [sharedContacts, setSharedContacts] = useState<SavedContactNote[]>([]);
  const [unreadNotificationsCount, setUnreadNotificationsCount] = useState<number>(0);
  const [fsmToast, setFsmToast] = useState<{ state: string; target?: string; detail?: string; timestamp: number } | null>(null);

  // UI Modals & Figma Panels
  const [hasJoined, setHasJoined] = useState(false);
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [isWhiteboardOpen, setIsWhiteboardOpen] = useState(false);
  const [isSavedContactsOpen, setIsSavedContactsOpen] = useState(false);
  const [isChecklistOpen, setIsChecklistOpen] = useState(false);
  const [isElevatorOpen, setIsElevatorOpen] = useState(false);
  const [elevatorTargetFloor, setElevatorTargetFloor] = useState<{ targetY: number; reqId: number } | null>(null);
  const [isElevatorMoving, setIsElevatorMoving] = useState<boolean>(false);
  const [isCoffeeRobotOpen, setIsCoffeeRobotOpen] = useState(false);
  const [isLibraryOpen, setIsLibraryOpen] = useState(false);
  const [isAtmModalOpen, setIsAtmModalOpen] = useState(false);
  const [isSwiftNoteOpen, setIsSwiftNoteOpen] = useState(false);
  const [isClaireModalOpen, setIsClaireModalOpen] = useState(false);
  const [chloeWaveCount, setChloeWaveCount] = useState<number>(0);
  const [claireWaveCount, setClaireWaveCount] = useState<number>(0);
  const [isHoldingBat, setIsHoldingBat] = useState(false);
  const [equippedItem, setEquippedItem] = useState<string | null>(null);
  const [lastFloorY, setLastFloorY] = useState<number>(0);

  // Floor transition reset effect: ping pong bat / active items are strictly restricted to 1st floor
  useEffect(() => {
    if (!currentUser) return;
    const currentY = currentUser.position.y || 0;
    const isMainFloor = Math.abs(currentY - 0.0) < 1.5;
    if (!isMainFloor) {
      setIsHoldingBat(false);
      setEquippedItem(null);
    }
    const floorChanged = Math.floor(currentY / 5) !== Math.floor(lastFloorY / 5);
    if (floorChanged) {
      setIsHoldingBat(false);
      setEquippedItem(null);
      setLastFloorY(currentY);
    }
  }, [currentUser?.position?.y, lastFloorY]);
  const [isDataCenterOpen, setIsDataCenterOpen] = useState(false);
  const [isPresentationModalOpen, setIsPresentationModalOpen] = useState(false);
  const [isPomodoroOpen, setIsPomodoroOpen] = useState(false);
  const [isAvatarCustomizerOpen, setIsAvatarCustomizerOpen] = useState(false);
  const [isWebShareOpen, setIsWebShareOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isEmoteWheelOpen, setIsEmoteWheelOpen] = useState(false);
  const [isLabGuideOpen, setIsLabGuideOpen] = useState(false);
  const [isMeetingActive, setIsMeetingActive] = useState(false);
  const [isB1GradingModalOpen, setIsB1GradingModalOpen] = useState(false);
  const [activeSubmissionPayload, setActiveSubmissionPayload] = useState<SubmissionPayload | null>(null);
  const [userSalaryBalance, setUserSalaryBalance] = useState<number>(() => {
    try {
      const saved = localStorage.getItem('idlelab_user_salary');
      if (saved) return parseInt(saved, 10);
    } catch (e) {}
    return 0;
  });
  const [dataCenterBookmarks, setDataCenterBookmarks] = useState<DataCenterBookmark[]>(() => {
    try {
      const saved = localStorage.getItem('b1_datacenter_bookmarks');
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error(e);
    }
    return [
      {
        id: 'bm-1',
        title: 'Production Kubernetes Cluster',
        url: 'https://k8s.company-hq.internal/dashboard',
        category: 'Production',
        description: 'Main us-east1 container cluster orchestrator and pod telemetry.',
        tags: ['k8s', 'prod', 'orchestration'],
        createdAt: Date.now() - 86400000 * 5,
        pinned: true,
      },
      {
        id: 'bm-2',
        title: 'Grafana Telemetry & Metrics',
        url: 'https://grafana.internal.infra/d/main-dash',
        category: 'Monitoring & Logs',
        description: 'Real-time CPU, RAM, API latencies, and WebSocket error budgets.',
        tags: ['metrics', 'grafana', 'apm'],
        createdAt: Date.now() - 86400000 * 4,
        pinned: true,
      },
      {
        id: 'bm-3',
        title: 'Figma Design System (Voxel UI)',
        url: 'https://www.figma.com/design-system/voxel-enterprise',
        category: 'Design & Figma',
        description: 'Master component library, typography tokens, and 3D UI palettes.',
        tags: ['figma', 'design-system', 'tokens'],
        createdAt: Date.now() - 86400000 * 3,
        pinned: true,
      },
      {
        id: 'bm-4',
        title: 'Antigravity Workspace Engine',
        url: 'https://github.com/google-deepmind/antigravity',
        category: 'Engineering & Docs',
        description: 'Multiplayer WebGL spatial canvas, WebRTC, and low-latency audio protocols.',
        tags: ['webrtc', 'webgl', 'threejs'],
        createdAt: Date.now() - 86400000 * 2,
        pinned: false,
      },
    ];
  });
  const [isLayersPanelOpen, setIsLayersPanelOpen] = useState(false);
  const [isInspectorPanelOpen, setIsInspectorPanelOpen] = useState(false);
  const [isCameraOn, setIsCameraOn] = useState(false);
  const [cameraMode, setCameraMode] = useState<'third_person' | 'first_person' | 'isometric'>('third_person');
  const [screenShareStream, setScreenShareStream] = useState<MediaStream | null>(null);
  const [screenShareFrame, setScreenShareFrame] = useState<string | null>(null);

  const currentUserRef = useRef<UserState | null>(null);
  currentUserRef.current = currentUser;

  const isChatOpenRef = useRef<boolean>(false);
  isChatOpenRef.current = isChatOpen;

  // Gesture & Smart Emoji Reaction Events
  const [lastGestureEvent, setLastGestureEvent] = useState<{ userId: string; gesture: GestureType; id: number } | null>(null);
  const [lastEmojiEvent, setLastEmojiEvent] = useState<{ userId: string; emoji: string; gesture?: GestureType; id: number } | null>(null);

  const handleToggleCamera = async () => {
    const active = await audioManager.enableCamera();
    setIsCameraOn(active);
  };

  // Initialize Socket connection
  useEffect(() => {
    socketClient.connect().then(() => {
      console.log('Connected to VR Office WebSocket server!');
    }).catch(console.error);

    // Socket Event Dispatcher
    const handleServerEvent = (event: ServerEvent) => {
      switch (event.type) {
        case 'INIT_STATE': {
          audioManager.setUserId(event.userId);
          const myUserObj = event.users.find((u) => u.id === event.userId) || null;
          setCurrentUser(myUserObj);

          const remotes = new Map<string, UserState>();
          event.users.forEach((u) => {
            if (u.id !== event.userId) {
              remotes.set(u.id, u);
              audioManager.initiatePeerConnection(u.id);
            }
          });
          setRemoteUsers(remotes);
          setDesks(event.desks);
          setWhiteboardStrokes(event.whiteboard);
          setPresenterUserId(event.screenShareUser);
          if (event.checklist) setSharedChecklist(event.checklist);
          if (event.contacts) setSharedContacts(event.contacts);
          break;
        }

        case 'USER_JOINED': {
          setRemoteUsers((prev) => {
            const next = new Map(prev);
            next.set(event.user.id, event.user);
            return next;
          });
          audioManager.initiatePeerConnection(event.user.id);
          break;
        }

        case 'USER_LEFT': {
          setRemoteUsers((prev) => {
            const next = new Map(prev);
            next.delete(event.userId);
            return next;
          });
          audioManager.removePeer(event.userId);
          break;
        }

        case 'USER_MOVED': {
          setRemoteUsers((prev) => {
            const existing = prev.get(event.userId);
            if (existing) {
              const next = new Map(prev);
              next.set(event.userId, {
                ...existing,
                position: event.position,
                rotationY: event.rotationY,
                isMoving: event.isMoving,
              });
              return next;
            }
            return prev;
          });
          break;
        }

        case 'USER_STATUS_UPDATED': {
          setRemoteUsers((prev) => {
            const existing = prev.get(event.userId);
            if (existing) {
              const next = new Map(prev);
              next.set(event.userId, {
                ...existing,
                isSpeaking: event.isSpeaking ?? existing.isSpeaking,
                isMuted: event.isMuted ?? existing.isMuted,
                isScreenSharing: event.isScreenSharing ?? existing.isScreenSharing,
                statusText: event.statusText ?? existing.statusText,
              });
              return next;
            }
            return prev;
          });
          break;
        }

        case 'USER_AVATAR_UPDATED': {
          setRemoteUsers((prev) => {
            const existing = prev.get(event.userId);
            if (existing) {
              const next = new Map(prev);
              next.set(event.userId, {
                ...existing,
                skin: event.skin ?? existing.skin,
                hoodieColor: event.hoodieColor ?? existing.hoodieColor,
                color: event.hoodieColor ?? existing.color,
                hairColor: event.hairColor ?? existing.hairColor,
                ethnicity: event.ethnicity ?? existing.ethnicity,
                skinTone: event.skinTone ?? existing.skinTone,
                pantsColor: event.pantsColor ?? existing.pantsColor,
                shoesColor: event.shoesColor ?? existing.shoesColor,
                capColor: event.capColor ?? existing.capColor,
                scarfColor: event.scarfColor ?? existing.scarfColor,
                isRidingScooter: event.isRidingScooter !== undefined ? event.isRidingScooter : existing.isRidingScooter,
                scooterConfig: event.scooterConfig ?? existing.scooterConfig,
              });
              return next;
            }
            return prev;
          });
          break;
        }

        case 'USER_GESTURE': {
          setLastGestureEvent({ userId: event.userId, gesture: event.gesture, id: Date.now() + Math.random() });
          soundEffects.playEmote();
          break;
        }

        case 'EMOJI_REACTION': {
          setLastEmojiEvent({ userId: event.userId, emoji: event.emoji, gesture: event.gesture, id: Date.now() + Math.random() });
          soundEffects.playEmote();
          break;
        }

        case 'DESK_UPDATED': {
          setDesks((prev) => prev.map((d) => (d.id === event.desk.id ? event.desk : d)));
          break;
        }

        case 'WHITEBOARD_STROKE': {
          setWhiteboardStrokes((prev) => [...prev, event.stroke]);
          break;
        }

        case 'WHITEBOARD_CLEARED': {
          setWhiteboardStrokes([]);
          soundEffects.playPop();
          break;
        }

        case 'CHAT_MESSAGE': {
          const msg = event.message;
          setChatMessages((prev) => [...prev, msg]);

          // Auto-response speech: Chloe speaks when sending messages
          if (msg.senderId === 'npc_b1_chloe' || msg.senderName.includes('Chloe')) {
            chloeVoice.speak(msg.text, 'chloe_chat_speech');
          }

          const activeUser = currentUserRef.current;
          if (activeUser && msg.senderId !== activeUser.id) {
            const isDirectMessage = !!(msg.isPrivate && msg.recipientId === activeUser.id);
            const isMentioned = !msg.isPrivate && notificationManager.isMentioned(msg.text, activeUser.name);

            if (isDirectMessage || isMentioned) {
              soundEffects.playMentionAlert();
              const title = isDirectMessage
                ? `🔒 Direct Message from ${msg.senderName}`
                : `📣 @Mention from ${msg.senderName}`;
              const body = msg.text;

              notificationManager.notify({
                title,
                body,
                tag: `chat-${msg.id}`,
                onClick: () => {
                  setIsChatOpen(true);
                  setUnreadNotificationsCount(0);
                },
              });

              if (!isChatOpenRef.current) {
                setUnreadNotificationsCount((prev) => prev + 1);
              }
            } else {
              soundEffects.playChatIncoming();
            }
          }
          break;
        }

        case 'CHLOE_FSM_UPDATED': {
          simulatorEngine.logFsmStateChange(
            event.fsm.currentState,
            event.fsm.targetZone,
            event.fsm.activeObject,
            event.fsm.lastAction
          );
          break;
        }

        case 'TRIGGER_OFFICE_OBJECT': {
          simulatorEngine.logFsmStateChange(
            'EXECUTING_WORKFLOW',
            undefined,
            event.objectId,
            `Triggered ${event.objectId} (${event.action || 'open'})`
          );

          if (event.objectId === 'Healthcare Pomodoro COMPANION') {
            setIsPomodoroOpen(true);
            soundEffects.playTeleport();
          } else if (event.objectId === 'Idleboard HUB') {
            setIsDataCenterOpen(true);
            soundEffects.playTeleport();
          } else if (event.objectId === 'Assessment SUBMIT') {
            setIsB1GradingModalOpen(true);
            soundEffects.playTeleport();
          } else if (event.objectId === 'Leaderboard RANKS') {
            setIsDataCenterOpen(true);
            soundEffects.playTeleport();
          }
          break;
        }

        case 'SCREEN_SHARE_CHANGED': {
          setPresenterUserId(event.presenterUserId);
          if (event.presenterUserId) {
            const activeStream = audioManager.getScreenStream() || audioManager.getRemoteScreenStream();
            const activeFrame = audioManager.getRemoteScreenFrame();
            setScreenShareStream(activeStream);
            setScreenShareFrame(activeFrame);
          } else {
            setScreenShareStream(null);
            setScreenShareFrame(null);
          }
          break;
        }

        case 'CHECKLIST_UPDATED': {
          setSharedChecklist(event.checklist);
          break;
        }

        case 'CONTACTS_UPDATED': {
          setSharedContacts(event.contacts);
          break;
        }

        case 'PROJECTION_STATE_CHANGED': {
          break;
        }
      }
    };

    socketClient.on('*', handleServerEvent);

    const unsubscribeSimulator = simulatorEngine.subscribe((_trace, memory) => {
      if (memory.lastFsmState) {
        setFsmToast({
          state: memory.lastFsmState,
          target: memory.lastFsmTarget,
          detail: memory.lastFsmAction,
          timestamp: Date.now(),
        });
      }
    });

    audioManager.onScreenStreamUpdated = (stream) => {
      setScreenShareStream(stream);
    };

    audioManager.onRemoteScreenStreamUpdated = (stream) => {
      setScreenShareStream(stream || audioManager.getScreenStream());
    };

    audioManager.onRemoteScreenFrameUpdated = (frame) => {
      setScreenShareFrame(frame);
    };

    audioManager.onRemoteVideoUpdated = (_userId, _stream) => {
      // Trigger state re-render so components update with new remote video stream
      setRemoteUsers((prev) => new Map(prev));
    };

    audioManager.onRemoteVideoFrameUpdated = () => {
      setRemoteUsers((prev) => new Map(prev));
    };

    const unsubscribeChloeScreen = chloeAgentClient.onScreenShareTrigger(async (start, options) => {
      if (start) {
        const stream = await audioManager.startChloeScreenShare(options);
        if (stream) {
          setScreenShareStream(stream);
        }
      } else {
        audioManager.stopChloeScreenShare();
        setScreenShareStream(null);
        setScreenShareFrame(null);
      }
    });

    const unsubscribeChloeChecklist = chloeAgentClient.onChecklistSync((items) => {
      setSharedChecklist((prev) => {
        const next = [...prev];
        items.forEach((item, idx) => {
          if (!next.some((u) => u.text.toLowerCase().includes(item.text.toLowerCase()))) {
            next.push({
              id: `chloe-task-${Date.now()}-${idx}`,
              text: item.text,
              completed: item.done ?? false,
              category: 'Task',
              color: '#38bdf8',
            });
          }
        });
        socketClient.send({
          type: 'UPDATE_CHECKLIST',
          checklist: next,
        });
        return next;
      });
      soundEffects.playPop();
    });

    return () => {
      socketClient.off('*', handleServerEvent);
      unsubscribeSimulator();
      unsubscribeChloeScreen();
      unsubscribeChloeChecklist();
      audioManager.onRemoteScreenStreamUpdated = undefined;
      audioManager.onRemoteScreenFrameUpdated = undefined;
      audioManager.onRemoteVideoUpdated = undefined;
      audioManager.onRemoteVideoFrameUpdated = undefined;
    };
  }, []);

  // AFK & User Inactivity Detector to forward idle events to Chloe Becker / Cloud Agent
  useEffect(() => {
    if (!currentUser) return;
    let idleTimeout: any = null;

    const resetIdleTimer = () => {
      if (idleTimeout) clearTimeout(idleTimeout);
      idleTimeout = setTimeout(() => {
        if (currentUser) {
          chloeAgentClient.notifyAFK(60000, currentUser.name);
        }
      }, 60000);
    };

    window.addEventListener('mousemove', resetIdleTimer, { passive: true });
    window.addEventListener('keydown', resetIdleTimer, { passive: true });
    window.addEventListener('pointerdown', resetIdleTimer, { passive: true });
    resetIdleTimer();

    return () => {
      if (idleTimeout) clearTimeout(idleTimeout);
      window.removeEventListener('mousemove', resetIdleTimer);
      window.removeEventListener('keydown', resetIdleTimer);
      window.removeEventListener('pointerdown', resetIdleTimer);
    };
  }, [currentUser]);

  // Instant Join Action
  const handleJoinOffice = (
    name: string,
    skin: AvatarSkin,
    department: Department,
    ethnicity?: string,
    hairColor?: string,
    hoodieColor?: string,
    pantsColor?: string,
    shoesColor?: string,
    capColor?: string,
    scarfColor?: string
  ) => {
    socketClient.send({
      type: 'JOIN_ROOM',
      name,
      skin,
      department,
      ethnicity,
      hairColor,
      hoodieColor,
      pantsColor,
      shoesColor,
      capColor,
      scarfColor,
    });
    setHasJoined(true);
    soundEffects.playChime(true);
    audioManager.enableMicrophone();
    speechCommandListener.startListening(name);
  };

  // Avatar & Clothing Customization Action
  const handleUpdateAvatar = (
    skin: AvatarSkin,
    hoodieColor: string,
    hairColor?: string,
    ethnicity?: string,
    pantsColor?: string,
    shoesColor?: string,
    capColor?: string,
    scarfColor?: string,
    isRidingScooter?: boolean,
    scooterConfig?: ScooterConfig
  ) => {
    socketClient.send({
      type: 'UPDATE_AVATAR',
      skin,
      hoodieColor,
      hairColor,
      ethnicity,
      pantsColor,
      shoesColor,
      capColor,
      scarfColor,
      isRidingScooter,
      scooterConfig,
    });
    if (currentUser) {
      setCurrentUser({
        ...currentUser,
        skin,
        hoodieColor,
        color: hoodieColor,
        hairColor,
        ethnicity,
        pantsColor,
        shoesColor,
        capColor,
        scarfColor,
        isRidingScooter: isRidingScooter !== undefined ? isRidingScooter : currentUser.isRidingScooter,
        scooterConfig: scooterConfig || currentUser.scooterConfig,
      });
    }
  };

  const getSpatialZoneFromY = (y: number): SpatialZone => {
    if (Math.abs(y - 6.0) < 2) return '#2F Executive Boardroom';
    if (Math.abs(y - 0.0) < 2) return '#1F Open Workstations';
    if (Math.abs(y - 12.0) < 2) return '#3F Visitor Center Cafe';
    if (Math.abs(y - (-6.0)) < 2) return '#B1 Corporate Office';
    return '#1F Open Workstations';
  };

  // Move updates
  const handleMove = (position: Position3D, rotationY: number, isMoving: boolean) => {
    speechCommandListener.setCurrentZone(getSpatialZoneFromY(position.y));
    socketClient.send({
      type: 'MOVE',
      position,
      rotationY,
      isMoving,
    });
  };

  // Mic Mute / Unmute
  const handleToggleMic = () => {
    const muted = audioManager.toggleMute();
    if (currentUser) {
      setCurrentUser({ ...currentUser, isMuted: muted });
      if (!muted) {
        speechCommandListener.startListening(currentUser.name);
      } else {
        speechCommandListener.stopListening();
      }
    }
  };

  // Stop all active screen shares cleanly
  const handleStopScreenShare = () => {
    if (audioManager.isChloeSharing) {
      audioManager.stopChloeScreenShare();
    } else {
      audioManager.stopScreenShare();
    }
    setScreenShareStream(null);
    setScreenShareFrame(null);
  };

  // Screen Share Toggle & Tab Audio Options
  const handleToggleScreenShare = async () => {
    if (screenShareStream || audioManager.getIsSharingScreen() || audioManager.isChloeSharing) {
      handleStopScreenShare();
    } else {
      const stream = await audioManager.startScreenShare({ includeAudio: true, preferTab: true });
      if (stream) {
        setScreenShareStream(stream);
      } else {
        setScreenShareStream(null);
      }
    }
  };

  const handleStartScreenShareWithOptions = async (options: { includeAudio: boolean; preferTab: boolean }) => {
    if (screenShareStream || audioManager.getIsSharingScreen() || audioManager.isChloeSharing) {
      handleStopScreenShare();
    } else {
      const stream = await audioManager.startScreenShare(options);
      if (stream) {
        setScreenShareStream(stream);
      } else {
        setScreenShareStream(null);
      }
    }
  };

  // Camera Mode Toggle
  const handleChangeCameraMode = () => {
    setCameraMode((prev) => {
      if (prev === 'third_person') return 'first_person';
      if (prev === 'first_person') return 'isometric';
      return 'third_person';
    });
  };

  // Desk Actions
  const handleSelectDesk = (desk: DeskData) => {
    if (!currentUser) return;
    if (!desk.ownerId || desk.ownerId === currentUser.id) {
      soundEffects.playDeskClaim();
      socketClient.send({
        type: 'CLAIM_DESK',
        deskId: desk.id,
        theme: desk.theme,
        gear: desk.gear,
        customStatus: 'Seated',
      });
    }
  };

  const handleTeleportToDesk = () => {
    if (!currentUser) return;
    const myDesk = desks.find((d) => d.ownerId === currentUser.id) || desks.find((d) => !d.ownerId) || desks[0];
    if (myDesk) {
      soundEffects.playTeleport();
      const chairZ = myDesk.z + (myDesk.z > 0 ? -0.8 : 0.8);
      const telePos = { x: myDesk.x, y: 0, z: chairZ };
      const rotY = myDesk.z > 0 ? Math.PI : 0;
      handleMove(telePos, rotY, false);
      setCurrentUser({ ...currentUser, position: telePos, rotationY: rotY });
      handleSelectDesk(myDesk);
    }
  };

  const handleTeleportToPingPong = () => {
    if (!currentUser) return;
    soundEffects.playTeleport();
    const pingPongPos = { x: 6.8, y: 0, z: 0 };
    handleMove(pingPongPos, Math.PI / 2, false);
    setCurrentUser({ ...currentUser, position: pingPongPos, rotationY: Math.PI / 2 });
  };

  const handleTeleportToMeetingRoom = () => {
    if (!currentUser) return;
    soundEffects.playTeleport();
    const meetingRoomPos = { x: -0.5, y: 5.5, z: 1.6 }; // 2F Executive Boardroom Table
    handleMove(meetingRoomPos, Math.PI, false);
    setCurrentUser({ ...currentUser, position: meetingRoomPos, rotationY: Math.PI });
  };

  const handleTeleportToSushiBar = () => {
    if (!currentUser) return;
    soundEffects.playTeleport();
    const sushiBarPos = { x: -4.0, y: 11.0, z: -2.2 }; // 3F Reserved VIP Dining Table
    handleMove(sushiBarPos, Math.PI, false);
    setCurrentUser({ ...currentUser, position: sushiBarPos, rotationY: Math.PI });
  };

  const handleTeleportToBasementTheater = () => {
    if (!currentUser) return;
    soundEffects.playTeleport();
    const basementPos = { x: 0, y: -5.8, z: -3.5 }; // Front row of circular theater
    handleMove(basementPos, 0, false);
    setCurrentUser({ ...currentUser, position: basementPos, rotationY: 0 });
  };

  const handleTeleportToTennisCourt = () => {
    if (!currentUser) return;
    soundEffects.playTeleport();
    const tennisCourtPos = { x: 22.0, y: -6.0, z: 0.0 }; // Player baseline on indoor tennis arena
    handleMove(tennisCourtPos, Math.PI / 2, false);
    setCurrentUser({ ...currentUser, position: tennisCourtPos, rotationY: Math.PI / 2 });
  };

  const handleToggleElevator = () => {
    soundEffects.playPop();
    setIsElevatorOpen(true);
  };

  const handleSelectElevatorFloor = (targetY: number) => {
    if (!currentUser) return;
    soundEffects.playPop();
    setIsElevatorOpen(false);
    setElevatorTargetFloor({ targetY, reqId: Date.now() });
  };

  const handleElevatorArrived = (finalY: number) => {
    if (!currentUser) return;
    soundEffects.playTeleport();
    const targetPos = { x: 8.5, y: finalY, z: -8.0 };
    handleMove(targetPos, 0, false);
    setCurrentUser((prev) => (prev ? { ...prev, position: targetPos, rotationY: 0 } : null));
    setElevatorTargetFloor(null);
  };

  // Whiteboard Actions
  const handleAddWhiteboardStroke = (stroke: WhiteboardStroke) => {
    socketClient.send({ type: 'ADD_WHITEBOARD_STROKE', stroke });
  };

  const handleClearWhiteboard = () => {
    soundEffects.playPop();
    socketClient.send({ type: 'CLEAR_WHITEBOARD' });
  };

  // Shared Notes & Tasks Sync
  const handleUpdateChecklist = (items: ChecklistItem[]) => {
    soundEffects.playPop();
    setSharedChecklist(items);
    socketClient.send({ type: 'UPDATE_CHECKLIST', checklist: items });
  };

  // Submit Work for Live B1 Chloe Grading
  const handleSubmitForB1Review = (payload: SubmissionPayload) => {
    soundEffects.playTeleport();
    setActiveSubmissionPayload(payload);
    setIsChecklistOpen(false);
    setIsWhiteboardOpen(false);

    // Teleport local user to Chloe's B1 Executive Desk area
    if (currentUser) {
      const b1ChloeDeskPos = { x: -2.5, y: -5.8, z: 4.5 };
      handleMove(b1ChloeDeskPos, Math.PI, false);
      setCurrentUser({ ...currentUser, position: b1ChloeDeskPos, rotationY: Math.PI });
    }

    setIsB1GradingModalOpen(true);
    notificationManager.notify({
      title: 'Chloe B1 Office Desk',
      body: 'Arrived at Chloe\'s B1 executive desk for live audit & grading.',
    });
  };

  // Claim Salary Reward handler
  const handleClaimSalaryReward = (amount: number) => {
    setUserSalaryBalance((prev) => {
      const next = prev + amount;
      try {
        localStorage.setItem('idlelab_user_salary', next.toString());
      } catch (e) {}
      return next;
    });
    soundEffects.playLevelUp();
    notificationManager.notify({
      title: 'Salary Disbursed!',
      body: `+$${amount.toLocaleString()} added to your corporate account balance.`,
    });
  };

  const handleUpdateContacts = (contactsList: SavedContactNote[]) => {
    setSharedContacts(contactsList);
    socketClient.send({ type: 'UPDATE_CONTACTS', contacts: contactsList });
  };

  // Chat Actions
  const handleSendChatMessage = (
    text: string,
    isProximity: boolean,
    isPrivate?: boolean,
    recipientId?: string,
    recipientName?: string
  ) => {
    soundEffects.playChatOutgoing();
    socketClient.send({
      type: 'SEND_CHAT',
      text,
      isProximity,
      isPrivate,
      recipientId,
      recipientName,
    });

    const currentZone = currentUser ? getSpatialZoneFromY(currentUser.position.y) : undefined;
    const intent = parseChloeIntent(text, currentZone);

    // Fallback Chat Trigger -> FSM spatial navigation
    if (intent.spatialZone) {
      socketClient.send({
        type: 'CHLOE_NAVIGATE_ZONE',
        targetZone: intent.spatialZone,
      });
      simulatorEngine.logFsmStateChange('NAVIGATING_TO_DESK', intent.spatialZone, undefined, `Chat: "${text}"`);
    }

    // Fallback Chat Trigger -> FSM interactive object
    if (intent.interactiveObject) {
      socketClient.send({
        type: 'CHLOE_TRIGGER_OBJECT',
        objectId: intent.interactiveObject,
        action: intent.action || 'open',
      });
      simulatorEngine.logFsmStateChange('EXECUTING_WORKFLOW', undefined, intent.interactiveObject, `Chat: "${text}"`);
    }

    // Autonomous Chloe AI Colleague response trigger in chat
    const isChloeMentioned =
      intent.isChloeCommand ||
      text.toLowerCase().includes('@chloe') ||
      text.toLowerCase().includes('chloe') ||
      recipientName?.toLowerCase().includes('chloe');

    if (isChloeMentioned && !intent.spatialZone && !intent.interactiveObject) {
      chloeAgentClient
        .sendQuery(text, { userName: currentUser?.name })
        .then((res) => {
          if (res && res.text) {
            const chloeMsg: ChatMessage = {
              id: `chloe-chat-${Date.now()}`,
              senderId: 'npc_b1_chloe',
              senderName: 'Chloe Becker (AI Agent)',
              senderSkin: 'college_dev_f',
              text: res.text,
              timestamp: Date.now(),
              isProximity: !!isProximity,
              isPrivate: !!isPrivate,
              recipientId: isPrivate ? currentUser?.id : undefined,
              recipientName: isPrivate ? currentUser?.name : undefined,
              curatedMedia: res.curatedMedia,
              suggestedActions: res.suggestedActions,
              activeSubAgent: res.activeSubAgent,
            };
            setChatMessages((prev) => [...prev, chloeMsg]);
            chloeVoice.speak(res.speech || res.text, 'chloe_chat_reply');
          }
        })
        .catch((err) => console.error('Chloe chat query error:', err));
    }
  };

  // Perform 3D gesture action
  const handlePerformGesture = (gesture: GestureType) => {
    soundEffects.playEmote();
    socketClient.send({
      type: 'PERFORM_GESTURE',
      gesture,
    });
    if (currentUser) {
      setLastGestureEvent({ userId: currentUser.id, gesture, id: Date.now() + Math.random() });
      chloeAgentClient.notifyAction('user_gesture', { gesture }, currentUser.name);

      if (gesture === 'wave') {
        const y = currentUser.position.y;
        if (y < -2) {
          // B1 Chloe zone
          setIsDataCenterOpen(true);
          soundEffects.playTeleport();
        } else if (y >= 5.0 && y <= 6.5) {
          // 2F Claire boardroom zone
          setIsClaireModalOpen(true);
          soundEffects.playTeleport();
        }
      }
    }
  };

  // Send floating 3D emoji reaction particle burst
  const handleSendEmojiReaction = (emoji: string, gesture?: GestureType) => {
    soundEffects.playEmote();
    socketClient.send({
      type: 'SEND_EMOJI_REACTION',
      emoji,
      gesture,
    });
    if (currentUser) {
      setLastEmojiEvent({ userId: currentUser.id, emoji, gesture, id: Date.now() + Math.random() });
    }
  };

  const handleUpdateBookmarks = (newBookmarks: DataCenterBookmark[]) => {
    soundEffects.playPop();
    setDataCenterBookmarks(newBookmarks);
    try {
      localStorage.setItem('b1_datacenter_bookmarks', JSON.stringify(newBookmarks));
    } catch (e) {
      console.error(e);
    }
  };

  const handleApplyCoffeeBuff = (drinkName: string, buffText: string, emoji: string) => {
    soundEffects.playCoffeeBrew();
    notificationManager.notify({
      title: `☕ Brewed ${drinkName}`,
      body: `${buffText} — Enjoy your artisanal roast!`,
    });
    handleSendEmojiReaction(emoji, 'cheer');
    if (currentUser) {
      chloeAgentClient.notifyAction('coffee_brewed', { drinkName, buffText }, currentUser.name);
    }
  };

  const handleBroadcastAnnouncement = (title: string, message: string) => {
    const annMsg = `📢 [B1 PRESENTATION SCREEN] ${title} — ${message}`;
    handleSendChatMessage(annMsg, false);
    notificationManager.notify({
      title,
      body: message,
    });
  };

  const handleSyncChloeTasksToChecklist = (newItems: ChecklistItem[]) => {
    if (!newItems || newItems.length === 0) return;
    const updated = [...sharedChecklist];
    newItems.forEach((item) => {
      if (!updated.some((u) => u.text === item.text)) {
        updated.push(item);
      }
    });
    setSharedChecklist(updated);
    socketClient.send({ type: 'UPDATE_CHECKLIST', checklist: updated });
    notificationManager.notify({
      title: '📋 Checklist Synced from Chloe Becker',
      body: `Added ${newItems.length} action items to team checklist.`,
    });
  };

  const handleControlProjection = (
    action: 'play' | 'pause' | 'stop' | 'toggle' | 'seek' | 'change_video',
    details?: { videoId?: string; title?: string; category?: string; seekTime?: number }
  ) => {
    socketClient.send({
      type: 'CONTROL_PROJECTION',
      action,
      videoId: details?.videoId,
      title: details?.title,
      category: details?.category,
      seekTime: details?.seekTime,
    });
  };

  const handleSetProjectionState = (state: OfficeProjectionState | null) => {
    socketClient.send({
      type: 'SET_PROJECTION_STATE',
      projectionState: state,
    });
  };

  return (
    <div className="relative w-screen h-screen overflow-hidden bg-[#1e1e1e] font-sans">
      {/* Instant Join Screen Modal */}
      {!hasJoined && <JoinModal onJoin={handleJoinOffice} />}

      {/* Main 3D Voxel Office Canvas */}
      <OfficeCanvas
        currentUser={currentUser}
        remoteUsers={remoteUsers}
        desks={desks}
        whiteboardStrokes={whiteboardStrokes}
        cameraMode={cameraMode}
        screenShareStream={screenShareStream}
        isMuted={currentUser?.isMuted ?? false}
        isCameraOn={isCameraOn}
        onToggleMic={handleToggleMic}
        onToggleCamera={handleToggleCamera}
        onSendChat={handleSendChatMessage}
        onMove={handleMove}
        onSelectDesk={handleSelectDesk}
        onOpenWhiteboard={() => setIsWhiteboardOpen(true)}
        onOpenPingPong={handleTeleportToPingPong}
        onOpenElevatorModal={handleToggleElevator}
        elevatorTargetFloor={elevatorTargetFloor}
        onElevatorArrived={handleElevatorArrived}
        onElevatorMovingChange={setIsElevatorMoving}
        onOpenCoffeeRobot={() => setIsCoffeeRobotOpen(true)}
        onOpenLibrary={() => setIsLibraryOpen(true)}
        onOpenDataCenter={() => setIsDataCenterOpen(true)}
        onOpenPresentationModal={() => setIsPresentationModalOpen(true)}
        onOpenPomodoro={() => setIsPomodoroOpen(true)}
        onOpenAtmModal={() => setIsAtmModalOpen(true)}
        onPerformGesture={handlePerformGesture}
        onSendEmojiReaction={handleSendEmojiReaction}
        onStartScreenShare={handleToggleScreenShare}
        onOpenEmoteWheel={() => setIsEmoteWheelOpen(true)}
        onToggleScooter={(isRiding) => {
          if (currentUser) {
            handleUpdateAvatar(
              currentUser.skin,
              currentUser.hoodieColor || currentUser.color || '#3b82f6',
              currentUser.hairColor,
              currentUser.ethnicity,
              currentUser.pantsColor,
              currentUser.shoesColor,
              currentUser.capColor,
              currentUser.scarfColor,
              isRiding,
              currentUser.scooterConfig
            );
          }
        }}
        onUpdateScooterConfig={(scooterConfig) => {
          if (currentUser) {
            handleUpdateAvatar(
              currentUser.skin,
              currentUser.hoodieColor || currentUser.color || '#3b82f6',
              currentUser.hairColor,
              currentUser.ethnicity,
              currentUser.pantsColor,
              currentUser.shoesColor,
              currentUser.capColor,
              currentUser.scarfColor,
              currentUser.isRidingScooter,
              scooterConfig
            );
          }
        }}
        lastGestureEvent={lastGestureEvent}
        lastEmojiEvent={lastEmojiEvent}
      />

      {/* Figma Software Navigation Top Header */}
      {hasJoined && (
        <FigmaHeader
          currentUser={currentUser}
          onlineCount={remoteUsers.size + 1}
          isLayersPanelOpen={isLayersPanelOpen}
          isInspectorPanelOpen={isInspectorPanelOpen}
          onToggleLayersPanel={() => setIsLayersPanelOpen(!isLayersPanelOpen)}
          onToggleInspectorPanel={() => setIsInspectorPanelOpen(!isInspectorPanelOpen)}
          onStartScreenShare={handleToggleScreenShare}
          isScreenSharing={!!screenShareStream}
          onOpenAvatarCustomizer={() => setIsAvatarCustomizerOpen(true)}
          onOpenWebShare={() => setIsWebShareOpen(true)}
          onOpenLabGuide={() => setIsLabGuideOpen(true)}
        />
      )}

      {/* Figma Navigation ControlBar & Overlays */}
      {hasJoined && (
        <>
          <ControlBar
            isMuted={currentUser?.isMuted ?? false}
            isCameraOn={isCameraOn}
            isScreenSharing={Boolean(screenShareStream || audioManager.getIsSharingScreen() || audioManager.isChloeSharing)}
            cameraMode={cameraMode}
            onToggleMic={handleToggleMic}
            onToggleCamera={handleToggleCamera}
            onToggleScreenShare={handleToggleScreenShare}
            onStartScreenShareWithOptions={handleStartScreenShareWithOptions}
            onStopScreenShare={handleStopScreenShare}
            onChangeCameraMode={handleChangeCameraMode}
            onTeleportDesk={handleTeleportToDesk}
            onTeleportMeetingRoom={handleTeleportToMeetingRoom}
            onTeleportSushiBar={handleTeleportToSushiBar}
            onToggleElevator={handleToggleElevator}
            currentFloor={(currentUser?.position.y || 0) < -2 ? 'B1' : (currentUser?.position.y || 0) >= 8 ? 3 : (currentUser?.position.y || 0) >= 3 ? 2 : 1}
            onOpenSavedContacts={() => setIsSavedContactsOpen(true)}
            onOpenChecklist={() => setIsChecklistOpen(true)}
            onOpenPingPong={handleTeleportToPingPong}
            onOpenWhiteboard={() => setIsWhiteboardOpen(true)}
            onTeleportTennisCourt={handleTeleportToTennisCourt}
            onToggleLayersPanel={() => setIsLayersPanelOpen(!isLayersPanelOpen)}
            onToggleInspectorPanel={() => setIsInspectorPanelOpen(!isInspectorPanelOpen)}
            isLayersPanelOpen={isLayersPanelOpen}
            isInspectorPanelOpen={isInspectorPanelOpen}
            onlineCount={remoteUsers.size + 1}
            isChatOpen={isChatOpen}
            unreadCount={unreadNotificationsCount}
            onPerformGesture={handlePerformGesture}
            onSendEmojiReaction={handleSendEmojiReaction}
            onOpenEmoteWheel={() => setIsEmoteWheelOpen(true)}
            onOpenSettings={() => setIsSettingsOpen(true)}
            onToggleChat={() => {
              if (!isChatOpen) {
                setUnreadNotificationsCount(0);
              }
              setIsChatOpen(!isChatOpen);
            }}
          />

          <ChatOverlay
            isOpen={isChatOpen}
            onClose={() => setIsChatOpen(false)}
            messages={chatMessages}
            users={Array.from(remoteUsers.values()).concat(currentUser ? [currentUser] : [])}
            currentUserId={currentUser?.id || ''}
            currentUserName={currentUser?.name || 'You'}
            onSendMessage={handleSendChatMessage}
            onPerformGesture={handlePerformGesture}
            onSendEmojiReaction={handleSendEmojiReaction}
          />

          <FigmaInspectorPanel
            isLayersOpen={isLayersPanelOpen}
            isInspectorOpen={isInspectorPanelOpen}
            onCloseLayers={() => setIsLayersPanelOpen(false)}
            onCloseInspector={() => setIsInspectorPanelOpen(false)}
            currentUser={currentUser}
            remoteUsers={remoteUsers}
            desks={desks}
            cameraMode={cameraMode}
            onChangeCameraMode={handleChangeCameraMode}
            onTeleportDesk={handleTeleportToDesk}
            onTeleportMeetingRoom={handleTeleportToMeetingRoom}
            onTeleportSushiBar={handleTeleportToSushiBar}
            onTeleportBasementTheater={handleTeleportToBasementTheater}
            onTeleportTennisCourt={handleTeleportToTennisCourt}
            onToggleElevator={handleToggleElevator}
            currentFloor={(currentUser?.position.y || 0) < -2 ? 'B1' : (currentUser?.position.y || 0) >= 8 ? 3 : (currentUser?.position.y || 0) >= 3 ? 2 : 1}
            isMuted={currentUser?.isMuted ?? false}
            isCameraOn={isCameraOn}
            isScreenSharing={!!screenShareStream}
            onToggleMic={handleToggleMic}
            onToggleCamera={handleToggleCamera}
            onStartScreenShareWithOptions={handleStartScreenShareWithOptions}
            onStopScreenShare={handleToggleScreenShare}
            onOpenWhiteboard={() => setIsWhiteboardOpen(true)}
            onOpenChecklist={() => setIsChecklistOpen(true)}
            onOpenSavedContacts={() => setIsSavedContactsOpen(true)}
            onOpenCoffeeRobot={() => setIsCoffeeRobotOpen(true)}
            onOpenLibrary={() => setIsLibraryOpen(true)}
            onOpenDataCenter={() => setIsDataCenterOpen(true)}
            onOpenSwiftNote={() => setIsSwiftNoteOpen(true)}
            onOpenPresentationModal={() => setIsPresentationModalOpen(true)}
            onOpenPomodoro={() => setIsPomodoroOpen(true)}
            onOpenLabGuide={() => setIsLabGuideOpen(true)}
          />
        </>
      )}
      
      {isSwiftNoteOpen && (
        <SwiftNoteModal onClose={() => setIsSwiftNoteOpen(false)} />
      )}
      
      <AgentFacilitatorModal
        isOpen={isClaireModalOpen}
        onClose={() => setIsClaireModalOpen(false)}
        username={currentUser?.name || 'Guest'}
        userPosition={currentUser?.position || { x: 0, y: 5.5, z: 0 }}
        hasScreenStream={!!screenShareStream}
      />
      {/* Leaderboard & Active Online Directory Modal */}
      {isSavedContactsOpen && (
        <SavedContactsModal
          isOpen={isSavedContactsOpen}
          onClose={() => setIsSavedContactsOpen(false)}
          onStartScreenShare={handleToggleScreenShare}
          isScreenSharing={!!screenShareStream}
          contacts={sharedContacts}
          onUpdateContacts={handleUpdateContacts}
          currentUser={currentUser}
          remoteUsers={remoteUsers}
        />
      )}

      {/* Assessment Submission & Salary Reward Modal */}
      {isChecklistOpen && (
        <ChecklistModal
          isOpen={isChecklistOpen}
          onClose={() => setIsChecklistOpen(false)}
          userName={currentUser?.name || 'You'}
          items={sharedChecklist}
          onUpdateItems={handleUpdateChecklist}
          onRequestB1Review={handleSubmitForB1Review}
        />
      )}

      {/* Live B1 Office Desk Chloe Grading & Presentation Modal */}
      {isB1GradingModalOpen && (
        <B1ChloeGradingModal
          isOpen={isB1GradingModalOpen}
          onClose={() => setIsB1GradingModalOpen(false)}
          submission={activeSubmissionPayload}
          onClaimSalary={() => handleClaimSalaryReward(3000)}
          onClaimSalaryReward={handleClaimSalaryReward}
          currentBalance={userSalaryBalance}
          userCurrentSalary={userSalaryBalance}
        />
      )}

      {/* Executive Elevator Control Modal */}
      {isElevatorOpen && (
        <ElevatorModal
          isOpen={isElevatorOpen}
          onClose={() => setIsElevatorOpen(false)}
          currentY={currentUser?.position.y || 0}
          onSelectFloor={handleSelectElevatorFloor}
          onTeleportTennisCourt={handleTeleportToTennisCourt}
          isMoving={isElevatorMoving}
        />
      )}

      {/* B1 Robotic Coffee Arm Modal */}
      {isCoffeeRobotOpen && (
        <CoffeeRobotModal
          isOpen={isCoffeeRobotOpen}
          onClose={() => setIsCoffeeRobotOpen(false)}
          onApplyCoffeeBuff={handleApplyCoffeeBuff}
        />
      )}

      {/* B1 Technical Bookshelf Library Modal */}
      {isLibraryOpen && (
        <LibraryModal
          isOpen={isLibraryOpen}
          onClose={() => setIsLibraryOpen(false)}
        />
      )}

      {/* Agent Flow Modal */}
      {isDataCenterOpen && (
        <AgentFlowModal
          isOpen={isDataCenterOpen}
          onClose={() => setIsDataCenterOpen(false)}
          currentUser={currentUser}
        />
      )}

      {/* B1 Huge Presentation & Broadcast Screen Modal */}
      {isPresentationModalOpen && (
        <PresentationAnnouncementModal
          isOpen={isPresentationModalOpen}
          onClose={() => setIsPresentationModalOpen(false)}
          onStartScreenShare={handleToggleScreenShare}
          onBroadcastAnnouncement={handleBroadcastAnnouncement}
          isScreenSharing={!!screenShareStream}
        />
      )}

      {/* Avatar & Hoodie Customizer Modal */}
      {isAvatarCustomizerOpen && (
        <AvatarCustomizerModal
          isOpen={isAvatarCustomizerOpen}
          onClose={() => setIsAvatarCustomizerOpen(false)}
          currentUser={currentUser}
          onUpdateAvatar={handleUpdateAvatar}
        />
      )}

      {/* Web Share & Embed Link Modal */}
      {isWebShareOpen && (
        <WebShareModal
          isOpen={isWebShareOpen}
          onClose={() => setIsWebShareOpen(false)}
          onlineCount={remoteUsers.size + (currentUser ? 1 : 0)}
          roomName="IdleLab Workspace"
        />
      )}

      {/* Local Avatar Emote Wheel Modal */}
      <EmoteWheelModal
        isOpen={isEmoteWheelOpen}
        onClose={() => setIsEmoteWheelOpen(false)}
        onPerformGesture={handlePerformGesture}
        onSendEmojiReaction={handleSendEmojiReaction}
        userName={currentUser?.name}
      />

      {/* Settings & Preferences Modal */}
      {isSettingsOpen && (
        <SettingsModal
          currentUser={currentUser}
          onUpdateUser={(fields) => {
            if (currentUser) {
              const updated = { ...currentUser, ...fields };
              setCurrentUser(updated);
            }
          }}
          onClose={() => setIsSettingsOpen(false)}
          cameraMode={cameraMode}
          onChangeCameraMode={handleChangeCameraMode}
          onOpenAvatarCustomizer={() => {
            setIsSettingsOpen(false);
            setIsAvatarCustomizerOpen(true);
          }}
          onOpenPomodoro={() => {
            setIsSettingsOpen(false);
            setIsPomodoroOpen(true);
          }}
        />
      )}

      {/* Healthcare Pomodoro Companion Modal */}
      {isPomodoroOpen && (
        <PomodoroModal
          isOpen={isPomodoroOpen}
          onClose={() => setIsPomodoroOpen(false)}
          onRewardXP={(amount) => {
            setUserSalaryBalance((prev) => {
              const nextVal = prev + amount;
              try {
                localStorage.setItem('idlelab_user_salary', nextVal.toString());
              } catch {}
              return nextVal;
            });
          }}
        />
      )}

      {/* Chloe Becker ATM Submission & Payroll Kiosk Modal */}
      {isAtmModalOpen && (
        <ATMSubmissionModal
          isOpen={isAtmModalOpen}
          onClose={() => setIsAtmModalOpen(false)}
          currentUserName={currentUser?.name || 'Colleague'}
          onPayoutReceived={(amount) => {
            setUserSalaryBalance((prev) => {
              const nextVal = prev + amount;
              try {
                localStorage.setItem('idlelab_user_salary', nextVal.toString());
              } catch {}
              return nextVal;
            });
          }}
        />
      )}

      {/* Hidden/Invisible Background Hydration Reminder System & Toast */}
      <HydrationReminderToast
        onOpenSettings={() => setIsSettingsOpen(true)}
        onOpenPomodoro={() => setIsPomodoroOpen(true)}
        onRewardXP={(amount) => {
          setUserSalaryBalance((prev) => {
            const nextVal = prev + amount;
            try {
              localStorage.setItem('idlelab_user_salary', nextVal.toString());
            } catch {}
            return nextVal;
          });
        }}
      />


      {/* Live Screen Projection Modal Panel */}
      <ScreenShareOverlay
        isOpen={Boolean(screenShareStream || screenShareFrame || audioManager.isChloeSharing)}
        onClose={handleStopScreenShare}
        stream={screenShareStream}
        screenFrame={screenShareFrame}
        onStartScreenShare={handleToggleScreenShare}
        presenterName={
          audioManager.isChloeSharing
            ? 'Chloe Becker (AI Agent)'
            : presenterUserId === currentUser?.id
            ? 'You'
            : remoteUsers.get(presenterUserId || '')?.name || 'Colleague'
        }
        onStopShare={handleStopScreenShare}
      />
    </div>
  );
}
