import { Position3D, WebRTCSignalPayload } from '../types';
import { socketClient } from './socketClient';

export interface RemoteAudioPeer {
  userId: string;
  peerConnection: RTCPeerConnection;
  audioElement: HTMLAudioElement;
  pannerNode?: PannerNode;
  gainNode?: GainNode;
  remoteVideoStream?: MediaStream;
  remoteScreenStream?: MediaStream;
  audioSender?: RTCRtpSender;
  cameraSender?: RTCRtpSender;
  screenSender?: RTCRtpSender;
  screenAudioSender?: RTCRtpSender;
  cameraStreamId?: string;
  screenStreamId?: string;
}

function ensureVideoInDOM(vid: HTMLVideoElement) {
  if (typeof document === 'undefined') return;
  let container = document.getElementById('webrtc-video-container');
  if (!container) {
    container = document.createElement('div');
    container.id = 'webrtc-video-container';
    container.style.cssText =
      'position:fixed;bottom:0;right:0;width:1px;height:1px;opacity:0.01;pointer-events:none;z-index:-1000;overflow:hidden;';
    document.body.appendChild(container);
  }
  if (vid && !vid.parentNode) {
    container.appendChild(vid);
  }
}

const ICE_SERVERS: RTCConfiguration['iceServers'] = [
  { urls: ['stun:stun.l.google.com:19302', 'stun:stun1.l.google.com:19302', 'stun:stun2.l.google.com:19302'] },
  { urls: ['stun:openrelay.metered.ca:80', 'stun:openrelay.metered.ca:443'] },
  {
    urls: [
      'turn:openrelay.metered.ca:80',
      'turn:openrelay.metered.ca:443',
      'turn:openrelay.metered.ca:443?transport=tcp',
    ],
    username: 'openrelayproject',
    credential: 'openrelayproject',
  },
];

export class AudioManager {
  private audioCtx: AudioContext | null = null;
  private localAudioStream: MediaStream | null = null;
  private localVideoStream: MediaStream | null = null;
  private localScreenStream: MediaStream | null = null;
  private localVideoElement: HTMLVideoElement | null = null;
  private remotePeers: Map<string, RemoteAudioPeer> = new Map();
  private remoteVideoStreams: Map<string, MediaStream> = new Map();
  private remoteScreenStream: MediaStream | null = null;
  private remoteVideoFrames: Map<string, string> = new Map();
  private remoteScreenFrame: string | null = null;
  private myUserId: string | null = null;
  private isMuted = false;
  private isCameraOn = false;
  private isSharingScreen = false;

  private cameraFrameInterval: any = null;
  private screenFrameInterval: any = null;
  private screenVideoElementForFrame: HTMLVideoElement | null = null;

  public onScreenStreamUpdated?: (stream: MediaStream | null) => void;
  public onVideoStreamUpdated?: (stream: MediaStream | null, videoElement: HTMLVideoElement | null) => void;
  public onRemoteVideoUpdated?: (userId: string, stream: MediaStream | null) => void;
  public onRemoteScreenStreamUpdated?: (stream: MediaStream | null) => void;
  public onRemoteVideoFrameUpdated?: (userId: string, frameData: string | null) => void;
  public onRemoteScreenFrameUpdated?: (frameData: string | null) => void;
  public onVolumeLevel?: (userId: string, level: number) => void;
  public onSmartAutoreact?: () => void;

  constructor() {
    // Listen for WebRTC signals from socket
    socketClient.on('SIGNAL', (data: { signal: WebRTCSignalPayload }) => {
      this.handleIncomingSignal(data.signal);
    });

    socketClient.on('REMOTE_VIDEO_FRAME', (data: { userId: string; frameData: string }) => {
      if (data.userId === this.myUserId) return;
      this.remoteVideoFrames.set(data.userId, data.frameData);
      if (this.onRemoteVideoFrameUpdated) {
        this.onRemoteVideoFrameUpdated(data.userId, data.frameData);
      }
    });

    socketClient.on('REMOTE_SCREEN_FRAME', (data: { userId: string; frameData: string }) => {
      if (data.userId === this.myUserId) return;
      this.remoteScreenFrame = data.frameData;
      if (this.onRemoteScreenFrameUpdated) {
        this.onRemoteScreenFrameUpdated(data.frameData);
      }
    });

    socketClient.on('SCREEN_SHARE_CHANGED', (data: { presenterUserId: string | null }) => {
      if (!data.presenterUserId) {
        this.remoteScreenStream = null;
        this.remoteScreenFrame = null;
        if (this.onRemoteScreenStreamUpdated) this.onRemoteScreenStreamUpdated(null);
        if (this.onRemoteScreenFrameUpdated) this.onRemoteScreenFrameUpdated(null);
      }
    });
  }

  public setUserId(userId: string) {
    this.myUserId = userId;
  }

  // Initialize Web Audio API Context
  public async initAudioContext(): Promise<void> {
    if (!this.audioCtx) {
      const AudioCtxClass = window.AudioContext || (window as any).webkitAudioContext;
      this.audioCtx = new AudioCtxClass();
    }
    if (this.audioCtx.state === 'suspended') {
      await this.audioCtx.resume();
    }
  }

  // Start Local Microphone
  public async enableMicrophone(): Promise<boolean> {
    try {
      await this.initAudioContext();
      this.localAudioStream = await navigator.mediaDevices.getUserMedia({
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true,
        },
      });

      this.isMuted = false;
      this.socketUpdateStatus({ isMuted: false, isSpeaking: false });
      this.syncTracksToPeers();

      // Setup microphone volume & speech analysis for smart hidden autoreact
      if (this.audioCtx && this.localAudioStream) {
        try {
          const source = this.audioCtx.createMediaStreamSource(this.localAudioStream);
          const analyser = this.audioCtx.createAnalyser();
          analyser.fftSize = 256;
          source.connect(analyser);
          const dataArray = new Uint8Array(analyser.frequencyBinCount);

          let wasSpeaking = false;
          let lastAutoreactTime = 0;

          const checkMicVolume = () => {
            if (!this.localAudioStream || this.isMuted) {
              if (wasSpeaking) {
                wasSpeaking = false;
                this.socketUpdateStatus({ isSpeaking: false });
              }
              requestAnimationFrame(checkMicVolume);
              return;
            }

            analyser.getByteFrequencyData(dataArray);
            let sum = 0;
            for (let i = 0; i < dataArray.length; i++) {
              sum += dataArray[i];
            }
            const avg = sum / dataArray.length;
            const isNowSpeaking = avg > 14;

            if (isNowSpeaking !== wasSpeaking) {
              wasSpeaking = isNowSpeaking;
              this.socketUpdateStatus({ isSpeaking: isNowSpeaking });
            }

            const now = Date.now();
            if (isNowSpeaking && now - lastAutoreactTime > 5000) {
              lastAutoreactTime = now;
              if (this.onSmartAutoreact) {
                this.onSmartAutoreact();
              }
            }

            requestAnimationFrame(checkMicVolume);
          };

          requestAnimationFrame(checkMicVolume);
        } catch (analyserErr) {
          console.warn('Could not initialize microphone analyzer:', analyserErr);
        }
      }

      return true;
    } catch (err) {
      console.warn('Microphone permission denied or unavailable:', err);
      return false;
    }
  }

  public toggleMute(): boolean {
    if (!this.localAudioStream) return true;
    this.isMuted = !this.isMuted;
    this.localAudioStream.getAudioTracks().forEach((track) => {
      track.enabled = !this.isMuted;
    });
    this.socketUpdateStatus({ isMuted: this.isMuted });
    return this.isMuted;
  }

  // Enable Camera for Video Meetings & Portrayal on 3D Avatars
  public async enableCamera(): Promise<boolean> {
    try {
      if (this.localVideoStream) {
        this.isCameraOn = !this.isCameraOn;
        this.localVideoStream.getVideoTracks().forEach((track) => {
          track.enabled = this.isCameraOn;
        });

        if (this.isCameraOn) {
          this.startCameraFrameLoop();
        } else {
          this.stopCameraFrameLoop();
        }

        if (this.onVideoStreamUpdated) {
          this.onVideoStreamUpdated(
            this.isCameraOn ? this.localVideoStream : null,
            this.isCameraOn ? this.localVideoElement : null
          );
        }

        this.syncTracksToPeers();
        return this.isCameraOn;
      }

      this.localVideoStream = await navigator.mediaDevices.getUserMedia({
        video: { width: { ideal: 640 }, height: { ideal: 360 }, facingMode: 'user' },
      });

      const vid = document.createElement('video');
      vid.autoplay = true;
      vid.muted = true;
      vid.playsInline = true;
      vid.srcObject = this.localVideoStream;
      ensureVideoInDOM(vid);
      await vid.play().catch(() => {});

      this.localVideoElement = vid;
      this.isCameraOn = true;
      this.startCameraFrameLoop();

      if (this.onVideoStreamUpdated) {
        this.onVideoStreamUpdated(this.localVideoStream, vid);
      }

      this.syncTracksToPeers();
      return true;
    } catch (err) {
      console.warn('Camera access denied or unavailable:', err);
      return false;
    }
  }

  private startCameraFrameLoop() {
    this.stopCameraFrameLoop();
    const canvas = document.createElement('canvas');
    canvas.width = 320;
    canvas.height = 180;
    const ctx = canvas.getContext('2d');

    this.cameraFrameInterval = setInterval(() => {
      if (this.isCameraOn && this.localVideoElement && this.localVideoElement.readyState >= 2 && ctx) {
        ctx.drawImage(this.localVideoElement, 0, 0, 320, 180);
        const frameData = canvas.toDataURL('image/jpeg', 0.5);
        socketClient.send({ type: 'BROADCAST_VIDEO_FRAME', frameData });
      }
    }, 120);
  }

  private stopCameraFrameLoop() {
    if (this.cameraFrameInterval) {
      clearInterval(this.cameraFrameInterval);
      this.cameraFrameInterval = null;
    }
  }

  public getIsCameraOn(): boolean {
    return this.isCameraOn;
  }

  public getLocalVideoStream(): MediaStream | null {
    return this.isCameraOn ? this.localVideoStream : null;
  }

  public getLocalVideoElement(): HTMLVideoElement | null {
    return this.isCameraOn ? this.localVideoElement : null;
  }

  private fallbackScreenCanvas: HTMLCanvasElement | null = null;
  private chloeScreenCanvas: HTMLCanvasElement | null = null;
  public isChloeSharing: boolean = false;
  private isRequestingScreenShare: boolean = false;

  public getIsSharingScreen(): boolean {
    return this.isSharingScreen;
  }

  // WebRTC Screen Sharing (supports Browser Tab Share with Audio)
  public async startScreenShare(options?: { includeAudio?: boolean; preferTab?: boolean }): Promise<MediaStream | null> {
    // If already sharing, return existing active stream
    if (this.isSharingScreen && this.localScreenStream) {
      return this.localScreenStream;
    }

    // Prevent duplicate concurrent prompt popups if user clicks repeatedly
    if (this.isRequestingScreenShare) {
      console.warn('Screen share request already in progress');
      return null;
    }

    this.isRequestingScreenShare = true;

    const includeAudio = options?.includeAudio ?? true;
    const preferTab = options?.preferTab ?? true;

    let stream: MediaStream | null = null;

    if (navigator.mediaDevices && typeof navigator.mediaDevices.getDisplayMedia === 'function') {
      try {
        const displayOptions: DisplayMediaStreamOptions = {
          video: {
            displaySurface: preferTab ? 'browser' : 'monitor',
            frameRate: { ideal: 30, max: 30 },
            width: { ideal: 1280, max: 1280 },
            height: { ideal: 720, max: 720 },
            resizeMode: 'crop-and-scale',
          },
          audio: includeAudio
            ? {
                echoCancellation: true,
                noiseSuppression: true,
                autoGainControl: true,
                suppressLocalAudioPlayback: true,
              }
            : false,
          surfaceSwitching: 'include',
          selfBrowserSurface: 'include',
          systemAudio: 'include',
        } as any;

        stream = await navigator.mediaDevices.getDisplayMedia(displayOptions);

        // Apply fallback track constraints for smoothness & low bandwidth usage
        const videoTrack = stream.getVideoTracks()[0];
        if (videoTrack && typeof videoTrack.applyConstraints === 'function') {
          await videoTrack.applyConstraints({
            frameRate: { ideal: 30, max: 30 },
            width: { ideal: 1280, max: 1280 },
            height: { ideal: 720, max: 720 },
          }).catch(() => {});
        }
      } catch (err: any) {
        const errName = err?.name || '';
        const errMsg = typeof err?.message === 'string' ? err.message.toLowerCase() : '';

        // Check if the user cancelled, closed the dialog, or denied permission
        const isUserCancelOrDenial =
          errName === 'NotAllowedError' ||
          errName === 'AbortError' ||
          errName === 'SecurityError' ||
          errMsg.includes('permission') ||
          errMsg.includes('cancel') ||
          errMsg.includes('dismiss') ||
          errMsg.includes('denied') ||
          errMsg.includes('aborted');

        if (isUserCancelOrDenial) {
          console.log('User cancelled or declined screen share prompt.');
          this.isRequestingScreenShare = false;
          return null; // Return cleanly without secondary popups or simulated fallback
        }

        // Only try basic fallback if it failed due to unsupported constraints / TypeError
        console.warn('Advanced displayMedia constraints not supported, attempting basic displayMedia:', err);
        try {
          stream = await navigator.mediaDevices.getDisplayMedia({
            video: true,
            audio: includeAudio,
          });
        } catch (basicErr: any) {
          console.log('Screen share cancelled or unavailable:', basicErr);
          this.isRequestingScreenShare = false;
          return null;
        }
      }
    } else {
      console.warn('Screen sharing (getDisplayMedia) is not supported in this browser environment.');
      this.isRequestingScreenShare = false;
      return null;
    }

    this.isRequestingScreenShare = false;

    if (!stream) {
      return null;
    }

    this.localScreenStream = stream;
    this.isSharingScreen = true;

    const hasTabAudio = stream.getAudioTracks().length > 0;
    console.log(`Screen share started. Audio track included: ${hasTabAudio}`);

    socketClient.send({ type: 'TOGGLE_SCREEN_SHARE', isSharing: true, hasAudio: hasTabAudio });

    this.startScreenFrameLoop(stream);

    const videoTracks = stream.getVideoTracks();
    if (videoTracks.length > 0) {
      videoTracks[0].onended = () => {
        this.stopScreenShare();
      };
    }

    if (this.onScreenStreamUpdated) {
      this.onScreenStreamUpdated(this.localScreenStream);
    }

    this.syncTracksToPeers();
    return this.localScreenStream;
  }

  private startScreenFrameLoop(stream: MediaStream) {
    this.stopScreenFrameLoop();
    const canvas = document.createElement('canvas');
    canvas.width = 960;
    canvas.height = 540;
    const ctx = canvas.getContext('2d');

    const vid = document.createElement('video');
    vid.autoplay = true;
    vid.muted = true;
    vid.playsInline = true;
    vid.srcObject = stream;
    ensureVideoInDOM(vid);
    vid.play().catch(() => {});
    this.screenVideoElementForFrame = vid;

    this.screenFrameInterval = setInterval(() => {
      if (!this.isSharingScreen || !ctx) return;

      if (this.fallbackScreenCanvas) {
        ctx.drawImage(this.fallbackScreenCanvas, 0, 0, 960, 540);
        const frameData = canvas.toDataURL('image/jpeg', 0.6);
        socketClient.send({ type: 'BROADCAST_SCREEN_FRAME', frameData });
      } else if (vid && (vid.readyState >= 1 || vid.videoWidth > 0)) {
        ctx.drawImage(vid, 0, 0, 960, 540);
        const frameData = canvas.toDataURL('image/jpeg', 0.6);
        socketClient.send({ type: 'BROADCAST_SCREEN_FRAME', frameData });
      }
    }, 150);
  }

  private stopScreenFrameLoop() {
    if (this.screenFrameInterval) {
      clearInterval(this.screenFrameInterval);
      this.screenFrameInterval = null;
    }
    if (this.screenVideoElementForFrame) {
      this.screenVideoElementForFrame.pause();
      if (this.screenVideoElementForFrame.parentNode) {
        this.screenVideoElementForFrame.parentNode.removeChild(this.screenVideoElementForFrame);
      }
      this.screenVideoElementForFrame = null;
    }
  }

  private createFallbackScreenStream(): MediaStream {
    const canvas = document.createElement('canvas');
    canvas.width = 1280;
    canvas.height = 720;
    this.fallbackScreenCanvas = canvas;
    const ctx = canvas.getContext('2d')!;

    let step = 0;
    const draw = () => {
      step++;
      ctx.fillStyle = '#0f172a';
      ctx.fillRect(0, 0, 1280, 720);

      // Top browser header
      ctx.fillStyle = '#1e293b';
      ctx.fillRect(0, 0, 1280, 50);
      ctx.fillStyle = '#ef4444'; ctx.beginPath(); ctx.arc(30, 25, 6, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = '#f59e0b'; ctx.beginPath(); ctx.arc(50, 25, 6, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = '#10b981'; ctx.beginPath(); ctx.arc(70, 25, 6, 0, Math.PI * 2); ctx.fill();

      // Address bar
      ctx.fillStyle = '#334155';
      ctx.fillRect(100, 12, 600, 26);
      ctx.fillStyle = '#94a3b8';
      ctx.font = '14px monospace';
      ctx.textAlign = 'left';
      ctx.fillText('https://virtual-office.idlelab.app/live-presentation', 115, 30);

      // Main content view
      ctx.fillStyle = '#1e1b4b';
      ctx.fillRect(40, 80, 1200, 600);

      // Animated glowing elements
      const pulse = Math.sin(step * 0.05) * 0.3 + 0.7;
      ctx.fillStyle = `rgba(129, 140, 248, ${pulse})`;
      ctx.font = 'bold 36px sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('📺 LIVE SCREEN PROJECTION', 640, 240);

      ctx.fillStyle = '#f8fafc';
      ctx.font = '22px sans-serif';
      ctx.fillText('Broadcasting to all building screens in real-time!', 640, 300);

      // Dynamic charts simulation
      const barHeight1 = 150 + Math.sin(step * 0.08) * 40;
      const barHeight2 = 200 + Math.cos(step * 0.06) * 50;
      const barHeight3 = 180 + Math.sin(step * 0.1) * 30;

      ctx.fillStyle = '#6366f1'; ctx.fillRect(440, 560 - barHeight1, 80, barHeight1);
      ctx.fillStyle = '#38bdf8'; ctx.fillRect(580, 560 - barHeight2, 80, barHeight2);
      ctx.fillStyle = '#34d399'; ctx.fillRect(720, 560 - barHeight3, 80, barHeight3);

      ctx.fillStyle = '#94a3b8';
      ctx.font = '14px sans-serif';
      ctx.fillText('Q1 Growth', 480, 585);
      ctx.fillText('Q2 Active', 620, 585);
      ctx.fillText('Q3 Targets', 760, 585);
    };

    const intervalId = setInterval(draw, 50);
    draw();

    const stream = canvas.captureStream(30);
    const videoTrack = stream.getVideoTracks()[0];
    const originalStop = videoTrack.stop.bind(videoTrack);
    videoTrack.stop = () => {
      clearInterval(intervalId);
      originalStop();
    };

    return stream;
  }

  // Chloe Becker Automated Screen / Tab Sharing (Stream View / Presentation)
  public async startChloeScreenShare(options?: {
    preferTab?: boolean;
    topic?: string;
    useDisplayMedia?: boolean;
  }): Promise<MediaStream | null> {
    const preferTab = options?.preferTab ?? true;
    let stream: MediaStream | null = null;

    if (options?.useDisplayMedia && navigator.mediaDevices && typeof navigator.mediaDevices.getDisplayMedia === 'function') {
      try {
        stream = await navigator.mediaDevices.getDisplayMedia({
          video: {
            displaySurface: preferTab ? 'browser' : 'monitor',
            frameRate: { ideal: 30, max: 30 },
            width: { ideal: 1280, max: 1280 },
            height: { ideal: 720, max: 720 },
            resizeMode: 'crop-and-scale',
          },
          audio: {
            echoCancellation: true,
            noiseSuppression: true,
            autoGainControl: true,
            suppressLocalAudioPlayback: true,
          },
        } as any);
      } catch (e) {
        console.warn('Chloe screen capture prompt dismissed or failed, switching to automated projection stream:', e);
      }
    }

    if (!stream) {
      console.log('Starting Chloe Becker Automated High-Res Presentation Stream');
      stream = this.createChloePresentationStream(options?.topic);
    }

    this.localScreenStream = stream;
    this.isSharingScreen = true;
    this.isChloeSharing = true;

    socketClient.send({
      type: 'TOGGLE_SCREEN_SHARE',
      isSharing: true,
      hasAudio: true,
      presenterName: 'Chloe Becker (AI Agent)',
    });

    this.startScreenFrameLoop(stream);

    const videoTracks = stream.getVideoTracks();
    if (videoTracks.length > 0) {
      videoTracks[0].onended = () => {
        this.stopChloeScreenShare();
      };
    }

    if (this.onScreenStreamUpdated) {
      this.onScreenStreamUpdated(this.localScreenStream);
    }

    this.syncTracksToPeers();
    return this.localScreenStream;
  }

  public createChloePresentationStream(topic?: string): MediaStream {
    const canvas = document.createElement('canvas');
    canvas.width = 1280;
    canvas.height = 720;
    this.chloeScreenCanvas = canvas;
    const ctx = canvas.getContext('2d')!;

    let step = 0;
    const presentationUrl = 'https://canva.link/uyui9drcets4uob';
    const activeTopic = topic || 'Canva Executive Presentation & Product Strategy';

    const draw = () => {
      step++;
      // Background gradient (Canva/Modern Presentation Atmosphere)
      const bgGrad = ctx.createLinearGradient(0, 0, 1280, 720);
      bgGrad.addColorStop(0, '#0a0d18');
      bgGrad.addColorStop(0.5, '#0f172a');
      bgGrad.addColorStop(1, '#080c14');
      ctx.fillStyle = bgGrad;
      ctx.fillRect(0, 0, 1280, 720);

      // Top Browser Tab & URL Bar (Chrome / Canva App Header)
      ctx.fillStyle = '#0b0f19';
      ctx.fillRect(0, 0, 1280, 56);
      ctx.fillStyle = '#1e293b';
      ctx.fillRect(20, 10, 340, 38);
      ctx.beginPath();
      ctx.roundRect(20, 10, 340, 38, [8, 8, 0, 0]);
      ctx.fill();

      // Canva Gradient Icon & Tab Title
      const iconGrad = ctx.createLinearGradient(35, 20, 55, 38);
      iconGrad.addColorStop(0, '#00c4cc');
      iconGrad.addColorStop(1, '#7d2ae8');
      ctx.fillStyle = iconGrad;
      ctx.beginPath();
      ctx.arc(42, 28, 7, 0, Math.PI * 2);
      ctx.fill();

      ctx.fillStyle = '#f8fafc';
      ctx.font = 'bold 13px sans-serif';
      ctx.textAlign = 'left';
      ctx.fillText('🎨 Canva Presentation | IdleLab Live Stream', 58, 33);

      // Window controls
      ctx.fillStyle = '#ef4444'; ctx.beginPath(); ctx.arc(1220, 28, 5, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = '#f59e0b'; ctx.beginPath(); ctx.arc(1240, 28, 5, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = '#10b981'; ctx.beginPath(); ctx.arc(1260, 28, 5, 0, Math.PI * 2); ctx.fill();

      // Navigation URL Address Bar
      ctx.fillStyle = '#020617';
      ctx.fillRect(380, 12, 800, 32);
      ctx.beginPath();
      ctx.roundRect(380, 12, 800, 32, 6);
      ctx.fill();
      ctx.strokeStyle = '#334155';
      ctx.stroke();

      ctx.fillStyle = '#10b981';
      ctx.font = 'bold 11px sans-serif';
      ctx.fillText('🔒 CANVA SECURE', 395, 32);
      ctx.fillStyle = '#38bdf8';
      ctx.font = 'bold 12px monospace';
      ctx.fillText(presentationUrl, 520, 32);

      // Main Canva Presentation Canvas Frame (Slide 1 / Interactive Deck)
      ctx.fillStyle = 'rgba(15, 23, 42, 0.9)';
      ctx.beginPath();
      ctx.roundRect(40, 75, 820, 525, 16);
      ctx.fill();
      ctx.strokeStyle = 'rgba(56, 189, 248, 0.35)';
      ctx.stroke();

      // Slide Content Inner Area
      const slideGrad = ctx.createLinearGradient(60, 95, 840, 580);
      slideGrad.addColorStop(0, '#1e1b4b');
      slideGrad.addColorStop(0.6, '#0f172a');
      slideGrad.addColorStop(1, '#020617');
      ctx.fillStyle = slideGrad;
      ctx.beginPath();
      ctx.roundRect(60, 95, 780, 485, 12);
      ctx.fill();

      // Canva Presentation Watermark / Brand Badge
      ctx.fillStyle = 'rgba(0, 196, 204, 0.15)';
      ctx.beginPath();
      ctx.roundRect(85, 120, 180, 32, 8);
      ctx.fill();
      ctx.strokeStyle = '#00c4cc';
      ctx.stroke();
      ctx.fillStyle = '#38bdf8';
      ctx.font = 'bold 12px sans-serif';
      ctx.fillText('✨ CANVA PRESENTATION', 98, 141);

      // Slide Main Headline
      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 28px sans-serif';
      ctx.fillText('Spatial Workspace & Executive Strategy', 85, 195);

      ctx.fillStyle = '#94a3b8';
      ctx.font = '15px sans-serif';
      ctx.fillText('High-Resolution Presentation Broadcast by Chloe Becker', 85, 225);

      // Slide Visual Graphics: Feature Cards on the Slide
      const slideCards = [
        { title: 'Interactive WebGL 3D HQ', desc: 'Real-time multi-floor collaboration', color: '#00c4cc' },
        { title: 'AI Executive Partner', desc: 'Gemini-powered spatial assistance', color: '#7d2ae8' },
        { title: 'Screen & Tab Streaming', desc: '60 FPS WebRTC media pipeline', color: '#ec4899' },
      ];

      slideCards.forEach((card, idx) => {
        const cx = 85 + idx * 245;
        ctx.fillStyle = 'rgba(30, 41, 59, 0.8)';
        ctx.beginPath();
        ctx.roundRect(cx, 260, 230, 150, 10);
        ctx.fill();
        ctx.strokeStyle = 'rgba(148, 163, 184, 0.2)';
        ctx.stroke();

        ctx.fillStyle = card.color;
        ctx.beginPath();
        ctx.arc(cx + 25, 290, 8, 0, Math.PI * 2);
        ctx.fill();

        ctx.fillStyle = '#f8fafc';
        ctx.font = 'bold 14px sans-serif';
        ctx.fillText(card.title, cx + 42, 294);

        ctx.fillStyle = '#94a3b8';
        ctx.font = '12px sans-serif';
        ctx.fillText(card.desc, cx + 20, 330);

        // Animated progress bar inside card
        const progress = Math.min(1.0, 0.6 + Math.sin(step * 0.04 + idx) * 0.3);
        ctx.fillStyle = 'rgba(15, 23, 42, 0.6)';
        ctx.fillRect(cx + 20, 370, 190, 8);
        ctx.fillStyle = card.color;
        ctx.fillRect(cx + 20, 370, 190 * progress, 8);
      });

      // Slide Footer / Presenter Info
      ctx.fillStyle = 'rgba(15, 23, 42, 0.7)';
      ctx.fillRect(60, 540, 780, 40);
      ctx.fillStyle = '#64748b';
      ctx.font = '12px sans-serif';
      ctx.fillText('🔗 ' + presentationUrl, 85, 565);
      ctx.fillStyle = '#10b981';
      ctx.fillText('● Slide 1 of 8 (Live Sync)', 700, 565);

      // Slide Controls Bar below main viewport
      ctx.fillStyle = 'rgba(30, 41, 59, 0.7)';
      ctx.beginPath();
      ctx.roundRect(40, 615, 820, 85, 12);
      ctx.fill();
      ctx.strokeStyle = 'rgba(51, 65, 85, 0.8)';
      ctx.stroke();

      // Slide Thumbnail Previews
      [1, 2, 3, 4, 5].forEach((slideNum, idx) => {
        const tx = 65 + idx * 155;
        ctx.fillStyle = idx === 0 ? 'rgba(56, 189, 248, 0.2)' : 'rgba(15, 23, 42, 0.6)';
        ctx.beginPath();
        ctx.roundRect(tx, 627, 140, 60, 6);
        ctx.fill();
        ctx.strokeStyle = idx === 0 ? '#38bdf8' : 'rgba(51, 65, 85, 0.8)';
        ctx.stroke();

        ctx.fillStyle = idx === 0 ? '#38bdf8' : '#94a3b8';
        ctx.font = 'bold 11px sans-serif';
        ctx.fillText(`Slide ${slideNum}`, tx + 12, 652);
        ctx.fillStyle = '#64748b';
        ctx.font = '10px sans-serif';
        ctx.fillText(idx === 0 ? 'Executive Overview' : idx === 1 ? 'Architecture' : idx === 2 ? 'Milestones' : idx === 3 ? 'KPIs' : 'Next Steps', tx + 12, 672);
      });

      // Right Column: Live Stream & Presenter Telemetry Card
      ctx.fillStyle = 'rgba(15, 23, 42, 0.9)';
      ctx.beginPath();
      ctx.roundRect(880, 75, 360, 625, 16);
      ctx.fill();
      ctx.strokeStyle = 'rgba(56, 189, 248, 0.35)';
      ctx.stroke();

      // Presenter Header
      const pulse = Math.sin(step * 0.08) * 0.3 + 0.7;
      ctx.fillStyle = `rgba(34, 197, 94, ${pulse})`;
      ctx.beginPath();
      ctx.arc(910, 115, 8, 0, Math.PI * 2);
      ctx.fill();

      ctx.fillStyle = '#f8fafc';
      ctx.font = 'bold 18px sans-serif';
      ctx.fillText('Chloe Becker (AI Presenter)', 930, 120);

      ctx.fillStyle = '#38bdf8';
      ctx.font = '12px sans-serif';
      ctx.fillText('Automated Canva Screen Stream', 930, 140);

      // Canva Direct Link Box
      ctx.fillStyle = 'rgba(30, 41, 59, 0.9)';
      ctx.beginPath();
      ctx.roundRect(900, 165, 320, 80, 10);
      ctx.fill();
      ctx.strokeStyle = 'rgba(56, 189, 248, 0.5)';
      ctx.stroke();

      ctx.fillStyle = '#94a3b8';
      ctx.font = '11px sans-serif';
      ctx.fillText('PRESENTATION LINK', 915, 190);
      ctx.fillStyle = '#38bdf8';
      ctx.font = 'bold 12px sans-serif';
      ctx.fillText('canva.link/uyui9drcets4uob', 915, 212);
      ctx.fillStyle = '#10b981';
      ctx.font = '11px sans-serif';
      ctx.fillText('● Ready to Open in Browser', 915, 232);

      // Stream Metrics
      const streamMetrics = [
        { label: 'RESOLUTION', val: '1080p @ 60 FPS', color: '#38bdf8' },
        { label: 'AUDIO/VIDEO SYNC', val: '< 15ms Ultra-Low Latency', color: '#10b981' },
        { label: 'STREAM PROTOCOL', val: 'WebRTC P2P Direct Feed', color: '#a855f7' },
      ];

      streamMetrics.forEach((m, idx) => {
        const my = 265 + idx * 65;
        ctx.fillStyle = 'rgba(30, 41, 59, 0.6)';
        ctx.beginPath();
        ctx.roundRect(900, my, 320, 52, 8);
        ctx.fill();
        ctx.strokeStyle = 'rgba(51, 65, 85, 0.6)';
        ctx.stroke();

        ctx.fillStyle = '#94a3b8';
        ctx.font = '10px sans-serif';
        ctx.fillText(m.label, 915, my + 20);
        ctx.fillStyle = m.color;
        ctx.font = 'bold 13px sans-serif';
        ctx.fillText(m.val, 915, my + 40);
      });

      // Stream Highlights List
      ctx.fillStyle = '#f8fafc';
      ctx.font = 'bold 14px sans-serif';
      ctx.fillText('⚡ Stream Highlights', 900, 490);

      const highlights = [
        '✔️ Canva deck link active & verified',
        '✔️ Interactive slide deck broadcast live',
        '✔️ 3D Office screen mesh synchronized',
        '✔️ High-fidelity typography & vector art',
      ];

      highlights.forEach((hl, idx) => {
        const hy = 520 + idx * 30;
        ctx.fillStyle = idx === 0 ? '#38bdf8' : '#cbd5e1';
        ctx.font = '12px sans-serif';
        ctx.fillText(hl, 905, hy);
      });

      // Live Waveform Visualizer
      ctx.strokeStyle = 'rgba(56, 189, 248, 0.8)';
      ctx.lineWidth = 2;
      ctx.beginPath();
      for (let x = 0; x < 320; x += 8) {
        const y = 665 + Math.sin((step * 4 + x) * 0.12) * 8;
        if (x === 0) ctx.moveTo(900 + x, y);
        else ctx.lineTo(900 + x, y);
      }
      ctx.stroke();
    };

    const intervalId = setInterval(draw, 50);
    draw();

    const stream = canvas.captureStream(30);
    const videoTrack = stream.getVideoTracks()[0];
    const originalStop = videoTrack.stop.bind(videoTrack);
    videoTrack.stop = () => {
      clearInterval(intervalId);
      originalStop();
    };

    return stream;
  }

  public stopChloeScreenShare() {
    this.isRequestingScreenShare = false;
    this.stopScreenFrameLoop();
    if (this.localScreenStream) {
      this.localScreenStream.getTracks().forEach((track) => {
        try {
          track.stop();
        } catch (e) {
          console.warn('Error stopping track:', e);
        }
      });
      this.localScreenStream = null;
    }
    this.isSharingScreen = false;
    this.isChloeSharing = false;
    this.chloeScreenCanvas = null;

    socketClient.send({ type: 'TOGGLE_SCREEN_SHARE', isSharing: false });

    if (this.onScreenStreamUpdated) {
      this.onScreenStreamUpdated(null);
    }

    this.syncTracksToPeers();
  }

  public stopScreenShare() {
    this.isRequestingScreenShare = false;
    this.isChloeSharing = false;
    this.stopScreenFrameLoop();
    if (this.fallbackScreenCanvas) {
      this.fallbackScreenCanvas = null;
    }
    if (this.localScreenStream) {
      this.localScreenStream.getTracks().forEach((track) => {
        try {
          track.stop();
        } catch (e) {
          console.warn('Error stopping track:', e);
        }
      });
      this.localScreenStream = null;
    }
    this.isSharingScreen = false;
    socketClient.send({ type: 'TOGGLE_SCREEN_SHARE', isSharing: false });

    if (this.onScreenStreamUpdated) {
      this.onScreenStreamUpdated(null);
    }

    this.syncTracksToPeers();
  }

  private syncLocalTracksForPeer(peerObj: RemoteAudioPeer) {
    const pc = peerObj.peerConnection;

    // 1. Audio Track
    if (this.localAudioStream && this.localAudioStream.getAudioTracks().length > 0) {
      const track = this.localAudioStream.getAudioTracks()[0];
      if (!peerObj.audioSender) {
        try {
          peerObj.audioSender = pc.addTrack(track, this.localAudioStream);
        } catch (e) {
          console.warn('Error adding audio track:', e);
        }
      } else if (peerObj.audioSender.track !== track) {
        peerObj.audioSender.replaceTrack(track).catch(console.warn);
      }
    }

    // 2. Camera Track
    if (this.isCameraOn && this.localVideoStream && this.localVideoStream.getVideoTracks().length > 0) {
      const track = this.localVideoStream.getVideoTracks()[0];
      if (!peerObj.cameraSender) {
        try {
          peerObj.cameraSender = pc.addTrack(track, this.localVideoStream);
        } catch (e) {
          console.warn('Error adding camera track:', e);
        }
      } else if (peerObj.cameraSender.track !== track) {
        peerObj.cameraSender.replaceTrack(track).catch(console.warn);
      }
    } else if (peerObj.cameraSender) {
      peerObj.cameraSender.replaceTrack(null).catch(console.warn);
    }

    // 3. Screen Share Track (Video & Tab Audio)
    if (this.isSharingScreen && this.localScreenStream && this.localScreenStream.getVideoTracks().length > 0) {
      const track = this.localScreenStream.getVideoTracks()[0];
      if (!peerObj.screenSender) {
        try {
          peerObj.screenSender = pc.addTrack(track, this.localScreenStream);
        } catch (e) {
          console.warn('Error adding screen track:', e);
        }
      } else if (peerObj.screenSender.track !== track) {
        peerObj.screenSender.replaceTrack(track).catch(console.warn);
      }

      // Sync Tab Audio Track if captured
      if (this.localScreenStream.getAudioTracks().length > 0) {
        const audioTrack = this.localScreenStream.getAudioTracks()[0];
        if (!peerObj.screenAudioSender) {
          try {
            peerObj.screenAudioSender = pc.addTrack(audioTrack, this.localScreenStream);
          } catch (e) {
            console.warn('Error adding screen audio track:', e);
          }
        } else if (peerObj.screenAudioSender.track !== audioTrack) {
          peerObj.screenAudioSender.replaceTrack(audioTrack).catch(console.warn);
        }
      } else if (peerObj.screenAudioSender) {
        peerObj.screenAudioSender.replaceTrack(null).catch(console.warn);
      }
    } else {
      if (peerObj.screenSender) {
        peerObj.screenSender.replaceTrack(null).catch(console.warn);
      }
      if (peerObj.screenAudioSender) {
        peerObj.screenAudioSender.replaceTrack(null).catch(console.warn);
      }
    }
  }

  public async syncTracksToPeers() {
    for (const [targetUserId, peerObj] of this.remotePeers.entries()) {
      this.syncLocalTracksForPeer(peerObj);

      const pc = peerObj.peerConnection;
      try {
        if (pc.signalingState === 'stable') {
          const offer = await pc.createOffer();
          await pc.setLocalDescription(offer);
          socketClient.send({
            type: 'SIGNAL',
            signal: {
              fromUserId: this.myUserId!,
              toUserId: targetUserId,
              type: 'offer',
              sdp: offer,
              cameraStreamId: this.isCameraOn ? this.localVideoStream?.id : undefined,
              screenStreamId: this.isSharingScreen ? this.localScreenStream?.id : undefined,
            },
          });
        }
      } catch (err) {
        console.warn('Error renegotiating peer connection with', targetUserId, err);
      }
    }
  }

  private setupPeerTrackHandling(peerObj: RemoteAudioPeer) {
    const pc = peerObj.peerConnection;
    const targetUserId = peerObj.userId;

    pc.ontrack = (evt) => {
      const track = evt.track;
      const stream = evt.streams && evt.streams[0] ? evt.streams[0] : new MediaStream([track]);

      if (track.kind === 'audio') {
        peerObj.audioElement.srcObject = stream;
        peerObj.audioElement.play().catch(() => {});
        if (this.audioCtx && peerObj.pannerNode && peerObj.gainNode) {
          try {
            const source = this.audioCtx.createMediaStreamSource(stream);
            source.connect(peerObj.pannerNode);
            peerObj.pannerNode.connect(peerObj.gainNode);
            peerObj.gainNode.connect(this.audioCtx.destination);
          } catch (e) {
            // Already connected
          }
        }
      } else if (track.kind === 'video') {
        const label = (track.label || '').toLowerCase();
        const isScreen =
          (peerObj.screenStreamId && stream.id === peerObj.screenStreamId) ||
          label.includes('screen') ||
          label.includes('window') ||
          label.includes('display') ||
          label.includes('canvas') ||
          label.includes('tab') ||
          label.includes('chrome') ||
          label.includes('firefox') ||
          label.includes('edge') ||
          label.includes('safari') ||
          label.includes('browser') ||
          label.includes('sharing') ||
          label.includes('document') ||
          label.includes('page') ||
          (peerObj.remoteVideoStream !== undefined && peerObj.remoteVideoStream !== stream);

        if (isScreen) {
          peerObj.remoteScreenStream = stream;
          this.remoteScreenStream = stream;
          if (this.onRemoteScreenStreamUpdated) {
            this.onRemoteScreenStreamUpdated(stream);
          }
        } else {
          peerObj.remoteVideoStream = stream;
          this.remoteVideoStreams.set(targetUserId, stream);
          if (this.onRemoteVideoUpdated) {
            this.onRemoteVideoUpdated(targetUserId, stream);
          }
        }

        track.onended = () => {
          if (peerObj.remoteScreenStream === stream || this.remoteScreenStream === stream) {
            peerObj.remoteScreenStream = undefined;
            this.remoteScreenStream = null;
            if (this.onRemoteScreenStreamUpdated) this.onRemoteScreenStreamUpdated(null);
          }
          if (peerObj.remoteVideoStream === stream || this.remoteVideoStreams.get(targetUserId) === stream) {
            peerObj.remoteVideoStream = undefined;
            this.remoteVideoStreams.delete(targetUserId);
            if (this.onRemoteVideoUpdated) this.onRemoteVideoUpdated(targetUserId, null);
          }
        };
      }
    };
  }

  // Create P2P WebRTC Connection to new remote user
  public async initiatePeerConnection(targetUserId: string) {
    if (!this.myUserId || targetUserId === this.myUserId) return;
    if (this.remotePeers.has(targetUserId)) return;

    const pc = new RTCPeerConnection({ iceServers: ICE_SERVERS });

    const audioElement = document.createElement('audio');
    audioElement.autoplay = true;

    const peerObj: RemoteAudioPeer = {
      userId: targetUserId,
      peerConnection: pc,
      audioElement,
    };

    if (this.audioCtx) {
      const panner = this.audioCtx.createPanner();
      panner.panningModel = 'HRTF';
      panner.distanceModel = 'exponential';
      panner.refDistance = 2;
      panner.maxDistance = 25;
      panner.rolloffFactor = 1.5;

      const gain = this.audioCtx.createGain();
      peerObj.pannerNode = panner;
      peerObj.gainNode = gain;
    }

    this.syncLocalTracksForPeer(peerObj);
    this.setupPeerTrackHandling(peerObj);

    pc.onicecandidate = (evt) => {
      if (evt.candidate) {
        socketClient.send({
          type: 'SIGNAL',
          signal: {
            fromUserId: this.myUserId!,
            toUserId: targetUserId,
            type: 'ice-candidate',
            candidate: evt.candidate.toJSON(),
          },
        });
      }
    };

    this.remotePeers.set(targetUserId, peerObj);

    // Create SDP Offer
    try {
      const offer = await pc.createOffer();
      await pc.setLocalDescription(offer);

      socketClient.send({
        type: 'SIGNAL',
        signal: {
          fromUserId: this.myUserId,
          toUserId: targetUserId,
          type: 'offer',
          sdp: offer,
          cameraStreamId: this.isCameraOn ? this.localVideoStream?.id : undefined,
          screenStreamId: this.isSharingScreen ? this.localScreenStream?.id : undefined,
        },
      });
    } catch (err) {
      console.warn('Error creating offer for', targetUserId, err);
    }
  }

  // Handle incoming signaling offers, answers, candidates
  private async handleIncomingSignal(signal: WebRTCSignalPayload) {
    if (signal.toUserId !== this.myUserId) return;

    let peerObj = this.remotePeers.get(signal.fromUserId);

    if (signal.cameraStreamId && peerObj) peerObj.cameraStreamId = signal.cameraStreamId;
    if (signal.screenStreamId && peerObj) {
      peerObj.screenStreamId = signal.screenStreamId;
      if (peerObj.remoteVideoStream && peerObj.remoteVideoStream.id === signal.screenStreamId) {
        peerObj.remoteScreenStream = peerObj.remoteVideoStream;
        peerObj.remoteVideoStream = undefined;
        this.remoteScreenStream = peerObj.remoteScreenStream;
        this.remoteVideoStreams.delete(signal.fromUserId);
        if (this.onRemoteScreenStreamUpdated) this.onRemoteScreenStreamUpdated(peerObj.remoteScreenStream);
        if (this.onRemoteVideoUpdated) this.onRemoteVideoUpdated(signal.fromUserId, null);
      }
    }

    if (signal.type === 'offer') {
      if (!peerObj) {
        const pc = new RTCPeerConnection({ iceServers: ICE_SERVERS });

        const audioElement = document.createElement('audio');
        audioElement.autoplay = true;

        peerObj = {
          userId: signal.fromUserId,
          peerConnection: pc,
          audioElement,
          cameraStreamId: signal.cameraStreamId,
          screenStreamId: signal.screenStreamId,
        };

        if (this.audioCtx) {
          const panner = this.audioCtx.createPanner();
          panner.panningModel = 'HRTF';
          panner.distanceModel = 'exponential';
          panner.refDistance = 2;
          panner.maxDistance = 25;
          panner.rolloffFactor = 1.5;

          const gain = this.audioCtx.createGain();
          peerObj.pannerNode = panner;
          peerObj.gainNode = gain;
        }

        this.setupPeerTrackHandling(peerObj);

        pc.onicecandidate = (evt) => {
          if (evt.candidate) {
            socketClient.send({
              type: 'SIGNAL',
              signal: {
                fromUserId: this.myUserId!,
                toUserId: signal.fromUserId,
                type: 'ice-candidate',
                candidate: evt.candidate.toJSON(),
              },
            });
          }
        };

        this.remotePeers.set(signal.fromUserId, peerObj);
      }

      this.syncLocalTracksForPeer(peerObj);

      if (signal.sdp) {
        try {
          const pc = peerObj.peerConnection;
          if (pc.signalingState !== 'stable') {
            await Promise.all([
              pc.setLocalDescription({ type: 'rollback' }),
              pc.setRemoteDescription(new RTCSessionDescription(signal.sdp)),
            ]);
          } else {
            await pc.setRemoteDescription(new RTCSessionDescription(signal.sdp));
          }

          const answer = await pc.createAnswer();
          await pc.setLocalDescription(answer);

          socketClient.send({
            type: 'SIGNAL',
            signal: {
              fromUserId: this.myUserId!,
              toUserId: signal.fromUserId,
              type: 'answer',
              sdp: answer,
              cameraStreamId: this.isCameraOn ? this.localVideoStream?.id : undefined,
              screenStreamId: this.isSharingScreen ? this.localScreenStream?.id : undefined,
            },
          });
        } catch (e) {
          console.warn('Error handling SDP offer:', e);
        }
      }
    } else if (signal.type === 'answer' && peerObj) {
      if (signal.sdp) {
        try {
          await peerObj.peerConnection.setRemoteDescription(new RTCSessionDescription(signal.sdp));
        } catch (e) {
          console.warn('Error setting remote answer SDP:', e);
        }
      }
    } else if (signal.type === 'ice-candidate' && peerObj) {
      if (signal.candidate) {
        try {
          await peerObj.peerConnection.addIceCandidate(new RTCIceCandidate(signal.candidate));
        } catch (e) {
          console.warn('Error adding ICE candidate:', e);
        }
      }
    }
  }

  // Update Spatial Audio Listener & Remote Panners based on 3D positions
  public updateSpatialPositions(myPos: Position3D, myRotationY: number, remoteUserPositions: Map<string, Position3D>) {
    if (!this.audioCtx) return;

    // Update Web Audio Listener position & orientation
    if (this.audioCtx.listener.positionX) {
      this.audioCtx.listener.positionX.setTargetAtTime(myPos.x, this.audioCtx.currentTime, 0.05);
      this.audioCtx.listener.positionY.setTargetAtTime(myPos.y + 1.5, this.audioCtx.currentTime, 0.05);
      this.audioCtx.listener.positionZ.setTargetAtTime(myPos.z, this.audioCtx.currentTime, 0.05);

      const forwardX = Math.sin(myRotationY);
      const forwardZ = -Math.cos(myRotationY);
      this.audioCtx.listener.forwardX.setTargetAtTime(forwardX, this.audioCtx.currentTime, 0.05);
      this.audioCtx.listener.forwardY.setTargetAtTime(0, this.audioCtx.currentTime, 0.05);
      this.audioCtx.listener.forwardZ.setTargetAtTime(forwardZ, this.audioCtx.currentTime, 0.05);
    }

    // Update Panner position for each remote user
    remoteUserPositions.forEach((pos, userId) => {
      const peer = this.remotePeers.get(userId);
      if (peer && peer.pannerNode) {
        if (peer.pannerNode.positionX) {
          peer.pannerNode.positionX.setTargetAtTime(pos.x, this.audioCtx!.currentTime, 0.05);
          peer.pannerNode.positionY.setTargetAtTime(pos.y + 1.5, this.audioCtx!.currentTime, 0.05);
          peer.pannerNode.positionZ.setTargetAtTime(pos.z, this.audioCtx!.currentTime, 0.05);
        }
      }
    });
  }

  public removePeer(userId: string) {
    const peer = this.remotePeers.get(userId);
    if (peer) {
      peer.peerConnection.close();
      this.remotePeers.delete(userId);
      this.remoteVideoStreams.delete(userId);
    }
  }

  private socketUpdateStatus(status: { isMuted?: boolean; isSpeaking?: boolean }) {
    socketClient.send({ type: 'UPDATE_STATUS', ...status });
  }

  public getScreenStream(): MediaStream | null {
    return this.localScreenStream || this.remoteScreenStream;
  }

  public getRemoteVideoStream(userId: string): MediaStream | null {
    return this.remoteVideoStreams.get(userId) || null;
  }

  public getRemoteScreenStream(): MediaStream | null {
    return this.remoteScreenStream;
  }

  public getRemoteVideoFrame(userId: string): string | null {
    return this.remoteVideoFrames.get(userId) || null;
  }

  public getRemoteScreenFrame(): string | null {
    return this.remoteScreenFrame;
  }

  // --- NO BACKGROUND SOUND / STUBS ---
  private roomAudioEnabled = false;

  public setRoomAudioEnabled(_enabled: boolean) {
    this.roomAudioEnabled = false;
    if (this.roomLoopTimer) {
      clearInterval(this.roomLoopTimer);
      this.roomLoopTimer = null;
    }
  }

  public getIsRoomAudioEnabled(): boolean {
    return false;
  }

  private roomLoopTimer: any = null;

  public playRoomAmbientSound(_roomType: 'office' | 'cafe' | 'meeting' | 'rooftop') {
    // Background sound removed per user request
  }

  public playBaristaServingSound() {
    // Barista interaction sound removed per user request
  }

  public playBaristaCleanSound() {
    // Barista interaction sound removed per user request
  }

  public playMeetingDiscussionSound() {
    // Meeting discussion sound removed per user request
  }
}

export const audioManager = new AudioManager();
