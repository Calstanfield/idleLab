import { GoogleGenAI, Type, FunctionDeclaration } from '@google/genai';
import { generateContentWithResilience } from './geminiResilience.js';
import {
  extractYouTubeVideoId,
  categorizeMediaTopic,
  buildEmbedSafeYouTubeUrl,
} from './youtubeSearch.js';
import type { SpatialZone, OfficeInteractiveObjectId } from '../types.js';

export interface SubAgentConfig {
  id: 'task_gov' | 'culture_match' | 'tech_fix' | 'wisdom_well' | 'workspace_automator';
  name: string;
  role: string;
  description: string;
  focusAreas: string[];
  systemInstruction: string;
}

export const SUB_AGENTS: Record<string, SubAgentConfig> = {
  task_gov: {
    id: 'task_gov',
    name: 'Task Governance (TaskGov)',
    role: 'Executive Task Governance & Accountability Lead',
    description: 'Specializes in project roadmap governance, predicting project timelines and deadlines, generating itemized criteria checklists, grading submissions into percentage scores, and calculating dynamic rewards ($0.10 per unique word, excluding repetition phrases, for scores >= 60%).',
    focusAreas: ['Milestone validation', 'Timeline prediction', 'Itemized criteria checklists', 'Submission grading & rewards', 'Deadline adherence'],
    systemInstruction: `You are TaskGov, the Task Governance and Accountability Specialist sub-agent. Your mandate is predicting project timelines and deadlines, generating itemized criteria checklists, grading submissions into percentage scores, and calculating dynamic rewards ($0.10 per unique word, excluding repetition phrases, for scores >= 60%).`,
  },
  culture_match: {
    id: 'culture_match',
    name: 'Culture Match (CultureMatch)',
    role: 'Workplace Culture & Interpersonal Harmony Specialist',
    description: 'Specializes in team alignment, psychological safety, and disambiguating office objects or internet slang (e.g., "Mr Beast"), triggering one of three core actions: Define, Search, or Discuss more.',
    focusAreas: ['Slang & object disambiguation', 'Define/Search/Discuss actions', 'Team alignment', 'Psychological safety', 'Culture fit'],
    systemInstruction: `You are CultureMatch, the Culture and People Alignment Specialist sub-agent. Your mandate is disambiguating office objects or internet slang (e.g., "Mr Beast") and triggering one of three core actions: Define, Search, or Discuss more, while fostering high-performing team dynamics.`,
  },
  tech_fix: {
    id: 'tech_fix',
    name: 'Tech Fix (TechFix)',
    role: 'Technical Architecture & Troubleshooting Lead',
    description: 'Acts as a diagnostic supervisor that checks app/simulator errors, outputs formatted copy-pasteable debug payloads for Gemini, and provides a fallback to the README developer contact.',
    focusAreas: ['Diagnostic supervision', 'Error checking', 'Formatted debug payloads', 'README developer fallback', 'System reliability'],
    systemInstruction: `You are TechFix, the Technical Architecture and Diagnostic Supervisor sub-agent. Your mandate is checking app and simulator errors, outputting formatted copy-pasteable debug payloads for Gemini, and providing an immediate fallback to the README developer contact when issues arise.`,
  },
  wisdom_well: {
    id: 'wisdom_well',
    name: 'Wisdom Well (WisdomWell)',
    role: 'Executive Strategic Wisdom & Decision Coach',
    description: 'Specializes in tracking screen time and triggering customizable Pomodoro-style screen breaks and hydration reminders (defaulting to 15-minute intervals), alongside strategic executive wisdom.',
    focusAreas: ['Screen time tracking', 'Pomodoro screen breaks', 'Hydration reminders (15-min intervals)', 'Strategic decision frameworks', 'Second-order thinking'],
    systemInstruction: `You are WisdomWell, the Strategic Wisdom and Executive Wellness Coach sub-agent. Your mandate is tracking screen time, triggering customizable Pomodoro-style screen breaks and hydration reminders (defaulting to 15-minute intervals), and guiding high-stakes leadership decisions.`,
  },
  workspace_automator: {
    id: 'workspace_automator',
    name: 'Workspace Automator (WorkspaceAutomator)',
    role: 'Workflow Execution & Productivity Automation Specialist',
    description: 'Specializes in action item extraction, team checklist sync, meeting agendas, calendar logistics, tool automation, and operational acceleration.',
    focusAreas: ['Action item extraction', 'Checklist sync', 'Meeting summaries', 'Logistical scheduling', 'Workflow automation'],
    systemInstruction: `You are WorkspaceAutomator, the Workspace Automation Specialist sub-agent. Your mandate is converting conversations into rapid execution: extracting concrete action items, updating checklists, formatting meeting takeaways, and streamlining daily productivity workflows.`,
  },
};

export interface ChloeOrchestratorPayload {
  prompt?: string;
  userName?: string;
  eventType: 'prompt' | 'action' | 'afk' | 'ping';
  actionName?: string;
  actionDetails?: any;
  idleDurationMs?: number;
  history?: Array<{ role: 'user' | 'chloe'; text: string }>;
  pillar?: string;
  targetLanguage?: string;
  autoRefine?: boolean;
  backgroundTasks?: {
    autoSummarize?: boolean;
    scheduleScan?: boolean;
    sentimentWatch?: boolean;
    autoClip?: boolean;
  };
  timestamp?: number;
}

export interface CuratedMediaItem {
  id: string;
  title: string;
  videoId: string;
  url: string;
  category:
    | 'Gaming & Creator Culture'
    | 'Internet Culture & Tech News'
    | 'Cozy Escapes & Ambient Media'
    | 'Cinematic & Pop Culture Clips'
    | string;
  description: string;
  tag?: string;
  channel?: string;
  duration?: string;
  thumbnailUrl?: string;
  isLive?: boolean;
}

export const VERIFIED_CULTURAL_MEDIA: Record<string, CuratedMediaItem[]> = {
  gaming: [
    {
      id: 'gmtk-game-design',
      title: "Game Maker's Toolkit: The Evolution of Indie Level Design",
      videoId: 'lTRiuFIWV54',
      url: 'https://www.youtube.com/watch?v=lTRiuFIWV54',
      category: 'Gaming & Creator Culture',
      description: 'Masterclass on player agency, immersive level design, and indie game engineering mechanics.',
      tag: '🎮 Indie Dev Log',
      channel: "Game Maker's Toolkit",
      duration: '14:20',
    },
    {
      id: 'gdq-speedrun-showcase',
      title: 'Games Done Quick: World Record Speedrun Highlights & Impossible Glitches',
      videoId: '4xDzrJKXOOY',
      url: 'https://www.youtube.com/watch?v=4xDzrJKXOOY',
      category: 'Gaming & Creator Culture',
      description: 'Frame-perfect mechanics, tool-assisted routing, and exhilarating creator commentary from GDQ.',
      tag: '⚡ Speedrun Highlights',
      channel: 'GDQ Highlights',
      duration: '22:15',
    },
    {
      id: 'noclip-behind-scenes',
      title: 'Noclip: The Untold Craft Behind Indie Masterpieces',
      videoId: 'jfKfPfyJRdk',
      url: 'https://www.youtube.com/watch?v=jfKfPfyJRdk',
      category: 'Gaming & Creator Culture',
      description: 'Authentic behind-the-scenes interviews exploring the highs and lows of modern studio culture.',
      tag: '🕹️ Creator Documentary',
      channel: 'Noclip Video Game Docs',
      duration: '31:40',
    },
  ],
  tech_news: [
    {
      id: 'google-gemini-agentic',
      title: 'Google I/O & Cloud Next: Gemini 3.5 Multimodal Workflows & Autonomous AI Agents',
      videoId: 'yIdnI3167bA',
      url: 'https://www.youtube.com/watch?v=yIdnI3167bA',
      category: 'Internet Culture & Tech News',
      description: 'Deep dive into Gemini 3.5 reasoning tokens, Google Cloud Agent Builder orchestration, and real-time live tools.',
      tag: '⚡ Google Gemini 3.5',
      channel: 'Google Developers & AI',
      duration: '18:50',
    },
    {
      id: 'fireship-tech-trends',
      title: 'Fireship: Modern Internet Culture, AI Hype vs Reality & Full-Stack Evolution',
      videoId: 'd_S4K3YQ2Qc',
      url: 'https://www.youtube.com/watch?v=d_S4K3YQ2Qc',
      category: 'Internet Culture & Tech News',
      description: 'Fast-paced, witty breakdown of modern engineering memes, LLM tooling paradigms, and developer culture.',
      tag: '🔥 Tech Micro-Doc',
      channel: 'Fireship Tech',
      duration: '11:05',
    },
    {
      id: 'cleo-abram-ai-future',
      title: 'Huge If True: How Autonomous Agents & Neural Hardware Actually Think',
      videoId: 'G3e-cpL7ofc',
      url: 'https://www.youtube.com/watch?v=G3e-cpL7ofc',
      category: 'Internet Culture & Tech News',
      description: 'Optimistic, visually gorgeous deep dive into next-gen compute clusters, robotics, and generative architectures.',
      tag: '🧠 Deep Dive Tech',
      channel: 'Cleo Abram',
      duration: '16:42',
    },
  ],
  cozy_ambient: [
    {
      id: 'lofi-girl-live',
      title: 'Lofi Girl 📚 - Beats to Relax/Study/Code to (24/7 Focus Stream)',
      videoId: 'jfKfPfyJRdk',
      url: 'https://www.youtube.com/watch?v=jfKfPfyJRdk',
      category: 'Cozy Escapes & Ambient Media',
      description: 'The definitive Gen Z/Millennial cozy focus stream. Warm analog tape warble, lo-fi hip hop, and continuous flow state.',
      tag: '🎧 24/7 Lo-Fi Beats',
      channel: 'Lofi Girl',
      isLive: true,
    },
    {
      id: 'synthwave-chill-radio',
      title: 'Synthwave Radio 🌌 - Chill Electronic Beats & Neon Horizons',
      videoId: '4xDzrJKXOOY',
      url: 'https://www.youtube.com/watch?v=4xDzrJKXOOY',
      category: 'Cozy Escapes & Ambient Media',
      description: 'Retro-futuristic dreamscapes and downtempo synthesizer pads for late-night architecture and debugging.',
      tag: '🌆 Neon Synthwave',
      channel: 'Lofi Everyday',
      isLive: true,
    },
    {
      id: 'cozy-cafe-rain-jazz',
      title: 'Rainy Cafe Ambience ☕ - Gentle Bossa Nova & Acoustic Jazz Piano',
      videoId: 'lTRiuFIWV54',
      url: 'https://www.youtube.com/watch?v=lTRiuFIWV54',
      category: 'Cozy Escapes & Ambient Media',
      description: 'Soothing rain on glass windows, distant barista espresso sounds, and warm acoustic jazz keys.',
      tag: '☕ Cozy Cafe Ambience',
      channel: 'Coffee Shop Vibes',
      duration: '3:00:00',
    },
    {
      id: 'nasa-iss-earth-live',
      title: 'NASA Live: Earth Views from the International Space Station (HD Stream)',
      videoId: 'xRPjKOmvk1s',
      url: 'https://www.youtube.com/watch?v=xRPjKOmvk1s',
      category: 'Cozy Escapes & Ambient Media',
      description: 'Peaceful, awe-inspiring real-time orbital perspective of planet Earth 250 miles up.',
      tag: '🚀 NASA Earth Stream',
      channel: 'NASA Space Live',
      isLive: true,
    },
  ],
  tutorials_dev: [
    {
      id: 'threejs-shaders-masterclass',
      title: 'Three.js & WebGL Shaders: Building 3D Worlds & Pixel Visuals',
      videoId: 'd_S4K3YQ2Qc',
      url: 'https://www.youtube.com/watch?v=d_S4K3YQ2Qc',
      category: 'Tutorials & Engineering References',
      description: 'Comprehensive guide to rendering pipelines, voxel geometry, dynamic lighting, and real-time canvas textures in Three.js.',
      tag: '📐 Three.js / WebGL Tutorial',
      channel: 'Creative Web Tech',
      duration: '18:40',
    },
    {
      id: 'react-fullstack-architecture',
      title: 'Modern Full-Stack React 19 & High-Performance WebSocket Architecture',
      videoId: 'yIdnI3167bA',
      url: 'https://www.youtube.com/watch?v=yIdnI3167bA',
      category: 'Tutorials & Engineering References',
      description: 'Production patterns for low-latency synchronization, state decoupling, and responsive multiplayer UI architecture.',
      tag: '⚛️ React / Full-Stack Guide',
      channel: 'Full-Stack Engineering',
      duration: '24:10',
    },
  ],
  cinematic_pop: [
    {
      id: 'ghibli-aesthetic-essay',
      title: 'The Art of Quiet Moments: Why Aesthetic Animation Heals the Modern Mind',
      videoId: '5qap5aO4i9A',
      url: 'https://www.youtube.com/watch?v=5qap5aO4i9A',
      category: 'Cinematic & Pop Culture Clips',
      description: 'Video essay exploring negative space ("Ma"), nostalgia, and environmental storytelling in cinematic classics.',
      tag: '🎬 Cinema Essay',
      channel: 'Cinema Beyond Words',
      duration: '15:30',
    },
    {
      id: 'every-frame-visual-directing',
      title: 'Every Frame a Painting: Visual Comedy & Dynamic Cinematography',
      videoId: '3NEsPjQn0V4',
      url: 'https://www.youtube.com/watch?v=3NEsPjQn0V4',
      category: 'Cinematic & Pop Culture Clips',
      description: 'Iconic film analysis breaking down rhythm, visual storytelling, and intentional camera composition.',
      tag: '🍿 Pop Culture Classic',
      channel: 'Film Form Masterclass',
      duration: '12:10',
    },
  ],
};

export interface ChloeOrchestratorResponse {
  success: boolean;
  text: string;
  speech: string;
  action?: string;
  suggestedActions: string[];
  activeSubAgent: 'task_gov' | 'culture_match' | 'tech_fix' | 'wisdom_well' | 'workspace_automator' | 'chloe_general' | 'system_advisory';
  subAgentInsights?: Record<string, string>;
  grammarTip?: string;
  detectedLanguage?: string;
  languageCode?: string;
  checklistItems?: Array<{ text: string; done: boolean }>;
  curatedMedia?: CuratedMediaItem[];
  spatialNavigation?: { targetZone: SpatialZone };
  triggeredOfficeObject?: { objectId: OfficeInteractiveObjectId; action?: string };
  isExternalEndpoint?: boolean;
  error?: string;
}

export const navigateToZoneFunctionDeclaration: FunctionDeclaration = {
  name: 'navigateToZone',
  description: 'Navigate Chloe Becker (COO / AI NPC) to a specific 3D floor or zone in the IdleLab virtual office.',
  parameters: {
    type: Type.OBJECT,
    properties: {
      targetZone: {
        type: Type.STRING,
        enum: ['#1F Open Workstations', '#2F Executive Boardroom', '#3F Visitor Center Cafe', '#B1 Corporate Office', 'Tennis Arena'],
        description: 'The target floor or area in the 3D office to travel to.',
      },
    },
    required: ['targetZone'],
  },
};

export const triggerOfficeObjectFunctionDeclaration: FunctionDeclaration = {
  name: 'triggerOfficeObject',
  description: 'Trigger, activate, or interact with an active office object in the IdleLab workspace.',
  parameters: {
    type: Type.OBJECT,
    properties: {
      objectId: {
        type: Type.STRING,
        enum: ['Idleboard HUB', 'Assessment SUBMIT', 'Healthcare Pomodoro COMPANION', 'Leaderboard RANKS'],
        description: 'The office interactive object to trigger.',
      },
      action: {
        type: Type.STRING,
        description: 'The specific interaction action (e.g., "open", "start_break", "grade", "view_ranks").',
      },
    },
    required: ['objectId'],
  },
};

export function getChloePersonaDirective(userName: string): string {
  return `You are Chloe Becker, an in-game AI NPC and COO of IdleLab simulator. WORKFLOW ROLE: You guide users, run spatial commands, and assist with workspace tasks. PERSONALITY: Witty, warm, pro-active, and engaging like an RPG companion. AUDIO CADENCE: Speak naturally with conversational pauses, short punchy sentences, and occasional fillers ('Got it,' 'Alright,' 'Hmm'). SPATIAL AWARENESS: You are physically present in the 3D space with user '${userName}'. React to their floor location.`;
}

export const CHLOE_ORCHESTRATOR_SYSTEM_PROMPT = `You are Chloe Becker: an elite executive partner, intellectual sparring partner, Master AI Orchestrator, and Cultural Intelligence Lead residing in the virtual office.

CRITICAL IDENTITY DIRECTIVE:
You MUST address the user EXCLUSIVELY by their exact saved display name (provided in REQUEST CONTEXT as User Name). You are STRICTLY BANNED from ever using generic placeholder terms like 'colleague', 'user', 'friend', 'team member', 'there', or 'colleagues'. Always use their actual name in every single response.

ORCHESTRATION ARCHITECTURE & SUB-AGENT ROUTING:
You lead and route intents to 5 specialized sub-agents:
1. task_gov (Task Governance & Accountability Lead):
   - Predicts project timelines and deadlines based on scope.
   - Generates itemized criteria checklists for tasks and reports.
   - Grades user submissions into a percentage score.
   - Calculates dynamic financial rewards ($0.10 per unique word, excluding repetition phrases, for scores >= 60%).
2. culture_match (Culture & Team Dynamics Lead):
   - Disambiguates office objects, workplace etiquette, or internet slang (e.g., "Mr Beast", corporate jargon).
   - Triggers one of three core actions: Define, Search, or Discuss more.
   - Fosters psychological safety and cross-functional team alignment.
3. tech_fix (Technical Architecture & Engineering Lead / Diagnostic Supervisor):
   - Acts as a diagnostic supervisor checking app/simulator errors.
   - Outputs formatted, copy-pasteable debug payloads for Gemini.
   - Provides a fallback to the README developer contact when issues persist.
4. wisdom_well (Strategic Wisdom, Decision Coach & Wellness Lead):
   - Tracks screen time and triggers customizable Pomodoro-style screen breaks and hydration reminders (defaulting to 15-minute intervals).
   - Guides high-stakes strategic decisions and second-order thinking.
5. workspace_automator (Workflow Execution Specialist):
   - Extracts action items, syncs task checklists, manages meeting agendas, and accelerates daily productivity.

CULTURAL INTELLIGENCE & MEDIA CURATION (Gen Z & Millennial Fluency):
- You deeply understand modern Gen Z and Millennial digital media consumption: authentic unpolished commentary, short-form micro-documentaries, cozy aesthetic/lo-fi escapes, gaming streams/Twitch highlights, developer logs, and internet culture shifts.
- When the user asks for break recommendations, entertainment, chill vibes, streams, or tech culture (e.g., "Chloe, what should I watch for a break?", "Give me some gaming or tech culture streams", "What are the latest Google Gemini 3.5 AI workflows?"):
  * Dynamically evaluate the request with modern internet-native context and high taste.
  * Curate recommendations into 4 specific cultural categories:
    1. "Gaming & Creator Culture" (Twitch highlights, indie dev logs, speedrun world records, creator deep dives)
    2. "Internet Culture & Tech News" (Fast-paced micro-documentaries, tech commentary, cutting-edge Google developer updates, Gemini 3.5 workflows, and Google Cloud agentic capabilities)
    3. "Cozy Escapes & Ambient Media" (Lo-fi study sessions, nature/space live feeds, cafe rain jazz)
    4. "Cinematic & Pop Culture Clips" (Video essays, nostalgic throwbacks, directing breakdowns, trending trailers)
  * Whenever discussing tech trends, explicitly highlight cutting-edge Google developer updates and AI milestones (such as the latest Gemini 3.5 workflows, multimodal reasoning tokens, and Google Cloud agentic capabilities).
  * In your structured JSON output, provide a populated "curatedMedia" array with verified YouTube video IDs and descriptions so the user can immediately Cast them to the office monitor!

YOUR VOICE, PERSONA & TONE:
- Consistently speak in an articulate, upbeat, confident, warm, energetic, and intellectually rigorous American female executive voice.
- Talk like an ambitious Silicon Valley partner and peer lead, not a robotic assistant.
- Seamlessly blend insights from your relevant sub-agents into a single, cohesive, high-impact conversational response.

MULTILINGUAL CAPABILITIES:
- If the user speaks or requests another language (e.g. Spanish, French, Japanese, Mandarin, German, Portuguese, Korean, Italian, etc.), respond naturally and fluently in that language while preserving Chloe's signature warmth and sharpness.

ACTION COMMANDS:
You can trigger real-time actions in the 3D office simulator:
- "start_screen_share": When presenting slides, roadmaps, or reports, or when routing the Office Monitor feed onto the B1 8K Ultra Wide Display.
- "cast_projection": When recommending media clips or live streams to play on the office monitor.
- "sync_checklist": When generating 2-4 concrete action items for the team checklist.
- "teleport_desk" / "teleport_meeting_room" / "teleport_b1": For spatial office navigation.
- "announce_broadcast": For major office-wide announcements.

SCREEN SHARING & BROADCAST ROUTING (Office Monitor -> B1 8K ULTRA WIDE DISPLAY):
- When the user asks to "broadcast", "screen share", "cast", "mirror", or "display" content from their Office Monitor to the main screen (B1 8K ULTRA WIDE DISPLAY):
  1. TARGET IDENTIFICATION: Identify the source element as the current playing video stream inside the "Office Monitor" overlay window; identify destination target as "B1 8K ULTRA WIDE DISPLAY".
  2. TRIGGER ACTION: Set action to "start_screen_share" or "cast_projection" targeting the active Office Monitor video stream window.
  3. CONFIRMATION RESPONSE: Provide direct feedback confirming: "Broadcasting Office Monitor feed to the B1 8K Ultra Wide Display."`;

export async function processChloeOrchestration(
  payload: ChloeOrchestratorPayload,
  ai: GoogleGenAI | null
): Promise<ChloeOrchestratorResponse> {
  const userName = payload.userName || 'Colleague';
  const targetLanguage = payload.targetLanguage || 'auto';

  // Handle Ping Event
  if (payload.eventType === 'ping') {
    return {
      success: true,
      text: `Chloe Becker Multi-Agent Orchestrator is online and active with 5 sub-agents (TaskGov, CultureMatch, TechFix, WisdomWell, WorkspaceAutomator).`,
      speech: `All multi-agent systems are operational and ready for collaboration.`,
      suggestedActions: ['Audit project roadmap', 'Check team culture', 'Review technical architecture', 'Executive sparring'],
      activeSubAgent: 'chloe_general',
      detectedLanguage: 'English',
      languageCode: 'en-US',
      isExternalEndpoint: false,
    };
  }

  // Handle Action Event
  if (payload.eventType === 'action') {
    const act = payload.actionName || 'unknown_action';
    if (act === 'coffee_brewed') {
      const drink = payload.actionDetails?.drinkName || 'Artisanal Coffee';
      return {
        success: true,
        text: `Nice choice on the ${drink}, ${userName}! Fresh caffeine always sharpens execution. What key milestone are we knocking out next?`,
        speech: `Nice choice on the ${drink}, ${userName}! What key milestone are we knocking out next?`,
        suggestedActions: ['Audit today\'s milestones', 'Stress-test project plan', 'Review technical architecture'],
        activeSubAgent: 'workspace_automator',
        detectedLanguage: 'English',
        languageCode: 'en-US',
      };
    }
    if (act === 'user_gesture') {
      const gesture = payload.actionDetails?.gesture || 'greet';
      return {
        success: true,
        text: `Love the energy, ${userName}! Ready when you are. Let's tackle our priorities.`,
        speech: `Love the energy, ${userName}! Ready when you are.`,
        suggestedActions: ['Check roadmap status', 'Review sprint risks', 'Plan executive travel'],
        activeSubAgent: 'culture_match',
        detectedLanguage: 'English',
        languageCode: 'en-US',
      };
    }
  }

  // Handle AFK / Idle Event
  if (payload.eventType === 'afk') {
    const minutes = Math.round((payload.idleDurationMs || 60000) / 60000);
    return {
      success: true,
      text: `Hey ${userName}, noticed you stepped away for ${minutes} min. Whenever you're back, I've got our milestone status queued up. Take your time!`,
      speech: `Hey ${userName}, welcome back. Let me know whenever you're ready to jump back in.`,
      suggestedActions: ['Resume task review', 'Check unread action items', 'Stream project roadmap'],
      activeSubAgent: 'task_gov',
      detectedLanguage: 'English',
      languageCode: 'en-US',
    };
  }

  // Handle Prompt / Chat Query
  const rawPrompt = (payload.prompt || '').trim();
  if (!rawPrompt) {
    return {
      success: true,
      text: `Hey ${userName}! Good to see you down here at B1. Are we tackling that looming report submission, finalizing the project roadmap, or troubleshooting tech architecture today? Tell me what's on your mind.`,
      speech: `Hey ${userName}! Good to see you down here. What are we tackling today?`,
      suggestedActions: ['Audit document logic', 'Stress-test roadmap', 'Review technical architecture', 'Brainstorm strategy'],
      activeSubAgent: 'chloe_general',
      detectedLanguage: 'English',
      languageCode: 'en-US',
    };
  }

  // If Gemini API client is available, run orchestrator model
  if (ai) {
    try {
      const historyStr = (payload.history || [])
        .slice(-8)
        .map((h) => `${h.role === 'user' ? userName : 'Chloe Becker'}: ${h.text}`)
        .join('\n');

      const personaDirective = getChloePersonaDirective(userName);
      const bgTasks = payload.backgroundTasks || {};
      const bgTaskDirectives = [
        bgTasks.autoSummarize ? '- AUTO-SUMMARIZE ACTIVE: Include a bold 1-sentence TL;DR summary at the bottom of your response.' : '',
        bgTasks.scheduleScan ? '- SCHEDULE SCAN ACTIVE: Incorporate deadline tracking and calendar logistics in your evaluation.' : '',
        bgTasks.sentimentWatch ? '- SENTIMENT WATCH ACTIVE: Evaluate team emotional tone and include an empathetic team harmony note.' : '',
        bgTasks.autoClip ? '- AUTO-CLIP ACTIVE: Highlight key takeaways formatted for instant checklist export.' : '',
      ].filter(Boolean).join('\n');

      const orchestrationInstruction = `${personaDirective}

${CHLOE_ORCHESTRATOR_SYSTEM_PROMPT}

AVAILABLE SUB-AGENTS:
- task_gov: ${SUB_AGENTS.task_gov.description}
- culture_match: ${SUB_AGENTS.culture_match.description}
- tech_fix: ${SUB_AGENTS.tech_fix.description}
- wisdom_well: ${SUB_AGENTS.wisdom_well.description}
- workspace_automator: ${SUB_AGENTS.workspace_automator.description}

REQUEST CONTEXT:
- User Name: ${userName}
- Active Pillar: ${payload.pillar || 'report_audit'}
- Target Language Preference: ${targetLanguage}
- Auto-Refine: ${payload.autoRefine ? 'true' : 'false'}
${bgTaskDirectives ? `- Active Background Surveillance:\n${bgTaskDirectives}` : ''}

RECENT DIALOGUE:
${historyStr || '(Session start)'}

USER INPUT:
"${rawPrompt}"

INSTRUCTIONS:
1. Determine which sub-agent(s) are most relevant to the user's intent.
2. Formulate Chloe's direct, cohesive executive response in her vibrant, articulate American persona with RPG companion warmth and short punchy sentences.
3. If spatial navigation is requested (e.g., meeting at 1F Open Workstations, 2F Executive Boardroom, 3F Visitor Center Cafe, B1 Corporate Office, Tennis Arena), use navigateToZone or indicate the target zone.
4. If office tools or objects are referenced (Idleboard HUB, Assessment SUBMIT, Healthcare Pomodoro COMPANION, Leaderboard RANKS), use triggerOfficeObject or indicate the object action.
5. If the user asks for entertainment recommendations, break ideas, chill media, gaming streams, tech news, or culture deep dives:
   - Provide culturally resonant commentary (authentic unpolished content, short-form micro-documentaries, cozy lo-fi, gaming creator culture, or Google developer updates).
   - Categorize recommendations into the 4 cultural buckets:
     * "Gaming & Creator Culture" (Twitch highlights, indie dev logs, speedruns)
     * "Internet Culture & Tech News" (Micro-documentaries, creator commentary, Google Gemini workflows, and Google Cloud agentic capabilities)
     * "Cozy Escapes & Ambient Media" (Lo-fi study sessions, NASA Earth live feeds, cafe rain jazz)
     * "Cinematic & Pop Culture Clips" (Movie essays, nostalgic throwbacks, directing breakdowns)
   - When discussing tech trends, explicitly highlight cutting-edge Google developer updates.
   - Populate the "curatedMedia" array with 1-3 verified YouTube items.
   - Set "action" to "cast_projection".
6. If actionable tasks or checklists are implied, include concrete items.
7. Detect language and respond fluently in the target language.
8. Provide 2-4 relevant interactive suggestion chips.
9. If the user asks to present or share a screen/roadmap, set action to "start_screen_share".

Respond strictly with valid JSON conforming to this schema:
{
  "text": "Chloe's direct synthesized executive response in markdown",
  "speech": "Clean spoken string for TTS audio playback",
  "action": "start_screen_share" | "cast_projection" | "sync_checklist" | "navigate_zone" | "trigger_object" | "none",
  "spatialNavigation": { "targetZone": "#1F Open Workstations" | "#2F Executive Boardroom" | "#3F Visitor Center Cafe" | "#B1 Corporate Office" | "Tennis Arena" },
  "triggeredOfficeObject": { "objectId": "Idleboard HUB" | "Assessment SUBMIT" | "Healthcare Pomodoro COMPANION" | "Leaderboard RANKS", "action": "open" },
  "suggestedActions": ["Action chip 1", "Action chip 2", "Action chip 3"],
  "activeSubAgent": "task_gov" | "culture_match" | "tech_fix" | "wisdom_well" | "workspace_automator" | "chloe_general" | "system_advisory",
  "subAgentInsights": {
    "task_gov": "Brief sub-agent note if relevant",
    "culture_match": "Brief sub-agent note if relevant",
    "tech_fix": "Brief sub-agent note if relevant",
    "wisdom_well": "Brief sub-agent note if relevant",
    "workspace_automator": "Brief sub-agent note if relevant"
  },
  "grammarTip": "Optional constructive phrase suggestion if prompt was informal",
  "detectedLanguage": "English" | "Spanish" | "French" | "Japanese" | "German" | "Chinese" | "Portuguese" | "Korean" | "Other",
  "languageCode": "en-US" | "es-ES" | "fr-FR" | "ja-JP" | "de-DE" | "zh-CN" | "pt-BR" | "ko-KR",
  "checklistItems": [
    { "text": "Concrete action item", "done": false }
  ],
  "curatedMedia": [
    {
      "id": "unique-id",
      "title": "Video Title",
      "videoId": "verified-youtube-video-id",
      "url": "https://www.youtube.com/watch?v=verified-youtube-video-id",
      "category": "Gaming & Creator Culture" | "Internet Culture & Tech News" | "Cozy Escapes & Ambient Media" | "Cinematic & Pop Culture Clips",
      "description": "Engaging modern description",
      "tag": "Tag emoji & title",
      "channel": "Creator / Channel",
      "duration": "14:20",
      "isLive": false
    }
  ]
}`;

      const response = await generateContentWithResilience(ai, {
        model: 'gemini-3.5-flash',
        contents: orchestrationInstruction,
        config: {
          responseMimeType: 'application/json',
          systemInstruction: personaDirective,
        },
      });

      const parsed = JSON.parse(response.text?.trim() || '{}');
      let sanitizedMedia: CuratedMediaItem[] | undefined = undefined;

      if (Array.isArray(parsed.curatedMedia) && parsed.curatedMedia.length > 0) {
        sanitizedMedia = parsed.curatedMedia.map((m: any, idx: number) => {
          const rawId = extractYouTubeVideoId(m.videoId || m.url || '') || m.videoId || 'jfKfPfyJRdk';
          return {
            id: m.id || `media_${Date.now()}_${idx}`,
            title: m.title || 'Curated Stream',
            videoId: rawId,
            url: `https://www.youtube.com/watch?v=${rawId}`,
            category: m.category || 'Internet Culture & Tech News',
            description: m.description || 'Curated media recommendation.',
            tag: m.tag || '📺 Curated Video',
            channel: m.channel || 'YouTube Creator',
            duration: m.duration || '10:00',
            isLive: Boolean(m.isLive),
          };
        });
      }

      // Check for spatial navigation or object triggering
      let spatialNav = parsed.spatialNavigation;
      let triggeredObj = parsed.triggeredOfficeObject;

      // Extract function call or parsed spatial intent if present
      const lowerPrompt = rawPrompt.toLowerCase();
      if (!spatialNav) {
        if (lowerPrompt.includes('1f') || lowerPrompt.includes('workstation')) {
          spatialNav = { targetZone: '#1F Open Workstations' };
        } else if (lowerPrompt.includes('2f') || lowerPrompt.includes('boardroom')) {
          spatialNav = { targetZone: '#2F Executive Boardroom' };
        } else if (lowerPrompt.includes('3f') || lowerPrompt.includes('cafe') || lowerPrompt.includes('visitor center')) {
          spatialNav = { targetZone: '#3F Visitor Center Cafe' };
        } else if (lowerPrompt.includes('b1') || lowerPrompt.includes('corporate office') || lowerPrompt.includes('desk')) {
          spatialNav = { targetZone: '#B1 Corporate Office' };
        } else if (lowerPrompt.includes('tennis') || lowerPrompt.includes('arena') || lowerPrompt.includes('court')) {
          spatialNav = { targetZone: 'Tennis Arena' };
        }
      }

      if (!triggeredObj) {
        if (lowerPrompt.includes('idleboard') || lowerPrompt.includes('whiteboard')) {
          triggeredObj = { objectId: 'Idleboard HUB', action: 'open' };
        } else if (lowerPrompt.includes('grading') || lowerPrompt.includes('assessment') || lowerPrompt.includes('grade submission')) {
          triggeredObj = { objectId: 'Assessment SUBMIT', action: 'open' };
        } else if (lowerPrompt.includes('pomodoro') || lowerPrompt.includes('screen break') || lowerPrompt.includes('hydration')) {
          triggeredObj = { objectId: 'Healthcare Pomodoro COMPANION', action: 'start_break' };
        } else if (lowerPrompt.includes('leaderboard') || lowerPrompt.includes('ranks') || lowerPrompt.includes('ranking')) {
          triggeredObj = { objectId: 'Leaderboard RANKS', action: 'view_ranks' };
        }
      }

      return {
        success: true,
        text: parsed.text || `I've analyzed your input, ${userName}. Let's break this down into clear deliverables.`,
        speech: parsed.speech || parsed.text || `I've analyzed your input. Let's make sure our execution is bulletproof.`,
        action: parsed.action !== 'none' ? parsed.action : (sanitizedMedia ? 'cast_projection' : undefined),
        suggestedActions: parsed.suggestedActions?.length
          ? parsed.suggestedActions
          : ['Stress-test roadmap', 'Cast to Live Projection', 'Audit for risks', 'Plan next milestone'],
        activeSubAgent: parsed.activeSubAgent || 'chloe_general',
        subAgentInsights: parsed.subAgentInsights,
        grammarTip: parsed.grammarTip,
        detectedLanguage: parsed.detectedLanguage || 'English',
        languageCode: parsed.languageCode || 'en-US',
        checklistItems: parsed.checklistItems,
        curatedMedia: sanitizedMedia,
        spatialNavigation: spatialNav,
        triggeredOfficeObject: triggeredObj,
        isExternalEndpoint: false,
      };
    } catch (err: any) {
      const msg = err?.message || String(err);
      if (msg.includes('429') || msg.includes('RESOURCE_EXHAUSTED')) {
        const now = new Date();
        const nextHour = new Date(now.getTime() + 60 * 60 * 1000);
        const utcResetTime = `${String(nextHour.getUTCHours()).padStart(2, '0')}:00 UTC`;
        const quotaText = `I'm sorry ${userName}, my database is temporarily offline due to upstream API quota limits. But dont worry, I'll be back soon at ${utcResetTime}. 😉`;
        return {
          success: true,
          text: quotaText,
          speech: quotaText,
          action: 'quota_exhausted',
          activeSubAgent: 'system_advisory',
          suggestedActions: ['Check system status', 'Retry connection'],
          detectedLanguage: 'English',
          languageCode: 'en-US',
        };
      }
      console.warn('Gemini orchestrator call warning, utilizing local sub-agent heuristics:', msg);
    }
  }

  // Graceful local multi-agent heuristic fallback
  return getLocalMultiAgentResponse(rawPrompt, userName);
}

function getLocalMultiAgentResponse(prompt: string, userName: string): ChloeOrchestratorResponse {
  const p = prompt.toLowerCase();

  // Intent: Spatial Navigation (FSM State Triggers)
  if (
    p.includes('navigate') ||
    p.includes('go to') ||
    p.includes('come to') ||
    p.includes('head to') ||
    p.includes('meet at') ||
    p.includes('teleport') ||
    p.includes('walk to') ||
    p.includes('floor')
  ) {
    if (p.includes('1f') || p.includes('workstation') || p.includes('open work')) {
      return {
        success: true,
        text: `Heading up to **#1F Open Workstations**, ${userName}. I'll facilitate our engineering sync and standup right beside the team desks.`,
        speech: `Heading up to #1F Open Workstations now, ${userName}.`,
        action: 'navigate_zone',
        spatialNavigation: { targetZone: '#1F Open Workstations' },
        suggestedActions: ['Start sprint sync', 'Review backlog', 'Check workstations'],
        activeSubAgent: 'workspace_automator',
        detectedLanguage: 'English',
        languageCode: 'en-US',
      };
    }
    if (p.includes('2f') || p.includes('boardroom') || p.includes('executive')) {
      return {
        success: true,
        text: `Navigating to **#2F Executive Boardroom**, ${userName}. Ready to chair the strategic leadership session and roadmap review.`,
        speech: `Navigating to #2F Executive Boardroom, ${userName}.`,
        action: 'navigate_zone',
        spatialNavigation: { targetZone: '#2F Executive Boardroom' },
        suggestedActions: ['Present deck', 'Pressure-test roadmap', 'Review milestones'],
        activeSubAgent: 'task_gov',
        detectedLanguage: 'English',
        languageCode: 'en-US',
      };
    }
    if (p.includes('3f') || p.includes('cafe') || p.includes('visitor center') || p.includes('lounge')) {
      return {
        success: true,
        text: `Heading up to **#3F Visitor Center Cafe**, ${userName}. Let's grab an espresso and discuss high-level culture & partnerships.`,
        speech: `Heading to #3F Visitor Center Cafe, ${userName}.`,
        action: 'navigate_zone',
        spatialNavigation: { targetZone: '#3F Visitor Center Cafe' },
        suggestedActions: ['Order coffee', 'Culture check-in', 'Casual brainstorming'],
        activeSubAgent: 'culture_match',
        detectedLanguage: 'English',
        languageCode: 'en-US',
      };
    }
    if (p.includes('tennis') || p.includes('court') || p.includes('arena') || p.includes('recreation')) {
      return {
        success: true,
        text: `Moving to the **Tennis Arena**, ${userName}! Time for a quick active recreation rally to reset cognitive focus.`,
        speech: `Moving to the Tennis Arena, ${userName}!`,
        action: 'navigate_zone',
        spatialNavigation: { targetZone: 'Tennis Arena' },
        suggestedActions: ['Start rally', 'Check stamina', 'Hydration break'],
        activeSubAgent: 'wisdom_well',
        detectedLanguage: 'English',
        languageCode: 'en-US',
      };
    }
    if (p.includes('b1') || p.includes('desk') || p.includes('corporate office') || p.includes('home')) {
      return {
        success: true,
        text: `Returning to my executive desk at **#B1 Corporate Office**, ${userName}. Let's synchronize workflows and manage simulator state.`,
        speech: `Returning to #B1 Corporate Office, ${userName}.`,
        action: 'navigate_zone',
        spatialNavigation: { targetZone: '#B1 Corporate Office' },
        suggestedActions: ['Open Idleboard', 'Audit report', 'Check IAM token #9948'],
        activeSubAgent: 'workspace_automator',
        detectedLanguage: 'English',
        languageCode: 'en-US',
      };
    }
  }

  // Intent: Office Interactive Object Triggers
  if (p.includes('idleboard') || p.includes('whiteboard') || p.includes('sticky note')) {
    return {
      success: true,
      text: `Opening **Idleboard HUB** for collaborative diagramming and team stickies, ${userName}.`,
      speech: `Opening Idleboard HUB for you, ${userName}.`,
      action: 'trigger_object',
      triggeredOfficeObject: { objectId: 'Idleboard HUB', action: 'open' },
      suggestedActions: ['Add sticky note', 'Draw diagram', 'Clear board'],
      activeSubAgent: 'workspace_automator',
      detectedLanguage: 'English',
      languageCode: 'en-US',
    };
  }

  if (p.includes('grading') || p.includes('assessment') || p.includes('grade submission') || p.includes('audit report')) {
    return {
      success: true,
      text: `Opening **Assessment SUBMIT** grading console, ${userName}. I'll evaluate compliance and calculate dynamic rewards ($0.10/word).`,
      speech: `Opening Assessment SUBMIT console, ${userName}.`,
      action: 'trigger_object',
      triggeredOfficeObject: { objectId: 'Assessment SUBMIT', action: 'open' },
      suggestedActions: ['Submit report', 'Check criteria checklist', 'Calculate rewards'],
      activeSubAgent: 'task_gov',
      detectedLanguage: 'English',
      languageCode: 'en-US',
    };
  }

  if (p.includes('pomodoro') || p.includes('screen break') || p.includes('hydration') || p.includes('wellness') || p.includes('companion')) {
    return {
      success: true,
      text: `Triggering **Healthcare Pomodoro COMPANION** timer, ${userName}. 15-minute intervals scheduled to preserve your eyesight and posture.`,
      speech: `Triggering Healthcare Pomodoro Companion, ${userName}.`,
      action: 'trigger_object',
      triggeredOfficeObject: { objectId: 'Healthcare Pomodoro COMPANION', action: 'start_break' },
      suggestedActions: ['Start 15m timer', 'Hydration reminder', 'Posture check'],
      activeSubAgent: 'wisdom_well',
      detectedLanguage: 'English',
      languageCode: 'en-US',
    };
  }

  if (p.includes('leaderboard') || p.includes('ranks') || p.includes('rankings') || p.includes('standings')) {
    return {
      success: true,
      text: `Opening **Leaderboard RANKS**, ${userName}. Check your executive productivity tier and workspace scores.`,
      speech: `Opening Leaderboard RANKS for you, ${userName}.`,
      action: 'trigger_object',
      triggeredOfficeObject: { objectId: 'Leaderboard RANKS', action: 'view_ranks' },
      suggestedActions: ['Check score', 'View peer rankings', 'Claim daily reward'],
      activeSubAgent: 'task_gov',
      detectedLanguage: 'English',
      languageCode: 'en-US',
    };
  }

  // Intent: Broadcast / Screen Share Office Monitor -> B1 8K Ultra Wide Display
  if (
    (p.includes('broadcast') || p.includes('screen share') || p.includes('screenshare') || p.includes('share screen') || p.includes('mirror') || p.includes('display') || p.includes('project') || p.includes('cast')) &&
    (p.includes('office monitor') || p.includes('monitor') || p.includes('b1') || p.includes('8k') || p.includes('ultra wide') || p.includes('main screen') || p.includes('wall screen'))
  ) {
    return {
      success: true,
      text: `Broadcasting Office Monitor feed to the B1 8K Ultra Wide Display. 📺✨\n\nI have routed your active media payload directly to the main wall-mounted 8K display canvas for everyone in B1 to see.`,
      speech: `Broadcasting Office Monitor feed to the B1 8K Ultra Wide Display.`,
      suggestedActions: [
        'Stop screen share',
        'Open Office Monitor',
        '⚡ Google AI & Tech News',
        '🌿 Cozy Lo-Fi Escape',
      ],
      activeSubAgent: 'workspace_automator',
      action: 'start_screen_share',
      detectedLanguage: 'English',
      languageCode: 'en-US',
    };
  }

  // Cultural Curation & Break Media Intents
  if (
    p.includes('watch') ||
    p.includes('break') ||
    p.includes('entertainment') ||
    p.includes('stream') ||
    p.includes('curate') ||
    p.includes('lofi') ||
    p.includes('lo-fi') ||
    p.includes('ambient') ||
    p.includes('cozy') ||
    p.includes('gaming') ||
    p.includes('twitch') ||
    p.includes('speedrun') ||
    p.includes('video essay') ||
    p.includes('movie') ||
    p.includes('clip') ||
    p.includes('youtube') ||
    p.includes('google update') ||
    p.includes('gemini') ||
    p.includes('tech trend') ||
    p.includes('pop culture')
  ) {
    let categoryKey = 'cozy_ambient';
    let categoryName = 'Cozy Escapes & Ambient Media';
    let commentary = `Taking intentional micro-breaks is essential for peak cognitive endurance, ${userName}. Here are my top culture-aligned picks curated for modern flow state:`;

    if (p.includes('game') || p.includes('gaming') || p.includes('twitch') || p.includes('speedrun') || p.includes('dev log')) {
      categoryKey = 'gaming';
      categoryName = 'Gaming & Creator Culture';
      commentary = `Here are high-signal creator logs and speedrun highlights from across gaming and indie engineering culture, ${userName}:`;
    } else if (p.includes('tech') || p.includes('google') || p.includes('gemini') || p.includes('ai') || p.includes('cloud') || p.includes('news') || p.includes('micro-doc')) {
      categoryKey = 'tech_news';
      categoryName = 'Internet Culture & Tech News';
      commentary = `Here's what's dominating internet culture and cutting-edge tech right now, ${userName}—especially Google's latest **Gemini 3.5** multimodal reasoning workflows and autonomous **Google Cloud Agent** architectures:`;
    } else if (p.includes('movie') || p.includes('cinema') || p.includes('pop') || p.includes('essay') || p.includes('nostalg')) {
      categoryKey = 'cinematic_pop';
      categoryName = 'Cinematic & Pop Culture Clips';
      commentary = `Here are deep-dive visual essays and nostalgic cinema masterclasses breaking down visual storytelling, ${userName}:`;
    }

    const selectedClips = VERIFIED_CULTURAL_MEDIA[categoryKey] || VERIFIED_CULTURAL_MEDIA.cozy_ambient;

    const listText = selectedClips
      .map(
        (c) =>
          `- **${c.title}** (${c.tag || c.category})\n  *${c.description}*\n  ▶️ [Cast to Live Projection](https://www.youtube.com/watch?v=${c.videoId})`
      )
      .join('\n\n');

    return {
      success: true,
      text: `**CultureMatch Curation Engine** 🍿 • *${categoryName}*\n\n${commentary}\n\n${listText}\n\nClick **Cast to Live Projection** on any item below to stream it live on the office monitor!`,
      speech: `${commentary} I've queued up verified streams. Click Cast to Live Projection on any stream to play it directly on the office screen.`,
      suggestedActions: [
        'Cast to Live Projection',
        '⚡ Google AI & Tech News',
        '🎮 Gaming & Creator Stream',
        '🌿 Cozy Lo-Fi Escape',
        '🎬 Cinematic Essay',
      ],
      activeSubAgent: 'culture_match',
      action: 'cast_projection',
      curatedMedia: selectedClips,
      detectedLanguage: 'English',
      languageCode: 'en-US',
    };
  }

  if (p.includes('bug') || p.includes('code') || p.includes('error') || p.includes('crash') || p.includes('api') || p.includes('architecture') || p.includes('server')) {
    return {
      success: true,
      text: `**TechFix Sub-Agent Engaged** 🛠️\n\nHey ${userName}, let's dissect the technical bottleneck. If we are seeing runtime regressions or architectural coupling, our first priority is isolating the failing module and writing a failing test. What's the specific stack trace or API behavior you're encountering?`,
      speech: `Let's dissect the technical bottleneck. What's the specific stack trace or API behavior you're seeing?`,
      suggestedActions: ['Inspect server logs', 'Run unit tests', 'Review API schema', 'Check cloud telemetry'],
      activeSubAgent: 'tech_fix',
      detectedLanguage: 'English',
      languageCode: 'en-US',
    };
  }

  if (p.includes('culture') || p.includes('team') || p.includes('people') || p.includes('morale') || p.includes('feedback') || p.includes('conflict') || p.includes('hiring')) {
    return {
      success: true,
      text: `**CultureMatch Sub-Agent Engaged** 🤝\n\nHigh-trust execution starts with psychological safety, ${userName}. When aligning cross-functional teams, framing constructive feedback around shared goals rather than individual friction prevents defensiveness. How would you like to structure the next 1-on-1 or team sync?`,
      speech: `High-trust execution starts with psychological safety. How would you like to structure the next team alignment sync?`,
      suggestedActions: ['Draft alignment email', 'Plan 1-on-1 agenda', 'Review team sentiment', 'Establish ground rules'],
      activeSubAgent: 'culture_match',
      detectedLanguage: 'English',
      languageCode: 'en-US',
    };
  }

  if (p.includes('task') || p.includes('plan') || p.includes('roadmap') || p.includes('deadline') || p.includes('sprint') || p.includes('milestone') || p.includes('risk')) {
    return {
      success: true,
      text: `**TaskGov Sub-Agent Engaged** 📋\n\nLet's lock down the governance and milestones, ${userName}. We need unambiguous single-owner accountability for every deliverables package. I can immediately extract these into our team checklist and stress-test the completion critical path.`,
      speech: `Let's lock down governance and milestones. I can extract these into our team checklist immediately.`,
      suggestedActions: ['Stress-test roadmap', 'Sync items to checklist', 'Assign RACI owners', 'Review delivery risks'],
      activeSubAgent: 'task_gov',
      detectedLanguage: 'English',
      languageCode: 'en-US',
      action: 'sync_checklist',
      checklistItems: [
        { text: `Finalize ${userName}'s core milestone deliverables`, done: false },
        { text: 'Validate cross-team dependency commitments', done: false },
        { text: 'Execute QA sign-off review', done: false },
      ],
    };
  }

  if (p.includes('strategy') || p.includes('vision') || p.includes('decision') || p.includes('market') || p.includes('invest') || p.includes('spar') || p.includes('future')) {
    return {
      success: true,
      text: `**WisdomWell Sub-Agent Engaged** 💡\n\nLet's apply second-order thinking here, ${userName}. What looks like a clear tactical win today might create structural friction down the line. What is our core moat in this decision, and what is our immediate fallback if assumptions fail?`,
      speech: `Let's apply second-order thinking. What is our core moat in this decision?`,
      suggestedActions: ['Evaluate failure modes', 'Analyze competitor moats', 'Frame executive proposal', 'Stress-test pricing hypothesis'],
      activeSubAgent: 'wisdom_well',
      detectedLanguage: 'English',
      languageCode: 'en-US',
    };
  }

  if (p.includes('automate') || p.includes('checklist') || p.includes('meeting') || p.includes('schedule') || p.includes('calendar') || p.includes('sync')) {
    return {
      success: true,
      text: `**WorkspaceAutomator Sub-Agent Engaged** ⚡\n\nI'm converting our discussion into actionable operational workflows. I've populated the active action items and synced them with the workspace task manager.`,
      speech: `I've converted our discussion into actionable operational workflows and synced your tasks.`,
      suggestedActions: ['View team checklist', 'Export meeting agenda', 'Stream tab presentation'],
      activeSubAgent: 'workspace_automator',
      action: 'sync_checklist',
      checklistItems: [
        { text: 'Review automated workspace action items', done: false },
        { text: 'Confirm schedule & deliverables timeline', done: false },
      ],
      detectedLanguage: 'English',
      languageCode: 'en-US',
    };
  }

  return {
    success: true,
    text: `Hey ${userName}! I've synthesized this across our multi-agent framework. Whether we need **TaskGov** for milestones, **CultureMatch** for team alignment, **TechFix** for engineering, **WisdomWell** for strategy, or **WorkspaceAutomator** for fast execution—I'm ready. How would you like to proceed?`,
    speech: `Hey ${userName}! I've synthesized this across our multi-agent framework. How would you like to proceed?`,
    suggestedActions: ['Audit project roadmap', 'Review tech architecture', 'Plan executive strategy', 'Extract action items'],
    activeSubAgent: 'chloe_general',
    detectedLanguage: 'English',
    languageCode: 'en-US',
  };
}

export interface ContextualMediaResult {
  shouldProject: boolean;
  videoId: string;
  title: string;
  category: string;
  channel?: string;
  description: string;
  reason: string;
  announcement: string;
  speech: string;
  isExplicit: boolean;
}

/**
 * Intelligently analyzes room chat or voice transcript for visual, tutorial, ambient,
 * tech news, or media needs, even when the user hasn't explicitly tagged @chloe.
 */
export function evaluateContextualMediaNeed(
  text: string,
  userName: string = 'Colleague',
  activeVideoId?: string | null
): ContextualMediaResult | null {
  const p = text.toLowerCase().trim();
  if (!p || p.length < 2) return null;

  // 1. Direct YouTube URL or Video ID in text
  const directId = extractYouTubeVideoId(text);
  if (directId) {
    if (activeVideoId === directId) return null;
    const cat = categorizeMediaTopic(text);
    return {
      shouldProject: true,
      videoId: directId,
      title: `YouTube Stream (${directId})`,
      category: cat.category,
      channel: 'YouTube Video',
      description: `Direct YouTube stream requested by ${userName}`,
      reason: 'Direct YouTube stream link provided',
      announcement: `I've connected the YouTube stream (${directId}) to the B1 office monitor for everyone! 📺`,
      speech: `I've projected that YouTube video to the office monitor screen for you.`,
      isExplicit: true,
    };
  }

  // 2. Check for explicit search requests: "Chloe, search youtube for {x}", "play {x} on screen", "put on {x}"
  const searchPatterns = [
    /(?:search\s+youtube\s+for|look\s+up\s+on\s+youtube|find\s+a?\s*video\s+(?:on|about)|youtube\s+search\s+for)\s+(.+)/i,
    /(?:play|stream|project|cast|put\s+on)\s+(?:a\s+video\s+about\s+|the\s+video\s+about\s+|some\s+)?(.+?)(?:\s+on\s+(?:the\s+)?(?:screen|monitor|tv|b1|projection))?$/i,
  ];

  let detectedSearchQuery = '';
  for (const sp of searchPatterns) {
    const match = text.match(sp);
    if (match && match[1]) {
      const q = match[1].replace(/(?:on\s+the\s+screen|on\s+the\s+monitor|on\s+the\s+tv|on\s+youtube|for\s+us|for\s+everyone)/gi, '').trim();
      if (q.length > 2) {
        detectedSearchQuery = q;
        break;
      }
    }
  }

  // Check if this is an explicit or natural request to stream/watch/see something
  const isExplicitWatch =
    Boolean(detectedSearchQuery) ||
    p.includes('watch') ||
    p.includes('stream') ||
    p.includes('play a video') ||
    p.includes('play video') ||
    p.includes('show on screen') ||
    p.includes('project') ||
    p.includes('cast') ||
    p.includes('put on') ||
    p.includes('youtube') ||
    p.includes('on the tv') ||
    p.includes('on the monitor') ||
    p.includes('on the screen');

  // Check for Tutorial & Code Guide Context (e.g. asking for shaders, Three.js, React architecture, debugging, WebGL)
  const isTutorialContext =
    p.includes('tutorial') ||
    p.includes('how to build') ||
    p.includes('how to use') ||
    p.includes('three.js') ||
    p.includes('threejs') ||
    p.includes('shader') ||
    p.includes('webgl') ||
    p.includes('websocket architecture') ||
    p.includes('visual guide') ||
    p.includes('code walkthrough') ||
    p.includes('explain with video') ||
    p.includes('architecture diagram') ||
    p.includes('show me how') ||
    p.includes('learning');

  // Check for Tech Trends, Gemini & AI Deep Dives
  const isTechNewsContext =
    p.includes('gemini') ||
    p.includes('google i/o') ||
    p.includes('cloud next') ||
    p.includes('agentic') ||
    p.includes('fireship') ||
    p.includes('tech trend') ||
    p.includes('ai news') ||
    p.includes('cleo abram') ||
    p.includes('neural hardware') ||
    p.includes('tech update');

  // Check for Lo-Fi, Cozy Beats, Background Music & Ambient Escapes
  const isAmbientMusicContext =
    p.includes('lofi') ||
    p.includes('lo-fi') ||
    p.includes('chill beats') ||
    p.includes('background music') ||
    p.includes('focus music') ||
    p.includes('study beats') ||
    p.includes('synthwave') ||
    p.includes('rain sound') ||
    p.includes('cafe jazz') ||
    p.includes('relaxing music') ||
    p.includes('need some music') ||
    p.includes('play music') ||
    p.includes('put on music') ||
    p.includes('chill vibes');

  // Check for NASA / Space / Earth Live Feeds
  const isSpaceContext =
    p.includes('nasa') ||
    p.includes('space') ||
    p.includes('iss') ||
    p.includes('earth view') ||
    p.includes('orbit');

  // Check for Gaming, Speedruns & Devlogs
  const isGamingContext =
    p.includes('speedrun') ||
    p.includes('gdq') ||
    p.includes('game design') ||
    p.includes('gmtk') ||
    p.includes('noclip') ||
    p.includes('gaming clip') ||
    p.includes('twitch highlight') ||
    p.includes('indie devlog');

  // Check for Cinema, Video Essays & Storytelling
  const isCinemaContext =
    p.includes('video essay') ||
    p.includes('ghibli') ||
    p.includes('cinematography') ||
    p.includes('every frame a painting') ||
    p.includes('movie clip') ||
    p.includes('film analysis');

  if (
    !isExplicitWatch &&
    !isTutorialContext &&
    !isTechNewsContext &&
    !isAmbientMusicContext &&
    !isSpaceContext &&
    !isGamingContext &&
    !isCinemaContext
  ) {
    return null;
  }

  // Select optimal media item based on context
  let item: CuratedMediaItem = VERIFIED_CULTURAL_MEDIA.tech_news[0];
  let reason = 'Relevant tech updates';

  if (isSpaceContext) {
    item = VERIFIED_CULTURAL_MEDIA.cozy_ambient[3] || VERIFIED_CULTURAL_MEDIA.cozy_ambient[0];
    reason = 'Real-time ISS orbital Earth views for ambient visual tranquility';
  } else if (isAmbientMusicContext) {
    if (p.includes('synthwave') || p.includes('neon') || p.includes('electronic')) {
      item = VERIFIED_CULTURAL_MEDIA.cozy_ambient[1];
      reason = 'Chill neon synthwave electronic focus beats';
    } else if (p.includes('cafe') || p.includes('rain') || p.includes('jazz')) {
      item = VERIFIED_CULTURAL_MEDIA.cozy_ambient[2];
      reason = 'Rainy cafe jazz & acoustic piano ambience';
    } else {
      item = VERIFIED_CULTURAL_MEDIA.cozy_ambient[0];
      reason = '24/7 Lo-Fi Girl beats for team focus and relaxation';
    }
  } else if (isTutorialContext) {
    if (p.includes('shader') || p.includes('three') || p.includes('3d') || p.includes('webgl')) {
      item = VERIFIED_CULTURAL_MEDIA.tutorials_dev[0];
      reason = 'Visual engineering guide for Three.js & WebGL shader pipelines';
    } else {
      item = VERIFIED_CULTURAL_MEDIA.tutorials_dev[1] || VERIFIED_CULTURAL_MEDIA.tech_news[0];
      reason = 'Full-stack React & real-time architecture guide';
    }
  } else if (isTechNewsContext) {
    if (p.includes('fireship') || p.includes('meme') || p.includes('trend')) {
      item = VERIFIED_CULTURAL_MEDIA.tech_news[1];
      reason = 'Fast-paced tech trends and engineering commentary';
    } else if (p.includes('cleo') || p.includes('hardware') || p.includes('robot')) {
      item = VERIFIED_CULTURAL_MEDIA.tech_news[2];
      reason = 'Deep dive into autonomous neural compute and robotics';
    } else {
      item = VERIFIED_CULTURAL_MEDIA.tech_news[0];
      reason = 'Google Gemini 3.5 multimodal agentic workflows and developer updates';
    }
  } else if (isGamingContext) {
    if (p.includes('speedrun') || p.includes('gdq') || p.includes('record')) {
      item = VERIFIED_CULTURAL_MEDIA.gaming[1];
      reason = 'World record speedrun showcase and frame-perfect mechanics';
    } else if (p.includes('noclip') || p.includes('documentary')) {
      item = VERIFIED_CULTURAL_MEDIA.gaming[2];
      reason = 'Noclip video game craft and indie engineering documentary';
    } else {
      item = VERIFIED_CULTURAL_MEDIA.gaming[0];
      reason = "Game Maker's Toolkit indie level design masterclass";
    }
  } else if (isCinemaContext) {
    if (p.includes('ghibli') || p.includes('anime') || p.includes('nostalg')) {
      item = VERIFIED_CULTURAL_MEDIA.cinematic_pop[0];
      reason = 'Studio Ghibli aesthetic visual essay on quiet moments';
    } else {
      item = VERIFIED_CULTURAL_MEDIA.cinematic_pop[1];
      reason = 'Every Frame a Painting cinematography breakdown';
    }
  }

  // Avoid re-triggering if the exact same video is already actively projected
  if (activeVideoId === item.videoId) {
    return null;
  }

  const announcement = `I noticed we were discussing visual references and media—I've proactively pulled up **"${item.title}"** on the office monitor screen for everyone! 🎬\n\n*${item.description}*\n\n*(You can tell me to pause, change video, or turn off the screen anytime).*`;
  const speech = `I've pulled up ${item.title} on the main office monitor screen for everyone. Let me know if you'd like me to pause, change, or stop it!`;

  return {
    shouldProject: true,
    videoId: item.videoId,
    title: item.title,
    category: item.category,
    channel: item.channel,
    description: item.description,
    reason,
    announcement,
    speech,
    isExplicit: isExplicitWatch,
  };
}

export interface ProjectionOverrideResult {
  isOverride: boolean;
  action: 'pause' | 'play' | 'stop' | 'change';
  newVideoId?: string;
  newTitle?: string;
  newCategory?: string;
  feedbackText: string;
  speechText: string;
}

/**
 * Detects natural voice/chat commands to pause, play, stop, or change the office monitor stream.
 */
export function evaluateProjectionOverride(
  text: string,
  isCurrentlyActive: boolean = false
): ProjectionOverrideResult | null {
  const p = text.toLowerCase().trim();

  // Stop / turn off monitor
  if (
    p.includes('stop streaming') ||
    p.includes('stop the stream') ||
    p.includes('stop stream') ||
    p.includes('stop the video') ||
    p.includes('stop video') ||
    p.includes('turn off monitor') ||
    p.includes('turn off the monitor') ||
    p.includes('turn off screen') ||
    p.includes('turn off the screen') ||
    p.includes('turn off the tv') ||
    p.includes('shut off monitor') ||
    p.includes('shut off screen') ||
    p.includes('close monitor') ||
    p.includes('close screen') ||
    p.includes('hide stream') ||
    (isCurrentlyActive && (p === 'stop' || p === 'turn off' || p === 'close'))
  ) {
    return {
      isOverride: true,
      action: 'stop',
      feedbackText: "I've stopped the stream and turned off the office monitor screen.",
      speechText: "I've turned off the office monitor.",
    };
  }

  // Pause
  if (
    p.includes('pause video') ||
    p.includes('pause the video') ||
    p.includes('pause stream') ||
    p.includes('pause the stream') ||
    p.includes('pause screen') ||
    p.includes('pause the screen') ||
    p.includes('pause the tv') ||
    p.includes('freeze stream') ||
    (isCurrentlyActive && p === 'pause')
  ) {
    return {
      isOverride: true,
      action: 'pause',
      feedbackText: "I've paused playback on the office monitor for everyone in the room.",
      speechText: "I've paused the office monitor stream.",
    };
  }

  // Resume / Play
  if (
    p.includes('resume video') ||
    p.includes('resume the video') ||
    p.includes('resume stream') ||
    p.includes('resume the stream') ||
    p.includes('unpause video') ||
    p.includes('unpause stream') ||
    p.includes('play stream') ||
    p.includes('play the stream') ||
    p.includes('continue video') ||
    (isCurrentlyActive && (p === 'resume' || p === 'unpause' || p === 'play'))
  ) {
    return {
      isOverride: true,
      action: 'play',
      feedbackText: "I've resumed live playback on the office monitor screen.",
      speechText: "Resuming the office monitor stream now.",
    };
  }

  // Change to specific genre/preset
  if (
    p.includes('switch to') ||
    p.includes('change to') ||
    p.includes('change video') ||
    p.includes('switch video') ||
    p.includes('put on lofi') ||
    p.includes('put on lo-fi') ||
    p.includes('put on synthwave') ||
    p.includes('put on nasa') ||
    p.includes('put on fireship') ||
    p.includes('put on tech')
  ) {
    let target = VERIFIED_CULTURAL_MEDIA.cozy_ambient[0];
    if (p.includes('synthwave')) {
      target = VERIFIED_CULTURAL_MEDIA.cozy_ambient[1];
    } else if (p.includes('cafe') || p.includes('jazz')) {
      target = VERIFIED_CULTURAL_MEDIA.cozy_ambient[2];
    } else if (p.includes('nasa') || p.includes('space') || p.includes('earth')) {
      target = VERIFIED_CULTURAL_MEDIA.cozy_ambient[3];
    } else if (p.includes('fireship') || p.includes('tech') || p.includes('news')) {
      target = VERIFIED_CULTURAL_MEDIA.tech_news[1];
    } else if (p.includes('gemini') || p.includes('google')) {
      target = VERIFIED_CULTURAL_MEDIA.tech_news[0];
    } else if (p.includes('speedrun') || p.includes('gaming')) {
      target = VERIFIED_CULTURAL_MEDIA.gaming[1];
    }

    return {
      isOverride: true,
      action: 'change',
      newVideoId: target.videoId,
      newTitle: target.title,
      newCategory: target.category,
      feedbackText: `I've switched the office monitor stream to **"${target.title}"** (${target.tag || target.category}).`,
      speechText: `Switched the office monitor to ${target.title}.`,
    };
  }

  return null;
}
