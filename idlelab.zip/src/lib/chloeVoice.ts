// High-Fidelity Text-to-Speech Synthesizer for Chloe Becker
// Powered by ElevenLabs Neural TTS with graceful Web Speech API fallback

export interface ElevenLabsVoiceSettings {
  stability: number;
  similarity_boost: number;
}

export interface ElevenLabsConfig {
  voice_id: string;
  model_id: string;
  voice_settings: ElevenLabsVoiceSettings;
}

export const ELEVENLABS_CONFIG: ElevenLabsConfig = {
  // Use 'EXAVITQu4vr4xnSDxMaL' (Bella - Soft, American, Young Female)
  voice_id: 'EXAVITQu4vr4xnSDxMaL',
  model_id: 'eleven_multilingual_v2',
  voice_settings: {
    stability: 0.5,
    similarity_boost: 0.75,
  },
};

/**
 * Securely retrieves the ElevenLabs API key from environment variables without hardcoding.
 */
export function getElevenLabsApiKey(): string {
  let key = '';

  try {
    if (typeof import.meta !== 'undefined' && import.meta.env?.VITE_ELEVENLABS_API_KEY) {
      key = import.meta.env.VITE_ELEVENLABS_API_KEY;
    }
  } catch {}

  if (!key) {
    try {
      if (typeof process !== 'undefined') {
        if (process.env?.VITE_ELEVENLABS_API_KEY) {
          key = process.env.VITE_ELEVENLABS_API_KEY;
        } else if (process.env?.ELEVENLABS_API_KEY) {
          key = process.env.ELEVENLABS_API_KEY;
        }
      }
    } catch {}
  }

  if (typeof key === 'string') {
    key = key.replace(/^["']|["']$/g, '').trim();
  }

  return key;
}

class ChloeVoiceEngine {
  private currentUtterance: SpeechSynthesisUtterance | null = null;
  private currentAudio: HTMLAudioElement | null = null;
  private abortController: AbortController | null = null;
  private isSpeaking: boolean = false;
  private activeTextId: string | null = null;
  private listeners: Set<(speaking: boolean, activeId: string | null) => void> = new Set();
  private keepAliveInterval: any = null;
  private lastSpokenText: string = '';
  private lastSpokenTime: number = 0;
  private config: ElevenLabsConfig = { ...ELEVENLABS_CONFIG };

  constructor() {
    if (typeof window !== 'undefined' && window.speechSynthesis) {
      // Warm up browser speech voices
      if (window.speechSynthesis.onvoiceschanged !== undefined) {
        window.speechSynthesis.onvoiceschanged = () => {};
      }
    }
  }

  public subscribe(fn: (speaking: boolean, activeId: string | null) => void): () => void {
    this.listeners.add(fn);
    return () => this.listeners.delete(fn);
  }

  private notify(speaking: boolean, activeId: string | null = null) {
    this.isSpeaking = speaking;
    this.activeTextId = activeId;
    this.listeners.forEach((fn) => {
      try {
        fn(speaking, activeId);
      } catch (e) {
        console.error('Chloe voice listener error:', e);
      }
    });
  }

  public getConfig(): ElevenLabsConfig {
    return { ...this.config };
  }

  public updateConfig(newConfig: Partial<ElevenLabsConfig>) {
    this.config = {
      ...this.config,
      ...newConfig,
      voice_settings: {
        ...this.config.voice_settings,
        ...(newConfig.voice_settings || {}),
      },
    };
  }

  public getVoices(): SpeechSynthesisVoice[] {
    if (typeof window === 'undefined' || !window.speechSynthesis) return [];
    return window.speechSynthesis.getVoices() || [];
  }

  public getChloeVoice(): SpeechSynthesisVoice | null {
    const voices = this.getVoices();
    if (!voices || voices.length === 0) return null;

    // Filter out any British / UK / Australian / non-US accents explicitly
    const isBritishOrNonUS = (v: SpeechSynthesisVoice) => {
      const name = v.name.toLowerCase();
      const lang = v.lang.toLowerCase();
      return (
        lang.includes('gb') ||
        lang.includes('uk') ||
        lang.includes('au') ||
        lang.includes('in') ||
        name.includes('british') ||
        name.includes('united kingdom') ||
        name.includes('english (uk)') ||
        name.includes('english (great britain)') ||
        name.includes('daniel') ||
        name.includes('oliver') ||
        name.includes('george')
      );
    };

    // Candidate pool: Strictly US English
    const usVoices = voices.filter(
      (v) => (v.lang.toLowerCase().startsWith('en-us') || v.lang.toLowerCase() === 'en_us') && !isBritishOrNonUS(v)
    );

    // Prioritized list of high-quality, natural American female voices
    const livelyAmericanGirlNames = [
      'aria online (natural)', // Edge Premium Natural
      'jenny online (natural)', // Edge Premium Natural
      'google us english', // Chrome OS / Android standard
      'samantha', // macOS high quality
      'ava',
      'allison',
      'victoria',
      'aria',
      'zira',
      'stephanie',
    ];

    for (const targetName of livelyAmericanGirlNames) {
      const match = usVoices.find((v) => v.name.toLowerCase().includes(targetName));
      if (match) return match;
    }

    // Any female-indicated US voice
    const anyFemaleUS = usVoices.find((v) => v.name.toLowerCase().includes('female'));
    if (anyFemaleUS) return anyFemaleUS;

    // Any US English voice
    if (usVoices.length > 0) return usVoices[0];

    // Fallback: any non-British English voice
    const nonBritishEn = voices.find(
      (v) => v.lang.toLowerCase().startsWith('en') && !isBritishOrNonUS(v)
    );
    if (nonBritishEn) return nonBritishEn;

    return voices[0] || null;
  }

  private startKeepAlive() {
    this.stopKeepAlive();
    this.keepAliveInterval = setInterval(() => {
      if (typeof window !== 'undefined' && window.speechSynthesis && this.isSpeaking) {
        window.speechSynthesis.pause();
        window.speechSynthesis.resume();
      }
    }, 8000);
  }

  private stopKeepAlive() {
    if (this.keepAliveInterval) {
      clearInterval(this.keepAliveInterval);
      this.keepAliveInterval = null;
    }
  }

  /**
   * Synthesizes and speaks text using ElevenLabs Neural TTS, with automatic Web Speech fallback.
   */
  public speak(
    text: string,
    id: string = 'global',
    onEnd?: () => void,
    onError?: () => void
  ): boolean {
    if (typeof window === 'undefined') return false;

    // If already speaking this exact ID, toggle off
    if (this.isSpeaking && this.activeTextId === id) {
      this.stop();
      return false;
    }

    // Cancel any ongoing speech to prevent overlapping voices
    this.stop();

    // Clean text of markdown, asterisks, hash tags, html tags, and URLs
    const cleanText = text
      .replace(/<[^>]*>/g, '')
      .replace(/[*_#`~[\]()]/g, ' ')
      .replace(/https?:\/\/\S+/g, '')
      .replace(/\s+/g, ' ')
      .trim();

    if (!cleanText) return false;

    // Prevent duplicate rapid speech triggers within 1200ms
    const now = Date.now();
    if (this.lastSpokenText === cleanText && now - this.lastSpokenTime < 1200) {
      return false;
    }
    this.lastSpokenText = cleanText;
    this.lastSpokenTime = now;

    const apiKey = getElevenLabsApiKey();

    if (apiKey) {
      // Execute ElevenLabs Neural TTS synthesis
      this.synthesizeElevenLabs(cleanText, id, apiKey, onEnd, onError);
      return true;
    }

    // Fallback to browser Web Speech API when no ElevenLabs API key is configured
    return this.speakWebSpeech(cleanText, id, onEnd, onError);
  }

  /**
   * Calls ElevenLabs TTS API directly with the configured voice settings
   */
  private async synthesizeElevenLabs(
    cleanText: string,
    id: string,
    apiKey: string,
    onEnd?: () => void,
    onError?: () => void,
    isRetryWithDefault: boolean = false
  ) {
    try {
      this.abortController = new AbortController();
      const signal = this.abortController.signal;

      this.notify(true, id);

      const voiceIdToUse = this.config.voice_id || 'EXAVITQu4vr4xnSDxMaL';
      const endpoint = `https://api.elevenlabs.io/v1/text-to-speech/${voiceIdToUse}`;
      const payload = {
        text: cleanText,
        model_id: this.config.model_id || 'eleven_multilingual_v2',
        voice_settings: {
          stability: this.config.voice_settings.stability,
          similarity_boost: this.config.voice_settings.similarity_boost,
        },
      };

      const response = await fetch(endpoint, {
        method: 'POST',
        headers: {
          'xi-api-key': apiKey,
          'Content-Type': 'application/json',
          'Accept': 'audio/mpeg',
        },
        body: JSON.stringify(payload),
        signal,
      });

      if (!response.ok) {
        let errorDetail = '';
        try {
          errorDetail = await response.text();
        } catch {
          errorDetail = response.statusText;
        }

        // If library voice requires paid plan (402) and not using Bella yet, retry with Bella once
        if (
          !isRetryWithDefault &&
          (response.status === 402 || errorDetail.includes('paid_plan_required')) &&
          this.config.voice_id !== 'EXAVITQu4vr4xnSDxMaL'
        ) {
          console.warn('[ElevenLabs TTS] Library voice restricted on free tier, switching to default premade Bella voice...');
          this.config.voice_id = 'EXAVITQu4vr4xnSDxMaL';
          return this.synthesizeElevenLabs(cleanText, id, apiKey, onEnd, onError, true);
        }

        console.warn(
          `[ElevenLabs TTS] API returned HTTP ${response.status} (${response.statusText}). Engaging seamless Web Speech synthesizer fallback.`
        );

        // Fallback gracefully to Web Speech API so voice never breaks
        this.notify(false, null);
        return this.speakWebSpeech(cleanText, id, onEnd, onError);
      }

      const audioBlob = await response.blob();
      const mpegBlob = new Blob([audioBlob], { type: 'audio/mpeg' });
      const audioUrl = URL.createObjectURL(mpegBlob);
      const audio = new Audio(audioUrl);
      this.currentAudio = audio;

      audio.onended = () => {
        URL.revokeObjectURL(audioUrl);
        if (this.currentAudio === audio) {
          this.currentAudio = null;
        }
        this.notify(false, null);
        if (onEnd) onEnd();
      };

      audio.onerror = (e) => {
        URL.revokeObjectURL(audioUrl);
        if (this.currentAudio === audio) {
          this.currentAudio = null;
        }
        console.warn('[ElevenLabs TTS] Audio element playback error, falling back to Web Speech:', e);
        this.notify(false, null);
        this.speakWebSpeech(cleanText, id, onEnd, onError);
      };

      await audio.play();
    } catch (err: any) {
      if (err?.name === 'AbortError') {
        // Speech was intentionally stopped
        return;
      }
      console.warn('[ElevenLabs TTS] Synthesis exception, seamlessly engaging Web Speech fallback:', err?.message || err);
      this.notify(false, null);
      this.speakWebSpeech(cleanText, id, onEnd, onError);
    }
  }

  /**
   * Web Speech API fallback mechanism
   */
  private speakWebSpeech(
    cleanText: string,
    id: string,
    onEnd?: () => void,
    onError?: () => void
  ): boolean {
    if (typeof window === 'undefined' || !window.speechSynthesis) {
      console.warn('Speech synthesis not supported in this environment');
      this.notify(false, null);
      if (onError) onError();
      return false;
    }

    try {
      if (window.speechSynthesis.paused) {
        window.speechSynthesis.resume();
      }

      const utterance = new SpeechSynthesisUtterance(cleanText);
      const voice = this.getChloeVoice();
      if (voice) {
        utterance.voice = voice;
      }
      utterance.rate = 1.0; // Natural pacing
      utterance.pitch = 1.0; // Slightly elevated but natural female pitch
      utterance.volume = 1.0;
      utterance.lang = 'en-US';

      utterance.onstart = () => {
        this.notify(true, id);
        this.startKeepAlive();
      };

      utterance.onend = () => {
        this.stopKeepAlive();
        this.notify(false, null);
        this.currentUtterance = null;
        if (onEnd) onEnd();
      };

      utterance.onerror = (e) => {
        this.stopKeepAlive();
        if (e.error !== 'canceled' && e.error !== 'interrupted') {
          console.warn('Chloe Web Speech error:', e);
        }
        this.notify(false, null);
        this.currentUtterance = null;
        if (onError) onError();
      };

      this.currentUtterance = utterance;
      window.speechSynthesis.speak(utterance);
      return true;
    } catch (err) {
      console.error('Speech synthesis failure:', err);
      this.stopKeepAlive();
      this.notify(false, null);
      if (onError) onError();
      return false;
    }
  }

  public stop() {
    this.stopKeepAlive();

    // Abort in-flight ElevenLabs network request
    if (this.abortController) {
      this.abortController.abort();
      this.abortController = null;
    }

    // Stop active HTML Audio playback
    if (this.currentAudio) {
      try {
        this.currentAudio.pause();
        this.currentAudio.currentTime = 0;
      } catch {}
      this.currentAudio = null;
    }

    // Stop Web Speech utterance
    if (typeof window !== 'undefined' && window.speechSynthesis) {
      window.speechSynthesis.cancel();
    }

    this.currentUtterance = null;
    this.notify(false, null);
  }

  public getIsSpeaking(): boolean {
    return this.isSpeaking;
  }

  public getActiveId(): string | null {
    return this.activeTextId;
  }
}

export const chloeVoice = new ChloeVoiceEngine();


