const fs = require('fs');
let code = fs.readFileSync('src/components/OfficeCanvas.tsx', 'utf8');

// Apply fast A/D movement on tennis court
const oldSpeedLogic = `          const riding = isRidingScooterRef.current;
          const baseSpeed = riding ? (keys['ShiftLeft'] || keys['ShiftRight'] ? 12.0 : 8.0) : (keys['ShiftLeft'] || keys['ShiftRight'] ? 6.5 : 3.8);
          const speed = baseSpeed * delta;`;

const newSpeedLogic = `          const riding = isRidingScooterRef.current;
          let baseSpeed = riding ? (keys['ShiftLeft'] || keys['ShiftRight'] ? 12.0 : 8.0) : (keys['ShiftLeft'] || keys['ShiftRight'] ? 6.5 : 3.8);
          
          const isNearTennis = Math.hypot(myPosRef.current.x - 29.0, myPosRef.current.z) < 22.0 && Math.abs((myPosRef.current.y || 0) - (-6.0)) < 4.0;
          if (isNearTennis) {
            // Very fast left/right movement on tennis court
            if (keys['KeyA'] || keys['KeyD']) {
                baseSpeed = 22.0;
            }
          }
          const speed = baseSpeed * delta;`;

code = code.replace(oldSpeedLogic, newSpeedLogic);

// Apply jump physics
const oldCurYLogic = `            const curY = myPosRef.current.y || 0;
            if (curY <= -3.0) {`;

const newCurYLogic = `            let curY = myPosRef.current.y || 0;
            if (isNearTennis) {
                // Apply jump physics
                playerVelYRef.current -= 15.0 * delta; // Gravity
                curY += playerVelYRef.current * delta;
                if (curY <= -6.0) {
                    curY = -6.0;
                    playerVelYRef.current = 0;
                }
                myPosRef.current.y = curY;
            }
            if (curY <= -3.0) {`;

code = code.replace(oldCurYLogic, newCurYLogic);

fs.writeFileSync('src/components/OfficeCanvas.tsx', code);
