const fs = require('fs');
let code = fs.readFileSync('src/components/OfficeCanvas.tsx', 'utf8');

// First remove the bad logic
const oldBadLogic = `            let curY = myPosRef.current.y || 0;
            if (isNearTennis) {
                // Apply jump physics
                playerVelYRef.current -= 15.0 * delta; // Gravity
                curY += playerVelYRef.current * delta;
                if (curY <= -6.0) {
                    curY = -6.0;
                    playerVelYRef.current = 0;
                }
                myPosRef.current.y = curY;
            }
            if (curY <= -3.0) {`;

const restoredLogic = `            const curY = myPosRef.current.y || 0;
            if (curY <= -3.0) {`;

code = code.replace(oldBadLogic, restoredLogic);

// Add the jump physics right before "const isKeyMoving = dx !== 0 || dz !== 0;"
const beforeKeyMoving = `          const isKeyMoving = dx !== 0 || dz !== 0;`;

const updatedPhysics = `
          if (isNearTennis) {
              if (playerVelYRef.current !== 0 || (myPosRef.current.y || 0) > -6.0) {
                  playerVelYRef.current -= 15.0 * delta; // Gravity
                  let updatedY = (myPosRef.current.y || 0) + playerVelYRef.current * delta;
                  if (updatedY <= -6.0) {
                      updatedY = -6.0;
                      playerVelYRef.current = 0;
                  }
                  myPosRef.current.y = updatedY;
              }
          }
          const isKeyMoving = dx !== 0 || dz !== 0;`;

code = code.replace(beforeKeyMoving, updatedPhysics);

fs.writeFileSync('src/components/OfficeCanvas.tsx', code);
