import { useState, useEffect } from 'react';
import {
  Coffee,
  Zap,
  Sparkles,
  Flame,
  Check,
  X,
  Cpu,
  RefreshCw,
  Activity,
  Bot,
} from 'lucide-react';
import { CoffeeOrder } from '../types';

interface CoffeeRobotModalProps {
  isOpen: boolean;
  onClose: () => void;
  onApplyCoffeeBuff?: (drinkName: string, buffText: string, emoji: string) => void;
}

const MENU_DRINKS: CoffeeOrder[] = [
  {
    id: 'cyber-espresso',
    name: 'Cyber Double-Shot Espresso',
    tagline: 'High-pressure 9-bar extraction with rich crema layer.',
    roast: 'Dark',
    temp: 'Hot',
    milk: 'None',
    caffeineMg: 150,
    brewTimeSec: 4,
    color: '#78350f',
    emoji: '☕',
    buffDescription: 'Instant +20% Focus Boost & Fast Walking Speed',
  },
  {
    id: 'nitro-cold-brew',
    name: 'Liquid Nitrogen Cascading Cold Brew',
    tagline: '24-hour steep infused with nitrogen for micro-bubble foam.',
    roast: 'Nitro',
    temp: 'Nitro Cold',
    milk: 'None',
    caffeineMg: 210,
    brewTimeSec: 5,
    color: '#451a03',
    emoji: '🧊',
    buffDescription: 'Sustained Energy & Zero Jitters Aura',
  },
  {
    id: 'oat-cortado',
    name: 'Artisan Microfoam Oat Cortado',
    tagline: '1:1 ratio of intense espresso and steamed organic oat milk.',
    roast: 'Medium',
    temp: 'Hot',
    milk: 'Oat',
    caffeineMg: 120,
    brewTimeSec: 5,
    color: '#d97706',
    emoji: '🥛',
    buffDescription: 'Smooth Collaboration & Creative Clarity',
  },
  {
    id: 'tokyo-matcha',
    name: 'Kyoto Ceremonial Matcha Latte',
    tagline: 'First-harvest shade-grown green tea whisked by robotic arm.',
    roast: 'Blonde',
    temp: 'Iced',
    milk: 'Almond',
    caffeineMg: 80,
    brewTimeSec: 4,
    color: '#15803d',
    emoji: '🍵',
    buffDescription: 'Zen Calm & Ultra-Crisp Brain Waves',
  },
  {
    id: 'caramel-macchiato',
    name: 'Robotic Caramel Drizzle Macchiato',
    tagline: 'Layered steamed vanilla milk, espresso shot, and salted caramel grid.',
    roast: 'Medium',
    temp: 'Hot',
    milk: 'Whole',
    caffeineMg: 135,
    brewTimeSec: 6,
    color: '#b45309',
    emoji: '✨',
    buffDescription: 'Delightful Euphoria & Coding Flow State',
  },
];

export function CoffeeRobotModal({
  isOpen,
  onClose,
  onApplyCoffeeBuff,
}: CoffeeRobotModalProps) {
  const [selectedDrink, setSelectedDrink] = useState<CoffeeOrder>(MENU_DRINKS[0]);
  const [selectedMilk, setSelectedMilk] = useState<CoffeeOrder['milk']>(MENU_DRINKS[0].milk);
  const [extraShot, setExtraShot] = useState<boolean>(false);
  const [isBrewing, setIsBrewing] = useState<boolean>(false);
  const [brewProgress, setBrewProgress] = useState<number>(0);
  const [brewStepText, setBrewStepText] = useState<string>('Robotic Arm Idle');
  const [brewCompleted, setBrewCompleted] = useState<boolean>(false);

  useEffect(() => {
    if (!isOpen) {
      setIsBrewing(false);
      setBrewProgress(0);
      setBrewCompleted(false);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleStartBrew = () => {
    setIsBrewing(true);
    setBrewProgress(0);
    setBrewCompleted(false);

    const steps = [
      { progress: 15, text: 'Precision Grinding Single-Origin Beans...' },
      { progress: 35, text: 'Tamping Portafilter with 15kg Robot Servo Pressure...' },
      { progress: 60, text: 'Pre-infusion & 9-Bar Extraction Underway...' },
      { progress: 80, text: 'Microfoam Steam Wand & Robotic Latte Art Drawing...' },
      { progress: 100, text: 'Order Complete! Dispensing Fresh Robotic Cup ☕' },
    ];

    let currentStepIdx = 0;
    const interval = setInterval(() => {
      currentStepIdx++;
      if (currentStepIdx < steps.length) {
        setBrewProgress(steps[currentStepIdx].progress);
        setBrewStepText(steps[currentStepIdx].text);
      } else {
        clearInterval(interval);
        setIsBrewing(false);
        setBrewCompleted(true);

        if (onApplyCoffeeBuff) {
          onApplyCoffeeBuff(
            selectedDrink.name,
            selectedDrink.buffDescription,
            selectedDrink.emoji
          );
        }
      }
    }, 900);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-200">
      <div
        id="coffee-robot-modal-card"
        className="relative w-full max-w-2xl max-h-[90vh] flex flex-col bg-slate-900 border border-slate-700/80 rounded-2xl shadow-[0_25px_60px_-15px_rgba(0,0,0,0.9)] overflow-hidden"
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-950/60">
          <div className="flex items-center space-x-3">
            <div className="p-2.5 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-400">
              <Bot className="w-6 h-6 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h2 className="text-lg font-bold text-slate-100 tracking-tight">
                  B1 Robotic Barista & Coffee Arm Station
                </h2>
                <span className="px-2 py-0.5 rounded-full bg-amber-500/10 border border-amber-500/30 text-[11px] font-semibold text-amber-400">
                  Arm v3.4 Calibrated
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Precision robotic espresso extraction, pour-over, and microfoam latte art.
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-slate-800/80 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Robotic Status Telemetry */}
        <div className="grid grid-cols-3 gap-2 px-6 py-2.5 bg-slate-950/30 border-b border-slate-800/60 text-xs">
          <div className="flex items-center space-x-2 text-slate-300">
            <Cpu className="w-3.5 h-3.5 text-sky-400" />
            <span className="text-slate-400">Arm Temp:</span>
            <span className="font-mono font-semibold text-sky-300">93.5°C Boiler</span>
          </div>
          <div className="flex items-center space-x-2 text-slate-300">
            <Activity className="w-3.5 h-3.5 text-emerald-400" />
            <span className="text-slate-400">Pressure:</span>
            <span className="font-mono font-semibold text-emerald-400">9.2 Bar</span>
          </div>
          <div className="flex items-center space-x-2 text-slate-300">
            <Zap className="w-3.5 h-3.5 text-amber-400" />
            <span className="text-slate-400">Servos:</span>
            <span className="font-mono font-semibold text-amber-300">6-Axis Online</span>
          </div>
        </div>

        {/* Content Area */}
        <div className="flex-1 overflow-y-auto p-6 space-y-5">
          {/* Drink Selection Grid */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-400 mb-2.5">
              Select Artisan Brew
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {MENU_DRINKS.map((drink) => {
                const isSelected = selectedDrink.id === drink.id;
                return (
                  <button
                    key={drink.id}
                    type="button"
                    onClick={() => {
                      setSelectedDrink(drink);
                      setSelectedMilk(drink.milk);
                      setBrewCompleted(false);
                    }}
                    className={`flex items-start space-x-3 p-3.5 rounded-xl border text-left transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-amber-950/20 border-amber-500/50 shadow-md shadow-amber-500/10'
                        : 'bg-slate-950/40 border-slate-800 hover:border-slate-700 hover:bg-slate-800/40'
                    }`}
                  >
                    <div className="text-2xl p-2 rounded-lg bg-slate-900 border border-slate-800">
                      {drink.emoji}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between">
                        <h4 className="text-xs font-bold text-slate-100 truncate">
                          {drink.name}
                        </h4>
                        <span className="text-[10px] font-mono text-amber-400 font-semibold">
                          {drink.caffeineMg}mg
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-400 mt-0.5 line-clamp-1">
                        {drink.tagline}
                      </p>
                      <div className="flex items-center space-x-2 mt-1.5 text-[10px]">
                        <span className="px-1.5 py-0.2 rounded bg-slate-800 text-slate-300 font-medium">
                          {drink.roast} Roast
                        </span>
                        <span className="px-1.5 py-0.2 rounded bg-slate-800 text-slate-300 font-medium">
                          {drink.temp}
                        </span>
                      </div>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Customization Options */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 p-4 rounded-xl bg-slate-950/40 border border-slate-800">
            <div>
              <label className="block text-[11px] font-semibold text-slate-300 mb-1.5">
                Milk Selection
              </label>
              <div className="flex items-center space-x-2">
                {(['Oat', 'Almond', 'Whole', 'None'] as const).map((milkOption) => (
                  <button
                    key={milkOption}
                    type="button"
                    onClick={() => setSelectedMilk(milkOption)}
                    className={`px-2.5 py-1 rounded-lg text-xs font-medium transition-all ${
                      selectedMilk === milkOption
                        ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 font-semibold'
                        : 'bg-slate-900 text-slate-400 border border-slate-800 hover:text-slate-200'
                    }`}
                  >
                    {milkOption}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-[11px] font-semibold text-slate-300 mb-1.5">
                Extra Booster Shot
              </label>
              <button
                type="button"
                onClick={() => setExtraShot(!extraShot)}
                className={`flex items-center space-x-2 px-3 py-1 rounded-lg text-xs font-medium transition-all ${
                  extraShot
                    ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 font-semibold'
                    : 'bg-slate-900 text-slate-400 border border-slate-800 hover:text-slate-200'
                }`}
              >
                <Zap className="w-3.5 h-3.5" />
                <span>{extraShot ? '+1 Extra Double Espresso Shot Added' : '+ Add Extra Boost (+60mg)'}</span>
              </button>
            </div>
          </div>

          {/* Brewing Progress / Active Status Bar */}
          {isBrewing && (
            <div className="p-4 rounded-xl bg-slate-950 border border-amber-500/40 space-y-2.5 animate-pulse">
              <div className="flex items-center justify-between text-xs">
                <span className="font-bold text-amber-400 flex items-center space-x-1.5">
                  <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                  <span>{brewStepText}</span>
                </span>
                <span className="font-mono font-bold text-slate-300">{brewProgress}%</span>
              </div>
              <div className="w-full h-2 rounded-full bg-slate-800 overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-amber-500 via-orange-500 to-amber-300 transition-all duration-500 rounded-full"
                  style={{ width: `${brewProgress}%` }}
                />
              </div>
            </div>
          )}

          {/* Brew Completed Notification */}
          {brewCompleted && (
            <div className="p-4 rounded-xl bg-emerald-950/30 border border-emerald-500/40 space-y-1.5 animate-in zoom-in-95 duration-200">
              <div className="flex items-center space-x-2 text-emerald-400 font-bold text-xs">
                <Check className="w-4 h-4" />
                <span>{selectedDrink.name} is ready on the B1 Marble Counter!</span>
              </div>
              <p className="text-xs text-slate-300">
                ✨ <strong className="text-amber-300">Active Avatar Buff:</strong> {selectedDrink.buffDescription}
              </p>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between px-6 py-4 border-t border-slate-800 bg-slate-950/60">
          <div className="text-xs text-slate-400">
            <span>Estimated caffeine: </span>
            <strong className="text-slate-200">
              {selectedDrink.caffeineMg + (extraShot ? 60 : 0)} mg
            </strong>
          </div>

          <div className="flex items-center space-x-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold rounded-xl transition-colors cursor-pointer"
            >
              Close
            </button>
            <button
              type="button"
              disabled={isBrewing}
              onClick={handleStartBrew}
              className={`flex items-center space-x-2 px-5 py-2 rounded-xl text-xs font-bold transition-all shadow-lg cursor-pointer ${
                isBrewing
                  ? 'bg-slate-800 text-slate-500 cursor-not-allowed'
                  : 'bg-amber-600 hover:bg-amber-500 text-white shadow-amber-900/30 active:scale-95'
              }`}
            >
              <Bot className="w-4 h-4" />
              <span>{isBrewing ? 'Arm Brewing...' : 'Order & Brew with Arm'}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
