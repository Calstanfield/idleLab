import React, { useEffect } from 'react';
import { ArrowUp, ArrowDown, Building2, Briefcase, Utensils, X, Check, MapPin, Sparkles } from 'lucide-react';

export interface ElevatorModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentY: number;
  onSelectFloor: (targetY: number) => void;
  onTeleportTennisCourt?: () => void;
  isMoving?: boolean;
}

export interface FloorInfo {
  id: string;
  code: string;
  keyLabel: string;
  name: string;
  tagline: string;
  y: number;
  icon: React.ReactNode;
  color: string;
  badge?: string;
}

export const FLOORS: FloorInfo[] = [
  {
    id: '3f',
    code: '3F',
    keyLabel: '3',
    name: 'Visitor Center Cafe',
    tagline: 'Artisanal Coffee, Pastries & Panoramic City Skyline',
    y: 11.0,
    icon: <Utensils className="w-4 h-4 text-amber-400" />,
    color: 'border-amber-500/40 text-amber-300 bg-amber-500/10',
  },
  {
    id: '2f',
    code: '2F',
    keyLabel: '2',
    name: 'Executive Boardroom Suite',
    tagline: 'Strategy Sync & Presentation Balcony',
    y: 5.5,
    icon: <Building2 className="w-4 h-4 text-indigo-400" />,
    color: 'border-indigo-500/40 text-indigo-300 bg-indigo-500/10',
  },
  {
    id: '1f',
    code: '1F',
    keyLabel: '1',
    name: 'Main Open Office Workspace',
    tagline: 'Collaborative Desks & Whiteboards',
    y: 0.0,
    icon: <Briefcase className="w-4 h-4 text-sky-400" />,
    color: 'border-sky-500/40 text-sky-300 bg-sky-500/10',
  },
  {
    id: 'b1',
    code: 'B1',
    keyLabel: 'B',
    name: 'Corporate Workspace & Tennis Arena',
    tagline: 'Chloe Becker Desk & Tesla Optimus Arena',
    y: -6.0,
    icon: <Building2 className="w-4 h-4 text-emerald-400" />,
    color: 'border-emerald-500/40 text-emerald-300 bg-emerald-500/10',
    badge: 'Tennis 🎾',
  },
];

export const ElevatorModal: React.FC<ElevatorModalProps> = ({
  isOpen,
  onClose,
  currentY,
  onSelectFloor,
  onTeleportTennisCourt,
  isMoving = false,
}) => {
  // Determine current floor index based on currentY
  let currentFloorIdx = 2; // Default 1F (index 2 in descending list)
  if (currentY < -2) currentFloorIdx = 3; // B1
  else if (currentY >= -2 && currentY < 3) currentFloorIdx = 2; // 1F
  else if (currentY >= 3 && currentY < 8) currentFloorIdx = 1; // 2F
  else if (currentY >= 8) currentFloorIdx = 0; // 3F

  const currentFloor = FLOORS[currentFloorIdx];

  const handleUp = () => {
    if (currentFloorIdx > 0 && !isMoving) {
      const target = FLOORS[currentFloorIdx - 1];
      onSelectFloor(target.y);
    }
  };

  const handleDown = () => {
    if (currentFloorIdx < FLOORS.length - 1 && !isMoving) {
      const target = FLOORS[currentFloorIdx + 1];
      onSelectFloor(target.y);
    }
  };

  // Keyboard controls (ArrowUp, ArrowDown, Escape, E, numbers 1-3, B)
  useEffect(() => {
    if (!isOpen || isMoving) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      // Ignore if typing in input/textarea
      if (document.activeElement?.tagName === 'INPUT' || document.activeElement?.tagName === 'TEXTAREA') {
        return;
      }

      if (e.key === 'Escape' || e.key === 'e' || e.key === 'E') {
        onClose();
      } else if (e.key === 'ArrowUp' || e.key === 'w' || e.key === 'W') {
        handleUp();
      } else if (e.key === 'ArrowDown' || e.key === 's' || e.key === 'S') {
        handleDown();
      } else if (e.key.toLowerCase() === 'b' || e.key === '0') {
        onSelectFloor(-6.0);
      } else if (e.key === '1') {
        onSelectFloor(0.0);
      } else if (e.key === '2') {
        onSelectFloor(5.5);
      } else if (e.key === '3') {
        onSelectFloor(11.0);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, currentFloorIdx, isMoving]);

  if (!isOpen || isMoving) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-xs animate-in fade-in duration-150"
      onClick={onClose}
    >
      <div
        className="relative w-full max-w-sm bg-slate-900/95 border border-sky-500/30 rounded-2xl shadow-[0_20px_50px_rgba(0,0,0,0.8)] overflow-hidden text-slate-100 backdrop-blur-xl"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Sleek Minimal Header */}
        <div className="flex items-center justify-between px-4 py-3 bg-gradient-to-r from-slate-800/80 to-slate-900/90 border-b border-slate-700/60">
          <div className="flex items-center space-x-2.5">
            <div className="p-1.5 bg-sky-500/20 border border-sky-500/40 rounded-lg text-sky-400">
              <Building2 className="w-4 h-4 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <h3 className="text-sm font-black text-slate-100 tracking-tight">Elevator</h3>
                <span className="text-[10px] font-bold px-1.5 py-0.2 rounded bg-sky-500/20 text-sky-300 border border-sky-500/30">
                  Current: {currentFloor.code}
                </span>
              </div>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
            title="Close (Esc)"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Quick Floor Step Buttons (▲ Up / ▼ Down) */}
        <div className="p-3.5 space-y-3">
          <div className="flex items-center justify-between gap-2">
            <button
              onClick={handleUp}
              disabled={currentFloorIdx === 0}
              className={`flex-1 py-2 px-3 rounded-xl border flex items-center justify-center space-x-2 transition-all cursor-pointer ${
                currentFloorIdx === 0
                  ? 'opacity-30 border-slate-800 bg-slate-900 cursor-not-allowed text-slate-600'
                  : 'bg-emerald-500/20 hover:bg-emerald-500/30 border-emerald-500/40 text-emerald-300 active:scale-95 shadow-sm'
              }`}
              title="Go Up One Floor (▲)"
            >
              <ArrowUp className="w-4 h-4 stroke-[2.5]" />
              <span className="text-xs font-bold tracking-wider">UP 1 FLOOR</span>
            </button>

            <button
              onClick={handleDown}
              disabled={currentFloorIdx === FLOORS.length - 1}
              className={`flex-1 py-2 px-3 rounded-xl border flex items-center justify-center space-x-2 transition-all cursor-pointer ${
                currentFloorIdx === FLOORS.length - 1
                  ? 'opacity-30 border-slate-800 bg-slate-900 cursor-not-allowed text-slate-600'
                  : 'bg-sky-500/20 hover:bg-sky-500/30 border-sky-500/40 text-sky-300 active:scale-95 shadow-sm'
              }`}
              title="Go Down One Floor (▼)"
            >
              <ArrowDown className="w-4 h-4 stroke-[2.5]" />
              <span className="text-xs font-bold tracking-wider">DOWN 1 FLOOR</span>
            </button>
          </div>

          {/* Minimal 4-Floor List */}
          <div className="space-y-1.5">
            {FLOORS.map((floor) => {
              const isCurrent = floor.y === currentFloor.y;

              return (
                <button
                  key={floor.id}
                  onClick={() => onSelectFloor(floor.y)}
                  className={`w-full flex items-center justify-between p-2.5 rounded-xl border transition-all text-left cursor-pointer group ${
                    isCurrent
                      ? 'bg-sky-500/20 border-sky-500 ring-1 ring-sky-500/40 shadow-sm'
                      : 'bg-slate-800/40 hover:bg-slate-800/80 border-slate-700/60 hover:border-slate-500'
                  }`}
                >
                  <div className="flex items-center space-x-2.5">
                    <div
                      className={`flex items-center justify-center w-8 h-8 rounded-lg font-black text-sm border ${
                        isCurrent
                          ? 'bg-sky-500 text-slate-950 border-sky-400 shadow-sm'
                          : 'bg-slate-800 text-slate-200 border-slate-700 group-hover:border-slate-500'
                      }`}
                    >
                      {floor.code}
                    </div>

                    <div>
                      <div className="flex items-center gap-1.5">
                        <span className="text-xs font-bold text-slate-100">{floor.name}</span>
                        {floor.badge && (
                          <span className="text-[9px] font-bold px-1 rounded bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                            {floor.badge}
                          </span>
                        )}
                      </div>
                      <p className="text-[11px] text-slate-400 leading-none mt-0.5">{floor.tagline}</p>
                    </div>
                  </div>

                  <div className="flex items-center space-x-1.5">
                    <span className="text-[10px] font-mono px-1.5 py-0.5 bg-slate-800 text-slate-400 rounded border border-slate-700">
                      [{floor.keyLabel}]
                    </span>
                    {isCurrent ? (
                      <span className="text-[10px] font-bold text-sky-400 bg-sky-500/20 px-2 py-0.5 rounded border border-sky-500/40 flex items-center gap-0.5">
                        <Check className="w-3 h-3" />
                        <span>Here</span>
                      </span>
                    ) : (
                      <span className="opacity-0 group-hover:opacity-100 transition-opacity text-[10px] font-bold text-sky-300">
                        Ride →
                      </span>
                    )}
                  </div>
                </button>
              );
            })}
          </div>

          {/* Direct Express Portal to Tennis Arena */}
          {onTeleportTennisCourt && (
            <div className="pt-1.5 border-t border-slate-800">
              <button
                onClick={() => {
                  onTeleportTennisCourt();
                  onClose();
                }}
                className="w-full flex items-center justify-between p-2 rounded-xl bg-emerald-950/40 hover:bg-emerald-900/50 border border-emerald-500/40 hover:border-emerald-400 transition-all text-left cursor-pointer"
              >
                <div className="flex items-center space-x-2">
                  <span className="text-lg">🎾</span>
                  <div>
                    <div className="text-[11px] font-bold text-emerald-300">Direct Entry to Tennis Arena</div>
                    <div className="text-[10px] text-slate-400">Step onto baseline vs Tesla Bot</div>
                  </div>
                </div>
                <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 text-[10px] font-bold border border-emerald-500/40">
                  Enter →
                </span>
              </button>
            </div>
          )}
        </div>

        {/* Minimal Footer */}
        <div className="px-4 py-2 bg-slate-950/80 border-t border-slate-800 flex items-center justify-between text-[11px] text-slate-400">
          <span>Hotkeys: <kbd className="px-1 py-0.5 bg-slate-800 border border-slate-700 rounded text-slate-300">3</kbd> <kbd className="px-1 py-0.5 bg-slate-800 border border-slate-700 rounded text-slate-300">2</kbd> <kbd className="px-1 py-0.5 bg-slate-800 border border-slate-700 rounded text-slate-300">1</kbd> <kbd className="px-1 py-0.5 bg-slate-800 border border-slate-700 rounded text-slate-300">B</kbd></span>
          <span>Close: <kbd className="px-1 py-0.5 bg-slate-800 border border-slate-700 rounded text-slate-300">E</kbd></span>
        </div>
      </div>
    </div>
  );
};

