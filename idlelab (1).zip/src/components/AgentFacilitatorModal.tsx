import React, { useState, useEffect, useRef } from 'react';
import {
  X,
  Sparkles,
  Vote,
  UserCheck,
  FileText,
  Volume2,
  VolumeX,
  Send,
  ShieldCheck,
  Activity,
  Radio,
  Link,
  CheckCircle2,
  AlertTriangle,
  Cpu,
  GitBranch,
  Terminal,
  Sliders,
  Paperclip,
  AtSign,
  MessageSquare
} from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import Markdown from 'react-markdown';
import { chloeVoice } from '../lib/chloeVoice';
import { chloeAgentClient } from '../lib/chloeAgentClient';

export interface AgentFacilitatorModalProps {
  isOpen: boolean;
  onClose: () => void;
  username?: string;
  userPosition?: { x: number; y: number; z: number };
  hasScreenStream?: boolean;
}

const cleanTextForSpeech = (text: string) => {
  return text
    .replace(/https?:\/\/[^\s]+/g, 'presentation link')
    .replace(/[#_*~`\/\\|—-]+/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
};

const claireVoice = {
  speak: (text: string, onEnd?: () => void) => {
    if (typeof localStorage !== 'undefined' && localStorage.getItem('claire_voice_muted') === 'true') {
      if (onEnd) onEnd();
      return;
    }
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(cleanTextForSpeech(text));
      utterance.rate = 1.05;
      utterance.pitch = 1.1;
      const voices = window.speechSynthesis.getVoices();
      const preferred = voices.find(v => v.name.includes('Samantha') || v.name.includes('Google US English'));
      if (preferred) utterance.voice = preferred;
      if (onEnd) utterance.onend = onEnd;
      window.speechSynthesis.speak(utterance);
    }
  },
  stop: () => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
  }
};

export const AgentFacilitatorModal: React.FC<AgentFacilitatorModalProps> = ({
  isOpen,
  onClose,
  username = 'Guest',
  userPosition,
  hasScreenStream = false,
}) => {
  const agentName = 'Claire Wang';
  const agentRole = '2F Boardroom facilitator';
  const agentModel = 'Gemini 3.5 Pro Executive';
  const [activeTab, setActiveTab] = useState<'pipeline' | 'chat' | 'vote' | 'compatibility' | 'summary' | 'emulator'>('chat');
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [isMuted, setIsMuted] = useState<boolean>(() => typeof localStorage !== 'undefined' ? localStorage.getItem('claire_voice_muted') === 'true' : false);

  const toggleClaireMute = () => {
    const nextMuted = !isMuted;
    if (isSpeaking) claireVoice.stop();
    setIsMuted(nextMuted);
    try {
      localStorage.setItem('claire_voice_muted', String(nextMuted));
    } catch {}
  };
  const [inputMessage, setInputMessage] = useState('');
  const [dialogueHistory, setDialogueHistory] = useState<{ sender: string; text: string }[]>([]);
  const [screenStreamActive, setScreenStreamActive] = useState(hasScreenStream);
  const [trafficLogs, setTrafficLogs] = useState<{ time: string; msg: string; type: 'success' | 'warn' | 'info' }[]>([]);
  const [hasVoted, setHasVoted] = useState(false);
  const [voteResults, setVoteResults] = useState({ approve: 0, revise: 0, reject: 0 });
  const [compatibilityScore, setCompatibilityScore] = useState(85);
  const [quotaData, setQuotaData] = useState<{ time: string; tokens: number }[]>([
    { time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }), tokens: 0 }
  ]);
  
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isOpen && dialogueHistory.length === 0) {
      const welcomeText = `Hello ${username}. I am ${agentName}, the ${agentRole}. I am actively ready to sync what's being shared on the tab. How can I assist you today?`;
      setDialogueHistory([
        { sender: agentName, text: welcomeText }
      ]);
      addTrafficLog(`AgentFlow pipeline initialized for 2F Executive Room.`, 'success');
      addTrafficLog(`Spatial audio tracking locked to participant: ${username}.`, 'info');
      setQuotaData(prev => [...prev.slice(-15), { time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }), tokens: welcomeText.length }]);
      
      if (!isMuted) {
        setIsSpeaking(true);
        claireVoice.speak(welcomeText, () => setIsSpeaking(false));
      }
    }
  }, [isOpen, username, agentName, agentRole]);

  useEffect(() => {
    setScreenStreamActive(hasScreenStream);
    if (hasScreenStream) {
      addTrafficLog('Presentation screen stream (8K) successfully intercepted and synced.', 'success');
    } else if (isOpen) {
      addTrafficLog('Presentation screen stream disconnected. Waiting for presenter signal.', 'warn');
    }
  }, [hasScreenStream, isOpen]);

  const addTrafficLog = (msg: string, type: 'success' | 'warn' | 'info') => {
    const time = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
    setTrafficLogs(prev => [{ time, msg, type }, ...prev].slice(0, 20));
  };

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputMessage.trim()) return;

    setDialogueHistory((prev) => [...prev, { sender: username, text: inputMessage }]);
    const query = inputMessage;
    setInputMessage('');
    addTrafficLog(`Received query from ${username}: ${query.substring(0, 20)}... (Synced with Tab: ${activeTab})`, 'info');
    
    // Update quota
    const timeStr = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
    setQuotaData(prev => {
      const lastTokens = prev.length > 0 ? prev[prev.length - 1].tokens : 0;
      return [...prev.slice(-15), { time: timeStr, tokens: lastTokens + query.length }];
    });

    const processReply = async () => {
      let reply = '';
      const lowerQ = query.toLowerCase();
      if (lowerQ.includes('quota') || lowerQ.includes('limit') || lowerQ.includes('spent') || lowerQ.includes('exhausted') || lowerQ.includes('ran out')) {
        reply = `Sorry ${username} for the inconveniences, we ran out quota. So the workspace is offline. But don't worry, we will be back soon`;
        addTrafficLog('Quota exhausted alert triggered; workspace set to offline mode.', 'warn');
      } else if (lowerQ.includes('emulator') || lowerQ.includes('graph') || lowerQ.includes('model') || lowerQ.includes('tokens')) {
        reply = `The Graph Emulator is actively tracking Gemini 3.5 API executive token consumption and Google Cloud Console quota metrics. You can view the live token traffic chart under the Graph Emulator tab.`;
        addTrafficLog('Switched view to Graph Emulator tab.', 'success');
        setActiveTab('emulator');
      } else if (query.toLowerCase().includes('vote') || query.toLowerCase().includes('ballot')) {
        reply = 'I have **unlocked** the executive voting pipeline. You may now conduct the vote tally from the ballot panel.';
        addTrafficLog('Executive voting pipeline unlocked via natural language command.', 'success');
        setActiveTab('vote');
      } else if (query.toLowerCase().includes('score') || query.toLowerCase().includes('compatible')) {
        reply = `Based on the latest transcript analysis, the guest alignment scorecard is currently at **${compatibilityScore}/100**. Check the compatibility tab for detailed metrics.`;
        setActiveTab('compatibility');
      } else {
        try {
          const claireRes = await fetch('/api/claire/chat', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              message: query,
              userName: username,
              history: dialogueHistory,
              activeTab,
              screenStreamActive,
            }),
          });
          if (claireRes.ok) {
            const data = await claireRes.json();
            if (data.text) {
              reply = data.text;
            }
          }
        } catch (err) {
          console.warn('Claire dedicated endpoint failed, engaging agent client fallback:', err);
        }

        if (!reply) {
          try {
            const res = await chloeAgentClient.sendQuery(query, {
              userName: username,
              tone: 'professional',
              context: `You are Claire Wang, an executive 2F Boardroom facilitator at IdleLab. Your name is strictly Claire Wang (never Chloe). You are actively syncing with the active tab "${activeTab}" and presentation stream. Keep response concise and professional.`
            });
            reply = res.text || `Hello ${username}, I am Claire Wang, the 2F Boardroom facilitator. I have synced with your active tab "${activeTab}". How can I assist with your meeting today?`;
          } catch (err) {
            reply = `Hello ${username}, I am Claire Wang, the 2F Boardroom facilitator. I have synced with your active tab "${activeTab}". How can I assist with your meeting today?`;
          }
        }
      }
      
      setDialogueHistory((prev) => [...prev, { sender: agentName, text: reply }]);
      
      setQuotaData(prev => {
        const lastTokens = prev.length > 0 ? prev[prev.length - 1].tokens : 0;
        return [...prev.slice(-15), { time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }), tokens: lastTokens + reply.length }];
      });
      
      if (!isMuted) {
        setIsSpeaking(true);
        claireVoice.speak(reply, () => setIsSpeaking(false));
      }
    };
    
    processReply();
  };

  const triggerAction = (action: string) => {
    if (action === 'vote') {
      addTrafficLog('Initiating secure vote tally across 2F board members.', 'info');
      setTimeout(() => {
        setHasVoted(true);
        setVoteResults({ approve: 8, revise: 2, reject: 0 });
        addTrafficLog('Vote tally finalized: 8 Approve, 2 Revise, 0 Reject.', 'success');
        const voteMsg = "The executive vote has concluded. The motion is approved with an overwhelming majority.";
        setDialogueHistory((prev) => [...prev, { sender: 'Claire Wang', text: voteMsg }]);
        if (!isMuted) {
          setIsSpeaking(true);
          claireVoice.speak(voteMsg, () => setIsSpeaking(false));
        }
      }, 1500);
    } else {
      addTrafficLog(`Executing pipeline action: ${action}`, 'info');
      setTimeout(() => {
        addTrafficLog(`Action ${action} completed successfully.`, 'success');
      }, 800);
    }
  };

  if (!isOpen) return null;

  const MODES = [
    { id: 'chat', label: 'Live Q&A Chat', icon: <MessageSquare className="w-4 h-4" />, subtitle: 'Dialogue & Questions' },
    { id: 'pipeline', label: 'Workflow Pipeline', icon: <GitBranch className="w-4 h-4" />, subtitle: 'Execution nodes' },
    { id: 'vote', label: 'Conduct Vote', icon: <Vote className="w-4 h-4" />, subtitle: 'Boardroom consensus' },
    { id: 'compatibility', label: 'Compatibility', icon: <UserCheck className="w-4 h-4" />, subtitle: 'Alignment scorecard' },
    { id: 'summary', label: 'Executive Summary', icon: <FileText className="w-4 h-4" />, subtitle: 'AI meeting synthesis' },
    { id: 'emulator', label: 'Graph Emulator', icon: <Activity className="w-4 h-4" />, subtitle: 'Model training & quota' },
  ] as const;

  const currentModeObj = MODES.find(m => m.id === activeTab) || MODES[0];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/85 backdrop-blur-xl animate-in fade-in duration-200">
      <div className="w-full max-w-[1400px] h-[92vh] bg-[#0d1117] border border-white/15 rounded-2xl shadow-[0_25px_100px_rgba(0,0,0,0.95)] flex flex-col overflow-hidden text-neutral-200 font-sans">
        
        {/* WINDOW TITLE BAR */}
        <div className="h-11 bg-[#161b22] border-b border-white/10 px-4 flex items-center justify-between shrink-0 select-none">
          <div className="flex items-center space-x-2">
            <div className="flex items-center space-x-1.5 mr-3">
              <button onClick={onClose} className="w-3 h-3 rounded-full bg-rose-500 hover:opacity-80 transition-opacity cursor-pointer" />
              <div className="w-3 h-3 rounded-full bg-amber-500" />
              <div className="w-3 h-3 rounded-full bg-emerald-500" />
            </div>
            <div className="flex items-center space-x-1.5">
              <span className="font-bold text-sm text-white tracking-wide">{agentName} · Meeting Facilitator</span>
            </div>
            <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-semibold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse mr-1.5" />
              Live
            </span>
          </div>
          <div className="flex items-center space-x-3">
            <button
              onClick={toggleClaireMute}
              className={`p-1 rounded-lg transition-colors cursor-pointer flex items-center space-x-1 text-xs px-2 ${
                isMuted ? 'text-rose-400 bg-rose-500/10 border border-rose-500/20' : 'text-neutral-400 hover:text-white hover:bg-white/10'
              }`}
              title={isMuted ? 'Unmute Claire Voice' : 'Mute Claire Voice'}
            >
              {isMuted ? <VolumeX className="w-4 h-4 text-rose-400" /> : <Volume2 className="w-4 h-4 text-cyan-400" />}
              <span className="hidden sm:inline">{isMuted ? 'Muted' : 'Voice'}</span>
            </button>
            <button className="p-1 rounded-lg text-neutral-400 hover:text-white hover:bg-white/10 transition-colors cursor-pointer" onClick={onClose}>
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* MAIN WORKSPACE BODY */}
        <div className="grid grid-cols-1 md:grid-cols-12 flex-1 min-h-0 bg-[#090d16]">
          
          {/* LEFT SIDEBAR: MODES (3 cols) */}
          <div className="md:col-span-3 border-r border-white/10 bg-[#0d1117] flex flex-col overflow-hidden">
            <div className="px-4 py-3 border-b border-white/10 flex items-center justify-between text-xs font-semibold text-neutral-400 uppercase tracking-wider">
              <span>Facilitator Modes</span>
              <button className="text-neutral-500 hover:text-white transition-colors cursor-pointer">
                <Sliders className="w-3.5 h-3.5" />
              </button>
            </div>
            <div className="flex-1 overflow-y-auto p-2 space-y-1">
              {MODES.map((mode) => {
                const isSelected = mode.id === activeTab;
                return (
                  <div
                    key={mode.id}
                    onClick={() => setActiveTab(mode.id as any)}
                    className={`p-3 rounded-xl cursor-pointer transition-all ${
                      isSelected
                        ? 'bg-white/10 border border-white/15 text-white shadow-md'
                        : 'hover:bg-white/5 text-neutral-400 hover:text-neutral-200 border border-transparent'
                    }`}
                  >
                    <div className="flex items-center space-x-2.5 mb-1">
                      <span className="text-base text-cyan-400">{mode.icon}</span>
                      <span className="font-semibold text-sm text-white">{mode.label}</span>
                    </div>
                    <div className="text-[11px] text-neutral-400 leading-tight pl-7">{mode.subtitle}</div>
                  </div>
                );
              })}
            </div>
            {/* Bottom User Workspace */}
            <div className="p-3 border-t border-white/10 bg-[#161b22]/50 flex items-center justify-between shrink-0">
              <div className="flex items-center space-x-2.5">
                <div className="w-8 h-8 rounded-full bg-cyan-600 font-bold text-white flex items-center justify-center text-xs uppercase">
                  {username ? username.charAt(0) : 'G'}
                </div>
                <div>
                  <div className="font-semibold text-xs text-white">{username || 'Guest'}</div>
                  <div className="text-[10px] text-emerald-400 font-medium">Participant</div>
                </div>
              </div>
            </div>
          </div>

          {/* CENTER PANEL: CONTENT & CHAT (6 cols) */}
          <div className="md:col-span-6 border-r border-white/10 flex flex-col min-h-0 bg-[#090d16]">
            
            {/* Top Workspace Bar */}
            <div className="px-6 py-3.5 border-b border-white/10 flex items-center justify-between bg-[#0d1117]/60 shrink-0">
              <div className="font-bold text-sm text-white flex items-center space-x-2">
                <span>{currentModeObj.label}</span>
                <span className="text-neutral-500 font-normal">·</span>
                <span className="text-xs text-neutral-400 font-normal">AgentFlow Traffic Monitor</span>
              </div>
              <button
                onClick={toggleClaireMute}
                className={`px-2.5 py-1 rounded-lg text-xs font-semibold flex items-center space-x-1.5 transition-colors cursor-pointer border ${
                  isMuted
                    ? 'bg-rose-500/20 text-rose-400 border-rose-500/40 hover:bg-rose-500/30'
                    : 'bg-cyan-500/15 text-cyan-300 border-cyan-500/30 hover:bg-cyan-500/25'
                }`}
                title={isMuted ? 'Unmute Claire Voice' : 'Mute Claire Voice'}
              >
                {isMuted ? <VolumeX className="w-3.5 h-3.5" /> : <Volume2 className="w-3.5 h-3.5" />}
                <span>{isMuted ? 'Muted' : 'Voice On'}</span>
              </button>
            </div>

            {/* TAB CONTENT SWITCHER */}
            <div className="flex-1 overflow-y-auto p-6 space-y-4">
              {activeTab === 'chat' && (
                <>
                  {isSpeaking && (
                    <div className="flex items-center gap-2 p-3 bg-cyan-950/40 border border-cyan-800/50 rounded-xl mb-4">
                      <span className="relative flex h-3 w-3">
                        <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-cyan-400 opacity-75"></span>
                        <span className="relative inline-flex rounded-full h-3 w-3 bg-cyan-500"></span>
                      </span>
                      <span className="text-xs text-cyan-300 font-medium">Claire Wang is speaking with executive voice synthesis...</span>
                    </div>
                  )}
                  <div className="space-y-4">
                    {dialogueHistory.map((item, idx) => {
                      const isAi = item.sender === 'Claire Wang';
                      return (
                        <div key={idx} className={`flex flex-col space-y-1 ${isAi ? 'items-start' : 'items-end'}`}>
                          <div className="flex items-center space-x-2">
                            <span className="text-[11px] text-neutral-500 font-medium">{item.sender}</span>
                          </div>
                          <div className={`p-3 rounded-2xl max-w-[85%] text-sm leading-relaxed ${isAi ? 'bg-[#161b22] border border-white/5 text-white rounded-tl-sm shadow-sm' : 'bg-cyan-600 text-white rounded-tr-sm shadow-md'}`}>
                            {isAi ? (
                              <div className="prose prose-sm prose-invert max-w-none prose-p:my-1 prose-ul:my-1">
                                <Markdown>{item.text}</Markdown>
                              </div>
                            ) : (
                              item.text
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </>
              )}

              {activeTab === 'pipeline' && (
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <h4 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-2">
                      <GitBranch className="w-4 h-4 text-cyan-400" /> Workflow Execution Pipeline
                    </h4>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div className={`p-4 rounded-xl border flex flex-col justify-between space-y-2 ${screenStreamActive ? 'bg-[#161b22] border-emerald-500/30' : 'bg-[#161b22] border-white/10'}`}>
                      <div className="flex items-center justify-between">
                        <span className="text-[11px] font-bold text-neutral-300">01 Presentation</span>
                        {screenStreamActive ? <CheckCircle2 className="w-4 h-4 text-emerald-400" /> : <AlertTriangle className="w-4 h-4 text-amber-400" />}
                      </div>
                      <p className="text-[11px] text-neutral-400">Screen Stream & Display Sync</p>
                      <div className="text-[10px] font-mono px-2 py-1 rounded bg-black/40 text-neutral-300">
                        {screenStreamActive ? 'STATUS: ACTIVE (8K)' : 'STATUS: INACTIVE'}
                      </div>
                    </div>
                    <div className="p-4 bg-[#161b22] border border-white/10 rounded-xl flex flex-col justify-between space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-[11px] font-bold text-neutral-300">02 Transcript</span>
                        <CheckCircle2 className="w-4 h-4 text-cyan-400" />
                      </div>
                      <p className="text-[11px] text-neutral-400">Live Audio & Speech Intake</p>
                      <div className="text-[10px] font-mono px-2 py-1 rounded bg-black/40 text-cyan-300">
                        STATUS: STREAMING
                      </div>
                    </div>
                    <div className="p-4 bg-[#161b22] border border-white/10 rounded-xl flex flex-col justify-between space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-[11px] font-bold text-neutral-300">03 Sentiment</span>
                        <CheckCircle2 className="w-4 h-4 text-purple-400" />
                      </div>
                      <p className="text-[11px] text-neutral-400">Speaker Emotional Analysis</p>
                      <div className="text-[10px] font-mono px-2 py-1 rounded bg-black/40 text-purple-300">
                        STATUS: ANALYZING
                      </div>
                    </div>
                    <div className="p-4 bg-[#161b22] border border-white/10 rounded-xl flex flex-col justify-between space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-[11px] font-bold text-neutral-300">04 Action Items</span>
                        <span className="w-4 h-4 rounded-full border-2 border-slate-600 border-t-cyan-400 animate-spin" />
                      </div>
                      <p className="text-[11px] text-neutral-400">Task Extraction & Routing</p>
                      <div className="text-[10px] font-mono px-2 py-1 rounded bg-black/40 text-slate-400">
                        STATUS: PENDING END
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {activeTab === 'vote' && (
                <div className="p-6 bg-[#161b22] border border-white/10 rounded-2xl space-y-4">
                  <h4 className="text-xs font-bold text-white uppercase tracking-wider">Live Vote Tally (2F Boardroom Consensus)</h4>
                  {!hasVoted ? (
                    <div className="py-12 text-center space-y-4 bg-black/20 rounded-xl border border-white/5">
                      <Vote className="w-10 h-10 text-neutral-500 mx-auto animate-pulse" />
                      <div className="space-y-1">
                        <p className="text-xs font-medium text-neutral-300">Vote tally pending. No votes have been conducted yet.</p>
                        <p className="text-[11px] text-neutral-500">Initiate the voting pipeline during the meeting evaluation to record committee ballots.</p>
                      </div>
                      <button
                        onClick={() => triggerAction('vote')}
                        className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold rounded-xl transition shadow-lg cursor-pointer mx-auto block"
                      >
                        Conduct Vote Now
                      </button>
                    </div>
                  ) : (
                    <>
                      <div className="grid grid-cols-3 gap-3 text-center">
                        <div className="p-4 bg-emerald-950/30 border border-emerald-800/50 rounded-xl">
                          <span className="block text-2xl font-bold text-emerald-400">{voteResults.approve}</span>
                          <span className="text-[11px] text-emerald-300 uppercase font-semibold">Approve</span>
                        </div>
                        <div className="p-4 bg-amber-950/30 border border-amber-800/50 rounded-xl">
                          <span className="block text-2xl font-bold text-amber-400">{voteResults.revise}</span>
                          <span className="text-[11px] text-amber-300 uppercase font-semibold">Revise</span>
                        </div>
                        <div className="p-4 bg-red-950/30 border border-red-800/50 rounded-xl">
                          <span className="block text-2xl font-bold text-red-400">{voteResults.reject}</span>
                          <span className="text-[11px] text-red-300 uppercase font-semibold">Reject</span>
                        </div>
                      </div>
                      <p className="text-xs text-neutral-400 text-center">
                        All 2F executive committee members have cast their ballots via the AgentFlow pipeline.
                      </p>
                    </>
                  )}
                </div>
              )}

              {activeTab === 'compatibility' && (
                <div className="p-6 bg-[#161b22] border border-white/10 rounded-2xl space-y-4">
                  <div className="flex items-center justify-between">
                    <h4 className="text-xs font-bold text-white uppercase tracking-wider">Guest Alignment Scorecard</h4>
                    <span className="text-base font-bold text-amber-400">{compatibilityScore}/100</span>
                  </div>
                  <div className="w-full bg-black/40 h-3 rounded-full overflow-hidden p-0.5 border border-white/5">
                    <div className="bg-gradient-to-r from-amber-500 to-emerald-400 h-full rounded-full" style={{ width: `${compatibilityScore}%` }} />
                  </div>
                  <p className="text-xs text-neutral-300 leading-relaxed bg-black/20 p-4 rounded-xl border border-white/5">
                    <strong className="text-cyan-400 block mb-1">Claire's Executive Assessment:</strong> 
                    The participant demonstrates high strategic clarity and rigorous technical acumen. Fully recommended for partnership recruitment and immediate proposal sign-off.
                  </p>
                </div>
              )}

              {activeTab === 'summary' && (
                <div className="p-6 bg-[#161b22] border border-white/10 rounded-2xl space-y-3 text-xs text-neutral-300 leading-relaxed">
                  <h4 className="font-bold text-purple-400 uppercase tracking-wider flex items-center gap-2">
                    <FileText className="w-4 h-4" /> {agentModel} Executive Summary
                  </h4>
                  <div className="space-y-2 bg-black/20 p-4 rounded-xl border border-white/5">
                    <p>• Presentation stream securely isolated to 2nd-floor boardroom displays (`display_2f_*`).</p>
                    <p>• Value proposition validated with positive ROI metrics and cross-functional alignment.</p>
                    <p>• Slide deck link successfully attached and synchronized with live participant transcripts.</p>
                    <p>• Recommended Action: Proceed with final contract execution and resource allocation.</p>
                  </div>
                </div>
              )}

              {activeTab === 'emulator' && (
                <div className="p-6 bg-[#161b22] border border-white/10 rounded-2xl space-y-4">
                  <div className="flex items-center justify-between">
                    <h4 className="font-bold text-emerald-400 uppercase tracking-wider flex items-center gap-2">
                      <Activity className="w-4 h-4" /> Google Cloud Console • Gemini 3.5 API Quota & Metrics
                    </h4>
                    <span className="text-[10px] bg-emerald-500/20 text-emerald-400 px-2.5 py-1 rounded-full border border-emerald-500/30 flex items-center gap-1.5 font-semibold">
                      <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" /> Active (Normal)
                    </span>
                  </div>
                  <p className="text-xs text-neutral-400">Live API quota consumption, request rates, and token limits across regional endpoints (`asia-east1`).</p>

                  {/* Cloud Console Quota Summary Cards */}
                  <div className="grid grid-cols-3 gap-3">
                    <div className="bg-[#090d16] p-3 rounded-xl border border-white/10">
                      <span className="text-[10px] text-neutral-400 block uppercase font-medium">Requests / Min (RPM)</span>
                      <div className="flex items-baseline justify-between mt-1">
                        <span className="text-lg font-bold text-white">1,420</span>
                        <span className="text-[10px] text-emerald-400 font-semibold">9.5% of 15k limit</span>
                      </div>
                      <div className="w-full bg-white/10 h-1.5 rounded-full mt-2 overflow-hidden">
                        <div className="bg-emerald-400 h-full rounded-full" style={{ width: '9.5%' }} />
                      </div>
                    </div>

                    <div className="bg-[#090d16] p-3 rounded-xl border border-white/10">
                      <span className="text-[10px] text-neutral-400 block uppercase font-medium">Tokens / Min (TPM)</span>
                      <div className="flex items-baseline justify-between mt-1">
                        <span className="text-lg font-bold text-white">385.2k</span>
                        <span className="text-[10px] text-cyan-400 font-semibold">9.6% of 4M limit</span>
                      </div>
                      <div className="w-full bg-white/10 h-1.5 rounded-full mt-2 overflow-hidden">
                        <div className="bg-cyan-400 h-full rounded-full" style={{ width: '9.6%' }} />
                      </div>
                    </div>

                    <div className="bg-[#090d16] p-3 rounded-xl border border-white/10">
                      <span className="text-[10px] text-neutral-400 block uppercase font-medium">Requests / Day (RPD)</span>
                      <div className="flex items-baseline justify-between mt-1">
                        <span className="text-lg font-bold text-white">48,250</span>
                        <span className="text-[10px] text-purple-400 font-semibold">3.2% of 1.5M limit</span>
                      </div>
                      <div className="w-full bg-white/10 h-1.5 rounded-full mt-2 overflow-hidden">
                        <div className="bg-purple-400 h-full rounded-full" style={{ width: '3.2%' }} />
                      </div>
                    </div>
                  </div>
                  
                  <div className="bg-[#090d16] p-4 rounded-xl border border-white/10 h-52 mt-2">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-xs font-semibold text-neutral-300">Live Token Traffic & Quota Utilization</span>
                      <span className="text-[10px] text-neutral-500">Gemini 3.5 Flash Model</span>
                    </div>
                    <ResponsiveContainer width="100%" height="80%">
                      <LineChart data={quotaData} margin={{ top: 5, right: 10, left: -25, bottom: 0 }}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#ffffff15" vertical={false} />
                        <XAxis dataKey="time" stroke="#6b7280" fontSize={10} tickMargin={5} />
                        <YAxis stroke="#6b7280" fontSize={10} />
                        <Tooltip 
                          contentStyle={{ backgroundColor: '#161b22', borderColor: '#ffffff20', borderRadius: '8px', fontSize: '12px' }}
                          itemStyle={{ color: '#34d399' }}
                        />
                        <Line type="monotone" dataKey="tokens" stroke="#34d399" strokeWidth={2} dot={{ r: 3, fill: '#161b22', stroke: '#34d399' }} activeDot={{ r: 5 }} />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                </div>
              )}
            </div>

            {/* Chat Input Bar */}
            <div className="p-4 bg-[#0d1117]/80 border-t border-white/10 shrink-0 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2 text-[10px] font-bold text-amber-500 tracking-wider uppercase">
                  <span className="w-3 h-3 rounded-sm bg-amber-500/20 flex items-center justify-center mr-1">✨</span>
                  AI Studio Prompt Flow:
                </div>
                <div className="flex items-center space-x-1.5">
                  <button
                    type="button"
                    onClick={() => setInputMessage(prev => `[Context: Live presentation] ${prev}`)}
                    className="px-2.5 py-1 rounded-lg bg-white/5 hover:bg-white/10 border border-white/10 text-neutral-300 font-mono text-[11px] transition-colors cursor-pointer"
                  >
                    <span className="text-emerald-400">[Context]</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setInputMessage(prev => `[Action: Summarize] ${prev}`)}
                    className="px-2.5 py-1 rounded-lg bg-white/5 hover:bg-white/10 border border-white/10 text-neutral-300 font-mono text-[11px] transition-colors cursor-pointer"
                  >
                    <span className="text-amber-400">[Action]</span>
                  </button>
                </div>
              </div>
              
              <input
                type="file"
                ref={fileInputRef}
                className="hidden"
              />
              <form onSubmit={handleSendMessage} className="flex items-center space-x-2 bg-[#161b22] border border-white/15 rounded-xl px-4 py-2.5 focus-within:border-cyan-500 transition-colors">
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  title="Attach Document (.txt, .md, .json, .csv)"
                  className="p-1.5 text-neutral-400 hover:text-cyan-400 transition-colors cursor-pointer"
                >
                  <Paperclip className="w-4 h-4" />
                </button>
                <input
                  type="text"
                  value={inputMessage}
                  onChange={(e) => setInputMessage(e.target.value)}
                  placeholder="Ask Claire a question or request meeting evaluation... (+50 XP)"
                  className="flex-1 bg-transparent text-sm text-white placeholder-neutral-500 focus:outline-none"
                />
                <button type="button" className="p-1.5 text-neutral-400 hover:text-white transition-colors cursor-pointer">
                  <AtSign className="w-4 h-4" />
                </button>
                <button type="button" className="p-1.5 text-neutral-400 hover:text-white transition-colors cursor-pointer">
                  <span className="font-mono text-sm font-bold">/</span>
                </button>
                <button
                  type="submit"
                  className="px-3 py-1.5 bg-cyan-600 hover:bg-cyan-500 text-white rounded-lg font-semibold text-xs flex items-center space-x-1.5 transition-colors cursor-pointer"
                >
                  <span>Send</span>
                  <Send className="w-3.5 h-3.5" />
                </button>
              </form>
            </div>
          </div>

          {/* RIGHT SIDEBAR: INSPECTOR (3 cols) */}
          <div className="md:col-span-3 bg-[#0d1117] border-l border-white/10 flex flex-col overflow-y-auto p-4 space-y-5 text-xs">
            <div className="font-bold text-xs uppercase tracking-wider text-neutral-400 pb-2 border-b border-white/10">
              Inspector
            </div>

            {/* SPATIAL LOCK & STREAM */}
            <div className="space-y-3 pt-1">
              <div className="font-semibold text-neutral-300">Spatial Lock & Stream</div>
              <div className="space-y-2">
                <div className="flex flex-col bg-[#161b22] px-3 py-2 rounded-xl border border-white/10 space-y-1">
                  <span className="text-neutral-400 text-[10px] uppercase">Secure Room</span>
                  <div className="flex items-center gap-1.5 text-emerald-400 font-medium">
                    <ShieldCheck className="w-4 h-4" />
                    <span>2F Boardroom</span>
                  </div>
                </div>
                <div className="flex items-center justify-between bg-[#161b22] px-3 py-2 rounded-xl border border-white/10">
                  <div className="flex items-center gap-2 text-neutral-300 font-medium">
                    <span className={`w-2 h-2 rounded-full ${screenStreamActive ? 'bg-emerald-400 animate-ping' : 'bg-amber-400'}`} />
                    Screen Stream
                  </div>
                  <button
                    onClick={() => {
                      setScreenStreamActive(!screenStreamActive);
                      addTrafficLog(`Manual override: Screen Stream ${!screenStreamActive ? 'enabled' : 'disabled'}.`, 'warn');
                    }}
                    className={`w-9 h-5 rounded-full transition-colors relative p-0.5 cursor-pointer ${
                      screenStreamActive ? 'bg-emerald-500' : 'bg-neutral-700'
                    }`}
                  >
                    <div className={`w-4 h-4 rounded-full bg-white transition-transform ${screenStreamActive ? 'translate-x-4' : 'translate-x-0'}`} />
                  </button>
                </div>
                <div className="flex items-center justify-between bg-[#161b22] px-3 py-2 rounded-xl border border-white/10">
                  <span className="text-neutral-300 font-medium">Network Latency</span>
                  <div className="flex items-center gap-1 text-emerald-400 font-mono font-bold">
                    <Radio className="w-3.5 h-3.5" /> 12ms
                  </div>
                </div>
              </div>
            </div>

            {/* DYNAMIC TRAFFIC LOGS */}
            <div className="flex-1 flex flex-col mt-4 border border-white/10 rounded-xl overflow-hidden bg-[#090a0f]">
              <div className="px-4 py-2 border-b border-white/5 flex items-center justify-between bg-black/40">
                <div className="flex items-center gap-2 text-[10px] font-mono text-neutral-400 uppercase tracking-widest">
                  <Terminal className="w-3 h-3 text-emerald-500" />
                  Agent Traffic Monitor
                </div>
                <div className="flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
                  <span className="text-[9px] font-mono text-emerald-500 uppercase tracking-widest">Live</span>
                </div>
              </div>
              <div className="flex-1 p-4 font-mono text-[10px] space-y-1.5 max-h-64 overflow-y-auto text-emerald-400/80 custom-scrollbar">
                {trafficLogs.map((log, idx) => (
                  <div key={idx} className="flex items-start gap-3 opacity-90 hover:opacity-100 transition-opacity">
                    <span className="text-emerald-700/70 whitespace-nowrap">[{log.time}]</span>
                    <span className={`whitespace-nowrap ${
                      log.type === 'success' ? 'text-cyan-400' : log.type === 'warn' ? 'text-amber-400' : 'text-purple-400'
                    }`}>
                      [{log.type.toUpperCase()}]
                    </span>
                    <span className="leading-relaxed text-emerald-300">{log.msg}</span>
                  </div>
                ))}
                <div className="flex items-center gap-2 pt-2 animate-pulse">
                  <span className="w-1.5 h-3 bg-emerald-500"></span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
