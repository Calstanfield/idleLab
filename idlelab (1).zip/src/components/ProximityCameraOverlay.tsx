import React, { useEffect, useRef, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Video, VideoOff, Mic, MicOff, Hand, Users, Sparkles, X } from 'lucide-react';
import { UserState } from '../types';
import { audioManager } from '../lib/audioManager';

interface ProximityCameraOverlayProps {
  currentUser: UserState | null;
  proximityUser: UserState | null;
  distance: number;
  isMuted: boolean;
  isCameraOn: boolean;
  remoteVideoStream?: MediaStream | null;
  onToggleMic: () => void;
  onToggleCamera: () => void;
  onSendChat?: (text: string) => void;
  onClose?: () => void;
}

export const ProximityCameraOverlay: React.FC<ProximityCameraOverlayProps> = ({
  currentUser,
  proximityUser,
  distance,
  isMuted,
  isCameraOn,
  remoteVideoStream,
  onToggleMic,
  onToggleCamera,
  onSendChat,
  onClose,
}) => {
  const localVideoRef = useRef<HTMLVideoElement | null>(null);
  const remoteVideoRef = useRef<HTMLVideoElement | null>(null);
  const [isMinimized, setIsMinimized] = useState(false);

  useEffect(() => {
    if (remoteVideoRef.current) {
      if (remoteVideoStream) {
        remoteVideoRef.current.srcObject = remoteVideoStream;
        remoteVideoRef.current.play().catch(() => {});
      } else {
        remoteVideoRef.current.srcObject = null;
      }
    }
  }, [remoteVideoStream]);

  useEffect(() => {
    // Attach video stream whenever local camera changes or video stream updates
    const handleVideoUpdate = (stream: MediaStream | null, vidEl: HTMLVideoElement | null) => {
      if (localVideoRef.current) {
        if (stream) {
          localVideoRef.current.srcObject = stream;
          localVideoRef.current.play().catch(() => {});
        } else if (vidEl && vidEl.srcObject) {
          localVideoRef.current.srcObject = vidEl.srcObject;
          localVideoRef.current.play().catch(() => {});
        } else {
          localVideoRef.current.srcObject = null;
        }
      }
    };

    audioManager.onVideoStreamUpdated = handleVideoUpdate;

    // Initial check
    if (isCameraOn) {
      audioManager.enableCamera();
    }

    return () => {
      // Restore default handler
      audioManager.onVideoStreamUpdated = undefined;
    };
  }, [isCameraOn]);

  if (!proximityUser) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0, y: -20, scale: 0.95 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        exit={{ opacity: 0, y: -20, scale: 0.95 }}
        transition={{ type: 'spring', damping: 25, stiffness: 300 }}
        className="fixed top-4 left-1/2 -translate-x-1/2 z-50 w-[95vw] max-w-2xl bg-slate-900/95 border border-sky-500/40 rounded-2xl shadow-2xl backdrop-blur-2xl text-slate-100 overflow-hidden pointer-events-auto"
      >
        {/* Banner Header */}
        <div className="flex items-center justify-between px-4 py-2.5 bg-gradient-to-r from-sky-950/80 via-indigo-950/80 to-slate-900/90 border-b border-sky-500/20">
          <div className="flex items-center space-x-2.5">
            <span className="relative flex h-3 w-3">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-3 w-3 bg-emerald-500"></span>
            </span>
            <div className="flex items-center space-x-2">
              <span className="text-xs font-bold uppercase tracking-wider text-sky-400 flex items-center gap-1">
                <Sparkles className="w-3.5 h-3.5" /> Face-to-Face Proximity Cam
              </span>
              <span className="px-2 py-0.5 text-[11px] font-mono bg-sky-500/20 text-sky-300 border border-sky-500/30 rounded-full">
                {distance.toFixed(1)}m away
              </span>
            </div>
          </div>

          <div className="flex items-center space-x-1.5">
            <button
              onClick={() => setIsMinimized(!isMinimized)}
              className="px-2 py-1 text-xs bg-slate-800/80 hover:bg-slate-700 text-slate-300 rounded-lg transition-colors cursor-pointer"
            >
              {isMinimized ? 'Expand' : 'Minimize'}
            </button>
            {onClose && (
              <button
                onClick={onClose}
                className="p-1 hover:bg-slate-800 text-slate-400 hover:text-white rounded-lg transition-colors cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>

        {!isMinimized && (
          <div className="p-3 sm:p-4 space-y-3">
            {/* Split Screen Video Windows */}
            <div className="grid grid-cols-2 gap-3 aspect-[16/9] sm:aspect-[2/1] max-h-[220px]">
              {/* Left Pane: Local Participant */}
              <div className="relative rounded-xl overflow-hidden bg-slate-950 border border-slate-800 flex flex-col items-center justify-center group shadow-inner">
                {isCameraOn ? (
                  <video
                    ref={localVideoRef}
                    autoPlay
                    playsInline
                    muted
                    className="w-full h-full object-cover transform -scale-x-100"
                  />
                ) : (
                  <div className="flex flex-col items-center justify-center p-3 text-center space-y-2">
                    <div className="w-14 h-14 rounded-full bg-slate-800 border-2 border-sky-500/40 flex items-center justify-center text-2xl shadow-lg">
                      👤
                    </div>
                    <div>
                      <p className="text-xs font-semibold text-slate-200">{currentUser?.name || 'You'}</p>
                      <p className="text-[10px] text-slate-400">Webcam Disabled</p>
                    </div>
                    <button
                      onClick={onToggleCamera}
                      className="px-2.5 py-1 text-[11px] font-medium bg-sky-600 hover:bg-sky-500 text-white rounded-lg shadow transition-all cursor-pointer flex items-center gap-1"
                    >
                      <Video className="w-3 h-3" /> Turn On Cam
                    </button>
                  </div>
                )}

                {/* Local Label Badge */}
                <div className="absolute bottom-2 left-2 px-2 py-0.5 bg-slate-900/80 backdrop-blur-md rounded-md text-[10px] font-medium text-slate-200 border border-slate-700/60 flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-sky-400" />
                  <span>{currentUser?.name || 'You'} (You)</span>
                </div>
              </div>

              {/* Right Pane: Proximity Partner */}
              <div className="relative rounded-xl overflow-hidden bg-slate-950 border border-slate-800 flex flex-col items-center justify-center group shadow-inner">
                {remoteVideoStream ? (
                  <video
                    ref={remoteVideoRef}
                    autoPlay
                    playsInline
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="flex flex-col items-center justify-center p-3 text-center space-y-2">
                    <div className="w-14 h-14 rounded-full bg-slate-800 border-2 border-emerald-500/50 flex items-center justify-center text-2xl shadow-lg relative">
                      🤝
                      {proximityUser.isSpeaking && (
                        <span className="absolute -top-1 -right-1 w-4 h-4 bg-emerald-500 rounded-full border-2 border-slate-900 animate-ping" />
                      )}
                    </div>
                    <div>
                      <p className="text-xs font-bold text-slate-100 flex items-center justify-center gap-1">
                        {proximityUser.name}
                      </p>
                      <p className="text-[10px] text-emerald-400 font-mono">
                        {proximityUser.department || 'Colleague'}
                      </p>
                    </div>
                    {proximityUser.statusText && (
                      <p className="text-[10px] text-slate-400 italic line-clamp-1 max-w-[140px]">
                        "{proximityUser.statusText}"
                      </p>
                    )}
                  </div>
                )}

                {/* Remote Label Badge */}
                <div className="absolute bottom-2 left-2 px-2 py-0.5 bg-slate-900/80 backdrop-blur-md rounded-md text-[10px] font-medium text-slate-200 border border-slate-700/60 flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                  <span>{proximityUser.name}</span>
                </div>
              </div>
            </div>

            {/* Quick Action Bar */}
            <div className="flex items-center justify-between pt-1 border-t border-slate-800/80">
              <div className="flex items-center space-x-2">
                <button
                  onClick={onToggleMic}
                  className={`px-3 py-1.5 rounded-xl border text-xs font-medium transition-all cursor-pointer flex items-center gap-1.5 ${
                    isMuted
                      ? 'bg-rose-500/10 text-rose-400 border-rose-500/30 hover:bg-rose-500/20'
                      : 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30 hover:bg-emerald-500/20'
                  }`}
                >
                  {isMuted ? <MicOff className="w-3.5 h-3.5" /> : <Mic className="w-3.5 h-3.5" />}
                  <span>{isMuted ? 'Unmute' : 'Muted'}</span>
                </button>

                <button
                  onClick={onToggleCamera}
                  className={`px-3 py-1.5 rounded-xl border text-xs font-medium transition-all cursor-pointer flex items-center gap-1.5 ${
                    isCameraOn
                      ? 'bg-sky-500/10 text-sky-400 border-sky-500/30 hover:bg-sky-500/20'
                      : 'bg-slate-800 text-slate-400 border-slate-700 hover:bg-slate-700 hover:text-slate-200'
                  }`}
                >
                  {isCameraOn ? <Video className="w-3.5 h-3.5" /> : <VideoOff className="w-3.5 h-3.5" />}
                  <span>{isCameraOn ? 'Cam On' : 'Cam Off'}</span>
                </button>
              </div>

              {onSendChat && (
                <button
                  onClick={() => onSendChat(`👋 Hi ${proximityUser.name}!`)}
                  className="px-3 py-1.5 bg-indigo-600/30 hover:bg-indigo-600/50 text-indigo-200 border border-indigo-500/30 rounded-xl text-xs font-medium transition-all cursor-pointer flex items-center gap-1.5 active:scale-95"
                >
                  <Hand className="w-3.5 h-3.5 text-indigo-400" />
                  <span>Say Hi 👋</span>
                </button>
              )}
            </div>
          </div>
        )}
      </motion.div>
    </AnimatePresence>
  );
};
