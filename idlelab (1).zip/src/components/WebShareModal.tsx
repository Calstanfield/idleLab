import React, { useState } from 'react';
import {
  X,
  Copy,
  Check,
  Globe,
  Sparkles,
  ShieldCheck,
  Radio,
  ExternalLink,
} from 'lucide-react';

interface WebShareModalProps {
  isOpen: boolean;
  onClose: () => void;
  onlineCount: number;
  roomName?: string;
}

export const WebShareModal: React.FC<WebShareModalProps> = ({
  isOpen,
  onClose,
  onlineCount,
  roomName = 'IdleLab',
}) => {
  const [copiedLink, setCopiedLink] = useState(false);

  if (!isOpen) return null;

  // Canonical US-Global region endpoint configuration
  const baseUrl = typeof window !== 'undefined' ? window.location.origin : 'https://idlelab.dev';
  const canonicalUrl = `${baseUrl}?region=us-global&room=${encodeURIComponent(roomName.toLowerCase().replace(/\s+/g, '-'))}`;

  const handleCopyLink = async () => {
    try {
      await navigator.clipboard.writeText(canonicalUrl);
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 2500);
    } catch (e) {
      console.error('Failed to copy workspace link', e);
    }
  };

  const handleOpenLink = () => {
    window.open(canonicalUrl, '_blank', 'noopener,noreferrer');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-md p-4 animate-fadeIn">
      <div className="relative w-full max-w-md bg-slate-900/95 border border-white/10 rounded-2xl shadow-2xl overflow-hidden text-slate-100 flex flex-col">
        {/* Top Header */}
        <div className="p-5 border-b border-white/10 flex items-center justify-between bg-slate-950/50">
          <div className="flex items-center space-x-2.5">
            <div className="p-2 rounded-xl bg-indigo-500/10 border border-indigo-500/20 text-indigo-400">
              <Globe className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white tracking-tight">Share Workspace</h2>
              <p className="text-[11px] text-slate-400">US-Global High-Speed Collaboration Endpoint</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-xl bg-white/5 hover:bg-white/10 text-slate-400 hover:text-white border border-white/10 transition-all cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-5 space-y-4">
          {/* Region Status & Online Counter */}
          <div className="flex items-center justify-between p-3 rounded-xl bg-slate-950/60 border border-white/5 text-xs">
            <div className="flex items-center space-x-2">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <span className="font-mono text-[11px] text-slate-300">Cluster: US-Global (Primary)</span>
            </div>
            <span className="px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 font-mono text-[10px] font-semibold">
              {onlineCount} Online
            </span>
          </div>

          {/* Canonical Endpoint URL Box */}
          <div className="space-y-1.5">
            <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400">
              Canonical Workspace Endpoint
            </label>
            <div className="relative">
              <input
                type="text"
                readOnly
                value={canonicalUrl}
                className="w-full pl-3 pr-10 py-2.5 bg-slate-950/80 border border-white/10 rounded-xl text-indigo-300 font-mono text-xs select-all focus:outline-none focus:border-indigo-400"
              />
              <button
                onClick={handleOpenLink}
                title="Open in new tab"
                className="absolute right-2.5 top-2.5 text-slate-400 hover:text-white transition-colors cursor-pointer"
              >
                <ExternalLink className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Single Clean "Copy Workspace Link" Button */}
          <button
            type="button"
            onClick={handleCopyLink}
            className={`w-full py-3.5 px-5 rounded-xl font-bold text-sm transition-all shadow-lg flex items-center justify-center space-x-2 cursor-pointer ${
              copiedLink
                ? 'bg-emerald-500 text-slate-950 font-black shadow-emerald-500/20 scale-[0.99]'
                : 'bg-gradient-to-r from-indigo-500 via-indigo-600 to-sky-500 hover:from-indigo-400 hover:to-sky-400 text-white shadow-indigo-600/30 active:scale-[0.99]'
            }`}
          >
            {copiedLink ? (
              <>
                <Check className="w-4 h-4 stroke-[3]" />
                <span>Link Copied to Clipboard!</span>
              </>
            ) : (
              <>
                <Copy className="w-4 h-4" />
                <span>Copy Workspace Link</span>
              </>
            )}
          </button>

          {/* Security & Access Notice */}
          <div className="flex items-center space-x-2 text-[11px] text-slate-400 justify-center pt-1">
            <ShieldCheck className="w-3.5 h-3.5 text-indigo-400" />
            <span>Instant guest access • End-to-end WebRTC audio</span>
          </div>
        </div>

        {/* Footer */}
        <div className="px-5 py-3 bg-slate-950/50 border-t border-white/10 flex items-center justify-between text-xs text-slate-400">
          <div className="flex items-center space-x-1.5 text-[11px]">
            <Radio className="w-3 h-3 text-indigo-400" />
            <span>IdleLab Mesh v9.0</span>
          </div>
          <button
            onClick={onClose}
            className="px-3 py-1 rounded-lg bg-white/5 hover:bg-white/10 text-slate-300 hover:text-white border border-white/10 font-semibold cursor-pointer transition-colors"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};

