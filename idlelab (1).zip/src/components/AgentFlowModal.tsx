import React, { useState, useEffect, useRef } from 'react';
import ReactMarkdown from 'react-markdown';
import { t } from '../lib/i18n';
import {
  X,
  Send,
  Sliders,
  AtSign,
  ChevronDown,
  Terminal,
  CheckSquare,
  Plus,
  Trash2,
  Award,
  Star,
  CheckCircle,
  Paperclip,
  FileText,
  Sparkles,
  Volume2,
  VolumeX,
} from 'lucide-react';
import { chloeVoice } from '../lib/chloeVoice';
import { UserState } from '../types';
import { systemLogger } from '../lib/logger';
import { SystemLogsModal } from './SystemLogsModal';

interface AgentFlowModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser?: UserState | null;
}

interface PersonaCategory {
  id: string;
  nameKey: string;
  subtitleKey: string;
  icon: string;
}

const PERSONA_CATEGORIES: PersonaCategory[] = [
  { id: 'remote', nameKey: 'remote_work', subtitleKey: 'remote_subtitle', icon: '💻' },
  { id: 'academic', nameKey: 'academic_research', subtitleKey: 'academic_subtitle', icon: '📚' },
  { id: 'content', nameKey: 'content_creation', subtitleKey: 'content_subtitle', icon: '✍️' },
  { id: 'forum', nameKey: 'forum_moderation', subtitleKey: 'forum_subtitle', icon: '🛡️' },
  { id: 'business', nameKey: 'small_business', subtitleKey: 'small_business_subtitle', icon: '📊' },
  { id: 'streaming', nameKey: 'live_streaming', subtitleKey: 'live_streaming_subtitle', icon: '🎙️' },
];

export function AgentFlowModal({ isOpen, onClose, currentUser }: AgentFlowModalProps) {
  const displayName = currentUser?.name || 'Colleague';
  const [selectedPersona, setSelectedPersona] = useState<string>('remote');
  const [activeTab, setActiveTab] = useState<'Agents' | 'Tasks' | 'XP & Level'>('Agents');
  const [chatInput, setChatInput] = useState<string>('');
  const [attachedDoc, setAttachedDoc] = useState<{ name: string; content: string } | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string || '';
      setAttachedDoc({ name: file.name, content });
      systemLogger.addLog('success', 'DocumentUpload', `Attached document "${file.name}" (${content.length} chars). Ready for Chloe across sessions.`);
    };
    reader.readAsText(file);
    e.target.value = '';
  };
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [showLogsModal, setShowLogsModal] = useState<boolean>(false);
  const [isVoiceMuted, setIsVoiceMuted] = useState<boolean>(() => chloeVoice.isMuted());
  const [isChloeEnabledState, setIsChloeEnabledState] = useState<boolean>(() => chloeVoice.isChloeEnabled());
  const [chloeLang, setChloeLang] = useState<string>(localStorage.getItem('chloe_lang') || 'en-US');

  const toggleChloeVoiceMute = () => {
    const nextMuted = !isVoiceMuted;
    chloeVoice.setMuted(nextMuted);
    setIsVoiceMuted(nextMuted);
  };

  const toggleChloeEnabled = () => {
    const nextEnabled = !isChloeEnabledState;
    chloeVoice.setChloeEnabled(nextEnabled);
    setIsChloeEnabledState(nextEnabled);
  };

  useEffect(() => {
    const handleLangChange = (e: any) => {
      if (e.detail?.lang) {
        setChloeLang(e.detail.lang);
      }
    };
    window.addEventListener('chloe-language-change', handleLangChange as EventListener);
    return () => {
      window.removeEventListener('chloe-language-change', handleLangChange as EventListener);
    };
  }, []);

  const [messages, setMessages] = useState<Array<{ sender: 'user' | 'ai'; text: string; time: string; agent?: string; translationKey?: string; translationParams?: any }>>([
    {
      sender: 'ai',
      agent: 'Chloe Becker',
      text: t('chloe_initial_greeting', chloeLang, { name: displayName }),
      translationKey: 'chloe_initial_greeting',
      translationParams: { name: displayName },
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    },
  ]);

  useEffect(() => {
    setMessages(prev => prev.map(msg => {
      if (msg.translationKey) {
        return {
          ...msg,
          text: t(msg.translationKey, chloeLang, msg.translationParams || { name: displayName })
        };
      }
      return msg;
    }));
  }, [chloeLang, displayName]);

  // Checklist & Plan manager state
  const [savedPlan, setSavedPlan] = useState<Array<{ id: string; text: string; done: boolean }>>(() => {
    try {
      const saved = localStorage.getItem('idlelab_saved_plan');
      if (saved) return JSON.parse(saved);
    } catch {}
    return [
      { id: '1', text: 'Coordinate team multi-agent architecture sync', done: true },
      { id: '2', text: 'Review department compliance and security audit', done: false },
      { id: '3', text: 'Deploy optimized production bundle with esbuild', done: false },
    ];
  });
  const [newTaskText, setNewTaskText] = useState<string>('');

  // XP & Level state
  const [userXp, setUserXp] = useState<number>(() => {
    try {
      const saved = localStorage.getItem('idlelab_user_xp');
      return saved ? parseInt(saved, 10) : 280;
    } catch {
      return 280;
    }
  });

  // Inspector states
  const [voiceTone, setVoiceTone] = useState<number>(0);
  const [autoSummarize, setAutoSummarize] = useState<boolean>(true);
  const [chloePersona, setChloePersona] = useState<string>(localStorage.getItem('chloe_voice_persona') || 'soft_pro_female');
  const [scheduleScan, setScheduleScan] = useState<boolean>(true);
  const [sentimentWatch, setSentimentWatch] = useState<boolean>(false);
  const [autoClip, setAutoClip] = useState<boolean>(false);
  const [temperature, setTemperature] = useState<number>(0.70);
  const [contextWindow, setContextWindow] = useState<string>('32k');
  const [activeModel, setActiveModel] = useState<string>('gemini-2.5-pro');

  // Agent cards states
  const [agentsState] = useState([
    { id: 'scheduler', name: 'Scheduler', role: 'Calendar & Tasks', status: 'Active', statusColor: 'bg-emerald-400', progress: 72, task: 'Parsing meeting transcripts', model: 'gemini-2.5-flash' },
    { id: 'writer', name: 'Writer', role: 'Async Communication', status: 'Processing', statusColor: 'bg-blue-400', progress: 38, task: 'Drafting weekly update email', model: 'gemini-2.5-pro' },
    { id: 'summarizer', name: 'Summarizer', role: 'Document Digest', status: 'Standby', statusColor: 'bg-neutral-500', progress: 0, task: 'Document Digest', model: 'gemini-2.5-flash' }
  ]);

  if (!isOpen) return null;

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if ((!chatInput.trim() && !attachedDoc) || isLoading) return;

    const userMsg = chatInput.trim() || `[Uploaded Document: ${attachedDoc?.name}]`;
    const finalPrompt = attachedDoc ? `${userMsg}\n\n[Attached Document Content (${attachedDoc.name})]:\n${attachedDoc.content}` : userMsg;
    const timeStr = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

    setMessages((prev) => [
      ...prev,
      { sender: 'user', text: attachedDoc ? `${userMsg} (📎 ${attachedDoc.name})` : userMsg, time: timeStr },
    ]);
    setChatInput('');
    setAttachedDoc(null);
    setIsLoading(true);

    try {
      systemLogger.addLog('info', 'Orchestrator', `Sending prompt to Chloe orchestrator: "${finalPrompt.substring(0, 50)}..."`);
      const res = await fetch('/api/chloe/orchestrator', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: finalPrompt,
          userName: displayName,
          pillar: selectedPersona === 'remote' ? 'report_audit' : 'tech_architecture',
          backgroundTasks: {
            autoSummarize,
            scheduleScan,
            sentimentWatch,
            autoClip,
          },
        }),
      });

      const data = await res.json();
      const replyTime = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

      if (
        data.action === 'quota_exhausted' ||
        res.status === 429 ||
        (data.error && (data.error.includes('429') || data.error.includes('RESOURCE_EXHAUSTED') || data.error.includes('quota')))
      ) {
        const quotaNotice = t('chloe_quota_notice', chloeLang, { name: displayName });
        setMessages((prev) => [
          ...prev,
          {
            sender: 'ai',
            agent: 'Orchestrator',
            text: quotaNotice,
            translationKey: 'chloe_quota_notice',
            translationParams: { name: displayName },
            time: replyTime,
          },
        ]);
        chloeVoice.speak(quotaNotice, 'quota_notice');
        systemLogger.addLog('warn', 'Quota', 'Gemini API quota exhausted (429), activated fallback notice.');
        return;
      }

      // Award XP for effective prompting (+50 XP)
      const newXp = userXp + 50;
      setUserXp(newXp);
      localStorage.setItem('idlelab_user_xp', String(newXp));
      systemLogger.addLog('success', 'Orchestrator', `Prompt successfully evaluated. Awarded +50 XP (Total: ${newXp} XP).`);

      // Merge generated checklist items if any
      if (data.checklistItems && Array.isArray(data.checklistItems)) {
        const newItems = data.checklistItems.map((item: any, idx: number) => ({
          id: `item_${Date.now()}_${idx}`,
          text: item.text,
          done: Boolean(item.done),
        }));
        setSavedPlan((prev) => [...prev, ...newItems]);
      }

      const personaReplyKeyMap: Record<string, string> = {
        remote: 'chloe_reply_remote',
        academic: 'chloe_reply_academic',
        content: 'chloe_reply_content',
        forum: 'chloe_reply_forum',
        business: 'chloe_reply_business',
        streaming: 'chloe_reply_streaming',
      };
      const replyKey = personaReplyKeyMap[selectedPersona] || 'chloe_reply_remote';

      if (data && (data.text || data.speech)) {
        const translatedText = t(replyKey, chloeLang, { name: displayName });
        setMessages((prev) => [
          ...prev,
          {
            sender: 'ai',
            agent: data.activeSubAgent || 'Orchestrator',
            text: translatedText,
            translationKey: replyKey,
            translationParams: { name: displayName },
            time: replyTime,
          },
        ]);
        if (data.speech) {
          chloeVoice.speak(data.speech, 'chloe_dashboard_reply');
        }
      } else {
        const personaName = t(currentPersonaObj.nameKey, chloeLang);
        const pipelineText = t('chloe_pipeline_exec', chloeLang, { mode: personaName });
        setMessages((prev) => [
          ...prev,
          {
            sender: 'ai',
            agent: 'Orchestrator',
            text: pipelineText,
            translationKey: 'chloe_pipeline_exec',
            translationParams: { mode: personaName },
            time: replyTime,
          },
        ]);
      }
    } catch (err: any) {
      const replyTime = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
      const errStr = String(err?.message || err);
      systemLogger.addLog('error', 'OrchestratorFetch', `Failed to query orchestrator: ${errStr}`);

      if (errStr.includes('429') || errStr.includes('RESOURCE_EXHAUSTED') || errStr.includes('quota')) {
        const quotaNotice = t('chloe_quota_notice', chloeLang, { name: displayName });
        setMessages((prev) => [
          ...prev,
          {
            sender: 'ai',
            agent: 'Orchestrator',
            text: quotaNotice,
            translationKey: 'chloe_quota_notice',
            translationParams: { name: displayName },
            time: replyTime,
          },
        ]);
        chloeVoice.speak(quotaNotice, 'quota_notice');
      } else {
        const personaName = t(currentPersonaObj.nameKey, chloeLang);
        const pipelineText = t('chloe_pipeline_exec', chloeLang, { mode: personaName });
        setMessages((prev) => [
          ...prev,
          {
            sender: 'ai',
            agent: 'Orchestrator',
            text: pipelineText,
            translationKey: 'chloe_pipeline_exec',
            translationParams: { mode: personaName },
            time: replyTime,
          },
        ]);
      }
    } finally {
      setIsLoading(false);
    }
  };

  const handleSavePlan = () => {
    localStorage.setItem('idlelab_saved_plan', JSON.stringify(savedPlan));
    systemLogger.addLog('success', 'PlanManager', 'Plan checklist saved and persisted successfully.');
    alert('Plan successfully saved!');
  };

  const currentPersonaObj = PERSONA_CATEGORIES.find((p) => p.id === selectedPersona) || PERSONA_CATEGORIES[0];
  const currentLevel = Math.floor(userXp / 200) + 1;
  const xpIntoLevel = userXp % 200;
  const xpProgressPercent = Math.min(100, (xpIntoLevel / 200) * 100);

  return (
    <>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/85 backdrop-blur-xl animate-in fade-in duration-200">
        <div className="w-full max-w-[1400px] h-[92vh] bg-[#0d1117] border border-white/15 rounded-2xl shadow-[0_25px_100px_rgba(0,0,0,0.95)] flex flex-col overflow-hidden text-neutral-200 font-sans">
          
          {/* WINDOW TITLE BAR */}
          <div className="h-11 bg-[#161b22] border-b border-white/10 px-4 flex items-center justify-between shrink-0 select-none">
            <div className="flex items-center space-x-2">
              {/* macOS Traffic Lights */}
              <div className="flex items-center space-x-1.5 mr-3">
                <button onClick={onClose} className="w-3 h-3 rounded-full bg-rose-500 hover:opacity-80 transition-opacity cursor-pointer" />
                <div className="w-3 h-3 rounded-full bg-amber-500" />
                <div className="w-3 h-3 rounded-full bg-emerald-500" />
              </div>
              <div className="flex items-center space-x-1.5">
                <span className="font-bold text-sm text-white tracking-wide">{t('workspace_title', chloeLang)}</span>
              </div>
              <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-semibold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse mr-1.5" />
                {t('live', chloeLang)}
              </span>
            </div>

            <div className="flex items-center space-x-3">
              {/* Chloe On/Off Toggle */}
              <button
                onClick={toggleChloeEnabled}
                className={`p-1 rounded-lg text-xs px-2.5 transition-colors cursor-pointer flex items-center space-x-1 border ${
                  isChloeEnabledState ? 'bg-sky-500/15 text-sky-300 border-sky-500/30 hover:bg-sky-500/25' : 'bg-neutral-800 text-neutral-400 border-neutral-700 hover:text-white'
                }`}
                title={isChloeEnabledState ? 'Disable Chloe (Turn Off)' : 'Enable Chloe (Turn On)'}
              >
                <span className={`w-2 h-2 rounded-full ${isChloeEnabledState ? 'bg-sky-400 animate-pulse' : 'bg-neutral-500'}`} />
                <span className="hidden sm:inline">{isChloeEnabledState ? 'Chloe On' : 'Chloe Off'}</span>
              </button>

              {/* Voice Mute Toggle for Chloe Becker */}
              <button
                onClick={toggleChloeVoiceMute}
                className="p-1 rounded-lg text-neutral-400 hover:text-white hover:bg-white/10 transition-colors cursor-pointer flex items-center space-x-1 text-xs px-2"
                title={isVoiceMuted ? 'Unmute Chloe Voice' : 'Mute Chloe Voice'}
              >
                {isVoiceMuted ? <VolumeX className="w-4 h-4 text-rose-400" /> : <Volume2 className="w-4 h-4 text-emerald-400" />}
                <span className="hidden sm:inline">{isVoiceMuted ? 'Muted' : 'Voice'}</span>
              </button>

              {/* Logs / Terminal button (Selector 7 target) */}
              <button
                onClick={() => setShowLogsModal(true)}
                className="p-1 rounded-lg text-neutral-400 hover:text-white hover:bg-white/10 transition-colors cursor-pointer flex items-center space-x-1 text-xs px-2"
                title="View IdleLab System & Error Logs"
              >
                <Terminal className="w-4 h-4 text-emerald-400" />
                <span className="hidden sm:inline">{t('logs', chloeLang)}</span>
              </button>
              <button
                onClick={onClose}
                className="p-1 rounded-lg text-neutral-400 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* MAIN WORKSPACE BODY */}
          <div className="grid grid-cols-1 md:grid-cols-12 flex-1 min-h-0 bg-[#090d16]">
            
            {/* LEFT SIDEBAR: PERSONA (3 cols) */}
            <div className="md:col-span-3 border-r border-white/10 bg-[#0d1117] flex flex-col overflow-hidden">
              <div className="px-4 py-3 border-b border-white/10 flex items-center justify-between text-xs font-semibold text-neutral-400 uppercase tracking-wider">
                <span>{t('persona', chloeLang)}</span>
                <button className="text-neutral-500 hover:text-white transition-colors cursor-pointer">
                  <Sliders className="w-3.5 h-3.5" />
                </button>
              </div>

              <div className="flex-1 overflow-y-auto p-2 space-y-1">
                {PERSONA_CATEGORIES.map((cat) => {
                  const isSelected = cat.id === selectedPersona;
                  const catName = t(cat.nameKey, chloeLang);
                  const catSubtitle = t(cat.subtitleKey, chloeLang);
                  return (
                    <div
                      key={cat.id}
                      onClick={() => setSelectedPersona(cat.id)}
                      className={`p-3 rounded-xl cursor-pointer transition-all ${
                        isSelected
                          ? 'bg-white/10 border border-white/15 text-white shadow-md'
                          : 'hover:bg-white/5 text-neutral-400 hover:text-neutral-200 border border-transparent'
                      }`}
                    >
                      <div className="flex items-center space-x-2.5 mb-1">
                        <span className="text-base">{cat.icon}</span>
                        <span className="font-semibold text-sm text-white">{catName}</span>
                      </div>
                      <div className="text-[11px] text-neutral-400 leading-tight pl-7">{catSubtitle}</div>
                    </div>
                  );
                })}
              </div>

              {/* Bottom User Workspace */}
              <div className="p-3 border-t border-white/10 bg-[#161b22]/50 flex items-center justify-between shrink-0">
                <div className="flex items-center space-x-2.5">
                  <div className="w-8 h-8 rounded-full bg-blue-600 font-bold text-white flex items-center justify-center text-xs">
                    U
                  </div>
                  <div>
                    <div className="font-semibold text-xs text-white">{displayName}</div>
                    <div className="text-[10px] text-emerald-400 font-medium">Level {currentLevel} · {userXp} XP</div>
                  </div>
                </div>
              </div>
            </div>

            {/* CENTER PANEL: AGENT CHAT & CARDS (6 cols) */}
            <div className="md:col-span-6 border-r border-white/10 flex flex-col min-h-0 bg-[#090d16]">
              
              {/* Top Workspace Bar */}
              <div className="px-6 py-3.5 border-b border-white/10 flex items-center justify-between bg-[#0d1117]/60 shrink-0">
                <div>
                  <div className="font-bold text-sm text-white flex items-center space-x-2">
                    <span>{t(currentPersonaObj.nameKey, chloeLang)}</span>
                    <span className="text-neutral-500 font-normal">·</span>
                    <span className="text-xs text-neutral-400 font-normal">{t(currentPersonaObj.subtitleKey, chloeLang)}</span>
                  </div>
                </div>

                {/* Tabs & Voice Mute */}
                <div className="flex items-center space-x-2">
                  <button
                    onClick={toggleChloeVoiceMute}
                    className={`px-2.5 py-1 rounded-lg text-xs font-semibold flex items-center space-x-1.5 transition-colors cursor-pointer border ${
                      isVoiceMuted
                        ? 'bg-rose-500/20 text-rose-400 border-rose-500/40 hover:bg-rose-500/30'
                        : 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30 hover:bg-emerald-500/25'
                    }`}
                    title={isVoiceMuted ? 'Unmute Chloe Voice' : 'Mute Chloe Voice'}
                  >
                    {isVoiceMuted ? <VolumeX className="w-3.5 h-3.5" /> : <Volume2 className="w-3.5 h-3.5" />}
                    <span>{isVoiceMuted ? 'Muted' : 'Voice'}</span>
                  </button>

                  <div className="flex items-center bg-[#161b22] border border-white/10 rounded-lg p-1 text-xs font-medium">
                    {[
                      { key: 'Agents', label: t('tabs_agents', chloeLang) },
                      { key: 'Tasks', label: t('tabs_tasks', chloeLang) },
                      { key: 'XP & Level', label: t('tabs_xp', chloeLang) },
                    ].map((tab) => (
                      <button
                        key={tab.key}
                        onClick={() => setActiveTab(tab.key as any)}
                        className={`px-3 py-1 rounded-md transition-colors cursor-pointer ${
                          activeTab === tab.key ? 'bg-white/15 text-white shadow' : 'text-neutral-400 hover:text-neutral-200'
                        }`}
                      >
                        {tab.label}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* TAB CONTENT SWITCHER */}
              {activeTab === 'Agents' && (
                <>
                  {/* Chat History & Stream */}
                  <div className="flex-1 overflow-y-auto p-6 space-y-4">
                    {messages.map((msg, idx) => {
                      if (msg.sender === 'user') {
                        return (
                          <div key={idx} className="flex flex-col items-end space-y-1">
                            <div className="max-w-[85%] bg-sky-600 text-white px-4 py-3 rounded-2xl rounded-tr-sm shadow-lg text-sm font-normal">
                              <div className="leading-relaxed">
                                <ReactMarkdown
                                  components={{
                                    strong: ({ children }) => <strong className="font-bold text-white underline decoration-white/40">{children}</strong>,
                                    b: ({ children }) => <strong className="font-bold text-white underline decoration-white/40">{children}</strong>,
                                    p: ({ children }) => <p className="mb-1 last:mb-0 leading-relaxed">{children}</p>,
                                  }}
                                >
                                  {msg.text}
                                </ReactMarkdown>
                              </div>
                            </div>
                            <span className="text-[10px] text-neutral-500 pr-1">{msg.time}</span>
                          </div>
                        );
                      } else {
                        return (
                          <div key={idx} className="flex flex-col items-start space-y-1">
                            <div className="flex items-center space-x-2 mb-0.5">
                              <div className="w-6 h-6 rounded-full bg-blue-600 flex items-center justify-center font-bold text-[10px] text-white">
                                AI
                              </div>
                              <span className="text-xs font-semibold text-neutral-300">{msg.agent || 'Orchestrator'}</span>
                            </div>
                            <div className="max-w-[85%] bg-[#161b22] border border-white/15 text-neutral-200 px-4 py-3 rounded-2xl rounded-tl-sm shadow-xl text-sm leading-relaxed">
                              <div className="leading-relaxed space-y-1.5">
                                <ReactMarkdown
                                  components={{
                                    strong: ({ children }) => (
                                      <strong className="font-bold text-white bg-white/10 px-1 py-0.5 rounded border border-white/10 mx-0.5">
                                        {children}
                                      </strong>
                                    ),
                                    b: ({ children }) => (
                                      <strong className="font-bold text-white bg-white/10 px-1 py-0.5 rounded border border-white/10 mx-0.5">
                                        {children}
                                      </strong>
                                    ),
                                    em: ({ children }) => <em className="italic text-sky-300">{children}</em>,
                                    p: ({ children }) => <p className="mb-2 last:mb-0 leading-relaxed">{children}</p>,
                                    ul: ({ children }) => <ul className="list-disc pl-4 space-y-1 my-2 text-neutral-300">{children}</ul>,
                                    ol: ({ children }) => <ol className="list-decimal pl-4 space-y-1 my-2 text-neutral-300">{children}</ol>,
                                    li: ({ children }) => <li className="leading-relaxed">{children}</li>,
                                    code: ({ children }) => (
                                      <code className="bg-black/60 border border-white/10 px-1.5 py-0.5 rounded text-sky-300 font-mono text-xs">
                                        {children}
                                      </code>
                                    ),
                                  }}
                                >
                                  {msg.text}
                                </ReactMarkdown>
                              </div>
                            </div>
                            <span className="text-[10px] text-neutral-500 pl-1">{msg.time}</span>
                          </div>
                        );
                      }
                    })}
                  </div>

                  {/* Bottom Chat Input Bar */}
                  <div className="p-4 bg-[#0d1117] border-t border-white/10 shrink-0 space-y-3">
                    {/* Attached Document Preview Badge */}
                    {attachedDoc && (
                      <div className="flex items-center justify-between bg-sky-950/40 border border-sky-500/30 px-3 py-1.5 rounded-lg text-xs text-sky-200">
                        <div className="flex items-center space-x-2 truncate">
                          <FileText className="w-4 h-4 text-sky-400 shrink-0" />
                          <span className="font-medium truncate">{attachedDoc.name}</span>
                          <span className="text-[10px] text-sky-400/70">({Math.round(attachedDoc.content.length / 1024 * 10) / 10} KB)</span>
                        </div>
                        <button
                          type="button"
                          onClick={() => setAttachedDoc(null)}
                          className="text-sky-400 hover:text-white p-1 cursor-pointer"
                        >
                          <X className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    )}

                    {/* AI Studio Prompt Flow Builder Banner ("Ghost Prompt" chips) */}
                    <div className="bg-[#161b22] border border-white/10 rounded-xl p-2.5 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs">
                      <div className="flex items-center space-x-1.5 text-neutral-400">
                        <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                        <span className="text-amber-400 font-semibold">AI Studio Prompt Flow:</span>
                      </div>
                      <div className="flex items-center space-x-1.5 flex-wrap">
                        <button
                          type="button"
                          onClick={() => setChatInput(prev => `[Persona: ${t(currentPersonaObj.nameKey, chloeLang)}] ${prev}`)}
                          className="px-2.5 py-1 rounded-lg bg-white/5 hover:bg-white/10 border border-white/10 text-neutral-300 font-mono text-[11px] transition-colors cursor-pointer flex items-center space-x-1"
                        >
                          <span className="text-sky-400">[Persona]</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => setChatInput(prev => `[Context: Active Workspace Session & Tasks] ${prev}`)}
                          className="px-2.5 py-1 rounded-lg bg-white/5 hover:bg-white/10 border border-white/10 text-neutral-300 font-mono text-[11px] transition-colors cursor-pointer flex items-center space-x-1"
                        >
                          <span className="text-emerald-400">[Context]</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => setChatInput(prev => `[Action: Synthesize department workflows & analyze] ${prev}`)}
                          className="px-2.5 py-1 rounded-lg bg-white/5 hover:bg-white/10 border border-white/10 text-neutral-300 font-mono text-[11px] transition-colors cursor-pointer flex items-center space-x-1"
                        >
                          <span className="text-amber-400">[Action]</span>
                        </button>
                      </div>
                    </div>

                    <input
                      type="file"
                      ref={fileInputRef}
                      accept=".txt,.md,.json,.csv"
                      onChange={handleFileSelect}
                      className="hidden"
                    />

                    <form onSubmit={handleSendMessage} className="flex items-center space-x-2 bg-[#161b22] border border-white/15 rounded-xl px-4 py-2.5 focus-within:border-sky-500 transition-colors">
                      <button
                        type="button"
                        onClick={() => fileInputRef.current?.click()}
                        title="Attach Document (.txt, .md, .json, .csv)"
                        className="p-1.5 text-neutral-400 hover:text-sky-400 transition-colors cursor-pointer"
                      >
                        <Paperclip className="w-4 h-4" />
                      </button>
                      <input
                        type="text"
                        value={chatInput}
                        onChange={(e) => setChatInput(e.target.value)}
                        placeholder={t('chat_placeholder', chloeLang, { mode: t(currentPersonaObj.nameKey, chloeLang) })}
                        className="flex-1 bg-transparent text-sm text-white placeholder-neutral-500 focus:outline-none"
                      />
                      <button type="button" className="p-1.5 text-neutral-400 hover:text-white transition-colors cursor-pointer">
                        <AtSign className="w-4 h-4" />
                      </button>
                      <button type="button" className="p-1.5 text-neutral-400 hover:text-white transition-colors cursor-pointer">
                        <span className="font-mono text-sm font-bold">/</span>
                      </button>
                      <button
                        type="submit"
                        disabled={isLoading}
                        className="px-3 py-1.5 bg-sky-600 hover:bg-sky-500 disabled:opacity-50 text-white rounded-lg font-semibold text-xs flex items-center space-x-1.5 transition-colors cursor-pointer"
                      >
                        <span>{isLoading ? t('thinking', chloeLang) : t('send', chloeLang)}</span>
                        <Send className="w-3 h-3" />
                      </button>
                    </form>
                  </div>
                </>
              )}

              {activeTab === 'Tasks' && (
                <div className="flex-1 overflow-y-auto p-6 space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="font-bold text-white text-base">{t('checklist_manager', chloeLang)}</h3>
                      <p className="text-xs text-neutral-400">{t('checklist_desc', chloeLang)}</p>
                    </div>
                    <button
                      onClick={handleSavePlan}
                      className="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs rounded-xl shadow transition-colors cursor-pointer flex items-center space-x-1.5"
                    >
                      <CheckCircle className="w-3.5 h-3.5" />
                      <span>{t('save_plan', chloeLang)}</span>
                    </button>
                  </div>

                  {/* Add task input */}
                  <div className="flex items-center space-x-2">
                    <input
                      type="text"
                      value={newTaskText}
                      onChange={(e) => setNewTaskText(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter' && newTaskText.trim()) {
                          setNewTaskText('');
                          setSavedPlan(prev => [...prev, { id: `task_${Date.now()}`, text: newTaskText.trim(), done: false }]);
                        }
                      }}
                      placeholder={t('add_task_placeholder', chloeLang)}
                      className="flex-1 bg-[#161b22] border border-white/15 rounded-xl px-4 py-2.5 text-sm text-white placeholder-neutral-500 focus:outline-none focus:border-emerald-500"
                    />
                    <button
                      type="button"
                      onClick={() => {
                        if (!newTaskText.trim()) return;
                        setSavedPlan(prev => [...prev, { id: `task_${Date.now()}`, text: newTaskText.trim(), done: false }]);
                        setNewTaskText('');
                      }}
                      className="px-4 py-2.5 bg-sky-600 hover:bg-sky-500 text-white font-semibold text-xs rounded-xl flex items-center space-x-1 cursor-pointer"
                    >
                      <Plus className="w-4 h-4" />
                      <span>{t('add', chloeLang)}</span>
                    </button>
                  </div>

                  {/* Tasks list */}
                  <div className="space-y-2 pt-2">
                    {savedPlan.map((task) => (
                      <div
                        key={task.id}
                        className={`flex items-center justify-between p-3.5 rounded-xl border transition-all ${
                          task.done ? 'bg-[#161b22]/40 border-emerald-500/30 opacity-75' : 'bg-[#161b22] border-white/15'
                        }`}
                      >
                        <div className="flex items-center space-x-3 flex-1 mr-3">
                          <input
                            type="checkbox"
                            checked={task.done}
                            onChange={(e) => {
                              const checked = e.target.checked;
                              setSavedPlan(prev => prev.map(t => t.id === task.id ? { ...t, done: checked } : t));
                            }}
                            className="w-4 h-4 accent-emerald-500 rounded cursor-pointer"
                          />
                          <span className={`text-sm ${task.done ? 'line-through text-neutral-500' : 'text-neutral-200'}`}>
                            {task.text}
                          </span>
                        </div>
                        <button
                          onClick={() => setSavedPlan(prev => prev.filter(t => t.id !== task.id))}
                          className="p-1.5 text-neutral-500 hover:text-red-400 transition-colors cursor-pointer"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {activeTab === 'XP & Level' && (
                <div className="flex-1 overflow-y-auto p-6 space-y-6">
                  <div className="bg-gradient-to-r from-emerald-900/40 via-sky-900/30 to-indigo-900/40 border border-emerald-500/30 p-6 rounded-2xl shadow-xl flex items-center justify-between">
                    <div>
                      <div className="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-semibold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 mb-2">
                        <Award className="w-3.5 h-3.5 mr-1.5" />
                        {t('level_progress', chloeLang, { level: currentLevel })}
                      </div>
                      <h2 className="text-2xl font-bold text-white mb-1">{displayName}</h2>
                      <p className="text-xs text-neutral-300">{t('checklist_desc', chloeLang)}</p>
                    </div>
                    <div className="text-right">
                      <div className="text-3xl font-extrabold text-emerald-400 font-mono">{userXp}</div>
                      <div className="text-xs text-neutral-400 uppercase tracking-wider font-semibold">{t('total_xp', chloeLang)}</div>
                    </div>
                  </div>

                  {/* XP Progress Bar */}
                  <div className="bg-[#161b22] border border-white/15 p-5 rounded-xl space-y-2">
                    <div className="flex items-center justify-between text-xs font-semibold">
                      <span className="text-neutral-300">{t('level_progress', chloeLang, { level: currentLevel })}</span>
                      <span className="text-emerald-400 font-mono">{xpIntoLevel} / 200 XP</span>
                    </div>
                    <div className="w-full bg-neutral-800 h-3 rounded-full overflow-hidden p-0.5 border border-white/10">
                      <div
                        className="bg-gradient-to-r from-emerald-500 to-sky-500 h-full rounded-full transition-all duration-500"
                        style={{ width: `${xpProgressPercent}%` }}
                      />
                    </div>
                    <div className="text-[11px] text-neutral-400 pt-1">
                      {t('xp_remaining', chloeLang, { nextLevel: currentLevel + 1, remaining: 200 - xpIntoLevel })}
                    </div>
                  </div>

                  {/* Earned Badges */}
                  <div className="space-y-3">
                    <h3 className="font-bold text-white text-sm">{t('unlocked_badges', chloeLang)}</h3>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div className="bg-[#161b22] border border-emerald-500/30 p-4 rounded-xl flex items-center space-x-3">
                        <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold text-lg">
                          ⚡
                        </div>
                        <div>
                          <div className="font-bold text-white text-xs">{t('prompt_master', chloeLang)}</div>
                          <div className="text-[11px] text-neutral-400">{t('prompt_master_desc', chloeLang)}</div>
                        </div>
                      </div>

                      <div className="bg-[#161b22] border border-sky-500/30 p-4 rounded-xl flex items-center space-x-3">
                        <div className="w-10 h-10 rounded-xl bg-sky-500/20 text-sky-400 flex items-center justify-center font-bold text-lg">
                          🎯
                        </div>
                        <div>
                          <div className="font-bold text-white text-xs">{t('task_strategist', chloeLang)}</div>
                          <div className="text-[11px] text-neutral-400">{t('task_strategist_desc', chloeLang)}</div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}

            </div>

            {/* RIGHT INSPECTOR PANEL (3 cols) */}
            <div className="md:col-span-3 bg-[#0d1117] border-l border-white/10 flex flex-col overflow-y-auto p-4 space-y-5 text-xs">
              <div className="font-bold text-xs uppercase tracking-wider text-neutral-400 pb-2 border-b border-white/10">
                {t('inspector', chloeLang)}
              </div>

              {/* LANGUAGE & VOICE PROFILE */}
              <div className="space-y-3 pt-1">
                <div className="font-semibold text-neutral-300">{t('language_profile', chloeLang)}</div>
                
                {/* Language Select */}
                <div className="space-y-1">
                  <label className="text-[10px] text-neutral-400 uppercase tracking-wider">{t('language_locale', chloeLang)}</label>
                  <select 
                    value={chloeLang} 
                    onChange={(e) => {
                      const newLang = e.target.value;
                      setChloeLang(newLang);
                      localStorage.setItem('chloe_lang', newLang);
                      
                      const translateEvent = new CustomEvent('chloe-language-change', { detail: { lang: newLang } });
                      window.dispatchEvent(translateEvent);
                    }}
                    className="w-full bg-[#161b22] text-neutral-200 text-xs px-3 py-2 rounded-xl border border-white/10 focus:outline-none focus:border-emerald-500 cursor-pointer"
                  >
                    <option value="en-US">English (US)</option>
                    <option value="zh-TW">Chinese (TW)</option>
                    <option value="ja-JP">Japanese</option>
                    <option value="es-ES">Español</option>
                    <option value="fr-FR">French</option>
                    <option value="hi-IN">Hindi</option>
                  </select>
                </div>

                {/* Voice Persona Select */}
                <div className="space-y-1">
                  <label className="text-[10px] text-neutral-400 uppercase tracking-wider">{t('voice_tone', chloeLang)}</label>
                  <select 
                    value={chloePersona} 
                    onChange={(e) => {
                      const newPersona = e.target.value;
                      setChloePersona(newPersona);
                      localStorage.setItem('chloe_voice_persona', newPersona);
                    }}
                    className="w-full bg-[#161b22] text-neutral-200 text-xs px-3 py-2 rounded-xl border border-white/10 focus:outline-none focus:border-emerald-500 cursor-pointer"
                  >
                    <option value="soft_pro_female">Soft Professional Female Voice</option>
                    <option value="warm_collab">Warm & Collaborative</option>
                    <option value="crisp_direct">Crisp & Direct Professional</option>
                  </select>
                </div>
              </div>

              {/* BACKGROUND TASKS (influences Chloe's reply) */}
              <div className="space-y-2.5">
                <div className="font-semibold text-neutral-300">{t('background_tasks', chloeLang)}</div>
                <div className="space-y-2">
                  {[
                    { label: t('auto_summarize', chloeLang), val: autoSummarize, setVal: setAutoSummarize },
                    { label: t('schedule_scan', chloeLang), val: scheduleScan, setVal: setScheduleScan },
                    { label: t('sentiment_watch', chloeLang), val: sentimentWatch, setVal: setSentimentWatch },
                    { label: t('auto_clip', chloeLang), val: autoClip, setVal: setAutoClip },
                  ].map((task) => (
                    <div key={task.label} className="flex items-center justify-between bg-[#161b22] px-3 py-2 rounded-xl border border-white/10">
                      <span className="text-neutral-300 font-medium">{task.label}</span>
                      <button
                        type="button"
                        onClick={() => task.setVal(!task.val)}
                        className={`w-9 h-5 rounded-full transition-colors relative p-0.5 cursor-pointer ${
                          task.val ? 'bg-emerald-500' : 'bg-neutral-700'
                        }`}
                      >
                        <div className={`w-4 h-4 rounded-full bg-white transition-transform ${task.val ? 'translate-x-4' : 'translate-x-0'}`} />
                      </button>
                    </div>
                  ))}
                </div>
              </div>

              {/* MODEL PARAMETERS */}
              <div className="space-y-3 pt-2 border-t border-white/10">
                <div className="font-semibold text-neutral-300">{t('model_parameters', chloeLang)}</div>
                <div className="space-y-3 bg-[#161b22] p-3 rounded-xl border border-white/10">
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-[11px] text-neutral-400">{t('temperature', chloeLang)}</span>
                      <span className="font-mono text-emerald-400 font-bold">{temperature.toFixed(2)}</span>
                    </div>
                    <input
                      type="range"
                      min="0"
                      max="1"
                      step="0.05"
                      value={temperature}
                      onChange={(e) => setTemperature(Number(e.target.value))}
                      className="w-full accent-emerald-400 cursor-pointer bg-neutral-800 h-1.5 rounded-lg"
                    />
                  </div>

                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-[11px] text-neutral-400">{t('context_window', chloeLang)}</span>
                      <span className="font-mono text-sky-400 font-bold">{contextWindow}</span>
                    </div>
                    <input
                      type="range"
                      min="8"
                      max="128"
                      step="8"
                      value={parseInt(contextWindow)}
                      onChange={(e) => setContextWindow(`${e.target.value}k`)}
                      className="w-full accent-sky-400 cursor-pointer bg-neutral-800 h-1.5 rounded-lg"
                    />
                  </div>
                </div>
              </div>

              {/* ACTIVE MODEL */}
              <div className="space-y-2 pt-2 border-t border-white/10">
                <div className="font-semibold text-neutral-300">{t('active_model', chloeLang)}</div>
                <select
                  value={activeModel}
                  onChange={(e) => setActiveModel(e.target.value)}
                  className="w-full bg-[#161b22] border border-orange-500/40 rounded-xl px-3 py-2 text-white font-mono text-xs focus:outline-none focus:border-orange-500 cursor-pointer shadow-sm"
                >
                  <option value="gemini-3.5-flash">Gemini 3.5 Flash</option>
                  <option value="gemini-3.0-flash">Gemini 3.0 Flash</option>
                </select>
              </div>

              {/* AGENT SUMMARY */}
              <div className="space-y-2 pt-2 border-t border-white/10">
                <div className="font-semibold text-neutral-300">{t('agent_summary', chloeLang)}</div>
                <div className="space-y-1.5 bg-[#161b22] p-3 rounded-xl border border-white/10">
                  {agentsState.map((ag) => (
                    <div key={ag.id} className="flex items-center justify-between text-[11px] py-1 border-b border-white/5 last:border-0">
                      <div className="flex items-center space-x-1.5">
                        <span className={`w-1.5 h-1.5 rounded-full ${ag.statusColor}`} />
                        <span className="text-white font-medium">{ag.name}</span>
                      </div>
                      <span className="text-neutral-400 text-[10px]">{ag.role}</span>
                    </div>
                  ))}
                </div>
              </div>

            </div>

          </div>

        </div>
      </div>

      {/* System Logs Modal */}
      <SystemLogsModal isOpen={showLogsModal} onClose={() => setShowLogsModal(false)} />
    </>
  );
}
