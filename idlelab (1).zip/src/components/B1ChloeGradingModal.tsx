import React, { useState, useEffect } from 'react';
import {
  X,
  Sparkles,
  Award,
  DollarSign,
  ShieldCheck,
  CheckCircle2,
  Volume2,
  VolumeX,
  FileCheck,
  ArrowRight,
  ExternalLink,
  Bot,
  Zap,
  TrendingUp,
  PartyPopper,
  Check,
} from 'lucide-react';
import { chloeVoice } from '../lib/chloeVoice';
import { soundEffects } from '../lib/soundEffects';

export interface SubmissionPayload {
  title: string;
  sourceType: 'url' | 'file';
  sourceValue: string;
  fileName?: string;
  fileSize?: string;
  notes?: string;
}

interface B1ChloeGradingModalProps {
  isOpen: boolean;
  onClose: () => void;
  submission: SubmissionPayload | null;
  onClaimSalary?: () => void;
  onClaimSalaryReward?: (rewardAmount?: number) => void;
  currentBalance?: number;
  userCurrentSalary?: number;
}

export const B1ChloeGradingModal: React.FC<B1ChloeGradingModalProps> = ({
  isOpen,
  onClose,
  submission,
  onClaimSalary,
  onClaimSalaryReward,
  currentBalance = 0,
  userCurrentSalary = 0,
}) => {
  const [isAuditing, setIsAuditing] = useState(true);
  const [auditStep, setAuditStep] = useState(0);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [isClaimed, setIsClaimed] = useState(false);
  const [score, setScore] = useState(94);

  const displayBalance = currentBalance || userCurrentSalary || 0;

  const auditStages = [
    'Connecting to Chloe’s B1 Executive Desk Terminal...',
    'Parsing submission payload & checking architectural bounds...',
    'Auditing 1.5-unit collision buffer & Idleboard rich node schemas...',
    'Synthesizing final executive verdict & compliance sign-off...',
  ];

  useEffect(() => {
    if (!isOpen) {
      chloeVoice.stop();
      return;
    }

    setIsAuditing(true);
    setAuditStep(0);
    setIsClaimed(false);

    // Progression of audit steps
    const timer1 = setTimeout(() => setAuditStep(1), 500);
    const timer2 = setTimeout(() => setAuditStep(2), 1100);
    const timer3 = setTimeout(() => setAuditStep(3), 1700);

    const timerDone = setTimeout(() => {
      setIsAuditing(false);
      soundEffects.playLevelUp();

      // Trigger Chloe's live spoken review
      const reviewSpeech = `Submission verified at B1 executive station. Exceptional work on ${
        submission?.title || 'your deliverable'
      }. All spatial boundaries, rich document nodes, and safety compliance rubrics are fully satisfied. You scored 94 percent. You are approved to claim your three-thousand dollar compensation reward.`;

      chloeVoice.speak(reviewSpeech, 'b1_grading');
      setIsSpeaking(true);
    }, 2300);

    const unsub = chloeVoice.subscribe((speaking) => {
      setIsSpeaking(speaking);
    });

    return () => {
      clearTimeout(timer1);
      clearTimeout(timer2);
      clearTimeout(timer3);
      clearTimeout(timerDone);
      unsub();
      chloeVoice.stop();
    };
  }, [isOpen, submission]);

  if (!isOpen) return null;

  const handleClaim = () => {
    setIsClaimed(true);
    if (onClaimSalary) {
      onClaimSalary();
    }
    if (onClaimSalaryReward) {
      onClaimSalaryReward(3000);
    }
    soundEffects.playLevelUp();
  };

  const handleToggleVoice = () => {
    if (isSpeaking) {
      chloeVoice.stop();
    } else {
      const reviewSpeech = `Executive review confirmed for ${
        submission?.title || 'this project'
      }. Score 94 percent approved for full release.`;
      chloeVoice.speak(reviewSpeech, 'b1_grading');
    }
  };

  return (
    <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-black/85 backdrop-blur-2xl animate-in fade-in duration-200 select-none font-sans text-neutral-200">
      <div className="relative w-full max-w-2xl bg-[#111420] border-2 border-amber-500/40 rounded-3xl shadow-[0_25px_90px_rgba(0,0,0,0.95)] overflow-hidden flex flex-col max-h-[92vh]">
        {/* Top Decorative Amber Rim */}
        <div className="h-1.5 w-full bg-gradient-to-r from-amber-500 via-yellow-400 to-amber-600 animate-pulse" />

        {/* Top Header */}
        <div className="p-5 border-b border-white/10 flex items-center justify-between bg-[#141826]">
          <div className="flex items-center space-x-3.5">
            <div className="relative">
              <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-amber-500 to-yellow-600 flex items-center justify-center text-black font-black shadow-lg shadow-amber-500/30">
                <Bot className="w-6 h-6" />
              </div>
              <div className="absolute -bottom-1 -right-1 w-4 h-4 rounded-full bg-emerald-500 border-2 border-[#141826] flex items-center justify-center">
                <div className="w-1.5 h-1.5 rounded-full bg-white animate-ping" />
              </div>
            </div>

            <div>
              <div className="flex items-center space-x-2">
                <h3 className="text-base font-black text-white tracking-tight">Chloe Becker • B1 Executive Station</h3>
                <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/40 font-mono">
                  Live Audit
                </span>
              </div>
              <p className="text-xs text-neutral-400">Automated Rubric Verification & Salary Compensation Sign-off</p>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            <button
              onClick={handleToggleVoice}
              className={`p-2.5 rounded-xl border transition-all cursor-pointer ${
                isSpeaking
                  ? 'bg-amber-500/20 border-amber-400 text-amber-300 shadow-md shadow-amber-500/20 animate-pulse'
                  : 'bg-white/5 border-white/10 text-neutral-400 hover:text-white'
              }`}
              title={isSpeaking ? 'Mute Chloe Review Speech' : 'Listen to Chloe Review Speech'}
            >
              {isSpeaking ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
            </button>

            <button
              onClick={onClose}
              className="p-2.5 rounded-xl bg-white/5 hover:bg-rose-500/20 border border-white/10 text-neutral-400 hover:text-rose-300 transition-all cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Content Area */}
        <div className="p-6 overflow-y-auto space-y-6 flex-1">
          {/* Submission Proof Banner */}
          <div className="p-4 rounded-2xl bg-white/5 border border-white/10 space-y-2">
            <div className="text-[10px] uppercase tracking-wider font-bold text-neutral-400">
              Active Submission Deliverable
            </div>
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <FileCheck className="w-4 h-4 text-emerald-400 shrink-0" />
                <span className="font-bold text-sm text-white">{submission?.title || 'Project Submission'}</span>
              </div>

              {submission?.sourceType === 'url' ? (
                <span className="text-xs font-mono text-sky-400 bg-sky-500/10 px-2 py-0.5 rounded-lg border border-sky-500/20 truncate max-w-[200px]">
                  {submission.sourceValue}
                </span>
              ) : (
                <span className="text-xs font-mono text-amber-300 bg-amber-500/10 px-2 py-0.5 rounded-lg border border-amber-500/20">
                  {submission?.fileName || 'Attached File Document'} ({submission?.fileSize || 'PDF'})
                </span>
              )}
            </div>
          </div>

          {/* Audit Process Progress or Completed Verdict */}
          {isAuditing ? (
            <div className="py-8 flex flex-col items-center justify-center space-y-4 text-center">
              <div className="w-16 h-16 rounded-full border-4 border-amber-500/20 border-t-amber-400 animate-spin flex items-center justify-center">
                <Sparkles className="w-6 h-6 text-amber-400 animate-pulse" />
              </div>
              <div className="space-y-1">
                <div className="text-sm font-bold text-white tracking-tight">{auditStages[auditStep]}</div>
                <div className="text-xs text-neutral-400">Verifying code compliance against executive rubric standards</div>
              </div>
            </div>
          ) : (
            <div className="space-y-5 animate-in fade-in zoom-in-95 duration-200">
              {/* Score & Verdict Header */}
              <div className="p-5 rounded-3xl bg-gradient-to-br from-emerald-500/20 via-teal-500/10 to-[#121624] border-2 border-emerald-500/40 shadow-xl flex items-center justify-between">
                <div className="space-y-1">
                  <div className="flex items-center space-x-2">
                    <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                    <span className="font-black text-sm text-emerald-300 uppercase tracking-wider">
                      Approved For Production Release
                    </span>
                  </div>
                  <p className="text-xs text-neutral-300 leading-relaxed">
                    Chloe has verified all architectural milestones and compliance rubrics.
                  </p>
                </div>

                <div className="text-right">
                  <div className="text-[10px] text-emerald-300 uppercase font-bold">Executive Score</div>
                  <div className="text-3xl font-black text-white font-mono">{score}%</div>
                </div>
              </div>

              {/* Rubric Breakdown Grid */}
              <div className="grid grid-cols-2 gap-3">
                <div className="p-3.5 rounded-2xl bg-white/5 border border-white/10 space-y-1">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-neutral-400 font-bold">Voxel Spatial Bounds:</span>
                    <span className="text-emerald-400 font-mono font-bold">100%</span>
                  </div>
                  <p className="text-[11px] text-neutral-300">Strict 1.5-unit anti-collision clearance verified.</p>
                </div>

                <div className="p-3.5 rounded-2xl bg-white/5 border border-white/10 space-y-1">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-neutral-400 font-bold">Idleboard Ingest:</span>
                    <span className="text-emerald-400 font-mono font-bold">95%</span>
                  </div>
                  <p className="text-[11px] text-neutral-300">Clean rich-text tags with zero raw markdown noise.</p>
                </div>

                <div className="p-3.5 rounded-2xl bg-white/5 border border-white/10 space-y-1">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-neutral-400 font-bold">Security & Keys:</span>
                    <span className="text-emerald-400 font-mono font-bold">100%</span>
                  </div>
                  <p className="text-[11px] text-neutral-300">Server-side proxy isolation with zero browser leaks.</p>
                </div>

                <div className="p-3.5 rounded-2xl bg-white/5 border border-white/10 space-y-1">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-neutral-400 font-bold">Deliverable Punctuality:</span>
                    <span className="text-emerald-400 font-mono font-bold">92%</span>
                  </div>
                  <p className="text-[11px] text-neutral-300">Completed prior to designated sprint due date.</p>
                </div>
              </div>

              {/* Roleplay Salary Reward Claim Card */}
              <div className="p-5 rounded-3xl bg-gradient-to-r from-amber-500/20 via-yellow-500/15 to-amber-600/20 border-2 border-amber-400 shadow-[0_0_30px_rgba(251,191,36,0.3)] flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div className="space-y-1">
                  <div className="flex items-center space-x-2 text-amber-300 font-black text-sm uppercase tracking-wide">
                    <PartyPopper className="w-5 h-5 text-amber-400" />
                    <span>Roleplay Salary Reward Unlocked</span>
                  </div>
                  <p className="text-xs text-neutral-300">
                    Your score exceeds the 70% threshold. Claim your designated compensation.
                  </p>
                </div>

                <div className="flex items-center space-x-3">
                  <div className="text-right">
                    <div className="text-[10px] text-amber-200/70 uppercase font-bold">Reward Amount</div>
                    <div className="text-xl font-black text-amber-300 font-mono">+$3,000</div>
                  </div>

                  <button
                    onClick={handleClaim}
                    disabled={isClaimed}
                    className={`px-5 py-3 rounded-2xl font-black text-xs transition-all flex items-center space-x-2 cursor-pointer ${
                      isClaimed
                        ? 'bg-emerald-500 text-black shadow-lg shadow-emerald-500/30'
                        : 'bg-gradient-to-r from-amber-400 to-yellow-400 hover:from-amber-300 hover:to-yellow-300 text-black shadow-lg shadow-amber-500/40 hover:scale-105 active:scale-95'
                    }`}
                  >
                    {isClaimed ? (
                      <>
                        <Check className="w-4 h-4 stroke-[3]" />
                        <span>Claimed!</span>
                      </>
                    ) : (
                      <>
                        <DollarSign className="w-4 h-4 stroke-[3]" />
                        <span>Claim $3,000</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-white/10 bg-[#121522] flex items-center justify-between text-xs text-neutral-400">
          <div className="flex items-center space-x-2">
            <span>Current Balance:</span>
            <strong className="text-amber-300 font-mono">${displayBalance.toLocaleString()}</strong>
          </div>

          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-white font-bold transition-all cursor-pointer"
          >
            Done & Return to Office
          </button>
        </div>
      </div>
    </div>
  );
};
