import React, { useState, useEffect } from 'react';
import {
  Settings,
  Volume2,
  VolumeX,
  User,
  Mic,
  Video,
  Sliders,
  Check,
  X,
  Sparkles,
  Monitor,
  Eye,
  Radio,
  RefreshCw,
  Droplet,
  Heart,
  Clock,
  Bell,
  Play
} from 'lucide-react';
import { UserState } from '../types';
import { soundEffects } from '../lib/soundEffects';
import { audioManager } from '../lib/audioManager';
import { socketClient } from '../lib/socketClient';

interface SettingsModalProps {
  currentUser: UserState | null;
  onUpdateUser: (updatedFields: Partial<UserState>) => void;
  onClose: () => void;
  cameraMode?: 'third_person' | 'first_person' | 'isometric';
  onChangeCameraMode?: () => void;
  onOpenAvatarCustomizer?: () => void;
  onOpenPomodoro?: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  currentUser,
  onUpdateUser,
  onClose,
  cameraMode = 'third_person',
  onChangeCameraMode,
  onOpenAvatarCustomizer,
  onOpenPomodoro,
}) => {
  const [activeTab, setActiveTab] = useState<'sound' | 'profile' | 'wellness' | 'devices'>('sound');

  // Display Name State
  const [displayName, setDisplayName] = useState(currentUser?.name || 'Architect User');
  const [nameSaved, setNameSaved] = useState(false);

  // Volume States
  const [masterVolume, setMasterVolume] = useState<number>(() => {
    try {
      const saved = localStorage.getItem('idlelab_master_volume');
      return saved !== null ? parseFloat(saved) : 0.8;
    } catch {
      return 0.8;
    }
  });

  const [sfxVolume, setSfxVolume] = useState<number>(() => soundEffects.getVolume());
  const [isSfxMuted, setIsSfxMuted] = useState<boolean>(() => soundEffects.isMuted());

  const [ambientVolume, setAmbientVolume] = useState<number>(() => {
    try {
      const saved = localStorage.getItem('idlelab_ambient_volume');
      return saved !== null ? parseFloat(saved) : 0.5;
    } catch {
      return 0.5;
    }
  });

  const [spatialAudioEnabled, setSpatialAudioEnabled] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem('idlelab_spatial_audio');
      return saved !== null ? saved === 'true' : true;
    } catch {
      return true;
    }
  });

  // Wellness & Hydration Reminder States
  const [hydrationIntervalMins, setHydrationIntervalMins] = useState<number>(() => {
    try {
      const saved = localStorage.getItem('idlelab_hydration_interval_mins');
      return saved !== null ? parseInt(saved, 10) : 5; // Default 5 minutes
    } catch {
      return 5;
    }
  });

  const [hydrationEnabled, setHydrationEnabled] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem('idlelab_hydration_enabled');
      return saved !== null ? saved === 'true' : true;
    } catch {
      return true;
    }
  });

  const [hydrationSound, setHydrationSound] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem('idlelab_hydration_sound');
      return saved !== null ? saved === 'true' : true;
    } catch {
      return true;
    }
  });

  const [hydrationTestSent, setHydrationTestSent] = useState(false);

  // Media Devices
  const [audioDevices, setAudioDevices] = useState<MediaDeviceInfo[]>([]);
  const [videoDevices, setVideoDevices] = useState<MediaDeviceInfo[]>([]);
  const [selectedAudioInput, setSelectedAudioInput] = useState<string>('');
  const [selectedVideoInput, setSelectedVideoInput] = useState<string>('');
  const [isTestingMic, setIsTestingMic] = useState<boolean>(false);
  const [micVolumeLevel, setMicVolumeLevel] = useState<number>(0);

  // Enumerate Media Devices
  const loadDevices = async () => {
    try {
      if (!navigator.mediaDevices || !navigator.mediaDevices.enumerateDevices) return;
      const devices = await navigator.mediaDevices.enumerateDevices();
      const audioInputs = devices.filter((d) => d.kind === 'audioinput');
      const videoInputs = devices.filter((d) => d.kind === 'videoinput');
      setAudioDevices(audioInputs);
      setVideoDevices(videoInputs);

      if (audioInputs.length > 0 && !selectedAudioInput) {
        setSelectedAudioInput(audioInputs[0].deviceId);
      }
      if (videoInputs.length > 0 && !selectedVideoInput) {
        setSelectedVideoInput(videoInputs[0].deviceId);
      }
    } catch (e) {
      console.warn('Could not enumerate media devices:', e);
    }
  };

  useEffect(() => {
    loadDevices();
  }, []);

  // Sync SFX Changes
  const handleSfxVolumeChange = (vol: number) => {
    setSfxVolume(vol);
    soundEffects.setVolume(vol);
    try {
      localStorage.setItem('idlelab_v6_sfx_volume', vol.toString());
    } catch {}
  };

  const handleToggleSfxMute = () => {
    const nextMute = !isSfxMuted;
    setIsSfxMuted(nextMute);
    soundEffects.setMuted(nextMute);
  };

  const handleMasterVolumeChange = (vol: number) => {
    setMasterVolume(vol);
    try {
      localStorage.setItem('idlelab_master_volume', vol.toString());
    } catch {}
  };

  const handleAmbientVolumeChange = (vol: number) => {
    setAmbientVolume(vol);
    try {
      localStorage.setItem('idlelab_ambient_volume', vol.toString());
    } catch {}
  };

  const handleToggleSpatialAudio = () => {
    const nextVal = !spatialAudioEnabled;
    setSpatialAudioEnabled(nextVal);
    try {
      localStorage.setItem('idlelab_spatial_audio', nextVal ? 'true' : 'false');
    } catch {}
  };

  const handleHydrationIntervalChange = (mins: number) => {
    const clamped = Math.max(1, Math.min(120, mins));
    setHydrationIntervalMins(clamped);
    try {
      localStorage.setItem('idlelab_hydration_interval_mins', clamped.toString());
      window.dispatchEvent(new CustomEvent('idlelab_hydration_settings_changed'));
    } catch {}
  };

  const handleToggleHydrationEnabled = () => {
    const nextVal = !hydrationEnabled;
    setHydrationEnabled(nextVal);
    try {
      localStorage.setItem('idlelab_hydration_enabled', nextVal ? 'true' : 'false');
      window.dispatchEvent(new CustomEvent('idlelab_hydration_settings_changed'));
    } catch {}
  };

  const handleToggleHydrationSound = () => {
    const nextVal = !hydrationSound;
    setHydrationSound(nextVal);
    try {
      localStorage.setItem('idlelab_hydration_sound', nextVal ? 'true' : 'false');
      window.dispatchEvent(new CustomEvent('idlelab_hydration_settings_changed'));
    } catch {}
  };

  const handleTriggerTestReminder = () => {
    if (hydrationSound) {
      soundEffects.playPomodoroChime();
    }
    setHydrationTestSent(true);
    try {
      // Force trigger the toast immediately
      localStorage.setItem('idlelab_hydration_interval_mins', hydrationIntervalMins.toString());
      window.dispatchEvent(new CustomEvent('idlelab_hydration_settings_changed'));
    } catch {}
    setTimeout(() => setHydrationTestSent(false), 2500);
  };

  const handleSaveName = (e: React.FormEvent) => {
    e.preventDefault();
    if (!displayName.trim()) return;
    const cleanName = displayName.trim();
    onUpdateUser({ name: cleanName });
    socketClient.send({ type: 'UPDATE_STATUS', statusText: cleanName });
    try {
      localStorage.setItem('idlelab_user_name', cleanName);
    } catch {}
    setNameSaved(true);
    soundEffects.playChime();
    setTimeout(() => setNameSaved(false), 2000);
  };

  const handlePlaySoundTest = () => {
    soundEffects.playChime();
  };

  // Mic test loop
  useEffect(() => {
    let animFrame: number;
    let stream: MediaStream | null = null;
    let audioCtx: AudioContext | null = null;

    if (isTestingMic) {
      navigator.mediaDevices
        .getUserMedia({ audio: true })
        .then((s) => {
          stream = s;
          const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
          audioCtx = new AudioCtx();
          const source = audioCtx.createMediaStreamSource(s);
          const analyser = audioCtx.createAnalyser();
          analyser.fftSize = 64;
          source.connect(analyser);

          const dataArray = new Uint8Array(analyser.frequencyBinCount);
          const updateMeter = () => {
            analyser.getByteFrequencyData(dataArray);
            let sum = 0;
            for (let i = 0; i < dataArray.length; i++) {
              sum += dataArray[i];
            }
            const avg = sum / dataArray.length;
            setMicVolumeLevel(Math.min(100, Math.round((avg / 128) * 100)));
            animFrame = requestAnimationFrame(updateMeter);
          };
          updateMeter();
        })
        .catch(() => {
          setIsTestingMic(false);
        });
    } else {
      setMicVolumeLevel(0);
    }

    return () => {
      if (animFrame) cancelAnimationFrame(animFrame);
      if (stream) stream.getTracks().forEach((t) => t.stop());
      if (audioCtx) audioCtx.close();
    };
  }, [isTestingMic]);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-xl bg-[#121216]/95 border border-white/15 rounded-3xl shadow-[0_25px_60px_rgba(0,0,0,0.8)] overflow-hidden text-neutral-100 flex flex-col max-h-[90vh]">
        
        {/* Modal Header */}
        <div className="flex items-center justify-between p-5 border-b border-white/10 bg-white/5">
          <div className="flex items-center space-x-3">
            <div className="p-2.5 rounded-2xl bg-sky-500/20 border border-sky-500/30 text-sky-400">
              <Settings className="w-5 h-5 animate-spin-slow" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white tracking-wide">Settings & Preferences</h2>
              <p className="text-xs text-neutral-400">Configure spatial audio, profile, and media hardware</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-white/5 hover:bg-white/15 text-neutral-400 hover:text-white transition-all cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center space-x-1 p-2 bg-black/40 border-b border-white/5">
          <button
            onClick={() => setActiveTab('sound')}
            className={`flex-1 flex items-center justify-center space-x-2 py-2 px-3 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
              activeTab === 'sound'
                ? 'bg-sky-500/20 text-sky-300 border border-sky-500/40 shadow-sm'
                : 'text-neutral-400 hover:text-neutral-200 hover:bg-white/5'
            }`}
          >
            <Volume2 className="w-4 h-4" />
            <span>Sound & Audio</span>
          </button>

          <button
            onClick={() => setActiveTab('profile')}
            className={`flex-1 flex items-center justify-center space-x-2 py-2 px-3 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
              activeTab === 'profile'
                ? 'bg-sky-500/20 text-sky-300 border border-sky-500/40 shadow-sm'
                : 'text-neutral-400 hover:text-neutral-200 hover:bg-white/5'
            }`}
          >
            <User className="w-4 h-4" />
            <span>Profile & Name</span>
          </button>

          <button
            onClick={() => setActiveTab('wellness')}
            className={`flex-1 flex items-center justify-center space-x-2 py-2 px-3 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
              activeTab === 'wellness'
                ? 'bg-sky-500/20 text-sky-300 border border-sky-500/40 shadow-sm'
                : 'text-neutral-400 hover:text-neutral-200 hover:bg-white/5'
            }`}
          >
            <Droplet className="w-4 h-4 text-sky-400" />
            <span>Wellness & Reminders</span>
          </button>

          <button
            onClick={() => setActiveTab('devices')}
            className={`flex-1 flex items-center justify-center space-x-2 py-2 px-3 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
              activeTab === 'devices'
                ? 'bg-sky-500/20 text-sky-300 border border-sky-500/40 shadow-sm'
                : 'text-neutral-400 hover:text-neutral-200 hover:bg-white/5'
            }`}
          >
            <Mic className="w-4 h-4" />
            <span>Hardware Devices</span>
          </button>
        </div>

        {/* Tab Content Area */}
        <div className="p-6 overflow-y-auto space-y-6 flex-1">
          {/* TAB 1: SOUND & AUDIO */}
          {activeTab === 'sound' && (
            <div className="space-y-6">
              {/* Master Volume */}
              <div className="p-4 rounded-2xl bg-white/5 border border-white/5 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2.5">
                    <Volume2 className="w-4 h-4 text-sky-400" />
                    <span className="text-sm font-semibold text-white">Master Volume</span>
                  </div>
                  <span className="text-xs font-mono text-sky-300 font-bold">{Math.round(masterVolume * 100)}%</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="1"
                  step="0.01"
                  value={masterVolume}
                  onChange={(e) => handleMasterVolumeChange(parseFloat(e.target.value))}
                  className="w-full accent-sky-500 cursor-pointer h-1.5 bg-white/10 rounded-lg"
                />
              </div>

              {/* Sound Effects Volume */}
              <div className="p-4 rounded-2xl bg-white/5 border border-white/5 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2.5">
                    {isSfxMuted ? <VolumeX className="w-4 h-4 text-rose-400" /> : <Sparkles className="w-4 h-4 text-amber-400" />}
                    <span className="text-sm font-semibold text-white">Sound Effects (SFX)</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <button
                      onClick={handlePlaySoundTest}
                      className="px-2.5 py-1 rounded-lg bg-sky-500/20 hover:bg-sky-500/30 border border-sky-500/30 text-[11px] font-medium text-sky-300 transition-all cursor-pointer"
                    >
                      Test Sound
                    </button>
                    <button
                      onClick={handleToggleSfxMute}
                      className={`px-2.5 py-1 rounded-lg border text-[11px] font-medium transition-all cursor-pointer ${
                        isSfxMuted
                          ? 'bg-rose-500/20 text-rose-300 border-rose-500/40'
                          : 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                      }`}
                    >
                      {isSfxMuted ? 'Muted' : 'Enabled'}
                    </button>
                    <span className="text-xs font-mono text-amber-300 font-bold">{Math.round(sfxVolume * 100)}%</span>
                  </div>
                </div>
                <input
                  type="range"
                  min="0"
                  max="1"
                  step="0.01"
                  value={sfxVolume}
                  disabled={isSfxMuted}
                  onChange={(e) => handleSfxVolumeChange(parseFloat(e.target.value))}
                  className="w-full accent-amber-500 cursor-pointer h-1.5 bg-white/10 rounded-lg disabled:opacity-40"
                />
              </div>

              {/* Ambient Sound Volume */}
              <div className="p-4 rounded-2xl bg-white/5 border border-white/5 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2.5">
                    <Radio className="w-4 h-4 text-emerald-400" />
                    <span className="text-sm font-semibold text-white">Ambient Room Audio</span>
                  </div>
                  <span className="text-xs font-mono text-emerald-300 font-bold">{Math.round(ambientVolume * 100)}%</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="1"
                  step="0.01"
                  value={ambientVolume}
                  onChange={(e) => handleAmbientVolumeChange(parseFloat(e.target.value))}
                  className="w-full accent-emerald-500 cursor-pointer h-1.5 bg-white/10 rounded-lg"
                />
              </div>

              {/* Spatial 3D Audio Toggle */}
              <div className="flex items-center justify-between p-4 rounded-2xl bg-white/5 border border-white/5">
                <div>
                  <h4 className="text-sm font-semibold text-white">HRTF 3D Spatial Audio</h4>
                  <p className="text-xs text-neutral-400">Position voice and sound effects based on 3D avatar coordinates</p>
                </div>
                <button
                  onClick={handleToggleSpatialAudio}
                  className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors cursor-pointer ${
                    spatialAudioEnabled ? 'bg-sky-500' : 'bg-white/20'
                  }`}
                >
                  <span
                    className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                      spatialAudioEnabled ? 'translate-x-6' : 'translate-x-1'
                    }`}
                  />
                </button>
              </div>
            </div>
          )}

          {/* TAB 2: PROFILE & NAME */}
          {activeTab === 'profile' && (
            <form onSubmit={handleSaveName} className="space-y-6">
              <div className="p-4 rounded-2xl bg-white/5 border border-white/5 space-y-4">
                <label className="block text-xs font-bold text-neutral-300 uppercase tracking-wider">
                  Display Name in Virtual Office
                </label>
                <div className="flex items-center space-x-2">
                  <div className="relative flex-1">
                    <User className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-400" />
                    <input
                      type="text"
                      value={displayName}
                      onChange={(e) => setDisplayName(e.target.value)}
                      placeholder="Enter your display name..."
                      className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-black/50 border border-white/15 text-white placeholder-neutral-500 text-sm focus:outline-none focus:border-sky-500 transition-all"
                      maxLength={32}
                    />
                  </div>
                  <button
                    type="submit"
                    className="flex items-center space-x-1.5 px-4 py-2.5 rounded-xl bg-sky-500 hover:bg-sky-400 text-white font-semibold text-xs transition-all shadow-md cursor-pointer"
                  >
                    {nameSaved ? <Check className="w-4 h-4 text-white" /> : <span>Save Name</span>}
                  </button>
                </div>
                {nameSaved && (
                  <p className="text-xs text-emerald-400 flex items-center space-x-1">
                    <Check className="w-3.5 h-3.5" />
                    <span>Display name updated and broadcasted to colleagues!</span>
                  </p>
                )}
              </div>

              {/* Department & Role Badge Preview */}
              {currentUser && (
                <div className="p-4 rounded-2xl bg-white/5 border border-white/5 space-y-3">
                  <h4 className="text-xs font-bold text-neutral-300 uppercase tracking-wider">My Virtual ID Badge</h4>
                  <div className="flex items-center space-x-3 p-3 rounded-xl bg-black/40 border border-white/10">
                    <div
                      className="w-10 h-10 rounded-full flex items-center justify-center font-bold text-white shadow-md text-sm"
                      style={{ backgroundColor: currentUser.color || '#38bdf8' }}
                    >
                      {currentUser.name.substring(0, 2).toUpperCase()}
                    </div>
                    <div>
                      <h5 className="text-sm font-bold text-white">{currentUser.name}</h5>
                      <span className="text-[11px] font-medium text-sky-400 bg-sky-500/10 px-2 py-0.5 rounded-md border border-sky-500/20">
                        {currentUser.department || 'Engineering'} Department
                      </span>
                    </div>
                  </div>
                </div>
              )}

              {/* 3D Avatar & Wardrobe Customization Action */}
              {onOpenAvatarCustomizer && (
                <div className="p-4 rounded-2xl bg-white/5 border border-white/5 space-y-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="text-sm font-semibold text-white flex items-center space-x-1.5">
                        <Sparkles className="w-4 h-4 text-amber-400" />
                        <span>3D Avatar & Wardrobe Studio</span>
                      </h4>
                      <p className="text-xs text-neutral-400">
                        Tailor hoodie tones, hairstyles, sneakers, pants, and complexion
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={onOpenAvatarCustomizer}
                      className="flex items-center space-x-1.5 px-3.5 py-2 rounded-xl bg-gradient-to-r from-indigo-500 to-sky-500 hover:from-indigo-400 hover:to-sky-400 text-white font-semibold text-xs transition-all shadow-md cursor-pointer"
                    >
                      <Sliders className="w-3.5 h-3.5" />
                      <span>Open Wardrobe Studio</span>
                    </button>
                  </div>
                </div>
              )}

              {/* Camera Perspective Mode Shortcut */}
              {onChangeCameraMode && (
                <div className="p-4 rounded-2xl bg-white/5 border border-white/5 space-y-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="text-sm font-semibold text-white">Default Camera Perspective</h4>
                      <p className="text-xs text-neutral-400">Switch between Third-Person Orbit, Isometric, and First-Person POV</p>
                    </div>
                    <button
                      type="button"
                      onClick={onChangeCameraMode}
                      className="flex items-center space-x-1.5 px-3 py-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-white font-medium text-xs transition-all border border-white/10 cursor-pointer"
                    >
                      <Eye className="w-3.5 h-3.5 text-sky-400" />
                      <span className="capitalize">{cameraMode.replace('_', ' ')}</span>
                    </button>
                  </div>
                </div>
              )}
            </form>
          )}

          {/* TAB 3: WELLNESS & HYDRATION REMINDERS */}
          {activeTab === 'wellness' && (
            <div className="space-y-6">
              {/* Main Toggle Switch */}
              <div className="flex items-center justify-between p-4 rounded-2xl bg-white/5 border border-white/5">
                <div className="flex items-start space-x-3">
                  <div className="p-2 rounded-xl bg-sky-500/20 text-sky-400 border border-sky-500/30">
                    <Droplet className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="text-sm font-semibold text-white">WisdomWell Ergonomic Hydration Alerts</h4>
                    <p className="text-xs text-neutral-400">
                      Discreet periodic reminders to drink water, stretch, and reduce digital eye strain
                    </p>
                  </div>
                </div>
                <button
                  onClick={handleToggleHydrationEnabled}
                  className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors cursor-pointer shrink-0 ${
                    hydrationEnabled ? 'bg-sky-500' : 'bg-white/20'
                  }`}
                >
                  <span
                    className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                      hydrationEnabled ? 'translate-x-6' : 'translate-x-1'
                    }`}
                  />
                </button>
              </div>

              {/* Interval Selection & Presets */}
              <div className="p-4 rounded-2xl bg-white/5 border border-white/5 space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <Clock className="w-4 h-4 text-sky-400" />
                    <span className="text-sm font-semibold text-white">Reminder Interval Frequency</span>
                  </div>
                  <span className="text-xs font-mono font-bold text-sky-300 bg-sky-500/15 px-2 py-0.5 rounded-md border border-sky-500/30">
                    Every {hydrationIntervalMins} minute{hydrationIntervalMins !== 1 ? 's' : ''}
                  </span>
                </div>

                <div className="space-y-2">
                  <span className="text-[11px] font-bold text-neutral-400 uppercase tracking-wider">Quick Presets</span>
                  <div className="flex flex-wrap gap-2">
                    {[3, 5, 10, 15, 20, 30, 45, 60].map((m) => (
                      <button
                        key={m}
                        type="button"
                        onClick={() => handleHydrationIntervalChange(m)}
                        className={`px-3 py-1.5 rounded-xl text-xs font-semibold font-mono transition-all cursor-pointer ${
                          hydrationIntervalMins === m
                            ? 'bg-sky-500 text-white shadow-md shadow-sky-500/20'
                            : 'bg-black/40 hover:bg-white/10 text-neutral-300 border border-white/10'
                        }`}
                      >
                        {m}m {m === 5 ? '(Default)' : m === 30 ? '(WisdomWell)' : ''}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Fine Custom Slider */}
                <div className="pt-2 space-y-1.5">
                  <div className="flex justify-between text-xs text-neutral-400">
                    <span>Fine Tuning Slider</span>
                    <span>1m – 120m</span>
                  </div>
                  <input
                    type="range"
                    min="1"
                    max="120"
                    step="1"
                    value={hydrationIntervalMins}
                    onChange={(e) => handleHydrationIntervalChange(parseInt(e.target.value, 10))}
                    className="w-full accent-sky-500 cursor-pointer h-1.5 bg-white/10 rounded-lg"
                  />
                </div>
              </div>

              {/* Sound Chime & Preview Controls */}
              <div className="p-4 rounded-2xl bg-white/5 border border-white/5 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <Bell className="w-4 h-4 text-emerald-400" />
                    <div>
                      <span className="text-sm font-semibold text-white">Tibetan Singing Bowl Chime</span>
                      <p className="text-xs text-neutral-400">Plays a soothing harmonic 528Hz bell when reminder appears</p>
                    </div>
                  </div>
                  <button
                    onClick={handleToggleHydrationSound}
                    className={`px-2.5 py-1 rounded-lg border text-[11px] font-medium transition-all cursor-pointer ${
                      hydrationSound
                        ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                        : 'bg-white/5 text-neutral-400 border-white/10'
                    }`}
                  >
                    {hydrationSound ? 'Sound On' : 'Muted'}
                  </button>
                </div>

                <div className="pt-2 flex items-center justify-between border-t border-white/5">
                  <span className="text-xs text-neutral-400">Test Reminder Notification UI:</span>
                  <button
                    type="button"
                    onClick={handleTriggerTestReminder}
                    className="flex items-center space-x-1.5 px-3 py-1.5 rounded-xl bg-sky-500/20 hover:bg-sky-500/30 text-sky-300 border border-sky-500/30 font-medium text-xs transition-all cursor-pointer"
                  >
                    <Play className="w-3.5 h-3.5 fill-current" />
                    <span>{hydrationTestSent ? 'Triggered!' : 'Send Test Alert'}</span>
                  </button>
                </div>
              </div>

              {/* Companion Modal Launcher */}
              {onOpenPomodoro && (
                <div className="p-4 rounded-2xl bg-gradient-to-r from-sky-500/10 to-indigo-500/10 border border-sky-500/20 flex items-center justify-between">
                  <div className="space-y-0.5">
                    <h5 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-1.5">
                      <Heart className="w-3.5 h-3.5 text-rose-400" /> Healthcare Pomodoro Companion
                    </h5>
                    <p className="text-xs text-neutral-300">
                      Full-screen 20-20-20 eye break & stretch timer station
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      onClose();
                      onOpenPomodoro();
                    }}
                    className="px-3 py-2 rounded-xl bg-sky-500 hover:bg-sky-400 text-white font-semibold text-xs transition-all cursor-pointer shadow-md"
                  >
                    Open Companion
                  </button>
                </div>
              )}
            </div>
          )}

          {/* TAB 4: HARDWARE DEVICES */}
          {activeTab === 'devices' && (
            <div className="space-y-6">
              {/* Refresh Devices */}
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-neutral-400 uppercase tracking-wider">Hardware Inputs</span>
                <button
                  onClick={loadDevices}
                  className="flex items-center space-x-1 text-xs text-sky-400 hover:text-sky-300 transition-colors cursor-pointer"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  <span>Rescan Devices</span>
                </button>
              </div>

              {/* Microphone Selection */}
              <div className="p-4 rounded-2xl bg-white/5 border border-white/5 space-y-3">
                <div className="flex items-center space-x-2">
                  <Mic className="w-4 h-4 text-emerald-400" />
                  <label className="text-sm font-semibold text-white">Microphone Input</label>
                </div>
                <select
                  value={selectedAudioInput}
                  onChange={(e) => setSelectedAudioInput(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-black/50 border border-white/15 text-white text-xs focus:outline-none focus:border-sky-500 cursor-pointer"
                >
                  {audioDevices.length > 0 ? (
                    audioDevices.map((d, i) => (
                      <option key={d.deviceId ? d.deviceId : `audio-dev-${i}`} value={d.deviceId}>
                        {d.label || `Microphone ${i + 1}`}
                      </option>
                    ))
                  ) : (
                    <option value="">Default Microphone</option>
                  )}
                </select>

                {/* Mic Test Meter */}
                <div className="pt-2 flex items-center space-x-3">
                  <button
                    type="button"
                    onClick={() => setIsTestingMic(!isTestingMic)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-semibold border transition-all cursor-pointer ${
                      isTestingMic
                        ? 'bg-rose-500/20 text-rose-300 border-rose-500/40'
                        : 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                    }`}
                  >
                    {isTestingMic ? 'Stop Mic Test' : 'Test Microphone'}
                  </button>
                  {isTestingMic && (
                    <div className="flex-1 bg-black/40 border border-white/10 rounded-full h-2.5 overflow-hidden">
                      <div
                        className="bg-emerald-400 h-full transition-all duration-75"
                        style={{ width: `${micVolumeLevel}%` }}
                      />
                    </div>
                  )}
                </div>
              </div>

              {/* Camera Selection */}
              <div className="p-4 rounded-2xl bg-white/5 border border-white/5 space-y-3">
                <div className="flex items-center space-x-2">
                  <Video className="w-4 h-4 text-sky-400" />
                  <label className="text-sm font-semibold text-white">Webcam Video Input</label>
                </div>
                <select
                  value={selectedVideoInput}
                  onChange={(e) => setSelectedVideoInput(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-black/50 border border-white/15 text-white text-xs focus:outline-none focus:border-sky-500 cursor-pointer"
                >
                  {videoDevices.length > 0 ? (
                    videoDevices.map((d, i) => (
                      <option key={d.deviceId ? d.deviceId : `video-dev-${i}`} value={d.deviceId}>
                        {d.label || `Camera ${i + 1}`}
                      </option>
                    ))
                  ) : (
                    <option value="">Default Webcam</option>
                  )}
                </select>
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="p-4 border-t border-white/10 bg-white/5 flex items-center justify-end space-x-3">
          <button
            onClick={onClose}
            className="px-5 py-2.5 rounded-xl bg-sky-500 hover:bg-sky-400 text-white font-semibold text-xs transition-all shadow-md cursor-pointer"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
