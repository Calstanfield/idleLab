import React, { useState } from 'react';
import {
  Server,
  Bookmark,
  ExternalLink,
  Plus,
  Trash2,
  Search,
  Pin,
  Copy,
  Check,
  Globe,
  Terminal,
  Layers,
  X,
  Radio,
  Cpu,
  HardDrive,
  ShieldCheck,
  RefreshCw,
} from 'lucide-react';
import { DataCenterBookmark } from '../types';

interface DataCenterModalProps {
  isOpen: boolean;
  onClose: () => void;
  bookmarks: DataCenterBookmark[];
  onUpdateBookmarks: (bookmarks: DataCenterBookmark[]) => void;
}

const DEFAULT_BOOKMARKS: DataCenterBookmark[] = [
  {
    id: 'bm-1',
    title: 'Production Kubernetes Cluster',
    url: 'https://k8s.company-hq.internal/dashboard',
    category: 'Production',
    description: 'Main us-east1 container cluster orchestrator and pod telemetry.',
    tags: ['k8s', 'prod', 'orchestration'],
    createdAt: Date.now() - 86400000 * 5,
    pinned: true,
  },
  {
    id: 'bm-2',
    title: 'Grafana Telemetry & Metrics',
    url: 'https://grafana.internal.infra/d/main-dash',
    category: 'Monitoring & Logs',
    description: 'Real-time CPU, RAM, API latencies, and WebSocket error budgets.',
    tags: ['metrics', 'grafana', 'apm'],
    createdAt: Date.now() - 86400000 * 4,
    pinned: true,
  },
  {
    id: 'bm-3',
    title: 'Figma Design System (Voxel UI)',
    url: 'https://www.figma.com/design-system/voxel-enterprise',
    category: 'Design & Figma',
    description: 'Master component library, typography tokens, and 3D UI palettes.',
    tags: ['figma', 'design-system', 'tokens'],
    createdAt: Date.now() - 86400000 * 3,
    pinned: true,
  },
  {
    id: 'bm-4',
    title: 'GitHub Organization Repositories',
    url: 'https://github.com/organization/main-monorepo',
    category: 'Staging & Dev',
    description: 'Core microservices, WebSocket mesh, and 3D spatial canvas engine.',
    tags: ['github', 'code', 'pr'],
    createdAt: Date.now() - 86400000 * 2,
    pinned: false,
  },
  {
    id: 'bm-5',
    title: 'PostgreSQL Cloud Database Cluster',
    url: 'https://console.cloud.google.com/sql/instances/b1-primary',
    category: 'Cloud & Infra',
    description: 'HA Relational store with automated read-replicas & replication logs.',
    tags: ['postgres', 'sql', 'storage'],
    createdAt: Date.now() - 86400000 * 1,
    pinned: false,
  },
  {
    id: 'bm-6',
    title: 'API Reference & Architecture Docs',
    url: 'https://docs.company-hq.internal/v2/architecture',
    category: 'Documentation',
    description: 'Spatial audio formulas, avatar skin matrices, and event schemas.',
    tags: ['docs', 'api', 'specs'],
    createdAt: Date.now() - 3600000 * 12,
    pinned: false,
  },
];

const CATEGORIES: Array<DataCenterBookmark['category'] | 'All'> = [
  'All',
  'Production',
  'Staging & Dev',
  'Monitoring & Logs',
  'Design & Figma',
  'Documentation',
  'Cloud & Infra',
  'General',
];

export function DataCenterModal({
  isOpen,
  onClose,
  bookmarks,
  onUpdateBookmarks,
}: DataCenterModalProps) {
  const [activeCategory, setActiveCategory] = useState<DataCenterBookmark['category'] | 'All'>('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [copiedId, setCopiedId] = useState<string | null>(null);

  // Form State for Adding New Link
  const [isAdding, setIsAdding] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newUrl, setNewUrl] = useState('');
  const [newCategory, setNewCategory] = useState<DataCenterBookmark['category']>('Production');
  const [newDesc, setNewDesc] = useState('');
  const [newTags, setNewTags] = useState('');

  if (!isOpen) return null;

  const currentList = bookmarks.length > 0 ? bookmarks : DEFAULT_BOOKMARKS;

  const filteredBookmarks = currentList.filter((bm) => {
    const matchesCat = activeCategory === 'All' || bm.category === activeCategory;
    const q = searchQuery.toLowerCase().trim();
    const matchesSearch =
      !q ||
      bm.title.toLowerCase().includes(q) ||
      bm.url.toLowerCase().includes(q) ||
      bm.description?.toLowerCase().includes(q) ||
      bm.tags?.some((t) => t.toLowerCase().includes(q));
    return matchesCat && matchesSearch;
  });

  const handleCopy = (id: string, url: string) => {
    navigator.clipboard.writeText(url);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleTogglePin = (id: string) => {
    const updated = currentList.map((bm) =>
      bm.id === id ? { ...bm, pinned: !bm.pinned } : bm
    );
    onUpdateBookmarks(updated);
  };

  const handleDelete = (id: string) => {
    const updated = currentList.filter((bm) => bm.id !== id);
    onUpdateBookmarks(updated);
  };

  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim() || !newUrl.trim()) return;

    let formattedUrl = newUrl.trim();
    if (!/^https?:\/\//i.test(formattedUrl)) {
      formattedUrl = 'https://' + formattedUrl;
    }

    const tagsArray = newTags
      .split(',')
      .map((t) => t.trim())
      .filter(Boolean);

    const newEntry: DataCenterBookmark = {
      id: `bm-${Date.now()}`,
      title: newTitle.trim(),
      url: formattedUrl,
      category: newCategory,
      description: newDesc.trim() || undefined,
      tags: tagsArray.length > 0 ? tagsArray : undefined,
      createdAt: Date.now(),
      pinned: false,
    };

    onUpdateBookmarks([newEntry, ...currentList]);
    setNewTitle('');
    setNewUrl('');
    setNewDesc('');
    setNewTags('');
    setIsAdding(false);
  };

  const handleResetDefaults = () => {
    onUpdateBookmarks(DEFAULT_BOOKMARKS);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-200">
      <div
        id="datacenter-modal-card"
        className="relative w-full max-w-4xl max-h-[90vh] flex flex-col bg-slate-900 border border-slate-700/80 rounded-2xl shadow-[0_25px_60px_-15px_rgba(0,0,0,0.9)] overflow-hidden"
      >
        {/* Modal Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-950/60">
          <div className="flex items-center space-x-3">
            <div className="p-2.5 rounded-xl bg-sky-500/10 border border-sky-500/30 text-sky-400">
              <Server className="w-6 h-6 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h2 className="text-lg font-bold text-slate-100 tracking-tight">
                  B1 Main Data Center & Bookmarks Hub
                </h2>
                <span className="flex items-center space-x-1 px-2 py-0.5 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-[11px] font-semibold text-emerald-400">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
                  <span>Nodes Online</span>
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Shared internal bookmarks, production dashboards, APIs, and team links.
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            <button
              type="button"
              onClick={handleResetDefaults}
              title="Restore standard server bookmarks"
              className="p-2 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-slate-800/80 transition-colors"
            >
              <RefreshCw className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={onClose}
              className="p-2 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-slate-800/80 transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Server Telemetry Bar */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 px-6 py-3 bg-slate-950/30 border-b border-slate-800/60 text-xs">
          <div className="flex items-center space-x-2 text-slate-300">
            <Cpu className="w-3.5 h-3.5 text-sky-400" />
            <span className="text-slate-400">Cluster:</span>
            <span className="font-mono font-semibold text-slate-200">US-EAST1-B</span>
          </div>
          <div className="flex items-center space-x-2 text-slate-300">
            <HardDrive className="w-3.5 h-3.5 text-emerald-400" />
            <span className="text-slate-400">Bookmarks:</span>
            <span className="font-mono font-semibold text-emerald-400">{currentList.length} Active</span>
          </div>
          <div className="flex items-center space-x-2 text-slate-300">
            <Radio className="w-3.5 h-3.5 text-amber-400" />
            <span className="text-slate-400">Latency:</span>
            <span className="font-mono font-semibold text-amber-300">14ms sync</span>
          </div>
          <div className="flex items-center space-x-2 text-slate-300">
            <ShieldCheck className="w-3.5 h-3.5 text-indigo-400" />
            <span className="text-slate-400">Protocol:</span>
            <span className="font-mono font-semibold text-indigo-300">TLS 1.3 / mTLS</span>
          </div>
        </div>

        {/* Controls & Category Filter Bar */}
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 px-6 py-3.5 bg-slate-900/90 border-b border-slate-800">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input
              type="text"
              placeholder="Search bookmarks, URLs, or tags..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-4 py-2 bg-slate-950/80 border border-slate-700/80 rounded-xl text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-sky-500 transition-colors"
            />
          </div>

          <div className="flex items-center space-x-2">
            <button
              type="button"
              onClick={() => setIsAdding(!isAdding)}
              className="flex items-center space-x-1.5 px-3.5 py-2 bg-sky-600 hover:bg-sky-500 text-white text-xs font-semibold rounded-xl shadow-lg shadow-sky-900/30 transition-all active:scale-95 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>{isAdding ? 'Cancel' : 'Add Link'}</span>
            </button>
          </div>
        </div>

        {/* Category Pills */}
        <div className="flex items-center space-x-1 px-6 py-2 bg-slate-950/40 border-b border-slate-800/80 overflow-x-auto no-scrollbar">
          {CATEGORIES.map((cat) => (
            <button
              key={cat}
              type="button"
              onClick={() => setActiveCategory(cat)}
              className={`px-3 py-1 rounded-lg text-xs font-medium whitespace-nowrap transition-all cursor-pointer ${
                activeCategory === cat
                  ? 'bg-sky-500/20 text-sky-300 border border-sky-500/40 font-semibold'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Add Link Collapsible Form */}
        {isAdding && (
          <form
            onSubmit={handleAddSubmit}
            className="p-5 bg-slate-950/90 border-b border-sky-500/30 space-y-3 animate-in slide-in-from-top duration-200"
          >
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold uppercase tracking-wider text-sky-400">
                Register New Server Link / Bookmark
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-[11px] font-medium text-slate-400 mb-1">
                  Title *
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Staging Auth Service"
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  className="w-full px-3 py-1.5 bg-slate-900 border border-slate-700 rounded-lg text-xs text-slate-200 focus:outline-none focus:border-sky-500"
                />
              </div>

              <div>
                <label className="block text-[11px] font-medium text-slate-400 mb-1">
                  URL *
                </label>
                <input
                  type="text"
                  required
                  placeholder="https://..."
                  value={newUrl}
                  onChange={(e) => setNewUrl(e.target.value)}
                  className="w-full px-3 py-1.5 bg-slate-900 border border-slate-700 rounded-lg text-xs text-slate-200 focus:outline-none focus:border-sky-500 font-mono"
                />
              </div>

              <div>
                <label className="block text-[11px] font-medium text-slate-400 mb-1">
                  Category
                </label>
                <select
                  value={newCategory}
                  onChange={(e) => setNewCategory(e.target.value as any)}
                  className="w-full px-3 py-1.5 bg-slate-900 border border-slate-700 rounded-lg text-xs text-slate-200 focus:outline-none focus:border-sky-500"
                >
                  <option value="Production">Production</option>
                  <option value="Staging & Dev">Staging & Dev</option>
                  <option value="Monitoring & Logs">Monitoring & Logs</option>
                  <option value="Design & Figma">Design & Figma</option>
                  <option value="Documentation">Documentation</option>
                  <option value="Cloud & Infra">Cloud & Infra</option>
                  <option value="General">General</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-[11px] font-medium text-slate-400 mb-1">
                  Description
                </label>
                <input
                  type="text"
                  placeholder="Brief note about what this service does"
                  value={newDesc}
                  onChange={(e) => setNewDesc(e.target.value)}
                  className="w-full px-3 py-1.5 bg-slate-900 border border-slate-700 rounded-lg text-xs text-slate-200 focus:outline-none focus:border-sky-500"
                />
              </div>
              <div>
                <label className="block text-[11px] font-medium text-slate-400 mb-1">
                  Tags (comma separated)
                </label>
                <input
                  type="text"
                  placeholder="e.g. auth, api, redis"
                  value={newTags}
                  onChange={(e) => setNewTags(e.target.value)}
                  className="w-full px-3 py-1.5 bg-slate-900 border border-slate-700 rounded-lg text-xs text-slate-200 focus:outline-none focus:border-sky-500 font-mono"
                />
              </div>
            </div>

            <div className="flex justify-end space-x-2 pt-1">
              <button
                type="button"
                onClick={() => setIsAdding(false)}
                className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium rounded-lg"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-1.5 bg-sky-600 hover:bg-sky-500 text-white text-xs font-semibold rounded-lg shadow-md shadow-sky-900/30"
              >
                Save to Data Center
              </button>
            </div>
          </form>
        )}

        {/* Bookmarks List */}
        <div className="flex-1 overflow-y-auto p-6 space-y-3 max-h-[480px]">
          {filteredBookmarks.length === 0 ? (
            <div className="text-center py-12 text-slate-500">
              <Bookmark className="w-10 h-10 mx-auto mb-2 text-slate-600 opacity-60" />
              <p className="text-sm font-medium text-slate-400">No bookmarks found matching your query.</p>
              <p className="text-xs text-slate-500 mt-1">Try selecting another category or click "Add Link".</p>
            </div>
          ) : (
            filteredBookmarks.map((bm) => (
              <div
                key={bm.id}
                className={`group relative flex flex-col sm:flex-row items-start sm:items-center justify-between p-4 bg-slate-950/60 hover:bg-slate-800/60 border rounded-xl transition-all ${
                  bm.pinned
                    ? 'border-sky-500/40 bg-sky-950/10 shadow-sm shadow-sky-500/5'
                    : 'border-slate-800 hover:border-slate-700'
                }`}
              >
                <div className="flex items-start space-x-3 flex-1 min-w-0 pr-4">
                  <div className="p-2 rounded-lg bg-slate-900 border border-slate-700 text-slate-300 mt-0.5 group-hover:text-sky-400 group-hover:border-sky-500/40 transition-colors">
                    {bm.category === 'Production' ? (
                      <Terminal className="w-4 h-4 text-rose-400" />
                    ) : bm.category === 'Monitoring & Logs' ? (
                      <Radio className="w-4 h-4 text-amber-400" />
                    ) : bm.category === 'Design & Figma' ? (
                      <Layers className="w-4 h-4 text-purple-400" />
                    ) : (
                      <Globe className="w-4 h-4 text-sky-400" />
                    )}
                  </div>

                  <div className="min-w-0 flex-1">
                    <div className="flex items-center space-x-2 flex-wrap gap-y-1">
                      <h4 className="text-sm font-semibold text-slate-100 group-hover:text-sky-300 transition-colors">
                        {bm.title}
                      </h4>
                      <span className="px-2 py-0.5 rounded text-[10px] font-medium bg-slate-800 text-slate-300 border border-slate-700">
                        {bm.category}
                      </span>
                      {bm.pinned && (
                        <span className="flex items-center space-x-1 px-1.5 py-0.5 rounded text-[10px] font-semibold bg-amber-500/10 text-amber-400 border border-amber-500/30">
                          <Pin className="w-2.5 h-2.5" />
                          <span>Pinned</span>
                        </span>
                      )}
                    </div>

                    {bm.description && (
                      <p className="text-xs text-slate-400 mt-0.5 line-clamp-1">{bm.description}</p>
                    )}

                    <div className="flex items-center space-x-3 mt-1.5">
                      <span className="text-[11px] font-mono text-slate-500 truncate max-w-xs sm:max-w-md">
                        {bm.url}
                      </span>
                      {bm.tags && bm.tags.length > 0 && (
                        <div className="hidden sm:flex items-center space-x-1">
                          {bm.tags.map((t) => (
                            <span
                              key={t}
                              className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-slate-900 text-slate-400 border border-slate-800"
                            >
                              #{t}
                            </span>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>
                </div>

                {/* Actions */}
                <div className="flex items-center space-x-1.5 mt-3 sm:mt-0 self-end sm:self-center">
                  <button
                    type="button"
                    onClick={() => handleTogglePin(bm.id)}
                    title={bm.pinned ? 'Unpin bookmark' : 'Pin to top'}
                    className={`p-2 rounded-lg transition-colors ${
                      bm.pinned
                        ? 'text-amber-400 bg-amber-500/10 hover:bg-amber-500/20'
                        : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
                    }`}
                  >
                    <Pin className="w-3.5 h-3.5" />
                  </button>

                  <button
                    type="button"
                    onClick={() => handleCopy(bm.id, bm.url)}
                    title="Copy URL"
                    className="p-2 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-slate-800 transition-colors"
                  >
                    {copiedId === bm.id ? (
                      <Check className="w-3.5 h-3.5 text-emerald-400" />
                    ) : (
                      <Copy className="w-3.5 h-3.5" />
                    )}
                  </button>

                  <a
                    href={bm.url}
                    target="_blank"
                    rel="noreferrer noopener"
                    className="flex items-center space-x-1.5 px-3 py-1.5 bg-slate-800 hover:bg-sky-600 text-slate-200 hover:text-white rounded-lg text-xs font-semibold transition-all shadow-sm cursor-pointer"
                  >
                    <span>Launch</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>

                  <button
                    type="button"
                    onClick={() => handleDelete(bm.id)}
                    title="Remove from Data Center"
                    className="p-2 rounded-lg text-slate-500 hover:text-rose-400 hover:bg-rose-500/10 transition-colors"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Modal Footer */}
        <div className="flex items-center justify-between px-6 py-3 border-t border-slate-800 bg-slate-950/60 text-xs text-slate-400">
          <span className="flex items-center space-x-1.5">
            <span className="w-2 h-2 rounded-full bg-sky-400" />
            <span>Encrypted WebSocket bookmark synchronization enabled</span>
          </span>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold rounded-lg transition-colors cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
}
