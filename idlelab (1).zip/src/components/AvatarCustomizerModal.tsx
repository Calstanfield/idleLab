import React, { useState, useEffect } from 'react';
import { AvatarSkin, ScooterConfig, UserState } from '../types';
import {
  X,
  Palette,
  Check,
  Sliders,
  Sparkles,
  User,
  Shirt,
  Footprints,
  Layers,
  AlertTriangle,
  Zap,
} from 'lucide-react';
import {
  HOODIE_COLOR_PALETTES,
  SKIN_TONE_OPTIONS,
  HAIR_COLOR_OPTIONS,
  JEANS_COLOR_PALETTES,
  SNEAKER_COLOR_PALETTES,
  BASEBALL_CAP_PALETTES,
  isGreenTone,
} from './JoinModal';
import { Avatar3DPreview } from './Avatar3DPreview';
import goldenGateImgUrl from '../assets/images/golden_gate_pixel_1786433260687.jpg';

export const SCOOTER_PRESETS: {
  id: string;
  name: string;
  badge: string;
  config: ScooterConfig;
}[] = [
  {
    id: 'lime_classic',
    name: 'Lime Gen4 Eco',
    badge: 'Classic Lime',
    config: {
      frameColor: '#00dd00',
      deckColor: '#18181b',
      accentColor: '#ffffff',
      gripTapeColor: '#27272a',
      underglowColor: '#00ff44',
      underglowEnabled: true,
      decalText: 'LIME',
    },
  },
  {
    id: 'cyberpunk_neon',
    name: 'Cyberpunk Neon',
    badge: 'Neon Synth',
    config: {
      frameColor: '#06b6d4',
      deckColor: '#0f172a',
      accentColor: '#ec4899',
      gripTapeColor: '#1e1b4b',
      underglowColor: '#06b6d4',
      underglowEnabled: true,
      decalText: 'CYBER',
    },
  },
  {
    id: 'stealth_matte',
    name: 'Stealth Onyx Carbon',
    badge: 'Blackout',
    config: {
      frameColor: '#27272a',
      deckColor: '#18181b',
      accentColor: '#ef4444',
      gripTapeColor: '#09090b',
      underglowColor: '#ef4444',
      underglowEnabled: true,
      decalText: 'STEALTH',
    },
  },
  {
    id: 'sunset_coral',
    name: 'Sunset High-Voltage',
    badge: 'Sunset Glow',
    config: {
      frameColor: '#f97316',
      deckColor: '#1e1b4b',
      accentColor: '#fbbf24',
      gripTapeColor: '#312e81',
      underglowColor: '#f97316',
      underglowEnabled: true,
      decalText: 'SUNSET',
    },
  },
  {
    id: 'arctic_glacier',
    name: 'Arctic Blizzard',
    badge: 'Ice Pure',
    config: {
      frameColor: '#38bdf8',
      deckColor: '#0f172a',
      accentColor: '#ffffff',
      gripTapeColor: '#1e293b',
      underglowColor: '#38bdf8',
      underglowEnabled: true,
      decalText: 'TURBO',
    },
  },
  {
    id: 'royal_violet',
    name: 'Electric Amethyst',
    badge: 'Royalty',
    config: {
      frameColor: '#a855f7',
      deckColor: '#18181b',
      accentColor: '#f43f5e',
      gripTapeColor: '#2e1065',
      underglowColor: '#d946ef',
      underglowEnabled: true,
      decalText: '⚡ SPEED',
    },
  },
];

interface AvatarCustomizerModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: UserState | null;
  onUpdateAvatar: (
    skin: AvatarSkin,
    hoodieColor: string,
    hairColor?: string,
    ethnicity?: string,
    pantsColor?: string,
    shoesColor?: string,
    capColor?: string,
    scarfColor?: string,
    isRidingScooter?: boolean,
    scooterConfig?: ScooterConfig
  ) => void;
}

export const AvatarCustomizerModal: React.FC<AvatarCustomizerModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  onUpdateAvatar,
}) => {
  const [activeTab, setActiveTab] = useState<'character' | 'wardrobe' | 'footwear' | 'scooter'>('character');
  const [skin, setSkin] = useState<AvatarSkin>(currentUser?.skin || 'college_dev_m');
  const [hoodieColor, setHoodieColor] = useState<string>(
    currentUser?.hoodieColor || (currentUser?.skin === 'college_dev_f' ? '#06b6d4' : '#ea580c')
  );
  const [hairColor, setHairColor] = useState<string>(currentUser?.hairColor || '#0f0f11');
  const [skinTone, setSkinTone] = useState<string>(currentUser?.ethnicity || currentUser?.skinTone || 'east_asian_1');
  const [pantsColor, setPantsColor] = useState<string>(
    currentUser?.pantsColor || (currentUser?.skin === 'college_dev_f' ? '#18181b' : '#1d4ed8')
  );
  const [shoesColor, setShoesColor] = useState<string>(
    currentUser?.shoesColor || (currentUser?.skin === 'college_dev_f' ? '#ffffff' : '#dc2626')
  );
  const [capColor, setCapColor] = useState<string>(currentUser?.capColor || '#ffffff');
  const [scarfColor, setScarfColor] = useState<string>(currentUser?.scarfColor || '#dc2626');

  // E-Scooter Customization State
  const [previewScooter, setPreviewScooter] = useState<boolean>(true);
  const [scooterConfig, setScooterConfig] = useState<ScooterConfig>(
    currentUser?.scooterConfig || {
      frameColor: '#00dd00',
      deckColor: '#18181b',
      accentColor: '#ffffff',
      gripTapeColor: '#27272a',
      underglowColor: '#00ff44',
      underglowEnabled: true,
      decalText: 'LIME',
    }
  );

  // Green cap taboo warning & hover states
  const [greenTabooWarning, setGreenTabooWarning] = useState<string | null>(null);
  const [isHoveringGreenTaboo, setIsHoveringGreenTaboo] = useState<boolean>(false);

  useEffect(() => {
    if (currentUser) {
      setSkin(currentUser.skin);
      setHoodieColor(currentUser.hoodieColor || (currentUser.skin === 'college_dev_f' ? '#06b6d4' : '#ea580c'));
      if (currentUser.hairColor) setHairColor(currentUser.hairColor);
      if (currentUser.ethnicity || currentUser.skinTone) {
        setSkinTone(currentUser.ethnicity || currentUser.skinTone || 'east_asian_1');
      }
      if (currentUser.pantsColor) setPantsColor(currentUser.pantsColor);
      if (currentUser.shoesColor) setShoesColor(currentUser.shoesColor);
      if (currentUser.capColor) setCapColor(currentUser.capColor);
      if (currentUser.scarfColor) setScarfColor(currentUser.scarfColor);
      if (currentUser.scooterConfig) setScooterConfig(currentUser.scooterConfig);
    }
  }, [currentUser, isOpen]);

  if (!isOpen) return null;

  const handleCapColorChange = (newHex: string) => {
    if (isGreenTone(newHex)) {
      setGreenTabooWarning(
        "🚫 Cultural Taboo: In East Asian and Chinese traditions, 'wearing a green hat' (戴绿帽子) symbolizes an unfaithful partner. Green caps are excluded to maintain cultural etiquette."
      );
      setTimeout(() => setGreenTabooWarning(null), 6000);
      return;
    }
    setGreenTabooWarning(null);
    setCapColor(newHex);
  };

  const handleSave = () => {
    onUpdateAvatar(
      skin,
      hoodieColor,
      hairColor,
      skinTone,
      pantsColor,
      shoesColor,
      capColor,
      scarfColor,
      currentUser?.isRidingScooter,
      scooterConfig
    );
    onClose();
  };

  const handleApplyPreset = (preset: (typeof SCOOTER_PRESETS)[0]) => {
    setScooterConfig({ ...preset.config });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/85 backdrop-blur-md p-3 sm:p-5 animate-fadeIn">
      <div className="relative w-full max-w-4xl bg-slate-900/95 border border-white/10 rounded-3xl shadow-2xl overflow-hidden text-slate-100 flex flex-col max-h-[92vh] backdrop-blur-xl">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 bg-slate-950/80 border-b border-white/10 shrink-0">
          <div className="flex items-center space-x-3">
            <div className="p-2 rounded-xl bg-lime-500/15 text-lime-400 border border-lime-500/30 shadow-inner">
              <Zap className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white tracking-tight">Avatar & E-Scooter Customizer</h2>
              <p className="text-xs text-slate-400">Personalize your 3D avatar, streetwear clothing, and Lime E-Scooter hardware</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-white bg-white/5 hover:bg-white/10 border border-white/10 transition-all cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Modal Body (2-Column Studio Layout) */}
        <div className="grid grid-cols-1 md:grid-cols-12 flex-1 overflow-hidden">
          {/* Left Column: Real-Time 3D Interactive Character Preview */}
          <div className="md:col-span-5 border-b md:border-b-0 md:border-r border-white/10 p-4 flex flex-col items-center justify-between min-h-[280px] md:min-h-[auto] relative overflow-hidden bg-slate-950">
            {/* SF Pixel Art Backdrop */}
            <div className="absolute inset-0 overflow-hidden pointer-events-none select-none">
              <img
                src={goldenGateImgUrl}
                alt="San Francisco Sunset"
                className="w-full h-full object-cover object-center filter brightness-90 contrast-105"
                style={{ imageRendering: 'pixelated' }}
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/45 to-slate-950/65" />
              <div className="absolute inset-0 bg-gradient-to-r from-lime-500/15 via-emerald-500/10 to-indigo-950/50 mix-blend-color-dodge" />
            </div>

            <div className="w-full flex items-center justify-between z-10">
              <div className="flex items-center space-x-2">
                <span className="text-[10px] uppercase font-bold text-lime-200/90 tracking-wider">3D Preview</span>
                {activeTab === 'scooter' && (
                  <span className="text-[9px] font-bold px-1.5 py-0.5 rounded bg-lime-500/20 text-lime-300 border border-lime-500/40">
                    🛴 E-Scooter Active
                  </span>
                )}
              </div>
              <button
                type="button"
                onClick={() => setPreviewScooter(!previewScooter)}
                className={`text-[10px] font-mono px-2 py-0.5 rounded-full border transition-all cursor-pointer ${
                  previewScooter
                    ? 'text-lime-300 bg-lime-500/20 border-lime-500/40'
                    : 'text-slate-400 bg-slate-800/60 border-white/10'
                }`}
                title="Toggle Scooter Preview"
              >
                {previewScooter ? '🛴 Rider Stance' : '🧍 Walking Stance'}
              </button>
            </div>

            <div className="w-full h-full max-h-[340px] flex-1 flex items-center justify-center relative my-2 z-10">
              <Avatar3DPreview
                skin={skin}
                hoodieColor={hoodieColor}
                hairColor={hairColor}
                skinTone={skinTone}
                name={currentUser?.name || 'Mascot'}
                pantsColor={pantsColor}
                shoesColor={shoesColor}
                capColor={capColor}
                scarfColor={scarfColor}
                isRidingScooter={activeTab === 'scooter' || previewScooter}
                scooterConfig={scooterConfig}
              />
            </div>

            <div className="w-full grid grid-cols-4 gap-1.5 pt-2 border-t border-white/10 text-[10px] z-10">
              <div className="bg-slate-950/60 p-1.5 rounded-xl border border-white/10">
                <span className="text-slate-400 block text-[8px] uppercase font-semibold">Scooter</span>
                <div className="flex items-center space-x-1 mt-0.5">
                  <span className="w-2.5 h-2.5 rounded-full border border-white/40" style={{ backgroundColor: scooterConfig.frameColor }} />
                  <span className="font-mono text-slate-200 truncate text-[9px]">{scooterConfig.decalText || 'LIME'}</span>
                </div>
              </div>
              <div className="bg-slate-950/60 p-1.5 rounded-xl border border-white/10">
                <span className="text-slate-400 block text-[8px] uppercase font-semibold">Underglow</span>
                <div className="flex items-center space-x-1 mt-0.5">
                  <span
                    className="w-2.5 h-2.5 rounded-full border border-white/40"
                    style={{ backgroundColor: scooterConfig.underglowEnabled ? scooterConfig.underglowColor : '#555' }}
                  />
                  <span className="font-mono text-slate-200 truncate text-[9px]">
                    {scooterConfig.underglowEnabled ? 'Neon ON' : 'Off'}
                  </span>
                </div>
              </div>
              <div className="bg-slate-950/60 p-1.5 rounded-xl border border-white/10">
                <span className="text-slate-400 block text-[8px] uppercase font-semibold">Cap</span>
                <div className="flex items-center space-x-1 mt-0.5">
                  <span className="w-2.5 h-2.5 rounded-full border border-white/40" style={{ backgroundColor: capColor }} />
                  <span className="font-mono text-slate-200 truncate text-[9px]">{capColor}</span>
                </div>
              </div>
              <div className="bg-slate-950/60 p-1.5 rounded-xl border border-white/10">
                <span className="text-slate-400 block text-[8px] uppercase font-semibold">Shoes</span>
                <div className="flex items-center space-x-1 mt-0.5">
                  <span className="w-2.5 h-2.5 rounded-full border border-white/40" style={{ backgroundColor: shoesColor }} />
                  <span className="font-mono text-slate-200 truncate text-[9px]">{shoesColor}</span>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column: Customization Controls with Segmented Tabs */}
          <div className="md:col-span-7 flex flex-col flex-1 overflow-hidden">
            {/* Sleek Segmented Tab Bar */}
            <div className="p-3 bg-slate-950/40 border-b border-white/10">
              <div className="grid grid-cols-4 gap-1 bg-slate-950/80 p-1 rounded-xl border border-white/10">
                <button
                  type="button"
                  onClick={() => setActiveTab('scooter')}
                  className={`py-2 px-2 rounded-lg text-xs font-semibold flex items-center justify-center space-x-1.5 transition-all cursor-pointer ${
                    activeTab === 'scooter'
                      ? 'bg-lime-600 text-white shadow-md shadow-lime-600/30'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-white/5'
                  }`}
                >
                  <Zap className="w-3.5 h-3.5" />
                  <span>🛴 E-Scooter</span>
                </button>

                <button
                  type="button"
                  onClick={() => setActiveTab('character')}
                  className={`py-2 px-2 rounded-lg text-xs font-semibold flex items-center justify-center space-x-1.5 transition-all cursor-pointer ${
                    activeTab === 'character'
                      ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-white/5'
                  }`}
                >
                  <User className="w-3.5 h-3.5" />
                  <span>Character</span>
                </button>

                <button
                  type="button"
                  onClick={() => setActiveTab('wardrobe')}
                  className={`py-2 px-2 rounded-lg text-xs font-semibold flex items-center justify-center space-x-1.5 transition-all cursor-pointer ${
                    activeTab === 'wardrobe'
                      ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-white/5'
                  }`}
                >
                  <Shirt className="w-3.5 h-3.5" />
                  <span>Wardrobe</span>
                </button>

                <button
                  type="button"
                  onClick={() => setActiveTab('footwear')}
                  className={`py-2 px-2 rounded-lg text-xs font-semibold flex items-center justify-center space-x-1.5 transition-all cursor-pointer ${
                    activeTab === 'footwear'
                      ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-white/5'
                  }`}
                >
                  <Footprints className="w-3.5 h-3.5" />
                  <span>Shoes & Hair</span>
                </button>
              </div>
            </div>

            {/* Tab Contents */}
            <div className="p-4 sm:p-5 space-y-4 overflow-y-auto max-h-[60vh] md:max-h-[68vh] flex-1">
              {/* Tab 0: E-Scooter Customization */}
              {activeTab === 'scooter' && (
                <div className="space-y-4 animate-fadeIn">
                  {/* Preset Themes */}
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <label className="block text-xs font-semibold uppercase tracking-wider text-slate-300">
                        🛴 E-Scooter Editions & Liveries
                      </label>
                      <span className="text-[10px] text-lime-400 font-mono">Lime Gen4 Platform</span>
                    </div>
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                      {SCOOTER_PRESETS.map((preset) => {
                        const isMatch = scooterConfig.frameColor === preset.config.frameColor;
                        return (
                          <button
                            key={preset.id}
                            type="button"
                            onClick={() => handleApplyPreset(preset)}
                            className={`p-2.5 rounded-2xl border text-left transition-all cursor-pointer flex flex-col justify-between space-y-2 ${
                              isMatch
                                ? 'bg-lime-500/15 border-lime-500 text-white ring-2 ring-lime-500/50 shadow-md'
                                : 'bg-slate-950/40 border-white/10 text-slate-300 hover:bg-white/5 hover:border-white/20'
                            }`}
                          >
                            <div className="flex items-center justify-between">
                              <span className="text-xs font-bold truncate">{preset.name}</span>
                              <span
                                className="w-3 h-3 rounded-full border border-white/30"
                                style={{ backgroundColor: preset.config.frameColor }}
                              />
                            </div>
                            <div className="flex items-center space-x-1.5">
                              <span className="text-[9px] px-1.5 py-0.5 rounded bg-slate-900 text-slate-400 font-mono">
                                {preset.badge}
                              </span>
                              {preset.config.underglowEnabled && (
                                <span className="text-[9px] text-lime-400">✨ Neon</span>
                              )}
                            </div>
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* Frame & Stem Color */}
                  <div className="bg-slate-950/40 border border-white/10 rounded-2xl p-4 space-y-2.5">
                    <div className="flex items-center justify-between">
                      <label className="block text-xs font-semibold uppercase tracking-wider text-slate-300">
                        Stem & Chassis Frame Color
                      </label>
                      <div className="flex items-center space-x-1.5">
                        <input
                          type="color"
                          value={scooterConfig.frameColor}
                          onChange={(e) => setScooterConfig({ ...scooterConfig, frameColor: e.target.value })}
                          className="w-5 h-5 rounded-lg border-0 bg-transparent cursor-pointer"
                        />
                        <input
                          type="text"
                          value={scooterConfig.frameColor}
                          onChange={(e) => setScooterConfig({ ...scooterConfig, frameColor: e.target.value })}
                          className="px-2 py-0.5 bg-slate-950/80 border border-white/10 rounded-lg text-xs font-mono text-white w-20 focus:outline-none focus:border-lime-400"
                        />
                      </div>
                    </div>
                    <div className="grid grid-cols-4 sm:grid-cols-8 gap-1.5">
                      {[
                        { name: 'Lime Green', color: '#00dd00' },
                        { name: 'Cyber Yellow', color: '#facc15' },
                        { name: 'Electric Cyan', color: '#06b6d4' },
                        { name: 'Hot Coral', color: '#f97316' },
                        { name: 'Neon Magenta', color: '#ec4899' },
                        { name: 'Royal Purple', color: '#a855f7' },
                        { name: 'Stealth Black', color: '#27272a' },
                        { name: 'Arctic White', color: '#f8fafc' },
                      ].map((item) => (
                        <button
                          key={item.color}
                          type="button"
                          onClick={() => setScooterConfig({ ...scooterConfig, frameColor: item.color })}
                          className={`flex items-center justify-center space-x-1 p-1.5 rounded-xl border text-[10px] transition-all cursor-pointer ${
                            scooterConfig.frameColor === item.color
                              ? 'bg-lime-600/20 border-lime-500 text-lime-300 ring-2 ring-lime-500 font-semibold'
                              : 'bg-white/[0.02] border-white/10 text-slate-400 hover:border-white/20'
                          }`}
                        >
                          <span
                            className="w-3.5 h-3.5 rounded-full shrink-0 border border-white/20 flex items-center justify-center"
                            style={{ backgroundColor: item.color }}
                          >
                            {scooterConfig.frameColor === item.color && (
                              <Check className="w-2.5 h-2.5 text-white stroke-[3]" />
                            )}
                          </span>
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Deck & Rim Accent Colors */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {/* Deck Color */}
                    <div className="bg-slate-950/40 border border-white/10 rounded-2xl p-3.5 space-y-2">
                      <div className="flex items-center justify-between">
                        <label className="block text-xs font-semibold uppercase tracking-wider text-slate-300">
                          Standing Deck
                        </label>
                        <input
                          type="color"
                          value={scooterConfig.deckColor}
                          onChange={(e) => setScooterConfig({ ...scooterConfig, deckColor: e.target.value })}
                          className="w-5 h-5 rounded-lg border-0 bg-transparent cursor-pointer"
                        />
                      </div>
                      <div className="grid grid-cols-4 gap-1">
                        {['#18181b', '#0f172a', '#1e1b4b', '#27272a'].map((c) => (
                          <button
                            key={c}
                            type="button"
                            onClick={() => setScooterConfig({ ...scooterConfig, deckColor: c })}
                            className={`p-1.5 rounded-lg border text-center text-[9px] ${
                              scooterConfig.deckColor === c ? 'border-lime-500 bg-lime-500/20' : 'border-white/10'
                            }`}
                          >
                            <span className="w-3 h-3 rounded-full inline-block" style={{ backgroundColor: c }} />
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Wheel Rim & Fork Accents */}
                    <div className="bg-slate-950/40 border border-white/10 rounded-2xl p-3.5 space-y-2">
                      <div className="flex items-center justify-between">
                        <label className="block text-xs font-semibold uppercase tracking-wider text-slate-300">
                          Rims & Grips Accent
                        </label>
                        <input
                          type="color"
                          value={scooterConfig.accentColor}
                          onChange={(e) => setScooterConfig({ ...scooterConfig, accentColor: e.target.value })}
                          className="w-5 h-5 rounded-lg border-0 bg-transparent cursor-pointer"
                        />
                      </div>
                      <div className="grid grid-cols-4 gap-1">
                        {['#ffffff', '#00dd00', '#facc15', '#ef4444'].map((c) => (
                          <button
                            key={c}
                            type="button"
                            onClick={() => setScooterConfig({ ...scooterConfig, accentColor: c })}
                            className={`p-1.5 rounded-lg border text-center text-[9px] ${
                              scooterConfig.accentColor === c ? 'border-lime-500 bg-lime-500/20' : 'border-white/10'
                            }`}
                          >
                            <span className="w-3 h-3 rounded-full inline-block" style={{ backgroundColor: c }} />
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Underglow Neon Lighting Engine */}
                  <div className="bg-slate-950/40 border border-white/10 rounded-2xl p-4 space-y-2.5">
                    <div className="flex items-center justify-between">
                      <div>
                        <label className="block text-xs font-semibold uppercase tracking-wider text-slate-300">
                          Deck Underglow LED Light
                        </label>
                        <p className="text-[10px] text-slate-400">Ground-illuminating high-lumen neon radiance</p>
                      </div>
                      <button
                        type="button"
                        onClick={() =>
                          setScooterConfig({
                            ...scooterConfig,
                            underglowEnabled: !scooterConfig.underglowEnabled,
                          })
                        }
                        className={`px-3 py-1 rounded-xl text-xs font-bold border transition-all cursor-pointer ${
                          scooterConfig.underglowEnabled
                            ? 'bg-lime-500 text-slate-950 border-lime-400 shadow-md shadow-lime-500/30'
                            : 'bg-slate-800 text-slate-400 border-white/10'
                        }`}
                      >
                        {scooterConfig.underglowEnabled ? '⚡ LED Active' : 'Off'}
                      </button>
                    </div>

                    {scooterConfig.underglowEnabled && (
                      <div className="grid grid-cols-5 gap-1.5 pt-1">
                        {[
                          { name: 'Lime Neon', color: '#00ff44' },
                          { name: 'Cyan Glow', color: '#06b6d4' },
                          { name: 'Hot Pink', color: '#ec4899' },
                          { name: 'Amber Gold', color: '#f59e0b' },
                          { name: 'Electric Violet', color: '#d946ef' },
                        ].map((u) => (
                          <button
                            key={u.color}
                            type="button"
                            onClick={() => setScooterConfig({ ...scooterConfig, underglowColor: u.color })}
                            className={`p-1.5 rounded-xl border text-[10px] flex items-center justify-center space-x-1 ${
                              scooterConfig.underglowColor === u.color
                                ? 'bg-lime-500/20 border-lime-400 text-white font-bold'
                                : 'border-white/10 text-slate-400 hover:border-white/20'
                            }`}
                          >
                            <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: u.color }} />
                            <span className="truncate text-[9px]">{u.name}</span>
                          </button>
                        ))}
                      </div>
                    )}
                  </div>

                  {/* Stem Decal / Branding Text */}
                  <div className="bg-slate-950/40 border border-white/10 rounded-2xl p-4 space-y-2">
                    <label className="block text-xs font-semibold uppercase tracking-wider text-slate-300">
                      Stem Graphic Badge
                    </label>
                    <div className="grid grid-cols-4 sm:grid-cols-6 gap-1.5">
                      {['LIME', 'TURBO', 'FAST', 'DEV', '⚡ LIME', 'ECO'].map((tag) => (
                        <button
                          key={tag}
                          type="button"
                          onClick={() => setScooterConfig({ ...scooterConfig, decalText: tag })}
                          className={`py-1.5 px-2 rounded-xl border text-xs font-mono font-bold transition-all cursor-pointer ${
                            scooterConfig.decalText === tag
                              ? 'bg-lime-500/20 border-lime-400 text-lime-300 ring-2 ring-lime-400'
                              : 'bg-slate-900/60 border-white/10 text-slate-400 hover:text-slate-200'
                          }`}
                        >
                          {tag}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {/* Tab 1: Character (Model Archetype, Hair & Complexion) */}
              {activeTab === 'character' && (
                <div className="space-y-4 animate-fadeIn">
                  {/* Mascot Archetype */}
                  <div className="space-y-2">
                    <label className="block text-xs font-semibold uppercase tracking-wider text-slate-300">
                      Mascot Model Archetype
                    </label>
                    <div className="grid grid-cols-2 gap-3">
                      <button
                        type="button"
                        onClick={() => {
                          setSkin('college_dev_m');
                          if (hoodieColor === '#06b6d4') setHoodieColor('#ea580c');
                          if (pantsColor === '#18181b') setPantsColor('#1d4ed8');
                          if (shoesColor === '#ffffff') setShoesColor('#dc2626');
                        }}
                        className={`relative flex items-center space-x-3 p-3 rounded-2xl border transition-all text-left cursor-pointer backdrop-blur-sm ${
                          skin === 'college_dev_m'
                            ? 'bg-indigo-600/20 border-indigo-500 text-white ring-2 ring-indigo-500 shadow-[0_0_15px_rgba(99,102,241,0.25)]'
                            : 'bg-white/[0.03] border-white/10 text-slate-400 hover:border-white/20'
                        }`}
                      >
                        <span className="text-2xl p-1.5 bg-slate-900/80 rounded-xl border border-white/10">🧢</span>
                        <div className="overflow-hidden min-w-0 pr-3">
                          <div className="text-xs font-bold text-white truncate">Indie Mascot (M)</div>
                          <div className="text-[11px] text-slate-400 truncate">Cap & Headphones</div>
                        </div>
                        {skin === 'college_dev_m' && (
                          <span className="absolute top-3 right-3 w-4 h-4 rounded-full bg-indigo-500 text-white flex items-center justify-center shadow">
                            <Check className="w-2.5 h-2.5 stroke-[3]" />
                          </span>
                        )}
                      </button>

                      <button
                        type="button"
                        onClick={() => {
                          setSkin('college_dev_f');
                          if (hoodieColor === '#ea580c') setHoodieColor('#06b6d4');
                          if (pantsColor === '#1d4ed8') setPantsColor('#18181b');
                          if (shoesColor === '#dc2626') setShoesColor('#ffffff');
                        }}
                        className={`relative flex items-center space-x-3 p-3 rounded-2xl border transition-all text-left cursor-pointer backdrop-blur-sm ${
                          skin === 'college_dev_f'
                            ? 'bg-indigo-600/20 border-indigo-500 text-white ring-2 ring-indigo-500 shadow-[0_0_15px_rgba(99,102,241,0.25)]'
                            : 'bg-white/[0.03] border-white/10 text-slate-400 hover:border-white/20'
                        }`}
                      >
                        <span className="text-2xl p-1.5 bg-slate-900/80 rounded-xl border border-white/10">🎧</span>
                        <div className="overflow-hidden min-w-0 pr-3">
                          <div className="text-xs font-bold text-white truncate">Indie Mascot (F)</div>
                          <div className="text-[11px] text-slate-400 truncate">Ponytail & Headset</div>
                        </div>
                        {skin === 'college_dev_f' && (
                          <span className="absolute top-3 right-3 w-4 h-4 rounded-full bg-indigo-500 text-white flex items-center justify-center shadow">
                            <Check className="w-2.5 h-2.5 stroke-[3]" />
                          </span>
                        )}
                      </button>
                    </div>
                  </div>

                  {/* Skin Tone (Complexion) Selector */}
                  <div className="bg-slate-950/40 border border-white/10 rounded-2xl p-4 space-y-2.5">
                    <div className="flex items-center justify-between">
                      <label className="text-xs font-semibold uppercase tracking-wider text-slate-300 flex items-center space-x-1.5">
                        <User className="w-3.5 h-3.5 text-indigo-400" />
                        <span>Skin Complexion Tone</span>
                      </label>
                      <span className="text-xs text-slate-300 font-medium">
                        {SKIN_TONE_OPTIONS.find((s) => s.id === skinTone || s.color.toLowerCase() === skinTone.toLowerCase())?.name || 'Custom'}
                      </span>
                    </div>
                    <div className="grid grid-cols-7 gap-1.5">
                      {SKIN_TONE_OPTIONS.map((tone) => {
                        const isActive = skinTone === tone.id || skinTone.toLowerCase() === tone.color.toLowerCase();
                        return (
                          <button
                            key={tone.id}
                            type="button"
                            onClick={() => setSkinTone(tone.id)}
                            className={`group flex flex-col items-center p-1.5 rounded-xl border transition-all cursor-pointer ${
                              isActive
                                ? 'bg-indigo-600/20 border-indigo-500 text-white ring-2 ring-indigo-500'
                                : 'bg-white/[0.02] border-white/10 text-slate-400 hover:border-white/20'
                            }`}
                            title={tone.name}
                          >
                            <span
                              className="w-5 h-5 rounded-full border border-white/20 shadow-sm flex items-center justify-center shrink-0 mb-1"
                              style={{ backgroundColor: tone.color }}
                            >
                              {isActive && <Check className="w-3 h-3 text-slate-900 stroke-[3]" />}
                            </span>
                            <span className="text-[9px] font-medium leading-none truncate w-full text-center">{tone.name}</span>
                          </button>
                        );
                      })}
                    </div>
                  </div>
                </div>
              )}

              {/* Tab 2: Wardrobe (Baseball Cap, Hoodie & Jeans) */}
              {activeTab === 'wardrobe' && (
                <div className="space-y-4 animate-fadeIn">
                  {/* Baseball Cap Color Picker (With Green Taboo Notice) */}
                  <div className="bg-slate-950/40 border border-white/10 rounded-2xl p-4 space-y-2.5">
                    <div className="flex items-center justify-between">
                      <label className="text-xs font-semibold uppercase tracking-wider text-slate-300 flex items-center space-x-1.5">
                        <span className="text-sm">🧢</span>
                        <span>Baseball Cap Tone</span>
                      </label>
                      <div className="flex items-center space-x-1.5">
                        <div
                          className="w-3.5 h-3.5 rounded-full border border-white/60 shadow-sm"
                          style={{ backgroundColor: capColor }}
                        />
                        <span className="text-xs font-mono text-slate-300 uppercase">{capColor}</span>
                      </div>
                    </div>

                    <div className="grid grid-cols-6 gap-2">
                      {BASEBALL_CAP_PALETTES.map((swatch) => {
                        const isActive = capColor.toLowerCase() === swatch.hex.toLowerCase();
                        return (
                          <button
                            key={swatch.hex}
                            type="button"
                            onClick={() => handleCapColorChange(swatch.hex)}
                            className={`relative h-8 rounded-xl flex items-center justify-center border transition-all cursor-pointer ${
                              isActive
                                ? 'border-indigo-400 ring-2 ring-indigo-500 ring-offset-2 ring-offset-slate-900 scale-105 shadow-md z-10'
                                : 'border-white/10 hover:scale-105 hover:border-white/30'
                            }`}
                            style={{ backgroundColor: swatch.hex }}
                            title={`${swatch.name} (${swatch.hex})`}
                          >
                            {isActive && (
                              <Check
                                className={`w-3.5 h-3.5 stroke-[3] ${
                                  ['#ffffff', '#fef3c7', '#d97706'].includes(swatch.hex)
                                    ? 'text-slate-950'
                                    : 'text-white'
                                }`}
                              />
                            )}
                          </button>
                        );
                      })}

                      {/* Excluded Green Taboo Button Swatch */}
                      <button
                        type="button"
                        onMouseEnter={() => setIsHoveringGreenTaboo(true)}
                        onMouseLeave={() => setIsHoveringGreenTaboo(false)}
                        onClick={() => {
                          setGreenTabooWarning(
                            "🚫 Green Hat Cultural Taboo: In East Asian and Chinese culture, 'wearing a green hat' (戴绿帽子) is a recognized cultural taboo symbolizing an unfaithful partner. Green caps are excluded to maintain cultural etiquette."
                          );
                        }}
                        className="relative h-8 rounded-xl flex items-center justify-center border border-emerald-500/40 bg-emerald-700/40 text-emerald-300 opacity-60 hover:opacity-100 hover:scale-105 hover:border-rose-400 hover:bg-rose-950/40 transition-all cursor-not-allowed group"
                        title="Green Cap Excluded (Asian Cultural Taboo)"
                      >
                        <span className="text-xs font-bold text-rose-400 group-hover:scale-110 transition-transform">
                          🚫
                        </span>
                      </button>
                    </div>

                    {/* Cultural Taboo Hover / Trigger Info Banner */}
                    {(isHoveringGreenTaboo || greenTabooWarning) && (
                      <div className="p-3 rounded-xl bg-amber-950/40 border border-amber-500/30 flex items-start space-x-2 text-xs text-amber-200 animate-fadeIn">
                        <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                        <div className="space-y-0.5">
                          <span className="font-semibold text-amber-300 block">Green Hat Cultural Taboo (戴绿帽子)</span>
                          <p className="text-[11px] leading-relaxed text-amber-200/90">
                            {greenTabooWarning ||
                              "In East Asian culture, 'wearing a green hat' carries a significant cultural taboo regarding infidelity. Green caps are purposefully excluded from headwear customization."}
                          </p>
                        </div>
                      </div>
                    )}

                    <div className="flex items-center space-x-2 pt-2 border-t border-white/5">
                      <span className="text-xs text-slate-400">Custom Cap:</span>
                      <div className="flex items-center space-x-1.5">
                        <input
                          type="color"
                          value={capColor}
                          onChange={(e) => handleCapColorChange(e.target.value)}
                          className="w-6 h-6 rounded-md border border-white/20 bg-transparent cursor-pointer p-0"
                        />
                        <input
                          type="text"
                          value={capColor}
                          onChange={(e) => handleCapColorChange(e.target.value)}
                          placeholder="#ffffff"
                          className="px-2 py-0.5 bg-slate-950/80 border border-white/10 rounded-lg text-xs font-mono text-white w-24 focus:outline-none focus:border-indigo-400 focus:ring-1 focus:ring-indigo-500/25"
                        />
                      </div>
                    </div>
                  </div>

                  {/* Scarf Color Picker */}
                  <div className="bg-slate-950/40 border border-white/10 rounded-2xl p-4 space-y-2.5">
                    <div className="flex items-center justify-between">
                      <label className="text-xs font-semibold uppercase tracking-wider text-slate-300 flex items-center space-x-1.5">
                        <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                        <span>Knitted Scarf Color</span>
                      </label>
                      <div className="flex items-center space-x-1.5">
                        <div
                          className="w-3.5 h-3.5 rounded-full border border-white/60 shadow-sm"
                          style={{ backgroundColor: scarfColor }}
                        />
                        <span className="text-xs font-mono text-slate-300 uppercase">{scarfColor}</span>
                      </div>
                    </div>

                    <div className="grid grid-cols-6 gap-2">
                      {[
                        { name: 'Crimson Red', hex: '#dc2626' },
                        { name: 'Royal Blue', hex: '#2563eb' },
                        { name: 'Emerald Green', hex: '#16a34a' },
                        { name: 'Warm Mustard', hex: '#d97706' },
                        { name: 'Cosmopolitan Pink', hex: '#db2777' },
                        { name: 'Plum Violet', hex: '#7c3aed' },
                        { name: 'Cozy Cream', hex: '#fef3c7' },
                        { name: 'Midnight Charcoal', hex: '#374151' },
                        { name: 'Snow White', hex: '#ffffff' },
                        { name: 'Cyan Breeze', hex: '#0891b2' },
                        { name: 'Amber Sunset', hex: '#f97316' },
                        { name: 'Forest Teal', hex: '#0d9488' },
                      ].map((swatch) => {
                        const isActive = scarfColor.toLowerCase() === swatch.hex.toLowerCase();
                        return (
                          <button
                            key={swatch.hex}
                            type="button"
                            onClick={() => setScarfColor(swatch.hex)}
                            className={`relative h-8 rounded-xl flex items-center justify-center border transition-all cursor-pointer ${
                              isActive
                                ? 'border-amber-400 ring-2 ring-amber-500 ring-offset-2 ring-offset-slate-900 scale-105 shadow-md z-10'
                                : 'border-white/10 hover:scale-105 hover:border-white/30'
                            }`}
                            style={{ backgroundColor: swatch.hex }}
                            title={`${swatch.name} (${swatch.hex})`}
                          >
                            {isActive && (
                              <Check className={`w-3.5 h-3.5 stroke-[3] ${['#fef3c7', '#ffffff'].includes(swatch.hex) ? 'text-slate-950' : 'text-white'}`} />
                            )}
                          </button>
                        );
                      })}
                    </div>

                    <div className="flex items-center space-x-2 pt-2 border-t border-white/5">
                      <span className="text-xs text-slate-400">Custom Scarf:</span>
                      <div className="flex items-center space-x-1.5">
                        <input
                          type="color"
                          value={scarfColor}
                          onChange={(e) => setScarfColor(e.target.value)}
                          className="w-6 h-6 rounded-md border border-white/20 bg-transparent cursor-pointer p-0"
                        />
                        <input
                          type="text"
                          value={scarfColor}
                          onChange={(e) => setScarfColor(e.target.value)}
                          placeholder="#dc2626"
                          className="px-2 py-0.5 bg-slate-950/80 border border-white/10 rounded-lg text-xs font-mono text-white w-24 focus:outline-none focus:border-amber-400 focus:ring-1 focus:ring-amber-500/25"
                        />
                      </div>
                    </div>
                  </div>

                  {/* Hoodie Color Picker */}
                  <div className="bg-slate-950/40 border border-white/10 rounded-2xl p-4 space-y-2.5">
                    <div className="flex items-center justify-between">
                      <label className="text-xs font-semibold uppercase tracking-wider text-slate-300 flex items-center space-x-1.5">
                        <Palette className="w-3.5 h-3.5 text-indigo-400" />
                        <span>Hoodie Color</span>
                      </label>
                      <div className="flex items-center space-x-1.5">
                        <div
                          className="w-3.5 h-3.5 rounded-full border border-white/60 shadow-sm"
                          style={{ backgroundColor: hoodieColor }}
                        />
                        <span className="text-xs font-mono text-slate-300 uppercase">{hoodieColor}</span>
                      </div>
                    </div>

                    <div className="grid grid-cols-6 gap-2">
                      {HOODIE_COLOR_PALETTES.map((swatch) => {
                        const isActive = hoodieColor.toLowerCase() === swatch.hex.toLowerCase();
                        return (
                          <button
                            key={swatch.hex}
                            type="button"
                            onClick={() => setHoodieColor(swatch.hex)}
                            className={`relative h-8 rounded-xl flex items-center justify-center border transition-all cursor-pointer ${
                              isActive
                                ? 'border-indigo-400 ring-2 ring-indigo-500 ring-offset-2 ring-offset-slate-900 scale-105 shadow-md z-10'
                                : 'border-white/10 hover:scale-105 hover:border-white/30'
                            }`}
                            style={{ backgroundColor: swatch.hex }}
                            title={`${swatch.name} (${swatch.hex})`}
                          >
                            {isActive && (
                              <Check className={`w-3.5 h-3.5 stroke-[3] ${['#f8fafc', '#eab308'].includes(swatch.hex) ? 'text-slate-950' : 'text-white'}`} />
                            )}
                          </button>
                        );
                      })}
                    </div>

                    <div className="flex items-center space-x-2 pt-2 border-t border-white/5">
                      <span className="text-xs text-slate-400">Custom Color:</span>
                      <div className="flex items-center space-x-1.5">
                        <input
                          type="color"
                          value={hoodieColor}
                          onChange={(e) => setHoodieColor(e.target.value)}
                          className="w-6 h-6 rounded-md border border-white/20 bg-transparent cursor-pointer p-0"
                        />
                        <input
                          type="text"
                          value={hoodieColor}
                          onChange={(e) => setHoodieColor(e.target.value)}
                          placeholder="#ea580c"
                          className="px-2 py-0.5 bg-slate-950/80 border border-white/10 rounded-lg text-xs font-mono text-white w-24 focus:outline-none focus:border-indigo-400 focus:ring-1 focus:ring-indigo-500/25"
                        />
                      </div>
                    </div>
                  </div>

                  {/* Jeans / Pants Color Picker */}
                  <div className="bg-slate-950/40 border border-white/10 rounded-2xl p-4 space-y-2.5">
                    <div className="flex items-center justify-between">
                      <label className="text-xs font-semibold uppercase tracking-wider text-slate-300 flex items-center space-x-1.5">
                        <Sliders className="w-3.5 h-3.5 text-indigo-400" />
                        <span>Jeans & Pants Tone</span>
                      </label>
                      <div className="flex items-center space-x-1.5">
                        <div
                          className="w-3.5 h-3.5 rounded-full border border-white/60 shadow-sm"
                          style={{ backgroundColor: pantsColor }}
                        />
                        <span className="text-xs font-mono text-slate-300 uppercase">{pantsColor}</span>
                      </div>
                    </div>

                    <div className="grid grid-cols-4 sm:grid-cols-8 gap-1.5">
                      {JEANS_COLOR_PALETTES.map((swatch) => {
                        const isActive = pantsColor.toLowerCase() === swatch.hex.toLowerCase();
                        return (
                          <button
                            key={swatch.hex}
                            type="button"
                            onClick={() => setPantsColor(swatch.hex)}
                            className={`relative h-7 rounded-xl flex items-center justify-center border transition-all cursor-pointer ${
                              isActive
                                ? 'border-indigo-400 ring-2 ring-indigo-500 ring-offset-1 ring-offset-slate-900 scale-105 shadow-md z-10'
                                : 'border-white/10 hover:scale-105 hover:border-white/30'
                            }`}
                            style={{ backgroundColor: swatch.hex }}
                            title={`${swatch.name} (${swatch.hex})`}
                          >
                            {isActive && (
                              <Check className="w-3 h-3 text-white stroke-[3]" />
                            )}
                          </button>
                        );
                      })}
                    </div>

                    <div className="flex items-center space-x-2 pt-2 border-t border-white/5">
                      <span className="text-xs text-slate-400">Custom Tone:</span>
                      <div className="flex items-center space-x-1.5">
                        <input
                          type="color"
                          value={pantsColor}
                          onChange={(e) => setPantsColor(e.target.value)}
                          className="w-6 h-6 rounded-md border border-white/20 bg-transparent cursor-pointer p-0"
                        />
                        <input
                          type="text"
                          value={pantsColor}
                          onChange={(e) => setPantsColor(e.target.value)}
                          placeholder="#1d4ed8"
                          className="px-2 py-0.5 bg-slate-950/80 border border-white/10 rounded-lg text-xs font-mono text-white w-24 focus:outline-none focus:border-indigo-400 focus:ring-1 focus:ring-indigo-500/25"
                        />
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* Tab 3: Footwear & Hair */}
              {activeTab === 'footwear' && (
                <div className="space-y-4 animate-fadeIn">
                  {/* Sneakers / Shoes Color Picker */}
                  <div className="bg-slate-950/40 border border-white/10 rounded-2xl p-4 space-y-2.5">
                    <div className="flex items-center justify-between">
                      <label className="text-xs font-semibold uppercase tracking-wider text-slate-300 flex items-center space-x-1.5">
                        <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
                        <span>Sneakers & Shoes Color</span>
                      </label>
                      <div className="flex items-center space-x-1.5">
                        <div
                          className="w-3.5 h-3.5 rounded-full border border-white/60 shadow-sm"
                          style={{ backgroundColor: shoesColor }}
                        />
                        <span className="text-xs font-mono text-slate-300 uppercase">{shoesColor}</span>
                      </div>
                    </div>

                    <div className="grid grid-cols-4 sm:grid-cols-8 gap-1.5">
                      {SNEAKER_COLOR_PALETTES.map((swatch) => {
                        const isActive = shoesColor.toLowerCase() === swatch.hex.toLowerCase();
                        return (
                          <button
                            key={swatch.hex}
                            type="button"
                            onClick={() => setShoesColor(swatch.hex)}
                            className={`relative h-7 rounded-xl flex items-center justify-center border transition-all cursor-pointer ${
                              isActive
                                ? 'border-indigo-400 ring-2 ring-indigo-500 ring-offset-1 ring-offset-slate-900 scale-105 shadow-md z-10'
                                : 'border-white/10 hover:scale-105 hover:border-white/30'
                            }`}
                            style={{ backgroundColor: swatch.hex }}
                            title={`${swatch.name} (${swatch.hex})`}
                          >
                            {isActive && (
                              <Check className={`w-3.5 h-3.5 stroke-[3] ${['#ffffff', '#eab308', '#84cc16'].includes(swatch.hex) ? 'text-slate-950' : 'text-white'}`} />
                            )}
                          </button>
                        );
                      })}
                    </div>

                    <div className="flex items-center space-x-2 pt-2 border-t border-white/5">
                      <span className="text-xs text-slate-400">Custom Sneaker:</span>
                      <div className="flex items-center space-x-1.5">
                        <input
                          type="color"
                          value={shoesColor}
                          onChange={(e) => setShoesColor(e.target.value)}
                          className="w-6 h-6 rounded-md border border-white/20 bg-transparent cursor-pointer p-0"
                        />
                        <input
                          type="text"
                          value={shoesColor}
                          onChange={(e) => setShoesColor(e.target.value)}
                          placeholder="#dc2626"
                          className="px-2 py-0.5 bg-slate-950/80 border border-white/10 rounded-lg text-xs font-mono text-white w-24 focus:outline-none focus:border-indigo-400 focus:ring-1 focus:ring-indigo-500/25"
                        />
                      </div>
                    </div>
                  </div>

                  {/* Hair Color */}
                  <div className="bg-slate-950/40 border border-white/10 rounded-2xl p-4 space-y-2.5">
                    <div className="flex items-center justify-between">
                      <label className="block text-xs font-semibold uppercase tracking-wider text-slate-300">
                        Hairstyle Tone
                      </label>
                      <span className="text-xs text-slate-300 font-medium">
                        {HAIR_COLOR_OPTIONS.find((h) => h.hex === hairColor)?.name || 'Hair'}
                      </span>
                    </div>
                    <div className="grid grid-cols-4 sm:grid-cols-8 gap-1.5">
                      {HAIR_COLOR_OPTIONS.map((h) => {
                        const isActive = hairColor === h.hex;
                        return (
                          <button
                            key={h.hex}
                            type="button"
                            onClick={() => setHairColor(h.hex)}
                            className={`flex items-center justify-center space-x-1 p-1.5 rounded-xl border text-[10px] transition-all cursor-pointer ${
                              isActive
                                ? 'bg-indigo-600/20 border-indigo-500 text-indigo-300 ring-2 ring-indigo-500 font-semibold'
                                : 'bg-white/[0.02] border-white/10 text-slate-400 hover:border-white/20'
                            }`}
                            title={h.name}
                          >
                            <span
                              className="w-3.5 h-3.5 rounded-full shrink-0 border border-white/20 flex items-center justify-center"
                              style={{ backgroundColor: h.color }}
                            >
                              {isActive && <Check className="w-2.5 h-2.5 text-white stroke-[3]" />}
                            </span>
                            <span className="truncate text-[9px]">{h.name}</span>
                          </button>
                        );
                      })}
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="flex items-center justify-end space-x-3 px-6 py-4 bg-slate-950/95 border-t border-white/10 shrink-0">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-slate-400 hover:text-white transition-all cursor-pointer rounded-xl hover:bg-white/5"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={handleSave}
            className="flex items-center space-x-2 px-5 py-2.5 bg-gradient-to-r from-indigo-500 via-indigo-600 to-sky-500 hover:from-indigo-400 hover:to-sky-400 active:scale-[0.98] text-white text-xs font-bold rounded-xl transition-all shadow-lg shadow-indigo-600/30 cursor-pointer"
          >
            <Check className="w-4 h-4 stroke-[3]" />
            <span>Apply Customization</span>
          </button>
        </div>
      </div>
    </div>
  );
};
