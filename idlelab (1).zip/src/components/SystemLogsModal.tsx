import React, { useState, useEffect } from 'react';
import { X, Terminal, Trash2, ShieldAlert, CheckCircle, AlertTriangle, Info } from 'lucide-react';
import { systemLogger, LogEntry } from '../lib/logger';

interface SystemLogsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function SystemLogsModal({ isOpen, onClose }: SystemLogsModalProps) {
  const [logs, setLogs] = useState<LogEntry[]>(systemLogger.getLogs());
  const [filter, setFilter] = useState<'all' | 'error' | 'warn' | 'info'>('all');

  useEffect(() => {
    const unsubscribe = systemLogger.subscribe(() => {
      setLogs([...systemLogger.getLogs()]);
    });
    return unsubscribe;
  }, []);

  if (!isOpen) return null;

  const filteredLogs = logs.filter(l => {
    if (filter === 'all') return true;
    if (filter === 'error') return l.level === 'error';
    if (filter === 'warn') return l.level === 'warn';
    return l.level === 'info' || l.level === 'success';
  });

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="w-full max-w-4xl h-[80vh] bg-[#0d1117] border border-white/15 rounded-2xl shadow-2xl flex flex-col overflow-hidden text-neutral-200 font-sans">
        
        {/* Header */}
        <div className="h-12 bg-[#161b22] border-b border-white/10 px-4 flex items-center justify-between shrink-0">
          <div className="flex items-center space-x-2">
            <Terminal className="w-5 h-5 text-emerald-400" />
            <span className="font-bold text-sm text-white">IdleLab System & Error Logs</span>
            <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
              {logs.length} Total Logs
            </span>
          </div>

          <div className="flex items-center space-x-3">
            <button
              onClick={() => systemLogger.clearLogs()}
              className="px-2.5 py-1 bg-red-500/20 hover:bg-red-500/30 text-red-300 border border-red-500/30 rounded-lg text-xs font-semibold flex items-center space-x-1.5 transition-colors cursor-pointer"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Clear Logs</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-neutral-400 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Filter bar */}
        <div className="px-4 py-2 bg-[#161b22]/50 border-b border-white/10 flex items-center space-x-2 text-xs">
          <span className="text-neutral-400 font-medium mr-2">Filter Level:</span>
          {(['all', 'error', 'warn', 'info'] as const).map(f => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={`px-3 py-1 rounded-lg font-semibold uppercase tracking-wider transition-colors cursor-pointer ${
                filter === f
                  ? 'bg-sky-600 text-white shadow'
                  : 'bg-white/5 text-neutral-400 hover:text-white hover:bg-white/10'
              }`}
            >
              {f}
            </button>
          ))}
        </div>

        {/* Logs list */}
        <div className="flex-1 overflow-y-auto p-4 space-y-2 font-mono text-xs">
          {filteredLogs.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full text-neutral-500 space-y-2">
              <CheckCircle className="w-8 h-8 text-emerald-500/50" />
              <p>No system errors or warnings recorded. All systems operating smoothly.</p>
            </div>
          ) : (
            filteredLogs.map(log => {
              const isError = log.level === 'error';
              const isWarn = log.level === 'warn';
              const isSuccess = log.level === 'success';

              return (
                <div
                  key={log.id}
                  className={`p-3 rounded-xl border flex flex-col space-y-1 ${
                    isError
                      ? 'bg-red-500/10 border-red-500/30 text-red-200'
                      : isWarn
                      ? 'bg-amber-500/10 border-amber-500/30 text-amber-200'
                      : isSuccess
                      ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-200'
                      : 'bg-[#161b22] border-white/10 text-neutral-300'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      {isError ? (
                        <ShieldAlert className="w-4 h-4 text-red-400 shrink-0" />
                      ) : isWarn ? (
                        <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />
                      ) : (
                        <Info className="w-4 h-4 text-sky-400 shrink-0" />
                      )}
                      <span className="font-bold text-white px-1.5 py-0.5 rounded bg-black/30 border border-white/10 text-[10px]">
                        {log.source}
                      </span>
                      <span className="text-[11px] font-semibold text-neutral-400">{log.timestamp}</span>
                    </div>
                    <span className={`text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded ${
                      isError ? 'bg-red-500/20 text-red-300' : isWarn ? 'bg-amber-500/20 text-amber-300' : 'bg-sky-500/20 text-sky-300'
                    }`}>
                      {log.level}
                    </span>
                  </div>
                  <div className="break-all font-mono leading-relaxed pl-6">{log.message}</div>
                  {log.details && (
                    <div className="text-[10px] text-neutral-400 pl-6 font-mono opacity-80">{log.details}</div>
                  )}
                </div>
              );
            })
          )}
        </div>

        {/* Footer info */}
        <div className="px-4 py-2.5 bg-[#161b22] border-t border-white/10 text-[11px] text-neutral-400 flex items-center justify-between shrink-0">
          <span>IdleLab Automated Telemetry & Error Surveillance Engine</span>
          <span className="text-emerald-400 font-semibold">● Active Monitoring</span>
        </div>

      </div>
    </div>
  );
}
