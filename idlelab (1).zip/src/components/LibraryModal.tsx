import React, { useState } from 'react';
import {
  Library,
  BookOpen,
  Search,
  ExternalLink,
  Plus,
  Star,
  Bookmark,
  X,
  Sparkles,
  Layers,
  Code,
  Compass,
} from 'lucide-react';
import { LibraryBook } from '../types';

interface LibraryModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const DEFAULT_BOOKS: LibraryBook[] = [
  {
    id: 'book-1',
    title: 'Designing Data-Intensive Applications',
    author: 'Martin Kleppmann',
    category: 'Architecture',
    summary: 'The definitive guide to the fundamental principles of data systems, replication, partitioning, transactions, and distributed consensus.',
    keyTakeaway: 'Reliability, scalability, and maintainability should guide every distributed systems trade-off.',
    color: '#0284c7',
    pages: 616,
    rating: 5,
    readUrl: 'https://dataintensive.net/',
  },
  {
    id: 'book-2',
    title: 'Clean Architecture: A Craftsman\'s Guide',
    author: 'Robert C. Martin',
    category: 'Engineering',
    summary: 'Universal rules of software structure and boundary separation between business rules, use-cases, and external frameworks.',
    keyTakeaway: 'Depend in the direction of stability; keep business logic insulated from database and UI drivers.',
    color: '#16a34a',
    pages: 432,
    rating: 4.8,
    readUrl: 'https://cleanarchitecture.io',
  },
  {
    id: 'book-3',
    title: 'Refactoring UI & Design Systems',
    author: 'Adam Wathan & Steve Schoger',
    category: 'Design',
    summary: 'Practical tactical UI design advice for engineers—hierarchy, typography scaling, depth, and spatial balance.',
    keyTakeaway: 'Design with visual contrast and mathematical spacing instead of relying on borders and colors.',
    color: '#9333ea',
    pages: 250,
    rating: 4.9,
    readUrl: 'https://www.refactoringui.com/',
  },
  {
    id: 'book-4',
    title: 'Real-Time 3D Rendering & WebGL',
    author: 'Tomas Akenine-Möller & Eric Haines',
    category: '3D & Graphics',
    summary: 'Mastering modern shader pipelines, PBR material lighting, spatial audio, and WebGL/Three.js optimization.',
    keyTakeaway: 'Batch draw calls, instance repeated meshes, and minimize GPU-CPU state switches for silky 60 FPS.',
    color: '#ea580c',
    pages: 1178,
    rating: 5,
  },
  {
    id: 'book-5',
    title: 'Staff Engineer: Leadership Beyond Management',
    author: 'Will Larson',
    category: 'Leadership',
    summary: 'Navigating technical direction, architecture sponsorship, executive communication, and high-impact engineering.',
    keyTakeaway: 'Set the technical strategy and build alignment by writing crisp proposals and empowering autonomous pods.',
    color: '#e11d48',
    pages: 380,
    rating: 4.7,
  },
  {
    id: 'book-6',
    title: 'The Design of Everyday Things',
    author: 'Don Norman',
    category: 'Design',
    summary: 'Cognitive psychology of affordances, signifiers, mental models, and intuitive human-machine interfaces.',
    keyTakeaway: 'Good design is actually a lot harder to notice than poor design, because it fits human intuition naturally.',
    color: '#d97706',
    pages: 368,
    rating: 4.9,
  },
];

const CATEGORIES = ['All', 'Architecture', 'Engineering', 'Design', '3D & Graphics', 'Leadership'];

export function LibraryModal({ isOpen, onClose }: LibraryModalProps) {
  const [books, setBooks] = useState<LibraryBook[]>(DEFAULT_BOOKS);
  const [activeCategory, setActiveCategory] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedBook, setSelectedBook] = useState<LibraryBook | null>(DEFAULT_BOOKS[0]);
  const [savedBookIds, setSavedBookIds] = useState<Set<string>>(new Set(['book-1', 'book-3']));

  // Add Book Form
  const [isAdding, setIsAdding] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newAuthor, setNewAuthor] = useState('');
  const [newCategory, setNewCategory] = useState('Engineering');
  const [newSummary, setNewSummary] = useState('');
  const [newTakeaway, setNewTakeaway] = useState('');

  if (!isOpen) return null;

  const filteredBooks = books.filter((b) => {
    const matchesCat = activeCategory === 'All' || b.category === activeCategory;
    const q = searchQuery.toLowerCase().trim();
    const matchesSearch =
      !q ||
      b.title.toLowerCase().includes(q) ||
      b.author.toLowerCase().includes(q) ||
      b.summary.toLowerCase().includes(q) ||
      b.keyTakeaway.toLowerCase().includes(q);
    return matchesCat && matchesSearch;
  });

  const toggleBookmark = (id: string) => {
    setSavedBookIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const handleAddBook = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim() || !newAuthor.trim()) return;

    const newBook: LibraryBook = {
      id: `book-${Date.now()}`,
      title: newTitle.trim(),
      author: newAuthor.trim(),
      category: newCategory,
      summary: newSummary.trim() || 'Internal engineering documentation and handbook reference.',
      keyTakeaway: newTakeaway.trim() || 'Key company architectural standard.',
      color: '#0284c7',
      pages: 150,
      rating: 5,
    };

    setBooks([newBook, ...books]);
    setSelectedBook(newBook);
    setIsAdding(false);
    setNewTitle('');
    setNewAuthor('');
    setNewSummary('');
    setNewTakeaway('');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-200">
      <div
        id="library-modal-card"
        className="relative w-full max-w-4xl max-h-[90vh] flex flex-col bg-slate-900 border border-slate-700/80 rounded-2xl shadow-[0_25px_60px_-15px_rgba(0,0,0,0.9)] overflow-hidden"
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-950/60">
          <div className="flex items-center space-x-3">
            <div className="p-2.5 rounded-xl bg-sky-500/10 border border-sky-500/30 text-sky-400">
              <Library className="w-6 h-6 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h2 className="text-lg font-bold text-slate-100 tracking-tight">
                  B1 Engineering Library & Knowledge Center
                </h2>
                <span className="px-2 py-0.5 rounded-full bg-sky-500/10 border border-sky-500/30 text-[11px] font-semibold text-sky-400">
                  {books.length} Curated Volumes
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Staff architecture guides, design systems, algorithms, and engineering classics.
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-slate-800/80 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Controls & Search */}
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 px-6 py-3 bg-slate-900/90 border-b border-slate-800">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input
              type="text"
              placeholder="Search books, authors, or topics..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-4 py-2 bg-slate-950/80 border border-slate-700/80 rounded-xl text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-sky-500"
            />
          </div>

          <div className="flex items-center space-x-2">
            <button
              type="button"
              onClick={() => setIsAdding(!isAdding)}
              className="flex items-center space-x-1.5 px-3.5 py-2 bg-sky-600 hover:bg-sky-500 text-white text-xs font-semibold rounded-xl transition-all shadow-md active:scale-95 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>{isAdding ? 'Cancel' : 'Add Book / Manual'}</span>
            </button>
          </div>
        </div>

        {/* Category Pills */}
        <div className="flex items-center space-x-1 px-6 py-2 bg-slate-950/40 border-b border-slate-800/80 overflow-x-auto no-scrollbar">
          {CATEGORIES.map((cat) => (
            <button
              key={cat}
              type="button"
              onClick={() => setActiveCategory(cat)}
              className={`px-3 py-1 rounded-lg text-xs font-medium whitespace-nowrap transition-all ${
                activeCategory === cat
                  ? 'bg-sky-500/20 text-sky-300 border border-sky-500/40 font-semibold'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Add Book Form */}
        {isAdding && (
          <form
            onSubmit={handleAddBook}
            className="p-5 bg-slate-950/90 border-b border-sky-500/30 space-y-3 animate-in slide-in-from-top duration-200"
          >
            <span className="text-xs font-bold uppercase tracking-wider text-sky-400">
              Add New Technical Book or Internal Handbook
            </span>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-[11px] font-medium text-slate-400 mb-1">
                  Book Title *
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Distributed Consensus in Go"
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  className="w-full px-3 py-1.5 bg-slate-900 border border-slate-700 rounded-lg text-xs text-slate-200 focus:outline-none focus:border-sky-500"
                />
              </div>
              <div>
                <label className="block text-[11px] font-medium text-slate-400 mb-1">
                  Author / Team *
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Core Infrastructure Pod"
                  value={newAuthor}
                  onChange={(e) => setNewAuthor(e.target.value)}
                  className="w-full px-3 py-1.5 bg-slate-900 border border-slate-700 rounded-lg text-xs text-slate-200 focus:outline-none focus:border-sky-500"
                />
              </div>
              <div>
                <label className="block text-[11px] font-medium text-slate-400 mb-1">
                  Category
                </label>
                <select
                  value={newCategory}
                  onChange={(e) => setNewCategory(e.target.value)}
                  className="w-full px-3 py-1.5 bg-slate-900 border border-slate-700 rounded-lg text-xs text-slate-200 focus:outline-none focus:border-sky-500"
                >
                  <option value="Architecture">Architecture</option>
                  <option value="Engineering">Engineering</option>
                  <option value="Design">Design</option>
                  <option value="3D & Graphics">3D & Graphics</option>
                  <option value="Leadership">Leadership</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-[11px] font-medium text-slate-400 mb-1">
                  Summary
                </label>
                <input
                  type="text"
                  placeholder="Overview of core concepts"
                  value={newSummary}
                  onChange={(e) => setNewSummary(e.target.value)}
                  className="w-full px-3 py-1.5 bg-slate-900 border border-slate-700 rounded-lg text-xs text-slate-200 focus:outline-none focus:border-sky-500"
                />
              </div>
              <div>
                <label className="block text-[11px] font-medium text-slate-400 mb-1">
                  Key Takeaway
                </label>
                <input
                  type="text"
                  placeholder="Core lesson or architectural pattern"
                  value={newTakeaway}
                  onChange={(e) => setNewTakeaway(e.target.value)}
                  className="w-full px-3 py-1.5 bg-slate-900 border border-slate-700 rounded-lg text-xs text-slate-200 focus:outline-none focus:border-sky-500"
                />
              </div>
            </div>

            <div className="flex justify-end space-x-2">
              <button
                type="button"
                onClick={() => setIsAdding(false)}
                className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium rounded-lg"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-1.5 bg-sky-600 hover:bg-sky-500 text-white text-xs font-semibold rounded-lg shadow-md"
              >
                Save Book
              </button>
            </div>
          </form>
        )}

        {/* Dual Pane Layout: Books Grid + Reading Inspector */}
        <div className="flex-1 grid grid-cols-1 lg:grid-cols-5 divide-y lg:divide-y-0 lg:divide-x divide-slate-800 overflow-hidden max-h-[500px]">
          {/* Left Column: Book Cards */}
          <div className="lg:col-span-3 overflow-y-auto p-5 space-y-3">
            {filteredBooks.map((book) => {
              const isSelected = selectedBook?.id === book.id;
              const isSaved = savedBookIds.has(book.id);

              return (
                <div
                  key={book.id}
                  onClick={() => setSelectedBook(book)}
                  className={`group relative flex items-start space-x-3.5 p-3.5 rounded-xl border transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-sky-950/20 border-sky-500/50 shadow-md shadow-sky-500/10'
                      : 'bg-slate-950/40 border-slate-800 hover:border-slate-700 hover:bg-slate-800/40'
                  }`}
                >
                  {/* Book Spine Graphic */}
                  <div
                    className="w-10 h-14 rounded-md flex-shrink-0 flex flex-col justify-between p-1 shadow-md"
                    style={{ backgroundColor: book.color }}
                  >
                    <span className="text-[8px] font-black tracking-widest text-white/80 uppercase rotate-90 origin-bottom-left translate-x-3 translate-y-2 truncate max-w-[40px]">
                      {book.category}
                    </span>
                    <BookOpen className="w-3.5 h-3.5 text-white/90 self-end" />
                  </div>

                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between">
                      <h4 className="text-xs font-bold text-slate-100 group-hover:text-sky-300 transition-colors truncate">
                        {book.title}
                      </h4>
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          toggleBookmark(book.id);
                        }}
                        className={`p-1 rounded hover:bg-slate-800 transition-colors ${
                          isSaved ? 'text-amber-400' : 'text-slate-500 hover:text-slate-300'
                        }`}
                      >
                        <Bookmark className="w-3.5 h-3.5" fill={isSaved ? 'currentColor' : 'none'} />
                      </button>
                    </div>

                    <p className="text-[11px] text-slate-400 font-medium">{book.author}</p>
                    <p className="text-[11px] text-slate-400/90 mt-1 line-clamp-2">
                      {book.summary}
                    </p>

                    <div className="flex items-center space-x-3 mt-2 text-[10px] text-slate-400">
                      <span className="px-2 py-0.5 rounded bg-slate-900 border border-slate-800 text-slate-300 font-medium">
                        {book.category}
                      </span>
                      <span>{book.pages} pages</span>
                      <span className="flex items-center space-x-0.5 text-amber-400 font-semibold">
                        <Star className="w-3 h-3 fill-amber-400" />
                        <span>{book.rating}</span>
                      </span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Right Column: Book Detail Reader */}
          <div className="lg:col-span-2 overflow-y-auto p-6 bg-slate-950/40 flex flex-col justify-between">
            {selectedBook ? (
              <div className="space-y-4">
                <div className="flex items-start space-x-3">
                  <div
                    className="w-12 h-16 rounded-lg flex-shrink-0 flex items-center justify-center shadow-lg"
                    style={{ backgroundColor: selectedBook.color }}
                  >
                    <BookOpen className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-slate-100 leading-tight">
                      {selectedBook.title}
                    </h3>
                    <p className="text-xs text-sky-400 font-medium mt-0.5">{selectedBook.author}</p>
                    <div className="flex items-center space-x-2 mt-1.5 text-[11px] text-slate-400">
                      <span className="px-2 py-0.2 rounded bg-slate-800 text-slate-300 font-semibold">
                        {selectedBook.category}
                      </span>
                      <span>•</span>
                      <span>{selectedBook.pages} pages</span>
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
                    Executive Summary
                  </span>
                  <p className="text-xs text-slate-300 leading-relaxed bg-slate-900/80 p-3 rounded-xl border border-slate-800">
                    {selectedBook.summary}
                  </p>
                </div>

                <div className="space-y-2">
                  <span className="text-[11px] font-bold uppercase tracking-wider text-amber-400 flex items-center space-x-1.5">
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>Architectural Takeaway</span>
                  </span>
                  <div className="p-3 rounded-xl bg-amber-950/20 border border-amber-500/30 text-xs text-amber-200/90 leading-relaxed font-medium">
                    "{selectedBook.keyTakeaway}"
                  </div>
                </div>

                {selectedBook.readUrl && (
                  <a
                    href={selectedBook.readUrl}
                    target="_blank"
                    rel="noreferrer noopener"
                    className="flex items-center justify-center space-x-2 w-full py-2 bg-sky-600 hover:bg-sky-500 text-white rounded-xl text-xs font-semibold transition-all shadow-md"
                  >
                    <span>Read Full Book Spec</span>
                    <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                )}
              </div>
            ) : (
              <div className="text-center py-16 text-slate-500">
                <BookOpen className="w-8 h-8 mx-auto mb-2 opacity-50" />
                <p className="text-xs">Select any book on the left to inspect.</p>
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between px-6 py-3 border-t border-slate-800 bg-slate-950/60 text-xs text-slate-400">
          <span>B1 Library physical shelves synced with digital catalog</span>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold rounded-lg transition-colors cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
}
