import React, { useState, useEffect } from 'react';
import {
  X,
  Search,
  Plus,
  Tag,
  Pin,
  Trash2,
  ExternalLink,
  Book,
  FileText,
  Calendar as CalendarIcon,
  Calculator,
  Printer,
  PenTool,
  Loader2,
  Check,
  ChevronLeft,
  ChevronRight,
  LayoutDashboard,
  Link
} from 'lucide-react';
import Markdown from 'react-markdown';
import { chloeAgentClient } from '../lib/chloeAgentClient';
import { RichTextEditor } from './RichTextEditor';

interface SwiftNoteModalProps {
  onClose: () => void;
}

interface Note {
  id: string;
  title: string;
  content: string;
  notebook: string;
  tags: string[];
}

interface ScheduleEvent {
  id: string;
  date: string;
  title: string;
  tags: string[];
}

interface StickyNote {
  id: string;
  x: number;
  y: number;
  text: string;
  color: string;
}

interface StickyConnection {
  id: string;
  fromId: string;
  toId: string;
}

export const SwiftNoteModal: React.FC<SwiftNoteModalProps> = ({ onClose }) => {
  const [activeView, setActiveView] = useState<'notes' | 'calendar' | 'board'>('notes');
  const [activeTab, setActiveTab] = useState<'editor' | 'preview'>('editor');
  const [activeNoteId, setActiveNoteId] = useState<string>('1');
  const [isProcessing, setIsProcessing] = useState(false);
  const [targetFormat, setTargetFormat] = useState<string>('Article');
  const [isFormatDropdownOpen, setIsFormatDropdownOpen] = useState(false);
  const [showCalculator, setShowCalculator] = useState(false);
  const [calcInput, setCalcInput] = useState('');

  // Tags State
  const tagColors = ['bg-emerald-500', 'bg-blue-500', 'bg-amber-500', 'bg-rose-500', 'bg-purple-500'];
  const [tags, setTags] = useState<{name: string, count: number, color: string}[]>([
    {name: 'Advanced', count: 5, color: 'bg-emerald-500'},
    {name: 'Basics', count: 6, color: 'bg-blue-500'},
    {name: 'Intermediate', count: 4, color: 'bg-amber-500'}
  ]);
  const [isAddingTag, setIsAddingTag] = useState(false);
  const [newTagInput, setNewTagInput] = useState('');

  // Chloe Chat State
  const [chloeInput, setChloeInput] = useState('');
  const [chloeReply, setChloeReply] = useState('');
  const [isChloeThinking, setIsChloeThinking] = useState(false);

  // Calendar State
  const [currentMonth, setCurrentMonth] = useState(new Date());
  const [scheduleEvents, setScheduleEvents] = useState<ScheduleEvent[]>([]);
  const [newEventTitle, setNewEventTitle] = useState('');
  const [selectedDate, setSelectedDate] = useState<string | null>(null);

  // Board State
  const [stickies, setStickies] = useState<StickyNote[]>(() => {
    try {
      const saved = localStorage.getItem('swiftnote_stickies');
      if (saved) return JSON.parse(saved);
    } catch(e) {}
    return [];
  });

  const [connections, setConnections] = useState<StickyConnection[]>(() => {
    try {
      const saved = localStorage.getItem('swiftnote_connections');
      if (saved) return JSON.parse(saved);
    } catch(e) {}
    return [];
  });
  
  const [connectingFrom, setConnectingFrom] = useState<string | null>(null);
  const [mousePos, setMousePos] = useState<{x: number, y: number} | null>(null);
  const [draggingSticky, setDraggingSticky] = useState<{id: string, offsetX: number, offsetY: number} | null>(null);

  const [notes, setNotes] = useState<Note[]>(() => {
    const defaultNotes = [
   {
        id: 'prompt-1',
        title: 'US-China Tariff & Sourcing Strategy',
        content: `<p><strong>Persona</strong>: Supply Chain & Small Business Strategy Advisor</p><p><strong>Context</strong>: I am a US small business owner caught in the middle of US-China trade tariffs. I need to market my product as "Made in USA" / assembled locally to satisfy domestic customer demand, but core components or raw manufacturing processes still strictly depend on Chinese suppliers.</p><p><strong>Action</strong>:<br>1. Analyze options for dual-sourcing, final domestic assembly, or substantial transformation to legally and ethically navigate tariff rules.<br>2. Draft a clear customer messaging strategy that transparently handles supply chain origin without hurting brand trust.<br>3. Provide a cost-mitigation checklist for tariff impacts.</p>`,
        notebook: 'Templates',
        tags: ['Advanced']
      },
      {
        id: 'prompt-2',
        title: 'Twitch Streamer Audience Engagement',
        content: `<p><strong>Persona</strong>: Live-Stream Growth & Audience Retention Consultant</p><p><strong>Context</strong>: I am a Twitch streamer struggling to convert casual drop-in viewers into an active, chatty, and engaged community. Chat is often quiet, and viewers leave quickly.</p><p><strong>Action</strong>:<br>1. Provide 5 actionable real-time chat hooks and question techniques to get quiet lurkers to type in chat.<br>2. Propose 3 interactive stream segment ideas or mini-games (using free tools/extensions) that incentivize viewer participation.<br>3. Outline a 30-day plan to improve visual/audio pacing so stream energy remains high during low-viewer periods.</p>`,
        notebook: 'Templates',
        tags: ['Basics']
      },
      {
        id: 'prompt-3',
        title: 'Managing Toxic Mods & Discord Community Crisis',
        content: `<p><strong>Persona</strong>: Community Management & Moderation Specialist</p><p><strong>Context</strong>: I own a Discord server where a few long-time, trusted moderators have become toxic, creating friction with loyal members. Because they have been around since the beginning and hold authority, demoting or banning them carries a heavy risk of server drama, split loyalties, or mass exits.</p><p><strong>Action</strong>:<br>1. Draft a professional, firm, and de-escalating private message to address the toxic behavior directly with the moderators.<br>2. Outline a step-by-step transition plan to revamp server rules, update staff handbooks, and gracefully demote or replace them if behavior doesn't change.<br>3. Provide a public statement template for the general server to maintain calm and clear the air after action is taken.</p>`,
        notebook: 'Templates',
        tags: ['Advanced']
      }
    ];

    try {
      const saved = localStorage.getItem('swiftnote_notes');
      if (saved) {
        let parsed = JSON.parse(saved);
        if (parsed && Array.isArray(parsed) && parsed.length > 0) {
          // Force update the default prompts to ensure they have the latest Persona/Action text
          parsed = parsed.map(note => {
            const defaultNote = defaultNotes.find(dn => dn.id === note.id);
            if (defaultNote) {
              return { ...note, content: defaultNote.content }; // Force content to be the updated one
            }
            return note;
          });

          // Auto-inject demo prompts if they don't exist
          const hasDemo = parsed.some(n => n.id === 'prompt-1');
          if (!hasDemo) {
            parsed = [...parsed, ...defaultNotes];
          }
          return parsed;
        }
      }
    } catch(e) {}
    
    return defaultNotes;
  });

  useEffect(() => {
    localStorage.setItem('swiftnote_notes', JSON.stringify(notes));
  }, [notes]);

  useEffect(() => {
    localStorage.setItem('swiftnote_stickies', JSON.stringify(stickies));
  }, [stickies]);

  useEffect(() => {
    localStorage.setItem('swiftnote_connections', JSON.stringify(connections));
  }, [connections]);

  const activeNote = notes.find(n => n.id === activeNoteId) || (notes.length > 0 ? notes[0] : null);

  const updateActiveNote = (updates: Partial<Note>) => {
    setNotes(notes.map(n => n.id === activeNoteId ? { ...n, ...updates } : n));
  };

  const createNewNote = () => {
    const newId = Math.random().toString(36).substring(7);
    setNotes([{
      id: newId,
      title: 'Untitled Note',
      content: '',
      notebook: 'All Notes',
      tags: []
    }, ...notes]);
    setActiveNoteId(newId);
  };

  const handlePrintRefine = async () => {
    if (!activeNote || !activeNote.content.trim()) return;
    setIsProcessing(true);
    try {
      const res = await fetch('/api/swiftnote/refine', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          rawText: activeNote.content,
          targetFormat: targetFormat
        })
      });
      const data = await res.json();
      if (data.status === 'SUCCESS' && data.result) {
        updateActiveNote({ content: data.result });
      }
    } catch (err) {
      console.error('Failed to refine:', err);
    } finally {
      setIsProcessing(false);
      setIsFormatDropdownOpen(false);
    }
  };

  const handleCalcEval = () => {
    try {
      // eslint-disable-next-line no-eval
      const res = eval(calcInput.replace(/sin\(/g, 'Math.sin(').replace(/cos\(/g, 'Math.cos(').replace(/tan\(/g, 'Math.tan(').replace(/log\(/g, 'Math.log10('));
      setCalcInput(String(res));
    } catch (e) {
      setCalcInput('Error');
    }
  };

  const handleAddTag = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter' && newTagInput.trim()) {
      if (!tags.find(t => t.name === newTagInput.trim())) {
        const randColor = tagColors[Math.floor(Math.random() * tagColors.length)];
        setTags([...tags, { name: newTagInput.trim(), count: 0, color: randColor }]);
      }
      setNewTagInput('');
      setIsAddingTag(false);
    }
  };

  const handleDeleteTag = (tagName: string) => {
    setTags(tags.filter(t => t.name !== tagName));
  };

  const handleChloeSubmit = async () => {
    if (!chloeInput.trim()) return;
    setIsChloeThinking(true);
    try {
      const res = await chloeAgentClient.sendQuery(chloeInput, {
         tone: 'concise',
         context: 'User is in SwiftNote notebook. IMPORTANT: Always format response beautifully using standard Markdown. Do not output raw asterisks, use Markdown structure so the UI can render bold, italics, and lists cleanly.'
      });
      setChloeReply(res.text || 'I could not process that request.');
    } catch (err) {
      setChloeReply("Error communicating with Chloe.");
    } finally {
      setIsChloeThinking(false);
      setChloeInput('');
    }
  };

  const addCalendarEvent = () => {
    if (selectedDate && newEventTitle.trim()) {
      setScheduleEvents([...scheduleEvents, {
        id: Math.random().toString(),
        date: selectedDate,
        title: newEventTitle,
        tags: []
      }]);
      setNewEventTitle('');
    }
  };

  const getDaysInMonth = (date: Date) => {
    const year = date.getFullYear();
    const month = date.getMonth();
    const days = new Date(year, month + 1, 0).getDate();
    const firstDay = new Date(year, month, 1).getDay();
    return { days, firstDay, year, month };
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-[#fcfcfc] w-[90vw] max-w-6xl h-[85vh] rounded-xl shadow-2xl flex flex-col overflow-hidden text-slate-800 border border-slate-300">
        
        {/* Top Title Bar */}
        <div className="flex items-center justify-between px-4 py-2 border-b border-slate-200 bg-white select-none shrink-0">
          <div className="flex items-center space-x-2">
            <div className="bg-amber-400 p-1.5 rounded shadow-sm text-white flex items-center justify-center">
              <PenTool className="w-4 h-4" />
            </div>
            <span className="font-bold text-slate-800 text-sm tracking-tight">SwiftNote</span>
          </div>
          
          <button onClick={onClose} className="p-1 hover:bg-slate-100 rounded text-slate-500 hover:text-slate-800 transition-colors">
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Main Interface */}
        <div className="flex flex-1 overflow-hidden bg-white">
          
          {/* Sidebar */}
          <div className="w-56 bg-[#262c33] text-slate-300 flex flex-col overflow-y-auto shrink-0 select-none border-r border-slate-200 shadow-[inset_-1px_0_0_rgba(0,0,0,0.1)]">
            
            <div className="p-3">
              <div onClick={() => setActiveView('notes')} className={`flex items-center justify-between font-medium px-2 py-1.5 rounded cursor-pointer ${activeView === 'notes' ? 'bg-white/20 text-white' : 'text-slate-300 hover:bg-white/10'}`}>
                <div className="flex items-center space-x-2">
                  <FileText className="w-4 h-4" />
                  <span className="text-sm">Saved Folders</span>
                </div>
                <span className="text-xs bg-white/20 px-1.5 rounded-full">{notes.length}</span>
              </div>
            </div>

            <div className="px-3 pb-2">
              <div className="flex items-center justify-between text-slate-300 font-medium px-2 py-1.5 hover:bg-white/10 rounded cursor-pointer">
                <div className="flex items-center space-x-2">
                  <Book className="w-4 h-4" />
                  <span className="text-sm">Notebooks</span>
                </div>
                <span className="text-xs bg-white/20 px-1.5 rounded-full">2</span>
              </div>
              <div className="ml-6 mt-1 space-y-1">
                <div onClick={() => setActiveView('calendar')} className={`text-sm px-2 py-1 cursor-pointer flex items-center space-x-2 ${activeView === 'calendar' ? 'bg-white/20 text-white rounded' : 'text-slate-400 hover:text-slate-200'}`}>
                  <CalendarIcon className="w-3.5 h-3.5" />
                  <span>Calendar</span>
                </div>
                <div onClick={() => setActiveView('board')} className={`text-sm px-2 py-1 cursor-pointer flex items-center space-x-2 ${activeView === 'board' ? 'bg-white/20 text-white rounded' : 'text-slate-400 hover:text-slate-200'}`}>
                  <LayoutDashboard className="w-3.5 h-3.5" />
                  <span>Sticky Board</span>
                </div>
                <div onClick={() => setActiveView('notes')} className={`text-sm px-2 py-1 cursor-pointer ${activeView === 'notes' ? 'text-slate-400 hover:text-slate-200' : 'text-slate-400 hover:text-slate-200'}`}>Work</div>
              </div>
            </div>

            <div className="px-3 pt-2">
              <div className="flex items-center justify-between text-slate-300 font-medium px-2 py-1.5 hover:bg-white/10 rounded cursor-pointer">
                <div className="flex items-center space-x-2">
                  <Tag className="w-4 h-4" />
                  <span className="text-sm">Tags</span>
                </div>
                <span className="text-xs bg-white/20 px-1.5 rounded-full">{tags.length}</span>
              </div>
              <div className="ml-6 mt-1 space-y-1">
                {tags.map(tag => (
                  <div key={tag.name} className="text-sm px-2 py-1 text-slate-400 hover:text-slate-200 flex justify-between cursor-pointer group items-center">
                    <div className="flex items-center space-x-2" onClick={() => setActiveView('notes')}>
                      <div className={`w-2 h-2 rounded-full ${tag.color}`}></div>
                      <span>{tag.name}</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <span className="text-xs group-hover:hidden">{tag.count}</span>
                      <button onClick={() => handleDeleteTag(tag.name)} className="hidden group-hover:block text-rose-400 hover:text-rose-500"><X className="w-3 h-3" /></button>
                    </div>
                  </div>
                ))}
                {isAddingTag ? (
                  <input 
                    autoFocus 
                    value={newTagInput}
                    onChange={e => setNewTagInput(e.target.value)}
                    onBlur={() => setIsAddingTag(false)} 
                    onKeyDown={handleAddTag} 
                    className="w-full bg-black/20 text-sm text-white px-2 py-1 rounded outline-none mt-1" 
                    placeholder="New tag..." 
                  />
                ) : (
                  <div onClick={() => setIsAddingTag(true)} className="text-sm px-2 py-1 text-slate-500 hover:text-slate-300 cursor-pointer flex items-center space-x-1 mt-1">
                    <Plus className="w-3 h-3" /> <span>Add Tag</span>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Note List / Middle Bar */}
          <div className="w-64 bg-[#f8f9fa] border-r border-slate-200 flex flex-col shrink-0">
            <div className="p-3 border-b border-slate-200 flex flex-col space-y-2 bg-white">
              {chloeReply && (
                <div className="bg-indigo-50 border border-indigo-100 rounded p-3 text-xs text-indigo-900 relative shadow-sm">
                  <button onClick={() => setChloeReply('')} className="absolute top-1 right-1 text-indigo-400 hover:text-indigo-600"><X className="w-3 h-3" /></button>
                  <div className="font-semibold mb-1 text-indigo-900 flex items-center space-x-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-indigo-500 animate-pulse"></span>
                    <span>Chloe (AI)</span>
                  </div>
                  <div className="prose prose-sm prose-indigo max-w-none prose-p:my-1 prose-ul:my-1">
                    <Markdown>{chloeReply}</Markdown>
                  </div>
                </div>
              )}
              <div className="flex items-center space-x-2">
                <div className="relative flex-1">
                  <div className="absolute left-2 top-2 w-4 h-4 bg-indigo-500 rounded-full flex items-center justify-center">
                    <span className="text-[10px] text-white font-bold">C</span>
                  </div>
                  <input 
                    type="text" 
                    value={chloeInput}
                    onChange={e => setChloeInput(e.target.value)}
                    onKeyDown={e => e.key === 'Enter' && handleChloeSubmit()}
                    placeholder={isChloeThinking ? "Thinking..." : "Ask Chloe..."}
                    disabled={isChloeThinking}
                    className="w-full bg-slate-50 border border-slate-300 rounded-md pl-8 pr-2 py-1.5 text-sm focus:outline-none focus:border-indigo-400 focus:ring-1 focus:ring-indigo-400 transition-shadow disabled:opacity-50"
                  />
                </div>
                <button onClick={createNewNote} className="p-1.5 border border-slate-300 rounded-md hover:bg-slate-100 bg-white text-slate-600 shadow-sm transition-colors cursor-pointer shrink-0" title="New Note">
                  <Plus className="w-4 h-4" />
                </button>
              </div>
            </div>
            
            <div className="flex-1 overflow-y-auto">
              {notes.map(note => (
                <div 
                  key={note.id}
                  onClick={() => setActiveNoteId(note.id)}
                  className={`p-3 border-b border-slate-100 cursor-pointer transition-colors ${activeNoteId === note.id ? 'bg-white shadow-[inset_3px_0_0_#fbbf24]' : 'hover:bg-slate-50'}`}
                >
                  <div className="text-sm font-semibold text-slate-800 truncate mb-1">{note.title || 'Untitled'}</div>
                  <div className="text-xs text-slate-500 truncate">{note.content || 'No additional text'}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Main Area */}
          <div className="flex-1 flex flex-col bg-white min-w-0">
            
            {activeView === 'calendar' ? (
              <div className="flex-1 flex flex-col p-6 overflow-y-auto">
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-2xl font-bold text-slate-800">
                    {currentMonth.toLocaleString('default', { month: 'long', year: 'numeric' })}
                  </h2>
                  <div className="flex items-center space-x-2">
                    <button onClick={() => setCurrentMonth(new Date(currentMonth.getFullYear(), currentMonth.getMonth() - 1, 1))} className="p-1.5 rounded hover:bg-slate-100 text-slate-600">
                      <ChevronLeft className="w-5 h-5" />
                    </button>
                    <button onClick={() => setCurrentMonth(new Date(currentMonth.getFullYear(), currentMonth.getMonth() + 1, 1))} className="p-1.5 rounded hover:bg-slate-100 text-slate-600">
                      <ChevronRight className="w-5 h-5" />
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-7 gap-px bg-slate-200 border border-slate-200 rounded-lg overflow-hidden flex-1 min-h-[500px]">
                  {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(day => (
                    <div key={day} className="bg-slate-50 text-xs font-semibold text-slate-500 uppercase py-2 text-center">
                      {day}
                    </div>
                  ))}
                  
                  {Array.from({ length: getDaysInMonth(currentMonth).firstDay }).map((_, i) => (
                    <div key={`empty-${i}`} className="bg-slate-50/50 p-2 min-h-[100px]" />
                  ))}
                  
                  {Array.from({ length: getDaysInMonth(currentMonth).days }).map((_, i) => {
                    const date = i + 1;
                    const dateStr = `${getDaysInMonth(currentMonth).year}-${String(getDaysInMonth(currentMonth).month + 1).padStart(2, '0')}-${String(date).padStart(2, '0')}`;
                    const dayEvents = scheduleEvents.filter(e => e.date === dateStr);
                    const isSelected = selectedDate === dateStr;
                    
                    return (
                      <div 
                        key={date} 
                        onClick={() => setSelectedDate(dateStr)}
                        className={`bg-white p-2 min-h-[100px] cursor-pointer transition-colors relative flex flex-col ${isSelected ? 'ring-2 ring-inset ring-amber-400' : 'hover:bg-slate-50'}`}
                      >
                        <span className={`text-sm font-medium ${isSelected ? 'text-amber-600' : 'text-slate-700'}`}>{date}</span>
                        <div className="mt-1 flex flex-col space-y-1 overflow-y-auto flex-1 no-scrollbar">
                          {dayEvents.map(ev => (
                            <div key={ev.id} className="text-[10px] bg-amber-100 text-amber-800 px-1.5 py-1 rounded shadow-sm leading-tight border border-amber-200/50 break-words" title={ev.title}>
                              {ev.title}
                            </div>
                          ))}
                        </div>
                      </div>
                    );
                  })}
                </div>
                
                {selectedDate && (
                  <div className="mt-6 flex items-center space-x-2">
                    <input 
                      type="text"
                      value={newEventTitle}
                      onChange={e => setNewEventTitle(e.target.value)}
                      onKeyDown={e => e.key === 'Enter' && addCalendarEvent()}
                      placeholder={`Add event for ${selectedDate}...`}
                      className="flex-1 border border-slate-300 rounded-md px-3 py-2 text-sm focus:outline-none focus:border-amber-400"
                    />
                    <button onClick={addCalendarEvent} className="bg-amber-500 hover:bg-amber-600 text-white px-4 py-2 rounded-md text-sm font-medium transition-colors">
                      Add Event
                    </button>
                  </div>
                )}
              </div>
            ) : activeView === 'board' ? (
              <div className="flex-1 bg-slate-50 relative overflow-hidden flex flex-col">
                <div className="absolute inset-0 bg-[radial-gradient(#e5e7eb_1px,transparent_1px)] [background-size:20px_20px] opacity-50 z-0"></div>
                
                <div className="p-4 z-10 flex items-center justify-between border-b border-slate-200 bg-white shadow-sm">
                  <h2 className="font-bold text-slate-800">Sticky Board & Mindmap</h2>
                  <button 
                    onClick={() => setStickies([...stickies, { id: Math.random().toString(), x: 50, y: 50, text: '', color: 'bg-yellow-200' }])}
                    className="bg-amber-500 hover:bg-amber-600 text-white px-3 py-1.5 rounded text-sm font-medium flex items-center space-x-1"
                  >
                    <Plus className="w-4 h-4" /> <span>Add Sticky</span>
                  </button>
                </div>
                
                <div 
                  className="flex-1 relative z-10 p-4"
                  onPointerMove={(e) => {
                    const rect = e.currentTarget.getBoundingClientRect();
                    const x = e.clientX - rect.left;
                    const y = e.clientY - rect.top;
                    
                    if (connectingFrom) {
                      setMousePos({ x, y });
                    }
                    
                    if (draggingSticky) {
                      setStickies(prev => prev.map(s => s.id === draggingSticky.id ? { ...s, x: x - draggingSticky.offsetX, y: y - draggingSticky.offsetY } : s));
                    }
                  }}
                  onPointerUp={() => {
                    setDraggingSticky(null);
                  }}
                  onPointerLeave={() => {
                    setDraggingSticky(null);
                    setMousePos(null);
                  }}
                >
                  {/* SVG for Connectors */}
                  <svg className="absolute inset-0 w-full h-full z-0" style={{ pointerEvents: 'none' }}>
                    <defs>
                      <marker id="arrowhead" markerWidth="10" markerHeight="7" refX="9" refY="3.5" orient="auto">
                        <polygon points="0 0, 10 3.5, 0 7" fill="#94a3b8" />
                      </marker>
                      <marker id="arrowhead-active" markerWidth="10" markerHeight="7" refX="9" refY="3.5" orient="auto">
                        <polygon points="0 0, 10 3.5, 0 7" fill="#3b82f6" />
                      </marker>
                    </defs>
                    
                    {connections.map(conn => {
                      const fromSticky = stickies.find(s => s.id === conn.fromId);
                      const toSticky = stickies.find(s => s.id === conn.toId);
                      if (!fromSticky || !toSticky) return null;
                      
                      const x1 = fromSticky.x + 96;
                      const y1 = fromSticky.y + 96;
                      const x2 = toSticky.x + 96;
                      const y2 = toSticky.y + 96;
                      const midX = (x1 + x2) / 2;
                      const midY = (y1 + y2) / 2;

                      return (
                        <g key={conn.id} style={{ pointerEvents: 'auto' }}>
                          <line x1={x1} y1={y1} x2={x2} y2={y2} stroke="#94a3b8" strokeWidth="2" strokeDasharray="4 4" markerEnd="url(#arrowhead)" />
                          <circle cx={midX} cy={midY} r="8" fill="#e2e8f0" stroke="#94a3b8" strokeWidth="1" className="cursor-pointer hover:fill-rose-200 transition-colors" onClick={() => setConnections(connections.filter(c => c.id !== conn.id))} />
                          <text x={midX} y={midY} textAnchor="middle" dy="3" fontSize="10" fill="#475569" className="cursor-pointer pointer-events-none">×</text>
                        </g>
                      );
                    })}
                    
                    {connectingFrom && mousePos && (() => {
                      const fromSticky = stickies.find(s => s.id === connectingFrom);
                      if (!fromSticky) return null;
                      return <line x1={fromSticky.x + 96} y1={fromSticky.y + 96} x2={mousePos.x} y2={mousePos.y} stroke="#3b82f6" strokeWidth="2" strokeDasharray="4 4" markerEnd="url(#arrowhead-active)" />;
                    })()}
                  </svg>
                  
                  {stickies.map(sticky => (
                    <div 
                      key={sticky.id}
                      className={`group absolute w-48 h-48 shadow-lg rounded-md p-3 flex flex-col border ${sticky.color} ${draggingSticky?.id === sticky.id ? 'z-50 shadow-2xl scale-105 opacity-95 cursor-grabbing' : 'z-10 cursor-grab transform hover:-translate-y-1 transition-transform'} ${connectingFrom === sticky.id ? 'ring-2 ring-blue-500 ring-offset-2' : 'border-black/5'}`}
                      style={{ left: sticky.x, top: sticky.y }}
                    >
                      {/* Connection Handle (Right Edge) */}
                      <button 
                        onClick={() => {
                          if (connectingFrom === sticky.id) {
                            setConnectingFrom(null);
                            setMousePos(null);
                          } else if (connectingFrom) {
                            if (connectingFrom !== sticky.id && !connections.some(c => (c.fromId === connectingFrom && c.toId === sticky.id) || (c.fromId === sticky.id && c.toId === connectingFrom))) {
                              setConnections([...connections, { id: Math.random().toString(), fromId: connectingFrom, toId: sticky.id }]);
                            }
                            setConnectingFrom(null);
                            setMousePos(null);
                          } else {
                            setConnectingFrom(sticky.id);
                          }
                        }}
                        className={`absolute -right-3 top-1/2 -translate-y-1/2 w-6 h-6 bg-white border border-slate-300 rounded-full flex items-center justify-center shadow-md transition-opacity z-20 hover:bg-blue-50 hover:border-blue-300 hover:text-blue-600 ${connectingFrom === sticky.id ? 'opacity-100 text-blue-600 border-blue-400 bg-blue-50' : 'opacity-0 group-hover:opacity-100 text-slate-400'}`}
                        title="Link Note"
                        onPointerDown={(e) => e.stopPropagation()}
                      >
                        <Plus className="w-3.5 h-3.5" />
                      </button>

                      <div 
                        className="flex justify-between items-center mb-2 border-b border-black/10 pb-1 cursor-inherit"
                        onPointerDown={(e) => {
                          if ((e.target as HTMLElement).tagName === 'BUTTON' || (e.target as HTMLElement).closest('button')) return;
                          const rect = e.currentTarget.parentElement!.getBoundingClientRect();
                          const boardRect = e.currentTarget.closest('.relative.z-10.p-4')?.getBoundingClientRect();
                          if (boardRect) {
                            setDraggingSticky({
                              id: sticky.id,
                              offsetX: e.clientX - rect.left,
                              offsetY: e.clientY - rect.top
                            });
                          }
                        }}
                      >
                        <div className="flex space-x-1">
                          <button onClick={() => setStickies(stickies.map(s => s.id === sticky.id ? { ...s, color: 'bg-yellow-200' } : s))} className="w-3 h-3 rounded-full bg-yellow-400 shadow-sm border border-black/10"></button>
                          <button onClick={() => setStickies(stickies.map(s => s.id === sticky.id ? { ...s, color: 'bg-emerald-200' } : s))} className="w-3 h-3 rounded-full bg-emerald-400 shadow-sm border border-black/10"></button>
                          <button onClick={() => setStickies(stickies.map(s => s.id === sticky.id ? { ...s, color: 'bg-blue-200' } : s))} className="w-3 h-3 rounded-full bg-blue-400 shadow-sm border border-black/10"></button>
                          <button onClick={() => setStickies(stickies.map(s => s.id === sticky.id ? { ...s, color: 'bg-rose-200' } : s))} className="w-3 h-3 rounded-full bg-rose-400 shadow-sm border border-black/10"></button>
                        </div>
                        <div className="flex items-center space-x-2">
                          <button onClick={() => {
                            setStickies(stickies.filter(s => s.id !== sticky.id));
                            setConnections(connections.filter(c => c.fromId !== sticky.id && c.toId !== sticky.id));
                            if (connectingFrom === sticky.id) {
                              setConnectingFrom(null);
                              setMousePos(null);
                            }
                          }} className="text-black/40 hover:text-black/80">
                            <X className="w-3 h-3" />
                          </button>
                        </div>
                      </div>
                      <textarea
                        value={sticky.text}
                        onChange={(e) => setStickies(stickies.map(s => s.id === sticky.id ? { ...s, text: e.target.value } : s))}
                        className="flex-1 bg-transparent border-none outline-none resize-none text-slate-800 placeholder-slate-700/40 font-medium text-sm"
                        placeholder="Write something..."
                        onPointerDown={(e) => e.stopPropagation()}
                      />
                    </div>
                  ))}
                </div>
              </div>
            ) : (
              <>
            {/* Toolbar */}
            <div className="h-12 border-b border-slate-200 flex items-center justify-between px-4 bg-slate-50 shrink-0">
              <div className="flex items-center space-x-1">
                <button 
                  onClick={() => setActiveTab('editor')}
                  className={`p-1.5 rounded border transition-colors ${activeTab === 'editor' ? 'bg-white border-slate-300 shadow-sm text-amber-600' : 'border-transparent text-slate-500 hover:bg-slate-200'}`}
                  title="Edit Mode"
                >
                  <PenTool className="w-4 h-4" />
                </button>
                <button 
                  onClick={() => setActiveTab('preview')}
                  className={`p-1.5 rounded border transition-colors ${activeTab === 'preview' ? 'bg-white border-slate-300 shadow-sm text-amber-600' : 'border-transparent text-slate-500 hover:bg-slate-200'}`}
                  title="Preview Mode"
                >
                  <ExternalLink className="w-4 h-4" />
                </button>

                <div className="w-px h-5 bg-slate-300 mx-2" />

                <button className="p-1.5 rounded text-amber-500 hover:bg-amber-100 bg-amber-50 transition-colors" title="Pin Note"><Pin className="w-4 h-4" /></button>
                <button onClick={() => {
                  const newNotes = notes.filter(n => n.id !== activeNoteId);
                  setNotes(newNotes.length ? newNotes : [{ id: '1', title: 'Untitled', content: '', notebook: 'All Notes', tags: [] }]);
                  setActiveNoteId(newNotes.length ? newNotes[0].id : '1');
                }} className="p-1.5 rounded text-slate-500 hover:bg-rose-100 hover:text-rose-600 transition-colors" title="Delete Note"><Trash2 className="w-4 h-4" /></button>
              </div>

              <div className="flex items-center space-x-2">
                <div className="relative">
                  <button 
                    onClick={() => setShowCalculator(!showCalculator)}
                    className="p-1.5 rounded text-indigo-600 bg-indigo-50 hover:bg-indigo-100 border border-indigo-200 transition-colors flex items-center space-x-1" 
                    title="Scientific Calculator"
                  >
                    <Calculator className="w-4 h-4" />
                  </button>
                  {showCalculator && (
                    <div className="absolute top-full right-0 mt-2 w-64 bg-slate-800 border border-slate-700 rounded-xl shadow-2xl p-4 z-10 flex flex-col space-y-3">
                      <div className="text-xs font-bold text-slate-400 uppercase tracking-wider text-center">Scientific Calc</div>
                      <input 
                        type="text" 
                        value={calcInput} 
                        onChange={e => setCalcInput(e.target.value)} 
                        onKeyDown={e => e.key === 'Enter' && handleCalcEval()}
                        placeholder="0"
                        className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-right text-lg text-emerald-400 font-mono focus:outline-none focus:border-indigo-500 shadow-inner"
                      />
                      <div className="grid grid-cols-4 gap-2">
                        {['sin(', 'cos(', 'tan(', 'C', 'log(', '(', ')', '/', '7', '8', '9', '*', '4', '5', '6', '-', '1', '2', '3', '+', '0', '.', 'DEL', '='].map(btn => (
                          <button 
                            key={btn}
                            onClick={() => {
                              if (btn === '=') handleCalcEval();
                              else if (btn === 'C') setCalcInput('');
                              else if (btn === 'DEL') setCalcInput(prev => prev.slice(0, -1));
                              else setCalcInput(prev => prev + btn);
                            }}
                            className={`py-2 rounded-md font-medium text-sm shadow-sm transition-colors ${
                              btn === '=' ? 'bg-indigo-500 hover:bg-indigo-600 text-white col-span-1' 
                              : btn === 'C' || btn === 'DEL' ? 'bg-rose-500/20 text-rose-400 hover:bg-rose-500/30'
                              : ['/', '*', '-', '+'].includes(btn) ? 'bg-slate-700 text-amber-400 hover:bg-slate-600'
                              : ['sin(', 'cos(', 'tan(', 'log(', '(', ')'].includes(btn) ? 'bg-slate-700/50 text-slate-300 hover:bg-slate-600'
                              : 'bg-slate-600 hover:bg-slate-500 text-white'
                            }`}
                          >
                            {btn.replace('(', '')}
                          </button>
                        ))}
                      </div>
                    </div>
                  )}
                </div>

                <div className="w-px h-5 bg-slate-300 mx-1" />

                {/* AI Printer Logic */}
                <div className="relative">
                  <button 
                    onClick={() => setIsFormatDropdownOpen(!isFormatDropdownOpen)}
                    disabled={isProcessing}
                    className="pl-3 pr-2 py-1.5 rounded bg-amber-500 hover:bg-amber-600 text-white font-medium flex items-center space-x-2 transition-all shadow-sm disabled:opacity-50"
                  >
                    {isProcessing ? <Loader2 className="w-4 h-4 animate-spin" /> : <Printer className="w-4 h-4" />}
                    <span className="text-sm text-amber-50">Refine as {targetFormat}</span>
                  </button>
                  
                  {isFormatDropdownOpen && (
                    <div className="absolute top-full right-0 mt-1 w-48 bg-white border border-slate-200 rounded-lg shadow-xl py-1 z-10">
                      {['Article', 'Announcement Blog', 'Survey Form', 'Speech', 'Message', 'Summary'].map(fmt => (
                        <button 
                          key={fmt}
                          onClick={() => { setTargetFormat(fmt); setIsFormatDropdownOpen(false); handlePrintRefine(); }}
                          className="w-full text-left px-4 py-2 text-sm hover:bg-slate-50 text-slate-700 flex justify-between items-center"
                        >
                          {fmt}
                          {targetFormat === fmt && <Check className="w-3.5 h-3.5 text-amber-500" />}
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* Note Editor Canvas */}
            <div className="flex-1 overflow-y-auto bg-white p-10">
              {notes.length === 0 ? (
                <div className="h-full flex flex-col items-center justify-center text-slate-400 space-y-4">
                  <FileText className="w-16 h-16 text-slate-200" />
                  <p className="text-lg">No notes found.</p>
                  <button onClick={createNewNote} className="bg-amber-500 hover:bg-amber-600 text-white px-4 py-2 rounded shadow flex items-center space-x-2 transition-colors">
                    <Plus className="w-4 h-4" />
                    <span>Create a Note</span>
                  </button>
                </div>
              ) : (
                <div className="max-w-3xl mx-auto">
                  <input 
                    type="text"
                    value={activeNote?.title || ''}
                    onChange={e => updateActiveNote({ title: e.target.value })}
                    placeholder="Note Title"
                    className="w-full text-4xl font-bold text-slate-800 border-none outline-none placeholder-slate-300 mb-6 bg-transparent"
                  />
                  
                  {activeTab === 'editor' ? (
                    <RichTextEditor
                      content={activeNote?.content || ''}
                      onChange={(html) => updateActiveNote({ content: html })}
                      placeholder="Write your notes here in any language. Use the AI Printer above to refine and structure them..."
                      className="min-h-[400px]"
                    />
                  ) : (
                    <div className="prose prose-lg prose-slate max-w-none text-slate-700 prose-headings:text-slate-800">
                      <div className="markdown-body" dangerouslySetInnerHTML={{ __html: activeNote?.content || '' }} />
                    </div>
                  )}
                </div>
              )}
            </div>
            </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
