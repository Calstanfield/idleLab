import React, { useState, useEffect, useRef } from 'react';
import {
  Clock,
  Play,
  Pause,
  RotateCcw,
  Volume2,
  VolumeX,
  X,
  Droplet,
  Eye,
  Dumbbell,
  Moon,
  Sparkles,
  CheckCircle2,
  Coffee,
  Heart,
  Award
} from 'lucide-react';
import { HealthPomodoroMode } from '../types';
import { soundEffects } from '../lib/soundEffects';

interface PomodoroModalProps {
  isOpen: boolean;
  onClose: () => void;
  onRewardXP?: (amount: number) => void;
}

interface ModeConfig {
  id: HealthPomodoroMode;
  label: string;
  defaultMins: number;
  icon: React.ReactNode;
  color: string;
  description: string;
  tips: string[];
}

const MODES: ModeConfig[] = [
  {
    id: 'hydration',
    label: 'Hydration Sip',
    defaultMins: 5,
    icon: <Droplet className="w-4 h-4" />,
    color: 'from-sky-500 to-blue-600',
    description: 'Frequent hydration intervals to maintain peak cognitive energy and kidney health.',
    tips: [
      'Aim for 150–250ml of water per hydration cycle.',
      'Add a pinch of electrolytes or lemon for rapid absorption.',
      'Sip slowly rather than gulping rapidly.'
    ]
  },
  {
    id: 'screen_break',
    label: '20-20-20 Eye Break',
    defaultMins: 20,
    icon: <Eye className="w-4 h-4" />,
    color: 'from-emerald-500 to-teal-600',
    description: 'The 20-20-20 rule: Look at an object 20 feet away for 20 seconds to prevent digital eye strain.',
    tips: [
      'Gaze out a window into the horizon.',
      'Blink intentionally 10 times to re-moisturize cornea.',
      'Roll shoulders backward to reset posture.'
    ]
  },
  {
    id: 'workout',
    label: 'Micro-Ergo Stretch',
    defaultMins: 45,
    icon: <Dumbbell className="w-4 h-4" />,
    color: 'from-amber-500 to-orange-600',
    description: 'Desk stretches and standing mobility breaks to combat lumbar fatigue.',
    tips: [
      'Stand up and perform 5 thoracic spine extensions.',
      'Stretch wrists and flex extensor tendons.',
      'Do 10 bodyweight calf raises to circulate blood flow.'
    ]
  },
  {
    id: 'sleep',
    label: 'Circadian Recharge',
    defaultMins: 90,
    icon: <Moon className="w-4 h-4" />,
    color: 'from-purple-500 to-indigo-600',
    description: 'Ultradian rhythm deep work sprint followed by a complete mental reset.',
    tips: [
      'Dim harsh overhead lighting if working late.',
      'Practice 4-7-8 diaphragmatic breathing for 60 seconds.',
      'Step away from blue-light screens completely during break.'
    ]
  }
];

export const PomodoroModal: React.FC<PomodoroModalProps> = ({
  isOpen,
  onClose,
  onRewardXP
}) => {
  const [activeMode, setActiveMode] = useState<HealthPomodoroMode>('hydration');
  const [durationMins, setDurationMins] = useState<number>(5);
  const [secondsRemaining, setSecondsRemaining] = useState<number>(5 * 60);
  const [isRunning, setIsRunning] = useState<boolean>(false);
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);
  const [autoRepeat, setAutoRepeat] = useState<boolean>(true);
  const [completedSessions, setCompletedSessions] = useState<number>(0);
  const [lastLoggedMessage, setLastLoggedMessage] = useState<string | null>(null);

  const activeModeConfig = MODES.find((m) => m.id === activeMode) || MODES[0];
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  // Switch modes
  const handleSelectMode = (mode: HealthPomodoroMode) => {
    setActiveMode(mode);
    const cfg = MODES.find((m) => m.id === mode) || MODES[0];
    setDurationMins(cfg.defaultMins);
    setSecondsRemaining(cfg.defaultMins * 60);
    setIsRunning(false);
  };

  // Adjust custom minutes
  const handleSetCustomMinutes = (mins: number) => {
    const clamped = Math.max(1, Math.min(180, mins));
    setDurationMins(clamped);
    setSecondsRemaining(clamped * 60);
    setIsRunning(false);
  };

  // Main countdown tick
  useEffect(() => {
    if (isRunning && secondsRemaining > 0) {
      timerRef.current = setTimeout(() => {
        setSecondsRemaining((prev) => prev - 1);
      }, 1000);
    } else if (isRunning && secondsRemaining === 0) {
      // Completed!
      if (soundEnabled) {
        soundEffects.playPomodoroChime();
      }
      setCompletedSessions((prev) => prev + 1);
      setLastLoggedMessage(`Completed ${activeModeConfig.label}! +100 XP awarded.`);
      if (onRewardXP) onRewardXP(100);

      if (autoRepeat) {
        setSecondsRemaining(durationMins * 60);
      } else {
        setIsRunning(false);
        setSecondsRemaining(durationMins * 60);
      }
    }

    return () => {
      if (timerRef.current) clearTimeout(timerRef.current);
    };
  }, [isRunning, secondsRemaining, soundEnabled, autoRepeat, durationMins, activeModeConfig, onRewardXP]);

  if (!isOpen) return null;

  const minutesDisplay = Math.floor(secondsRemaining / 60);
  const secondsDisplay = secondsRemaining % 60;
  const progressPercent = Math.max(
    0,
    Math.min(100, ((durationMins * 60 - secondsRemaining) / (durationMins * 60)) * 100)
  );

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-xl bg-[#11131a]/95 border border-sky-500/25 rounded-3xl shadow-[0_25px_60px_rgba(0,162,255,0.2)] overflow-hidden text-neutral-100 flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-white/10 bg-white/5">
          <div className="flex items-center space-x-3">
            <div className="p-2.5 rounded-2xl bg-sky-500/20 border border-sky-500/30 text-sky-400">
              <Clock className="w-5 h-5 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h2 className="text-lg font-bold text-white tracking-wide">
                  Healthcare Pomodoro Companion
                </h2>
                <span className="text-[10px] bg-emerald-500/20 text-emerald-300 font-semibold px-2 py-0.5 rounded-full border border-emerald-500/30 flex items-center gap-1">
                  <Heart className="w-3 h-3 text-emerald-400" /> WisdomWell Engine
                </span>
              </div>
              <p className="text-xs text-neutral-400">
                Ergonomic posture breaks, hydration loops, and eye fatigue prevention
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-white/5 hover:bg-white/15 text-neutral-400 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Mode Selector Tabs */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5 p-3 bg-black/40 border-b border-white/5">
          {MODES.map((mode) => (
            <button
              key={mode.id}
              onClick={() => handleSelectMode(mode.id)}
              className={`flex flex-col items-center justify-center p-2.5 rounded-2xl transition-all cursor-pointer ${
                activeMode === mode.id
                  ? 'bg-sky-500/20 text-sky-300 border border-sky-500/40 shadow-inner'
                  : 'text-neutral-400 hover:text-white hover:bg-white/5 border border-transparent'
              }`}
            >
              <div className="mb-1">{mode.icon}</div>
              <span className="text-xs font-bold leading-tight">{mode.label}</span>
              <span className="text-[10px] text-neutral-400 font-mono mt-0.5">
                {mode.defaultMins}m loop
              </span>
            </button>
          ))}
        </div>

        {/* Main Countdown Display */}
        <div className="p-6 overflow-y-auto space-y-6 flex-1">
          <div className="relative flex flex-col items-center justify-center p-8 rounded-3xl bg-black/40 border border-white/10 overflow-hidden shadow-inner">
            {/* Circular Glowing Background Accent */}
            <div className={`absolute -top-10 -right-10 w-40 h-40 rounded-full blur-3xl opacity-25 bg-gradient-to-r ${activeModeConfig.color}`} />

            {/* Time String */}
            <div className="text-6xl sm:text-7xl font-mono font-extrabold tracking-tight text-white drop-shadow-[0_0_20px_rgba(56,189,248,0.3)]">
              {String(minutesDisplay).padStart(2, '0')}:{String(secondsDisplay).padStart(2, '0')}
            </div>

            <div className="mt-2 text-xs font-semibold text-neutral-400 flex items-center gap-1.5">
              <span>{activeModeConfig.label}</span>
              <span>•</span>
              <span className="text-sky-400 font-mono">{durationMins} minute target</span>
            </div>

            {/* Progress Bar */}
            <div className="w-full max-w-md mt-6 bg-white/10 rounded-full h-2 overflow-hidden border border-white/5">
              <div
                className={`h-full bg-gradient-to-r ${activeModeConfig.color} transition-all duration-300`}
                style={{ width: `${progressPercent}%` }}
              />
            </div>

            {/* Controls Bar */}
            <div className="flex items-center space-x-3 mt-6">
              <button
                onClick={() => setIsRunning(!isRunning)}
                className={`px-6 py-3 rounded-2xl font-bold text-sm flex items-center space-x-2 transition-all shadow-lg cursor-pointer ${
                  isRunning
                    ? 'bg-amber-500 hover:bg-amber-400 text-black shadow-amber-500/30'
                    : 'bg-gradient-to-r from-sky-500 to-blue-600 hover:from-sky-400 hover:to-blue-500 text-white shadow-sky-500/30'
                }`}
              >
                {isRunning ? (
                  <>
                    <Pause className="w-4 h-4" />
                    <span>Pause Timer</span>
                  </>
                ) : (
                  <>
                    <Play className="w-4 h-4 fill-current" />
                    <span>Start Interval</span>
                  </>
                )}
              </button>

              <button
                onClick={() => {
                  setIsRunning(false);
                  setSecondsRemaining(durationMins * 60);
                }}
                className="p-3 rounded-2xl bg-white/10 hover:bg-white/20 text-neutral-300 hover:text-white transition-all border border-white/10 cursor-pointer"
                title="Reset timer"
              >
                <RotateCcw className="w-4 h-4" />
              </button>

              <button
                onClick={() => setSoundEnabled(!soundEnabled)}
                className={`p-3 rounded-2xl border transition-all cursor-pointer ${
                  soundEnabled
                    ? 'bg-sky-500/20 text-sky-300 border-sky-500/40'
                    : 'bg-white/5 text-neutral-500 border-white/10'
                }`}
                title={soundEnabled ? 'Chime sound enabled' : 'Chime sound muted'}
              >
                {soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
              </button>
            </div>
          </div>

          {/* Quick Preset Buttons */}
          <div className="space-y-2">
            <label className="text-xs font-bold text-neutral-400 uppercase tracking-wider">
              Preset Intervals
            </label>
            <div className="flex flex-wrap gap-2">
              {[5, 10, 15, 20, 30, 45, 60].map((m) => (
                <button
                  key={m}
                  onClick={() => handleSetCustomMinutes(m)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-semibold font-mono transition-all cursor-pointer ${
                    durationMins === m
                      ? 'bg-sky-500 text-white shadow-sm'
                      : 'bg-white/5 hover:bg-white/15 text-neutral-400 hover:text-white border border-white/5'
                  }`}
                >
                  {m}m
                </button>
              ))}
            </div>
          </div>

          {/* Ergonomic Tips & Stats Card */}
          <div className="p-4 rounded-2xl bg-white/5 border border-white/5 space-y-2">
            <h4 className="text-xs font-bold text-neutral-300 uppercase tracking-wider flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-amber-400" /> Ergonomic Clinical Guidance
            </h4>
            <ul className="space-y-1.5 text-xs text-neutral-400">
              {activeModeConfig.tips.map((tip, idx) => (
                <li key={idx} className="flex items-start space-x-2">
                  <span className="text-sky-400 font-bold">•</span>
                  <span>{tip}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Completion Milestone Badge */}
          {completedSessions > 0 && (
            <div className="p-3.5 rounded-2xl bg-emerald-500/15 border border-emerald-500/30 flex items-center justify-between">
              <div className="flex items-center space-x-2.5 text-emerald-300 text-xs font-bold">
                <Award className="w-4 h-4 text-emerald-400" />
                <span>{completedSessions} Wellness Intervals Completed Today</span>
              </div>
              <span className="text-[11px] font-semibold text-emerald-400 bg-emerald-500/20 px-2 py-0.5 rounded-md border border-emerald-500/30">
                +{completedSessions * 100} XP
              </span>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-white/10 bg-white/5 flex items-center justify-between">
          <label className="flex items-center space-x-2 text-xs text-neutral-400 cursor-pointer">
            <input
              type="checkbox"
              checked={autoRepeat}
              onChange={(e) => setAutoRepeat(e.target.checked)}
              className="accent-sky-500 rounded cursor-pointer"
            />
            <span>Auto-repeat interval indefinitely</span>
          </label>
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-sky-500 hover:bg-sky-400 text-white font-semibold text-xs transition-all cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
