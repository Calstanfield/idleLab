import React, { useState, useRef, useEffect, useMemo } from 'react';
import ReactMarkdown from 'react-markdown';
import { ChatMessage, UserState, GestureType, CuratedMediaItem } from '../types';
import {
  Send,
  MessageSquare,
  Users,
  Radio,
  X,
  Smile,
  Paperclip,
  Upload,
  FileText,
  Bell,
  BellOff,
  BellRing,
  Lock,
  AtSign,
  UserCheck,
  ChevronDown,
  Sparkles,
  Volume2,
  VolumeX,
  Youtube,
  Play,
} from 'lucide-react';
import { notificationManager, NotificationPermissionState } from '../lib/notificationManager';
import { soundEffects } from '../lib/soundEffects';
import { chloeAgentClient } from '../lib/chloeAgentClient';

interface ChatOverlayProps {
  isOpen?: boolean;
  onClose?: () => void;
  messages: ChatMessage[];
  users: UserState[];
  currentUserId: string;
  currentUserName?: string;
  onSendMessage: (
    text: string,
    isProximity: boolean,
    isPrivate?: boolean,
    recipientId?: string,
    recipientName?: string
  ) => void;
  onPerformGesture?: (gesture: GestureType) => void;
  onSendEmojiReaction?: (emoji: string, gesture?: GestureType) => void;
  onCastProjection?: (videoId: string, title?: string, category?: string) => void;
}

const QUICK_EMOJIS = ['👋', '👍', '❤️', '🎉', '☕', '💡', '🚀', '🔥', '👏', '👀'];

export const ChatOverlay: React.FC<ChatOverlayProps> = ({
  isOpen = false,
  onClose,
  messages,
  users,
  currentUserId,
  currentUserName = 'You',
  onSendMessage,
  onPerformGesture,
  onSendEmojiReaction,
  onCastProjection,
}) => {
  const [activeTab, setActiveTab] = useState<'chat' | 'mentions' | 'direct' | 'users'>('chat');
  const [input, setInput] = useState('');
  const [isProximity, setIsProximity] = useState(false);
  const [selectedDmUserId, setSelectedDmUserId] = useState<string | null>(null);
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);
  const [showMentionAutocomplete, setShowMentionAutocomplete] = useState(false);
  const [mentionQuery, setMentionQuery] = useState('');
  const [attachedFile, setAttachedFile] = useState<{ name: string; size?: string } | null>(null);
  const [permissionState, setPermissionState] = useState<NotificationPermissionState>(
    notificationManager.getPermission()
  );
  const [testNotificationScheduled, setTestNotificationScheduled] = useState(false);
  const [isSfxMuted, setIsSfxMuted] = useState(soundEffects.isMuted());
  const [isChloeThinking, setIsChloeThinking] = useState(false);

  useEffect(() => {
    const unsub = soundEffects.onMuteChange((muted) => {
      setIsSfxMuted(muted);
    });
    const unsubChloe = chloeAgentClient.onLoadingChange((loading) => {
      setIsChloeThinking(loading);
    });
    return () => {
      unsub();
      unsubChloe();
    };
  }, []);

  const handleToggleSfx = () => {
    soundEffects.toggleMute();
  };

  const chatEndRef = useRef<HTMLDivElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const inputRef = useRef<HTMLInputElement | null>(null);

  // Real current date string formatting
  const todayDateStr = new Date().toLocaleDateString('en-US', {
    day: 'numeric',
    month: 'short',
    year: 'numeric',
  }).toUpperCase();

  // Keep notification permission state updated
  useEffect(() => {
    setPermissionState(notificationManager.getPermission());
  }, [isOpen]);

  // Auto-scroll on new messages
  useEffect(() => {
    if (isOpen) {
      chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages, isOpen, activeTab, selectedDmUserId]);

  const handleRequestPermission = async () => {
    const res = await notificationManager.requestPermission();
    setPermissionState(res);
  };

  const handleTriggerTestNotification = () => {
    setTestNotificationScheduled(true);
    // Notify after 2 seconds to allow switching tabs/backgrounding
    setTimeout(() => {
      notificationManager.notify({
        title: `🔒 Direct Message from Fortune Cookie`,
        body: `Hey ${currentUserName}, here are the latest 3D office architectural specs!`,
        tag: `test-notification-${Date.now()}`,
        onClick: () => {
          window.focus();
        },
      });
      setTestNotificationScheduled(false);
    }, 2000);
  };

  // Other colleagues excluding current user
  const otherUsers = useMemo(() => {
    return users.filter((u) => u.id !== currentUserId);
  }, [users, currentUserId]);

  // Mention counts for current user
  const mentionCount = useMemo(() => {
    return messages.filter(
      (m) =>
        m.senderId !== currentUserId &&
        !m.isPrivate &&
        notificationManager.isMentioned(m.text, currentUserName)
    ).length;
  }, [messages, currentUserId, currentUserName]);

  // Unread DM counts for current user
  const dmCount = useMemo(() => {
    return messages.filter(
      (m) => m.isPrivate && m.recipientId === currentUserId && m.senderId !== currentUserId
    ).length;
  }, [messages, currentUserId]);

  // Filter messages based on active tab
  const filteredMessages = useMemo(() => {
    if (activeTab === 'mentions') {
      return messages.filter(
        (m) =>
          !m.isPrivate &&
          (notificationManager.isMentioned(m.text, currentUserName) || m.senderId === currentUserId)
      );
    }
    if (activeTab === 'direct') {
      if (!selectedDmUserId) {
        // Show all DMs involving current user
        return messages.filter(
          (m) => m.isPrivate && (m.senderId === currentUserId || m.recipientId === currentUserId)
        );
      }
      return messages.filter(
        (m) =>
          m.isPrivate &&
          ((m.senderId === currentUserId && m.recipientId === selectedDmUserId) ||
            (m.senderId === selectedDmUserId && m.recipientId === currentUserId))
      );
    }
    // 'chat' tab: Show all public workspace/floor messages
    return messages.filter((m) => !m.isPrivate);
  }, [messages, activeTab, selectedDmUserId, currentUserId, currentUserName]);

  if (!isOpen) return null;

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value;
    setInput(val);

    // Detect if user is typing '@' for mention autocomplete
    const cursorIndex = e.target.selectionStart || val.length;
    const textBeforeCursor = val.slice(0, cursorIndex);
    const atMatch = textBeforeCursor.match(/@([a-zA-Z0-9_]*)$/);

    if (atMatch) {
      setShowMentionAutocomplete(true);
      setMentionQuery(atMatch[1].toLowerCase());
    } else {
      setShowMentionAutocomplete(false);
    }
  };

  const handleSelectMention = (name: string) => {
    const cursorIndex = inputRef.current?.selectionStart || input.length;
    const textBeforeCursor = input.slice(0, cursorIndex);
    const textAfterCursor = input.slice(cursorIndex);
    const newTextBefore = textBeforeCursor.replace(/@([a-zA-Z0-9_]*)$/, `@${name} `);

    setInput(newTextBefore + textAfterCursor);
    setShowMentionAutocomplete(false);
    inputRef.current?.focus();
  };

  const runEmoteDebugSequence = () => {
    soundEffects.playEmote();
    const sequence: Array<{ gesture: GestureType; emoji: string; label: string }> = [
      { gesture: 'wave', emoji: '👋', label: 'Wave' },
      { gesture: 'dance', emoji: '🎉', label: 'Dance' },
      { gesture: 'clap', emoji: '👏', label: 'Clap' },
      { gesture: 'think', emoji: '🤔', label: 'Point/Think' },
      { gesture: 'bow', emoji: '🙇', label: 'Bow' },
      { gesture: 'cheer', emoji: '🔥', label: 'Cheer' },
      { gesture: 'heart', emoji: '❤️', label: 'Heart' },
      { gesture: 'facepalm', emoji: '🤦', label: 'Facepalm' },
    ];

    onSendMessage(
      '🛠️ [EMOTE DEBUG STARTED] Sequentially testing all 8 avatar 3D gestures and emoji reactions...',
      isProximity,
      false
    );

    sequence.forEach((item, idx) => {
      setTimeout(() => {
        soundEffects.playEmote();
        if (onPerformGesture) onPerformGesture(item.gesture);
        if (onSendEmojiReaction) onSendEmojiReaction(item.emoji, item.gesture);
        onSendMessage(
          `🛠️ [DEBUG ${idx + 1}/8] Fired ${item.label.toUpperCase()} ${item.emoji} gesture & 3D particle burst`,
          isProximity,
          false
        );
      }, (idx + 1) * 1500);
    });

    setTimeout(() => {
      onSendMessage(
        '✅ [EMOTE DEBUG COMPLETED] All 8 avatar 3D gestures (Wave, Dance, Clap, Think, Bow, Cheer, Heart, Facepalm) verified successfully!',
        isProximity,
        false
      );
    }, (sequence.length + 1) * 1500);
  };

  const triggerSingleGesture = (gesture: GestureType, emoji: string) => {
    soundEffects.playEmote();
    if (onPerformGesture) onPerformGesture(gesture);
    if (onSendEmojiReaction) onSendEmojiReaction(emoji, gesture);
    onSendMessage(`[Emote: ${gesture.toUpperCase()} ${emoji}]`, isProximity, false);
  };

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    let textToSend = input.trim();
    if (attachedFile) {
      textToSend = textToSend ? `${textToSend}\n📎 ${attachedFile.name}` : `📎 ${attachedFile.name}`;
    }
    if (!textToSend) return;

    // Handle slash commands (/debug, /debug emotes, /wave, /dance, etc.)
    if (textToSend.startsWith('/')) {
      const lower = textToSend.toLowerCase().trim();
      if (
        lower === '/debug' ||
        lower === '/debug emotes' ||
        lower === '/debug emote' ||
        lower === '/debugemotes' ||
        lower === '/debug-emotes'
      ) {
        runEmoteDebugSequence();
        setInput('');
        setAttachedFile(null);
        return;
      }
      if (lower === '/wave') {
        triggerSingleGesture('wave', '👋');
        setInput('');
        setAttachedFile(null);
        return;
      }
      if (lower === '/dance') {
        triggerSingleGesture('dance', '🎉');
        setInput('');
        setAttachedFile(null);
        return;
      }
      if (lower === '/clap') {
        triggerSingleGesture('clap', '👏');
        setInput('');
        setAttachedFile(null);
        return;
      }
      if (lower === '/think' || lower === '/point') {
        triggerSingleGesture('think', '🤔');
        setInput('');
        setAttachedFile(null);
        return;
      }
      if (lower === '/bow') {
        triggerSingleGesture('bow', '🙇');
        setInput('');
        setAttachedFile(null);
        return;
      }
      if (lower === '/cheer') {
        triggerSingleGesture('cheer', '🔥');
        setInput('');
        setAttachedFile(null);
        return;
      }
      if (lower === '/heart') {
        triggerSingleGesture('heart', '❤️');
        setInput('');
        setAttachedFile(null);
        return;
      }
      if (lower === '/facepalm') {
        triggerSingleGesture('facepalm', '🤦');
        setInput('');
        setAttachedFile(null);
        return;
      }
      if (lower === '/emotes' || lower === '/emote') {
        runEmoteDebugSequence();
        setInput('');
        setAttachedFile(null);
        return;
      }
      if (lower === '/help') {
        onSendMessage(
          '💡 Available Commands:\n• /debug emotes - Test all 8 avatar gestures in sequence\n• /wave, /dance, /clap, /think, /bow, /cheer, /heart, /facepalm - Express gesture',
          isProximity,
          false
        );
        setInput('');
        setAttachedFile(null);
        return;
      }
    }

    if (activeTab === 'direct') {
      const recipient = otherUsers.find((u) => u.id === selectedDmUserId);
      if (recipient) {
        onSendMessage(textToSend, false, true, recipient.id, recipient.name);
      } else if (otherUsers.length > 0) {
        // Default to first available colleague if not selected
        const fallback = otherUsers[0];
        onSendMessage(textToSend, false, true, fallback.id, fallback.name);
      }
    } else {
      onSendMessage(textToSend, isProximity, false);
    }

    setInput('');
    setAttachedFile(null);
    setShowEmojiPicker(false);
    setShowMentionAutocomplete(false);
  };

  const handleAddEmoji = (emoji: string) => {
    soundEffects.playPop(100);
    setInput((prev) => (prev ? prev + ' ' + emoji : emoji));
    setShowEmojiPicker(false);
    inputRef.current?.focus();
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const sizeMb = (file.size / (1024 * 1024)).toFixed(1);
      const sizeStr = `${sizeMb} MB`;
      setAttachedFile({ name: file.name, size: sizeStr });
    }
  };

  const triggerFileUpload = () => {
    fileInputRef.current?.click();
  };

  const formatMessageTime = (ts?: number) => {
    if (!ts) return new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    return new Date(ts).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  const renderMessageContent = (text: string, isMe: boolean) => {
    const parts = text.split(/(@[a-zA-Z0-9_\s]+?\b|@[a-zA-Z0-9_]+)/g);

    return parts.map((part, i) => {
      if (part.startsWith('@')) {
        const isMyMention = notificationManager.isMentioned(part, currentUserName);
        return (
          <span
            key={`mention-${i}-${part}`}
            className={`font-semibold px-1 py-0.2 rounded-md ${
              isMyMention
                ? 'bg-amber-400/30 text-amber-800 border border-amber-400/40 font-bold'
                : isMe
                ? 'bg-sky-400/30 text-white underline'
                : 'bg-sky-100 text-sky-700 font-semibold'
            }`}
          >
            {part}
          </span>
        );
      }
      return <span key={`text-${i}`}>{part}</span>;
    });
  };

  // Mention Autocomplete Suggestions
  const mentionSuggestions = [
    { id: 'all', name: 'everyone', role: 'Notify all colleagues' },
    ...otherUsers.map((u) => ({ id: u.id, name: u.name, role: `${u.department || 'Colleague'} • ${u.statusText || 'Online'}` })),
  ].filter((item) => item.name.toLowerCase().includes(mentionQuery));

  return (
    <div className="fixed bottom-20 left-3 sm:bottom-20 sm:left-6 z-50 pointer-events-auto">
      {/* Hidden File Input */}
      <input
        type="file"
        ref={fileInputRef}
        onChange={handleFileChange}
        className="hidden"
      />

      {/* Clean Light Theme Chat Window */}
      <div className="w-[calc(100vw-1.5rem)] sm:w-[420px] h-[520px] sm:h-[560px] max-h-[calc(100vh-8rem)] bg-white border border-slate-200/90 rounded-2xl shadow-[0_20px_50px_rgba(0,0,0,0.18)] flex flex-col overflow-hidden text-slate-800 font-sans animate-in fade-in zoom-in-95 duration-150">
        
        {/* Top Header Bar */}
        <div className="flex items-center justify-between px-4 py-2.5 border-b border-slate-100 bg-white">
          <div className="flex items-center space-x-1.5 overflow-x-auto no-scrollbar">
            {/* Global Chat Tab */}
            <button
              onClick={() => setActiveTab('chat')}
              className={`flex items-center space-x-1 text-xs font-semibold px-2.5 py-1.5 rounded-lg transition-all ${
                activeTab === 'chat'
                  ? 'bg-slate-100 text-slate-900 shadow-xs'
                  : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              <MessageSquare className="w-3.5 h-3.5 text-sky-500" />
              <span>Workspace</span>
            </button>

            {/* Mentions Tab */}
            <button
              onClick={() => setActiveTab('mentions')}
              className={`flex items-center space-x-1 text-xs font-semibold px-2.5 py-1.5 rounded-lg transition-all relative ${
                activeTab === 'mentions'
                  ? 'bg-slate-100 text-slate-900 shadow-xs'
                  : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              <AtSign className="w-3.5 h-3.5 text-amber-500" />
              <span>Mentions</span>
              {mentionCount > 0 && (
                <span className="ml-1 px-1.5 py-0.2 bg-amber-500 text-white rounded-full text-[10px] font-bold">
                  {mentionCount}
                </span>
              )}
            </button>

            {/* Direct Messages Tab */}
            <button
              onClick={() => setActiveTab('direct')}
              className={`flex items-center space-x-1 text-xs font-semibold px-2.5 py-1.5 rounded-lg transition-all relative ${
                activeTab === 'direct'
                  ? 'bg-slate-100 text-slate-900 shadow-xs'
                  : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              <Lock className="w-3.5 h-3.5 text-emerald-500" />
              <span>Direct</span>
              {dmCount > 0 && (
                <span className="ml-1 px-1.5 py-0.2 bg-emerald-500 text-white rounded-full text-[10px] font-bold">
                  {dmCount}
                </span>
              )}
            </button>

            {/* Online Members Tab */}
            <button
              onClick={() => setActiveTab('users')}
              className={`flex items-center space-x-1 text-xs font-semibold px-2.5 py-1.5 rounded-lg transition-all ${
                activeTab === 'users'
                  ? 'bg-slate-100 text-slate-900 shadow-xs'
                  : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              <Users className="w-3.5 h-3.5 text-indigo-500" />
              <span>({users.length})</span>
            </button>
          </div>

          <div className="flex items-center space-x-1">
            <button
              onClick={handleToggleSfx}
              className={`p-1.5 rounded-lg transition-colors cursor-pointer ${
                isSfxMuted
                  ? 'text-amber-500 hover:bg-amber-50'
                  : 'text-indigo-600 hover:bg-indigo-50'
              }`}
              title={isSfxMuted ? 'Unmute Sound Effects & Chimes' : 'Mute Sound Effects & Chimes'}
            >
              {isSfxMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
            </button>

            {onClose && (
              <button
                onClick={onClose}
                className="text-slate-400 hover:text-slate-700 p-1.5 rounded-lg hover:bg-slate-100 transition-colors cursor-pointer"
                title="Close Chat"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>

        {/* Browser Notification Banner & Alert Status */}
        {permissionState !== 'granted' ? (
          <div className="bg-gradient-to-r from-amber-50 to-orange-50 px-3.5 py-2 border-b border-amber-200/60 flex items-center justify-between text-xs text-amber-900">
            <div className="flex items-center space-x-2">
              <BellRing className="w-4 h-4 text-amber-600 shrink-0 animate-bounce" />
              <span className="text-[11px] font-medium leading-tight">
                Enable browser alerts for private DMs & @mentions
              </span>
            </div>
            <button
              onClick={handleRequestPermission}
              className="px-2.5 py-1 bg-amber-600 hover:bg-amber-700 text-white rounded-lg text-[10px] font-bold transition-all shadow-xs cursor-pointer active:scale-95 shrink-0"
            >
              Allow Alerts
            </button>
          </div>
        ) : (
          <div className="bg-slate-50/90 px-3 py-1.5 border-b border-slate-100 flex items-center justify-between text-[11px] text-slate-500">
            <div className="flex items-center space-x-1.5">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              <span className="font-medium text-slate-600">Background notifications active</span>
            </div>
            <button
              onClick={handleTriggerTestNotification}
              disabled={testNotificationScheduled}
              className="text-[10px] text-sky-600 hover:text-sky-800 font-semibold px-2 py-0.5 rounded hover:bg-sky-50 transition-colors cursor-pointer flex items-center space-x-1"
              title="Test browser notification when switching tabs"
            >
              <Sparkles className="w-3 h-3 text-sky-500" />
              <span>{testNotificationScheduled ? 'Alert in 2s...' : 'Test Alert'}</span>
            </button>
          </div>
        )}

        {/* Direct Message Recipient Header Bar (When in Direct Tab) */}
        {activeTab === 'direct' && (
          <div className="px-3.5 py-2 bg-emerald-50/50 border-b border-emerald-100 flex items-center justify-between text-xs">
            <div className="flex items-center space-x-1.5 font-medium text-emerald-900">
              <Lock className="w-3.5 h-3.5 text-emerald-600" />
              <span>Recipient:</span>
              <select
                value={selectedDmUserId || ''}
                onChange={(e) => setSelectedDmUserId(e.target.value || null)}
                className="bg-white border border-emerald-200 rounded-md px-2 py-0.5 text-xs text-slate-800 font-semibold focus:outline-none focus:ring-1 focus:ring-emerald-500 cursor-pointer"
              >
                <option value="">All Direct Messages</option>
                {otherUsers.map((u) => (
                  <option key={u.id} value={u.id}>
                    {u.name} ({u.department || 'Colleague'})
                  </option>
                ))}
              </select>
            </div>
            <span className="text-[10px] text-emerald-700 font-semibold">1-on-1 End-to-End</span>
          </div>
        )}

        {/* Chat & Mentions & Direct Messages View */}
        {activeTab !== 'users' && (
          <div className="flex-1 flex flex-col min-h-0 bg-[#fdfdfd]">
            {/* Scrollable Message History */}
            <div className="flex-1 p-3.5 overflow-y-auto space-y-3 text-xs">
              {/* Date Divider */}
              <div className="flex items-center justify-center my-1.5 text-[10px] font-bold text-slate-300 tracking-wider">
                <div className="flex-1 h-px bg-slate-100" />
                <span className="px-3 text-slate-400 font-semibold uppercase text-[10px] bg-slate-50 py-0.5 rounded-full border border-slate-100">
                  {todayDateStr}
                </span>
                <div className="flex-1 h-px bg-slate-100" />
              </div>

              {/* Empty States */}
              {filteredMessages.length === 0 && (
                <div className="text-center py-10 text-slate-400 space-y-1.5">
                  {activeTab === 'mentions' ? (
                    <>
                      <AtSign className="w-8 h-8 mx-auto text-slate-300" />
                      <p className="font-semibold text-xs text-slate-600">No mentions yet</p>
                      <p className="text-[11px]">When someone types @{currentUserName}, it will appear here.</p>
                    </>
                  ) : activeTab === 'direct' ? (
                    <>
                      <Lock className="w-8 h-8 mx-auto text-slate-300" />
                      <p className="font-semibold text-xs text-slate-600">No private messages</p>
                      <p className="text-[11px]">Select a colleague above to start a direct 1-on-1 conversation.</p>
                    </>
                  ) : (
                    <>
                      <MessageSquare className="w-8 h-8 mx-auto text-slate-300" />
                      <p className="font-semibold text-xs text-slate-600">No messages yet today</p>
                      <p className="text-[11px]">Type a message or use <span className="font-bold text-sky-600">@mention</span> to notify colleagues!</p>
                    </>
                  )}
                </div>
              )}

              {/* Render Filtered Messages */}
              {filteredMessages.map((msg) => {
                const isMe = msg.senderId === currentUserId;
                const isDM = !!msg.isPrivate;
                const isMentioned = !isMe && notificationManager.isMentioned(msg.text, currentUserName);
                const hasAttachment = msg.text.includes('📎');
                const cleanText = msg.text.replace(/📎\s*\S+/g, '').trim();
                const attachmentMatch = msg.text.match(/📎\s*(\S+)/);
                const fileName = attachmentMatch ? attachmentMatch[1] : null;

                return (
                  <div
                    key={msg.id}
                    className={`flex flex-col ${
                      isMe ? 'items-end ml-auto max-w-[85%]' : 'items-start max-w-[85%]'
                    }`}
                  >
                    <div className="flex items-center space-x-1.5 mb-0.5 px-1">
                      {!isMe && (
                        <span className="text-[11px] font-bold text-slate-700 flex items-center space-x-1">
                          <span>{msg.senderName}</span>
                          {msg.senderName === 'Chloe Becker' && msg.activeSubAgent && msg.activeSubAgent !== 'chloe_general' && (
                            <span className="px-1.5 py-0.2 bg-indigo-100 text-indigo-800 rounded font-mono font-bold text-[9px]">
                              {msg.activeSubAgent === 'task_gov' ? '[Task_Gov]' : msg.activeSubAgent === 'culture_match' ? '[Culture_Match]' : msg.activeSubAgent === 'tech_fix' ? '[Tech_Fix]' : msg.activeSubAgent === 'wisdom_well' ? '[Wisdom_Well]' : msg.activeSubAgent === 'workspace_automator' ? '[Workspace_Automator]' : msg.activeSubAgent === 'system_advisory' ? '[System_Advisory]' : `[${msg.activeSubAgent}]`}
                            </span>
                          )}
                          {isDM && (
                            <span className="text-[9px] bg-emerald-100 text-emerald-800 px-1 rounded font-bold">
                              🔒 DM
                            </span>
                          )}
                          {isMentioned && (
                            <span className="text-[9px] bg-amber-100 text-amber-800 px-1 rounded font-bold">
                              @Mentioned
                            </span>
                          )}
                        </span>
                      )}
                      <span className="text-[9px] text-slate-400 font-mono">
                        {formatMessageTime(msg.timestamp)}
                      </span>
                    </div>

                    <div
                      className={`px-3.5 py-2.5 rounded-2xl shadow-[0_1px_3px_rgba(0,0,0,0.02)] ${
                        isMe
                          ? isDM
                            ? 'bg-emerald-600 text-white rounded-tr-xs'
                            : 'bg-[#0c8ce9] text-white rounded-tr-xs'
                          : isMentioned
                          ? 'bg-amber-50 text-slate-900 border-2 border-amber-300 rounded-tl-xs'
                          : isDM
                          ? 'bg-emerald-50/80 text-slate-900 border border-emerald-200 rounded-tl-xs'
                          : 'bg-slate-100 text-slate-800 rounded-tl-xs border border-slate-200/60'
                      }`}
                    >
                      {cleanText && (
                        msg.senderName === 'Chloe Becker' || cleanText.includes('**') || cleanText.includes('###') || cleanText.includes('\n- ') ? (
                          <div className="prose prose-slate max-w-none text-xs leading-relaxed [&>p]:mb-1 [&>p:last-child]:mb-0 [&>strong]:font-bold [&>strong]:text-slate-900 [&>ul]:list-disc [&>ul]:pl-4 [&>ol]:list-decimal [&>ol]:pl-4">
                            <ReactMarkdown>{cleanText}</ReactMarkdown>
                          </div>
                        ) : (
                          <p className="leading-relaxed font-normal break-words">
                            {renderMessageContent(cleanText, isMe)}
                          </p>
                        )
                      )}

                      {/* Chloe's Curated Media Recommendation Cards */}
                      {msg.curatedMedia && msg.curatedMedia.length > 0 && (
                        <div className="mt-2.5 space-y-2 pt-2 border-t border-slate-200/80">
                          <div className="flex items-center justify-between text-[10px] font-bold text-rose-600 uppercase tracking-wider">
                            <span className="flex items-center space-x-1">
                              <Sparkles className="w-3 h-3 text-amber-500" />
                              <span>Chloe's Curated Content</span>
                            </span>
                            <span className="text-[9px] px-1.5 py-0.2 bg-rose-100 text-rose-800 rounded font-semibold">
                              Culture Engine
                            </span>
                          </div>

                          <div className="space-y-1.5">
                            {msg.curatedMedia.map((item, idx) => (
                              <div
                                key={idx}
                                className="p-2.5 rounded-xl bg-white border border-slate-200 shadow-xs flex flex-col space-y-1.5 text-slate-800"
                              >
                                <div className="flex items-start justify-between gap-1.5">
                                  <div>
                                    <div className="text-xs font-bold text-slate-900 leading-tight">
                                      {item.title}
                                    </div>
                                    <div className="text-[10px] text-slate-500 font-semibold mt-0.5">
                                      {item.creator ? `${item.creator} • ` : ''}
                                      <span className="text-rose-600 font-bold">{item.category}</span>
                                    </div>
                                  </div>
                                  <span className="text-[9px] px-1.5 py-0.5 bg-slate-100 text-slate-600 rounded font-mono shrink-0">
                                    {item.tag}
                                  </span>
                                </div>

                                <p className="text-[11px] text-slate-600 leading-relaxed">
                                  {item.description}
                                </p>

                                <div className="flex items-center justify-between pt-1">
                                  <span className="text-[10px] text-slate-400 font-mono">
                                    ID: {item.videoId}
                                  </span>

                                  <span className="px-2 py-0.5 rounded-md bg-red-50 text-red-600 border border-red-200 font-semibold text-[10px] flex items-center space-x-1">
                                    <Youtube className="w-3 h-3 text-red-500" />
                                    <span>YouTube</span>
                                  </span>
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}

                      {hasAttachment && fileName && (
                        <div
                          className={`flex items-center space-x-1.5 font-semibold text-[11px] ${
                            cleanText ? 'mt-1.5 pt-1.5 border-t border-white/20' : ''
                          } ${isMe ? 'text-sky-100' : 'text-sky-700'}`}
                        >
                          <Paperclip className="w-3.5 h-3.5 shrink-0" />
                          <span className="underline decoration-sky-300 truncate">{fileName}</span>
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}

              {/* Chloe Becker Live Processing Indicator */}
              {isChloeThinking && (
                <div className="flex flex-col items-start max-w-[85%] animate-in fade-in duration-150">
                  <div className="flex items-center space-x-1.5 mb-0.5 px-1">
                    <span className="text-[11px] font-bold text-sky-700 flex items-center space-x-1">
                      <span>Chloe Becker</span>
                      <span className="px-1.5 py-0.2 bg-sky-100 text-sky-800 rounded font-mono font-bold text-[9px]">
                        Cloud Agent
                      </span>
                    </span>
                  </div>
                  <div className="px-3.5 py-2.5 rounded-2xl rounded-tl-xs bg-sky-50 text-sky-800 border border-sky-200/80 shadow-[0_1px_3px_rgba(0,0,0,0.02)] flex items-center space-x-2">
                    <div className="flex space-x-1">
                      <span className="w-1.5 h-1.5 rounded-full bg-sky-500 animate-bounce" />
                      <span className="w-1.5 h-1.5 rounded-full bg-sky-500 animate-bounce [animation-delay:0.2s]" />
                      <span className="w-1.5 h-1.5 rounded-full bg-sky-500 animate-bounce [animation-delay:0.4s]" />
                    </div>
                    <span className="text-xs font-medium">Chloe is thinking...</span>
                  </div>
                </div>
              )}

              <div ref={chatEndRef} />
            </div>

            {/* Mention Autocomplete Popup */}
            {showMentionAutocomplete && mentionSuggestions.length > 0 && (
              <div className="mx-3 mb-1 p-1 bg-white border border-slate-200 rounded-xl shadow-lg flex flex-col max-h-36 overflow-y-auto text-xs animate-in slide-in-from-bottom-1 duration-150">
                <div className="px-2 py-1 text-[10px] font-bold uppercase tracking-wider text-slate-400 border-b border-slate-50">
                  Mention Colleague (@)
                </div>
                {mentionSuggestions.map((s) => (
                  <button
                    key={s.id}
                    type="button"
                    onClick={() => handleSelectMention(s.name)}
                    className="flex items-center justify-between px-2.5 py-1.5 hover:bg-sky-50 rounded-lg text-left transition-colors cursor-pointer"
                  >
                    <span className="font-bold text-sky-700">@{s.name}</span>
                    <span className="text-[10px] text-slate-400">{s.role}</span>
                  </button>
                ))}
              </div>
            )}

            {/* Quick Emoji Reaction Popup */}
            {showEmojiPicker && (
              <div className="px-3 py-2 bg-slate-50 border-t border-slate-100 flex items-center space-x-2 overflow-x-auto no-scrollbar animate-in slide-in-from-bottom-1 duration-150">
                {QUICK_EMOJIS.map((em, idx) => (
                  <button
                    key={`emoji-${idx}-${em}`}
                    type="button"
                    onClick={() => handleAddEmoji(em)}
                    className="p-1.5 hover:bg-white rounded-lg text-base transition-transform hover:scale-125 cursor-pointer"
                  >
                    {em}
                  </button>
                ))}
              </div>
            )}

            {/* Attachment Preview Banner */}
            {attachedFile && (
              <div className="px-3 py-1.5 bg-sky-50 border-t border-sky-100 flex items-center justify-between text-xs text-sky-800">
                <span className="flex items-center space-x-1.5 font-medium truncate">
                  <FileText className="w-3.5 h-3.5 text-sky-600 shrink-0" />
                  <span className="truncate">{attachedFile.name}</span>
                  {attachedFile.size && (
                    <span className="text-[10px] text-sky-500 font-mono">({attachedFile.size})</span>
                  )}
                </span>
                <button
                  type="button"
                  onClick={() => setAttachedFile(null)}
                  className="text-sky-400 hover:text-sky-700 p-0.5 cursor-pointer"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>
            )}

            {/* Clean Input Area */}
            <div className="p-3 border-t border-slate-100 bg-white flex flex-col space-y-2">
              <form onSubmit={handleSend} className="flex items-center justify-between gap-2">
                <input
                  ref={inputRef}
                  type="text"
                  maxLength={240}
                  placeholder={
                    activeTab === 'direct'
                      ? 'Type private direct message...'
                      : 'Message... (type @ to mention)'
                  }
                  value={input}
                  onChange={handleInputChange}
                  className="flex-1 text-xs text-slate-800 placeholder:text-slate-400 bg-transparent border-none focus:outline-none py-1 px-1 font-normal"
                />
                <button
                  type="submit"
                  disabled={!input.trim() && !attachedFile}
                  className={`w-8 h-8 rounded-full text-white flex items-center justify-center transition-all shadow-xs cursor-pointer shrink-0 active:scale-95 disabled:bg-slate-200 ${
                    activeTab === 'direct'
                      ? 'bg-emerald-600 hover:bg-emerald-700'
                      : 'bg-[#0c8ce9] hover:bg-[#007be5]'
                  }`}
                  title="Send Message"
                >
                  <Send className="w-3.5 h-3.5 ml-0.5 fill-current" />
                </button>
              </form>

              {/* Bottom Control Bar */}
              <div className="flex items-center justify-between pt-1 border-t border-slate-50 text-slate-400">
                <div className="flex items-center space-x-1">
                  <button
                    type="button"
                    onClick={() => setShowEmojiPicker(!showEmojiPicker)}
                    className={`p-1.5 rounded-lg text-xs font-medium flex items-center space-x-1 transition-colors cursor-pointer ${
                      showEmojiPicker ? 'text-amber-500 bg-amber-50' : 'hover:text-slate-700 hover:bg-slate-100'
                    }`}
                    title="Add Emoji"
                  >
                    <Smile className="w-4 h-4" />
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setInput((prev) => (prev ? prev + ' @' : '@'));
                      setShowMentionAutocomplete(true);
                      inputRef.current?.focus();
                    }}
                    className="p-1.5 rounded-lg text-xs font-medium hover:text-slate-700 hover:bg-slate-100 transition-colors cursor-pointer"
                    title="Mention a colleague"
                  >
                    <AtSign className="w-4 h-4 text-sky-500" />
                  </button>

                  <button
                    type="button"
                    onClick={triggerFileUpload}
                    className="px-2 py-1 rounded-lg text-xs font-semibold text-sky-600 bg-sky-50 hover:bg-sky-100 flex items-center space-x-1 transition-colors cursor-pointer"
                    title="Upload Local File or Document"
                  >
                    <Upload className="w-3.5 h-3.5 text-sky-600" />
                    <span className="hidden sm:inline">Upload</span>
                  </button>
                </div>

                {activeTab === 'chat' && (
                  <button
                    type="button"
                    onClick={() => setIsProximity(!isProximity)}
                    className={`flex items-center space-x-1 px-2 py-0.5 rounded-full text-[10px] font-semibold transition-all border ${
                      isProximity
                        ? 'bg-emerald-50 border-emerald-200 text-emerald-700'
                        : 'bg-sky-50 border-sky-200 text-sky-700'
                    }`}
                    title="Toggle broadcast range"
                  >
                    <Radio className="w-3 h-3" />
                    <span>{isProximity ? 'Near Me' : 'All Floors'}</span>
                  </button>
                )}
              </div>
            </div>
          </div>
        )}

        {/* Online Colleagues Directory Tab */}
        {activeTab === 'users' && (
          <div className="flex-1 p-3 overflow-y-auto space-y-2 bg-[#fdfdfd]">
            <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider px-1 pb-1">
              Active Colleagues ({users.length})
            </div>
            {users.map((u) => {
              const isMe = u.id === currentUserId;
              return (
                <div
                  key={u.id}
                  className="flex items-center justify-between p-2.5 bg-white border border-slate-100 rounded-xl text-xs shadow-xs hover:border-slate-200 transition-colors"
                >
                  <div className="flex items-center space-x-2.5">
                    <div
                      className="w-3.5 h-3.5 rounded-full border border-slate-200"
                      style={{ backgroundColor: u.color || '#3b82f6' }}
                    />
                    <div>
                      <p className="font-bold text-slate-800">
                        {u.name} {isMe && '(You)'}
                      </p>
                      <p className="text-[10px] text-slate-400">
                        {u.department || 'Colleague'} • {u.statusText || 'Online'}
                      </p>
                    </div>
                  </div>

                  {!isMe && (
                    <div className="flex items-center space-x-1">
                      <button
                        onClick={() => {
                          setSelectedDmUserId(u.id);
                          setActiveTab('direct');
                        }}
                        className="px-2 py-1 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 rounded-lg text-[10px] font-bold flex items-center space-x-1 cursor-pointer transition-colors"
                        title={`Direct Message ${u.name}`}
                      >
                        <Lock className="w-3 h-3" />
                        <span>DM</span>
                      </button>

                      <button
                        onClick={() => {
                          setActiveTab('chat');
                          setInput((prev) => (prev ? `${prev} @${u.name} ` : `@${u.name} `));
                        }}
                        className="px-2 py-1 bg-sky-50 hover:bg-sky-100 text-sky-700 rounded-lg text-[10px] font-bold flex items-center space-x-1 cursor-pointer transition-colors"
                        title={`Mention @${u.name}`}
                      >
                        <AtSign className="w-3 h-3" />
                        <span>Mention</span>
                      </button>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
