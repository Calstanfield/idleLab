import React, { useState, useEffect } from 'react';
import {
  X,
  Trophy,
  Medal,
  Award,
  Search,
  Users,
  Sparkles,
  ChevronRight,
  BarChart3,
  TrendingUp,
  ShieldCheck,
  Zap,
  Activity,
  Flame,
  Check,
  Copy,
  ExternalLink,
  UserCheck,
  RefreshCw,
} from 'lucide-react';
import { UserState } from '../types';
import { soundEffects } from '../lib/soundEffects';

export interface LeaderboardUser {
  id: string;
  name: string;
  role: string;
  department: string;
  floor: '3F' | '2F' | '1F' | 'B1';
  performanceScore: number;
  tier: 'Gold' | 'Silver' | 'Bronze';
  isOnline: boolean;
  statusText: string;
  avatarColor: string;
  strengths: string[];
  growthAreas: string[];
  salaryEarned: number;
  isRealUser?: boolean;
}

interface SavedContactsModalProps {
  isOpen: boolean;
  onClose: () => void;
  onStartScreenShare?: () => void;
  isScreenSharing?: boolean;
  contacts?: any[];
  onUpdateContacts?: (contacts: any[]) => void;
  currentUser?: UserState | null;
  remoteUsers?: Map<string, UserState> | UserState[];
}

export const SavedContactsModal: React.FC<SavedContactsModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  remoteUsers,
}) => {
  // Stored base user performance scores & salary from local storage or defaults
  const [userScoreBoost, setUserScoreBoost] = useState<number>(() => {
    try {
      const saved = localStorage.getItem('idlelab_user_score_boost');
      return saved ? parseInt(saved, 10) : 0;
    } catch {
      return 0;
    }
  });

  const [searchQuery, setSearchQuery] = useState('');
  const [onlineOnlyFilter, setOnlineOnlyFilter] = useState(true);
  const [tierFilter, setTierFilter] = useState<'All' | 'Gold' | 'Silver' | 'Bronze'>('All');
  const [selectedUserStats, setSelectedUserStats] = useState<LeaderboardUser | null>(null);
  const [lastRefreshedAt, setLastRefreshedAt] = useState<number>(Date.now());

  // Listen for auto-refresh events from Idleboard portfolio ingestion
  useEffect(() => {
    const handlePortfolioIngested = (e: Event) => {
      const customEvent = e as CustomEvent;
      const boost = customEvent.detail?.scoreBoost || 6;
      setUserScoreBoost((prev) => {
        const updated = prev + boost;
        try {
          localStorage.setItem('idlelab_user_score_boost', updated.toString());
        } catch (err) {
          console.error(err);
        }
        return updated;
      });
      setLastRefreshedAt(Date.now());
      soundEffects.playLevelUp();
    };

    window.addEventListener('idleboard:portfolio_ingested', handlePortfolioIngested);
    return () => {
      window.removeEventListener('idleboard:portfolio_ingested', handlePortfolioIngested);
    };
  }, []);

  if (!isOpen) return null;

  // Determine current active floor for user
  const getUserFloor = (y?: number): '3F' | '2F' | '1F' | 'B1' => {
    if (y === undefined) return '1F';
    if (y >= 14) return '3F';
    if (y >= 8) return '2F';
    if (y >= 2) return '1F';
    return 'B1';
  };

  // Build the list of real online users strictly excluding standard office NPCs
  // The directory features real project members competing directly alongside Chloe Becker
  const rawLeaderboardUsers: LeaderboardUser[] = [];

  // 1. Chloe Becker (Executive AI Partner & Co-Manager)
  rawLeaderboardUsers.push({
    id: 'npc_b1_chloe',
    name: 'Chloe Becker',
    role: 'Executive Partner & AI Manager',
    department: 'Engineering Lead',
    floor: 'B1',
    performanceScore: 98,
    tier: 'Gold',
    isOnline: true,
    statusText: 'Auditing executive portfolios, sub-agents & rubric safety compliance',
    avatarColor: '#c89849',
    salaryEarned: 24000,
    isRealUser: true,
    strengths: [
      'Multi-Agent Orchestrator coordination across 5 executive pillars',
      'High-fidelity SSML voice synthesis with natural lively American inflection',
      'Instant document ingestion and keypoint extraction without markdown noise',
    ],
    growthAreas: [
      'Continue fine-tuning complex edge cases in legal disclaimer parsing',
      'Expand domain taxonomy for multi-region cloud cost estimation',
    ],
  });

  // 2. Current User (Real Participant)
  const currentUserName = currentUser?.name || 'You (Active Engineer)';
  const userBaseScore = 88 + userScoreBoost;
  const userCalculatedScore = Math.min(99, userBaseScore);
  const userTier: 'Gold' | 'Silver' | 'Bronze' =
    userCalculatedScore >= 90 ? 'Gold' : userCalculatedScore >= 80 ? 'Silver' : 'Bronze';

  rawLeaderboardUsers.push({
    id: currentUser?.id || 'current_user_local',
    name: currentUserName,
    role: 'Full-Stack Spatial Engineer',
    department: currentUser?.department || 'Engineering',
    floor: getUserFloor(currentUser?.position?.y),
    performanceScore: userCalculatedScore,
    tier: userTier,
    isOnline: true,
    statusText: `Active in Idleboard • ${userScoreBoost > 0 ? `${Math.floor(userScoreBoost / 6)} Portfolios Ingested` : 'Engaged in Project Architecture'}`,
    avatarColor: currentUser?.color || '#0284c7',
    salaryEarned: 15000 + userScoreBoost * 500,
    isRealUser: true,
    strengths: [
      'Active portfolio synthesis & rich document digest execution',
      'Seamless multi-floor spatial navigation and desk ownership',
      'Real-time Scrumboard architectural mindmapping and AI refinement',
    ],
    growthAreas: [
      'Submit additional milestone deliverables in Assessment portal',
      'Engage with Chloe in B1 for high-stakes executive sparring',
    ],
  });

  // 3. Real Connected Remote Peers (if any other human user is connected over WebSocket)
  if (remoteUsers) {
    const remoteList = Array.isArray(remoteUsers) ? remoteUsers : Array.from(remoteUsers.values());
    remoteList.forEach((ru) => {
      // Exclude Chloe (already handled as top partner) and any static NPC strings
      if (
        ru.id !== currentUser?.id &&
        ru.id !== 'npc_b1_chloe' &&
        !ru.id.startsWith('npc_') &&
        ru.name !== 'Wasabi Dragon' &&
        ru.name !== 'kitty' &&
        ru.name !== 'Philemon Cheung' &&
        ru.name !== 'Californian Roll' &&
        ru.name !== 'Fortune Cookie' &&
        ru.name !== 'Lofi Girl'
      ) {
        const score = 84 + (ru.name.length % 10);
        rawLeaderboardUsers.push({
          id: ru.id,
          name: ru.name,
          role: 'Connected Spatial Collaborator',
          department: ru.department || 'Product Eng',
          floor: getUserFloor(ru.position?.y),
          performanceScore: score,
          tier: score >= 90 ? 'Gold' : score >= 80 ? 'Silver' : 'Bronze',
          isOnline: true,
          statusText: ru.statusText || 'Collaborating in live office session',
          avatarColor: ru.color || '#10b981',
          salaryEarned: 12000,
          isRealUser: true,
          strengths: [
            'Live 3D avatar synchronization and peer interaction',
            'Collaborative whiteboard participation and desk alignment',
          ],
          growthAreas: [
            'Explore multi-agent research tools on Floor B1',
          ],
        });
      }
    });
  }

  // Sort descending by score
  const sortedUsers = [...rawLeaderboardUsers].sort((a, b) => b.performanceScore - a.performanceScore);

  const filteredUsers = sortedUsers.filter((u) => {
    const matchesOnline = onlineOnlyFilter ? u.isOnline : true;
    const matchesTier = tierFilter === 'All' || u.tier === tierFilter;
    const matchesSearch =
      u.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      u.role.toLowerCase().includes(searchQuery.toLowerCase()) ||
      u.department.toLowerCase().includes(searchQuery.toLowerCase()) ||
      u.floor.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesOnline && matchesTier && matchesSearch;
  });

  return (
    <div className="fixed inset-0 z-50 flex flex-col bg-[#0d0f17] text-neutral-200 font-sans select-none animate-in fade-in duration-150">
      {/* Top Header */}
      <div className="h-16 px-6 border-b border-white/10 bg-[#12141e] flex items-center justify-between shrink-0 shadow-lg">
        <div className="flex items-center space-x-4">
          <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-amber-500 via-yellow-500 to-amber-600 flex items-center justify-center text-black shadow-lg shadow-amber-500/20 font-black">
            <Trophy className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <span className="font-black text-base text-white tracking-tight">Leaderboard</span>
              <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                Online Members Only
              </span>
            </div>
            <p className="text-xs text-neutral-400">
              Auto-Refreshed Live Ranks, Metallic Tiers & Double-Click Analytical Dossiers
            </p>
          </div>
        </div>

        <div className="flex items-center space-x-3">
          <button
            onClick={onClose}
            className="p-2.5 rounded-2xl bg-white/5 hover:bg-rose-500/20 border border-white/10 hover:border-rose-500/40 text-neutral-400 hover:text-rose-300 transition-all cursor-pointer"
            title="Close Leaderboard"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Main Full-Screen Layout */}
      <div className="flex-1 overflow-hidden flex flex-col md:flex-row bg-[#0d0f17]">
        {/* Left Sidebar: Ranks Summary, Tier Guide & Filter Controls */}
        <div className="w-full md:w-80 border-r border-white/10 bg-[#11131c] p-6 flex flex-col space-y-6 overflow-y-auto shrink-0">
          {/* Double Tap Instruction Alert */}
          <div className="p-4 rounded-3xl bg-gradient-to-br from-sky-500/15 to-transparent border border-sky-500/30 space-y-2">
            <div className="flex items-center space-x-2 text-sky-300 text-xs font-bold uppercase tracking-wider">
              <Zap className="w-4 h-4 text-sky-400" />
              <span>Double-Click Dossier</span>
            </div>
            <p className="text-xs text-neutral-300 leading-relaxed">
              <strong className="text-white">Double-click</strong> any colleague card to view their analytical performance dossier (Strengths & Areas for Improvement).
            </p>
          </div>

          {/* Real-time Ingest Refresh Badge */}
          <div className="p-3.5 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-200 text-xs space-y-1">
            <div className="flex items-center space-x-1.5 font-bold">
              <TrendingUp className="w-3.5 h-3.5 text-emerald-400" />
              <span>Live Ingest Auto-Refresh:</span>
            </div>
            <p className="text-[11px] text-neutral-400 leading-relaxed">
              Leaderboard scores update dynamically whenever a new portfolio or spec is digested in Idleboard (+6 pts).
            </p>
          </div>

          {/* Tier Legend with Metallic Border Previews */}
          <div className="space-y-2.5">
            <div className="text-xs font-bold text-neutral-400 uppercase tracking-wider">Performance Tiers</div>

            <div className="p-3 rounded-2xl border-2 border-amber-400 bg-gradient-to-r from-amber-500/20 to-yellow-500/10 shadow-[0_0_15px_rgba(251,191,36,0.25)] flex items-center justify-between">
              <div className="flex items-center space-x-2.5">
                <span className="text-base">👑</span>
                <div>
                  <div className="text-xs font-black text-amber-300">Tier 1: GOLD</div>
                  <div className="text-[10px] text-amber-200/70">Top Score (&gt;= 90%)</div>
                </div>
              </div>
              <span className="text-xs font-mono font-bold text-amber-300">Gold</span>
            </div>

            <div className="p-3 rounded-2xl border-2 border-slate-300 bg-gradient-to-r from-slate-400/20 to-slate-200/10 shadow-[0_0_15px_rgba(203,213,225,0.2)] flex items-center justify-between">
              <div className="flex items-center space-x-2.5">
                <span className="text-base">🥈</span>
                <div>
                  <div className="text-xs font-black text-slate-200">Tier 2: SILVER</div>
                  <div className="text-[10px] text-slate-300/70">Score (80 - 89%)</div>
                </div>
              </div>
              <span className="text-xs font-mono font-bold text-slate-300">Silver</span>
            </div>

            <div className="p-3 rounded-2xl border-2 border-amber-700 bg-gradient-to-r from-amber-800/20 to-amber-900/10 shadow-[0_0_10px_rgba(180,83,9,0.15)] flex items-center justify-between">
              <div className="flex items-center space-x-2.5">
                <span className="text-base">🥉</span>
                <div>
                  <div className="text-xs font-black text-amber-500">Tier 3: BRONZE</div>
                  <div className="text-[10px] text-amber-400/70">Standard Active (70 - 79%)</div>
                </div>
              </div>
              <span className="text-xs font-mono font-bold text-amber-500">Bronze</span>
            </div>
          </div>

          {/* Member Filtering Rule */}
          <div className="p-3 rounded-2xl bg-white/5 border border-white/10 text-[11px] text-neutral-400 space-y-1">
            <div className="font-bold text-neutral-200 flex items-center space-x-1.5">
              <UserCheck className="w-3.5 h-3.5 text-sky-400" />
              <span>Strict Member Filter Active</span>
            </div>
            <p>
              Office NPCs are filtered out. Only verified online project members and Chloe Becker compete on the active leaderboard.
            </p>
          </div>
        </div>

        {/* Right Main Panel: Leaderboard Cards */}
        <div className="flex-1 p-6 md:p-8 overflow-y-auto flex flex-col space-y-4 bg-[#0a0c12]">
          {/* Search & Tier Filters */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-white/10">
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-neutral-500 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search colleague, role, or floor..."
                className="pl-8 pr-3 py-2 rounded-xl bg-white/5 border border-white/10 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-yellow-400 w-72"
              />
            </div>

            <div className="flex items-center space-x-1.5 text-xs">
              {(['All', 'Gold', 'Silver', 'Bronze'] as const).map((t) => (
                <button
                  key={t}
                  onClick={() => setTierFilter(t)}
                  className={`px-3 py-1.5 rounded-xl font-bold transition-all cursor-pointer ${
                    tierFilter === t
                      ? 'bg-yellow-500 text-black shadow-md shadow-yellow-500/20'
                      : 'bg-white/5 text-neutral-400 hover:text-white hover:bg-white/10'
                  }`}
                >
                  {t} Tiers
                </button>
              ))}
            </div>
          </div>

          {/* User Cards Grid with Dynamic Metallic Borders */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {filteredUsers.map((user, idx) => {
              // Dynamic metallic border based on Tier
              const isGold = user.tier === 'Gold';
              const isSilver = user.tier === 'Silver';
              const isBronze = user.tier === 'Bronze';

              const cardBorderClass = isGold
                ? 'border-2 border-amber-400 bg-gradient-to-br from-amber-500/20 via-yellow-500/10 to-[#121520] shadow-[0_0_20px_rgba(251,191,36,0.35)] text-amber-200'
                : isSilver
                ? 'border-2 border-slate-300 bg-gradient-to-br from-slate-400/20 via-slate-200/10 to-[#121520] shadow-[0_0_15px_rgba(203,213,225,0.3)] text-slate-100'
                : 'border-2 border-amber-700 bg-gradient-to-br from-amber-800/20 via-amber-900/10 to-[#121520] shadow-[0_0_10px_rgba(180,83,9,0.25)] text-amber-400';

              return (
                <div
                  key={user.id}
                  onDoubleClick={() => {
                    setSelectedUserStats(user);
                    soundEffects.playPop();
                  }}
                  className={`p-5 rounded-3xl ${cardBorderClass} transition-all duration-200 hover:scale-[1.01] flex flex-col justify-between space-y-4 cursor-pointer select-none`}
                  title="Double-click to expand comprehensive Strengths & Areas for Improvement Report"
                >
                  {/* Top: Rank, Name, Role & Floor Badge */}
                  <div className="flex items-start justify-between">
                    <div className="flex items-center space-x-3">
                      <div className="relative">
                        <div
                          className="w-12 h-12 rounded-2xl flex items-center justify-center font-black text-sm text-white shadow-md border border-white/20"
                          style={{ backgroundColor: user.avatarColor }}
                        >
                          {user.name.slice(0, 2).toUpperCase()}
                        </div>
                        <div className="absolute -bottom-1 -right-1 w-4 h-4 rounded-full bg-emerald-500 border-2 border-[#121520] flex items-center justify-center">
                          <div className="w-1.5 h-1.5 rounded-full bg-white animate-ping" />
                        </div>
                      </div>

                      <div>
                        <div className="flex items-center space-x-2">
                          <h4 className="font-bold text-sm text-white tracking-tight">{user.name}</h4>
                          <span
                            className={`text-[10px] font-black uppercase px-2 py-0.5 rounded-full border ${
                              isGold
                                ? 'bg-amber-400/20 text-amber-300 border-amber-400/50'
                                : isSilver
                                ? 'bg-slate-300/20 text-slate-200 border-slate-300/50'
                                : 'bg-amber-700/20 text-amber-400 border-amber-700/50'
                            }`}
                          >
                            {isGold ? '🥇 Gold' : isSilver ? '🥈 Silver' : '🥉 Bronze'}
                          </span>
                        </div>
                        <p className="text-xs text-neutral-400">{user.role}</p>
                      </div>
                    </div>

                    <div className="text-right flex flex-col items-end space-y-1">
                      <span className="text-xs font-black font-mono px-2.5 py-1 rounded-xl bg-white/10 text-white">
                        {user.floor}
                      </span>
                      <span className="text-[10px] font-bold text-neutral-400">Rank #{idx + 1}</span>
                    </div>
                  </div>

                  {/* Status Quote */}
                  <p className="text-xs text-neutral-300 italic line-clamp-2">"{user.statusText}"</p>

                  {/* Bottom Stats: Performance Score & Earned Salary */}
                  <div className="flex items-center justify-between pt-3 border-t border-white/10 text-xs">
                    <div className="flex items-center space-x-1.5">
                      <BarChart3 className="w-3.5 h-3.5 text-sky-400" />
                      <span className="text-neutral-400 text-[11px]">Score:</span>
                      <strong className="text-white font-mono">{user.performanceScore}%</strong>
                    </div>

                    <div className="flex items-center space-x-1.5">
                      <span className="text-neutral-400 text-[11px]">Salary Earned:</span>
                      <strong className="text-emerald-400 font-mono">${user.salaryEarned.toLocaleString()}</strong>
                    </div>

                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        setSelectedUserStats(user);
                        soundEffects.playPop();
                      }}
                      className="text-[11px] font-bold text-sky-300 hover:text-sky-200 flex items-center space-x-1 cursor-pointer"
                    >
                      <span>Dossier</span>
                      <ChevronRight className="w-3 h-3" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* DOUBLE-TAP ANALYTICAL STATS REPORT MODAL */}
      {selectedUserStats && (
        <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-black/85 backdrop-blur-xl animate-in zoom-in-95 duration-200">
          <div className="relative w-full max-w-xl bg-[#121522] border-2 border-white/20 rounded-3xl shadow-[0_20px_80px_rgba(0,0,0,0.9)] p-6 space-y-6 text-white overflow-y-auto max-h-[90vh]">
            {/* Top Bar */}
            <div className="flex items-center justify-between border-b border-white/10 pb-4">
              <div className="flex items-center space-x-3">
                <div
                  className="w-12 h-12 rounded-2xl flex items-center justify-center font-black text-sm text-white shadow-md"
                  style={{ backgroundColor: selectedUserStats.avatarColor }}
                >
                  {selectedUserStats.name.slice(0, 2).toUpperCase()}
                </div>
                <div>
                  <div className="flex items-center space-x-2">
                    <h3 className="text-base font-black tracking-tight">{selectedUserStats.name}</h3>
                    <span
                      className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded-full border ${
                        selectedUserStats.tier === 'Gold'
                          ? 'bg-amber-400/20 text-amber-300 border-amber-400/50'
                          : selectedUserStats.tier === 'Silver'
                          ? 'bg-slate-300/20 text-slate-200 border-slate-300/50'
                          : 'bg-amber-700/20 text-amber-400 border-amber-700/50'
                      }`}
                    >
                      {selectedUserStats.tier} Tier
                    </span>
                  </div>
                  <p className="text-xs text-neutral-400">
                    {selectedUserStats.role} • {selectedUserStats.department} • Floor {selectedUserStats.floor}
                  </p>
                </div>
              </div>

              <button
                onClick={() => setSelectedUserStats(null)}
                className="p-2 rounded-xl bg-white/5 hover:bg-rose-500/20 text-neutral-400 hover:text-rose-300 transition-all cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Score & Metrics Banner */}
            <div className="grid grid-cols-3 gap-3">
              <div className="p-3 rounded-2xl bg-white/5 border border-white/10 text-center">
                <span className="text-[10px] uppercase font-bold text-neutral-400 block">Performance</span>
                <span className="text-lg font-black text-amber-400 font-mono">
                  {selectedUserStats.performanceScore}%
                </span>
              </div>
              <div className="p-3 rounded-2xl bg-white/5 border border-white/10 text-center">
                <span className="text-[10px] uppercase font-bold text-neutral-400 block">Salary Earned</span>
                <span className="text-lg font-black text-emerald-400 font-mono">
                  ${selectedUserStats.salaryEarned.toLocaleString()}
                </span>
              </div>
              <div className="p-3 rounded-2xl bg-white/5 border border-white/10 text-center">
                <span className="text-[10px] uppercase font-bold text-neutral-400 block">Status</span>
                <span className="text-xs font-bold text-emerald-300 mt-1 block">Active Online</span>
              </div>
            </div>

            {/* Strengths Section */}
            <div className="space-y-2">
              <h4 className="text-xs font-bold text-emerald-400 uppercase tracking-wider flex items-center space-x-1.5">
                <ShieldCheck className="w-4 h-4" />
                <span>Identified Strengths & Core Competencies</span>
              </h4>
              <div className="space-y-1.5">
                {selectedUserStats.strengths.map((s, idx) => (
                  <div key={`strength-${idx}-${s.slice(0, 10)}`} className="p-3 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 text-xs text-emerald-100 flex items-start space-x-2">
                    <Check className="w-3.5 h-3.5 text-emerald-400 mt-0.5 shrink-0" />
                    <span>{s}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Growth Areas Section */}
            <div className="space-y-2">
              <h4 className="text-xs font-bold text-sky-400 uppercase tracking-wider flex items-center space-x-1.5">
                <TrendingUp className="w-4 h-4" />
                <span>Areas for Performance Acceleration</span>
              </h4>
              <div className="space-y-1.5">
                {selectedUserStats.growthAreas.map((g, idx) => (
                  <div key={`growth-${idx}-${g.slice(0, 10)}`} className="p-3 rounded-2xl bg-sky-500/10 border border-sky-500/20 text-xs text-sky-100 flex items-start space-x-2">
                    <Sparkles className="w-3.5 h-3.5 text-sky-400 mt-0.5 shrink-0" />
                    <span>{g}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
