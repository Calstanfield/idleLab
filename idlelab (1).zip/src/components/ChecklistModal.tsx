import React, { useState, useRef } from 'react';
import { soundEffects } from '../lib/soundEffects';
import {
  X,
  Plus,
  Trash2,
  CheckCircle2,
  Clock,
  Send,
  Sparkles,
  Award,
  DollarSign,
  AlertCircle,
  FileCheck,
  Check,
  Search,
  Filter,
  BarChart3,
  PartyPopper,
  ShieldCheck,
  Link,
  UploadCloud,
  FileText,
  Bot,
  ExternalLink,
} from 'lucide-react';
import { SubmissionPayload } from './B1ChloeGradingModal';

export interface AssessmentItem {
  id: string;
  title: string;
  assignee: string;
  priority: 'High' | 'Med' | 'Low';
  status: 'Pending' | 'Submitted' | 'Passed';
  dueDate: string; // Date of Submission
  notes?: string;
  submissionLink?: string;
}

interface ChecklistModalProps {
  isOpen: boolean;
  onClose: () => void;
  userName?: string;
  items?: any[];
  onUpdateItems?: (items: any[]) => void;
  onRequestB1Review?: (submission: SubmissionPayload) => void;
}

export const ChecklistModal: React.FC<ChecklistModalProps> = ({
  isOpen,
  onClose,
  userName = 'You',
  items: propsItems,
  onUpdateItems,
  onRequestB1Review,
}) => {
  // Pure User Data State: starts clean, populated dynamically by user or Idleboard sync
  const [assessmentItems, setAssessmentItems] = useState<AssessmentItem[]>(() => {
    try {
      const saved = localStorage.getItem('idlelab_assessment_items');
      if (saved) return JSON.parse(saved);
    } catch (e) {}
    return [];
  });

  const [newTitle, setNewTitle] = useState('');
  const [newPriority, setNewPriority] = useState<'High' | 'Med' | 'Low'>('High');
  const [newDueDate, setNewDueDate] = useState(() => new Date().toISOString().split('T')[0]);
  const [newNotes, setNewNotes] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [filterStatus, setFilterStatus] = useState<'All' | 'Pending' | 'Submitted' | 'Passed'>('All');

  // Submission tab state (URL Link vs File Upload)
  const [submissionType, setSubmissionType] = useState<'url' | 'file'>('url');
  const [submissionUrl, setSubmissionUrl] = useState('');
  const [uploadedFileName, setUploadedFileName] = useState('');
  const [uploadedFileSize, setUploadedFileSize] = useState('');
  const [submissionNotes, setSubmissionNotes] = useState('');
  const [isDraggingFile, setIsDraggingFile] = useState(false);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  // Claimed Salary Total
  const [claimedSalaryTotal, setClaimedSalaryTotal] = useState<number>(() => {
    try {
      const saved = localStorage.getItem('idlelab_user_salary');
      if (saved) return parseInt(saved, 10);
    } catch (e) {}
    return 0;
  });

  if (!isOpen) return null;

  const updateItems = (next: AssessmentItem[]) => {
    setAssessmentItems(next);
    if (onUpdateItems) {
      onUpdateItems(next as any);
    }
    try {
      localStorage.setItem('idlelab_assessment_items', JSON.stringify(next));
    } catch (e) {}
  };

  const handleAddItem = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;

    soundEffects.playPop(120);
    const newItem: AssessmentItem = {
      id: `as-${Date.now()}`,
      title: newTitle.trim(),
      assignee: userName || 'Lead Engineer',
      priority: newPriority,
      status: 'Pending',
      dueDate: newDueDate,
      notes: newNotes.trim() || 'Custom deliverable requirement',
    };

    updateItems([...assessmentItems, newItem]);
    setNewTitle('');
    setNewNotes('');
  };

  const handleDeleteItem = (id: string) => {
    soundEffects.playPop();
    updateItems(assessmentItems.filter((it) => it.id !== id));
  };

  const handleStatusChange = (id: string, status: 'Pending' | 'Submitted' | 'Passed') => {
    soundEffects.playPop();
    updateItems(assessmentItems.map((it) => (it.id === id ? { ...it, status } : it)));
  };

  const handleFileUpload = (file: File) => {
    setUploadedFileName(file.name);
    const sizeInKb = (file.size / 1024).toFixed(1);
    setUploadedFileSize(`${sizeInKb} KB`);
    soundEffects.playPop();
  };

  const handleFileDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDraggingFile(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFileUpload(e.dataTransfer.files[0]);
    }
  };

  // Trigger B1 Live Office Presentation & Review
  const handleSubmitToChloeB1 = () => {
    const payload: SubmissionPayload = {
      title:
        assessmentItems.find((i) => i.status === 'Pending' || i.status === 'Submitted')?.title ||
        (submissionType === 'url' ? submissionUrl : uploadedFileName) ||
        'Project Deliverable Submission',
      sourceType: submissionType,
      sourceValue: submissionType === 'url' ? submissionUrl || 'https://github.com/idlelab/project-build' : uploadedFileName || 'Submission_Audit_Document.pdf',
      fileName: uploadedFileName || (submissionType === 'file' ? 'Deliverable_Spec.pdf' : undefined),
      fileSize: uploadedFileSize || (submissionType === 'file' ? '320 KB' : undefined),
      notes: submissionNotes || 'Submitted for Chloe B1 executive evaluation.',
    };

    soundEffects.playPop();
    if (onRequestB1Review) {
      onRequestB1Review(payload);
    }
  };

  const filteredItems = assessmentItems.filter((item) => {
    const matchesFilter = filterStatus === 'All' || item.status === filterStatus;
    const matchesSearch =
      item.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.assignee.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (item.notes && item.notes.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchesFilter && matchesSearch;
  });

  const passedCount = assessmentItems.filter((i) => i.status === 'Passed').length;
  const submittedCount = assessmentItems.filter((i) => i.status === 'Submitted').length;
  const pendingCount = assessmentItems.filter((i) => i.status === 'Pending').length;

  return (
    <div className="fixed inset-0 z-50 flex flex-col bg-[#0d0f17] text-neutral-200 font-sans select-none animate-in fade-in duration-150">
      {/* Top Header */}
      <div className="h-16 px-6 border-b border-white/10 bg-[#12141e] flex items-center justify-between shrink-0 shadow-lg">
        <div className="flex items-center space-x-4">
          <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-emerald-500 via-teal-500 to-cyan-500 flex items-center justify-center text-white shadow-lg shadow-emerald-500/20 font-black">
            <ShieldCheck className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <span className="font-black text-base text-white tracking-tight">Assessment Portal</span>
              <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                Live B1 Chloe Grading
              </span>
            </div>
            <p className="text-xs text-neutral-400">Employer Deliverables Tracking & $3,000 Roleplay Salary Engine</p>
          </div>
        </div>

        {/* User Balance Banner & Close Button */}
        <div className="flex items-center space-x-4">
          <div className="px-3.5 py-1.5 rounded-2xl bg-amber-500/15 border border-amber-400/40 text-amber-300 flex items-center space-x-2 shadow-sm">
            <DollarSign className="w-4 h-4 text-amber-400" />
            <div className="text-xs">
              <span className="text-[10px] text-amber-200/70 block uppercase font-bold">Earned Balance</span>
              <span className="font-black text-sm text-amber-300 font-mono">${claimedSalaryTotal.toLocaleString()}</span>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2.5 rounded-2xl bg-white/5 hover:bg-rose-500/20 border border-white/10 hover:border-rose-500/40 text-neutral-400 hover:text-rose-300 transition-all cursor-pointer"
            title="Close Assessment"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Main Full-Screen Layout */}
      <div className="flex-1 overflow-hidden flex flex-col md:flex-row bg-[#0d0f17]">
        {/* Left Sidebar: Submission Portal & Form */}
        <div className="w-full md:w-96 border-r border-white/10 bg-[#11131c] p-6 flex flex-col space-y-5 overflow-y-auto shrink-0">
          {/* Submission Action Box */}
          <div className="p-4 rounded-3xl bg-gradient-to-br from-emerald-500/15 via-teal-500/10 to-transparent border border-emerald-500/30 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-emerald-300 uppercase tracking-wider flex items-center space-x-1.5">
                <Bot className="w-4 h-4 text-emerald-400" />
                <span>Submit Work for Grading</span>
              </span>
              <span className="text-[10px] bg-emerald-500/20 text-emerald-300 px-2 py-0.5 rounded-full font-bold">
                $3,000 Reward
              </span>
            </div>

            <p className="text-xs text-neutral-300 leading-relaxed">
              Submit via URL or upload PDF/spec. Submitting transitions your camera to Chloe's B1 office desk for live spoken grading.
            </p>

            {/* Submission Mode Selector: URL vs File */}
            <div className="grid grid-cols-2 gap-1.5 p-1 bg-white/5 rounded-xl border border-white/10">
              <button
                type="button"
                onClick={() => setSubmissionType('url')}
                className={`py-1.5 rounded-lg text-xs font-bold transition-all flex items-center justify-center space-x-1.5 cursor-pointer ${
                  submissionType === 'url' ? 'bg-emerald-500 text-black shadow-sm' : 'text-neutral-400 hover:text-white'
                }`}
              >
                <Link className="w-3.5 h-3.5" />
                <span>URL Link</span>
              </button>

              <button
                type="button"
                onClick={() => setSubmissionType('file')}
                className={`py-1.5 rounded-lg text-xs font-bold transition-all flex items-center justify-center space-x-1.5 cursor-pointer ${
                  submissionType === 'file' ? 'bg-emerald-500 text-black shadow-sm' : 'text-neutral-400 hover:text-white'
                }`}
              >
                <UploadCloud className="w-3.5 h-3.5" />
                <span>File / PDF</span>
              </button>
            </div>

            {/* URL Input or File Dropzone */}
            {submissionType === 'url' ? (
              <div className="space-y-1">
                <label className="text-[10px] font-bold text-neutral-400 uppercase">Deliverable Web / PR Link</label>
                <input
                  type="url"
                  value={submissionUrl}
                  onChange={(e) => setSubmissionUrl(e.target.value)}
                  placeholder="https://github.com/... or Figma link"
                  className="w-full px-3 py-2 rounded-xl bg-white/5 border border-white/15 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-emerald-400"
                />
              </div>
            ) : (
              <div className="space-y-1">
                <label className="text-[10px] font-bold text-neutral-400 uppercase">Upload PDF / Document</label>
                <div
                  onDragOver={(e) => {
                    e.preventDefault();
                    setIsDraggingFile(true);
                  }}
                  onDragLeave={() => setIsDraggingFile(false)}
                  onDrop={handleFileDrop}
                  onClick={() => fileInputRef.current?.click()}
                  className={`p-3 rounded-2xl border-2 border-dashed text-center transition-all cursor-pointer flex flex-col items-center justify-center space-y-1.5 ${
                    isDraggingFile
                      ? 'border-emerald-400 bg-emerald-500/20 text-emerald-200'
                      : uploadedFileName
                      ? 'border-emerald-500/50 bg-emerald-500/10 text-emerald-300'
                      : 'border-white/20 hover:border-white/40 bg-white/5 text-neutral-400'
                  }`}
                >
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept=".pdf,.doc,.docx,.txt,.json,.md"
                    className="hidden"
                    onChange={(e) => {
                      if (e.target.files && e.target.files[0]) {
                        handleFileUpload(e.target.files[0]);
                      }
                    }}
                  />
                  <FileText className="w-5 h-5 text-emerald-400" />
                  <span className="text-xs font-bold text-neutral-200">
                    {uploadedFileName ? uploadedFileName : 'Click or drag PDF/Doc here'}
                  </span>
                  {uploadedFileSize && (
                    <span className="text-[10px] text-emerald-400 font-mono">{uploadedFileSize}</span>
                  )}
                </div>
              </div>
            )}

            <button
              onClick={handleSubmitToChloeB1}
              className="w-full py-3 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-black font-black text-xs transition-all shadow-lg shadow-emerald-500/20 flex items-center justify-center space-x-2 cursor-pointer"
            >
              <Send className="w-4 h-4 text-black" />
              <span>Submit & Teleport to B1 Chloe</span>
            </button>
          </div>

          {/* Quick Metrics */}
          <div className="grid grid-cols-3 gap-2 text-center">
            <div className="p-3 rounded-2xl bg-emerald-500/10 border border-emerald-500/20">
              <div className="text-base font-black text-emerald-400 font-mono">{passedCount}</div>
              <div className="text-[10px] text-emerald-300/80 font-bold uppercase">Passed</div>
            </div>
            <div className="p-3 rounded-2xl bg-sky-500/10 border border-sky-500/20">
              <div className="text-base font-black text-sky-400 font-mono">{submittedCount}</div>
              <div className="text-[10px] text-sky-300/80 font-bold uppercase">Submitted</div>
            </div>
            <div className="p-3 rounded-2xl bg-amber-500/10 border border-amber-500/20">
              <div className="text-base font-black text-amber-400 font-mono">{pendingCount}</div>
              <div className="text-[10px] text-amber-300/80 font-bold uppercase">Pending</div>
            </div>
          </div>

          {/* Add New Requirement Task Form */}
          <form onSubmit={handleAddItem} className="space-y-3 pt-2 border-t border-white/10">
            <div className="text-xs font-bold text-white uppercase tracking-wider flex items-center space-x-1.5">
              <Plus className="w-3.5 h-3.5 text-emerald-400" />
              <span>Add Deliverable / Requirement</span>
            </div>

            <div className="space-y-1">
              <label className="text-[11px] text-neutral-400">Requirement Title</label>
              <input
                type="text"
                value={newTitle}
                onChange={(e) => setNewTitle(e.target.value)}
                placeholder="e.g. Implement API authentication spec"
                className="w-full px-3 py-2 rounded-xl bg-white/5 border border-white/15 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-emerald-400"
              />
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div className="space-y-1">
                <label className="text-[11px] text-neutral-400">Priority</label>
                <select
                  value={newPriority}
                  onChange={(e) => setNewPriority(e.target.value as any)}
                  className="w-full px-3 py-2 rounded-xl bg-[#1a1d29] border border-white/15 text-xs text-white focus:outline-none focus:border-emerald-400"
                >
                  <option value="High">High Priority</option>
                  <option value="Med">Medium</option>
                  <option value="Low">Low</option>
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-[11px] text-neutral-400">Date of Submission</label>
                <input
                  type="date"
                  value={newDueDate}
                  onChange={(e) => setNewDueDate(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-[#1a1d29] border border-white/15 text-xs text-white focus:outline-none focus:border-emerald-400"
                />
              </div>
            </div>

            <div className="space-y-1">
              <label className="text-[11px] text-neutral-400">Notes / Criteria</label>
              <input
                type="text"
                value={newNotes}
                onChange={(e) => setNewNotes(e.target.value)}
                placeholder="Optional criteria or instructions"
                className="w-full px-3 py-2 rounded-xl bg-white/5 border border-white/15 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-emerald-400"
              />
            </div>

            <button
              type="submit"
              disabled={!newTitle.trim()}
              className="w-full py-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-white font-bold text-xs transition-colors cursor-pointer disabled:opacity-40"
            >
              Add to Assessment
            </button>
          </form>
        </div>

        {/* Right Table / Grid View: Active Requirements */}
        <div className="flex-1 p-6 md:p-8 overflow-y-auto flex flex-col space-y-4 bg-[#0a0c12]">
          {/* Filter & Search Ribbon */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-white/10">
            <div className="flex items-center space-x-2">
              <div className="relative">
                <Search className="w-3.5 h-3.5 text-neutral-500 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search requirements or assignee..."
                  className="pl-8 pr-3 py-1.5 rounded-xl bg-white/5 border border-white/10 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-emerald-400 w-64"
                />
              </div>
            </div>

            <div className="flex items-center space-x-1.5 text-xs">
              {(['All', 'Pending', 'Submitted', 'Passed'] as const).map((st) => (
                <button
                  key={st}
                  onClick={() => setFilterStatus(st)}
                  className={`px-3 py-1 rounded-xl font-bold transition-all cursor-pointer ${
                    filterStatus === st
                      ? 'bg-emerald-500 text-black shadow-sm'
                      : 'bg-white/5 text-neutral-400 hover:text-white hover:bg-white/10'
                  }`}
                >
                  {st}
                </button>
              ))}
            </div>
          </div>

          {/* Assessment Items List or Clean Empty State */}
          {filteredItems.length === 0 ? (
            <div className="flex-1 flex flex-col items-center justify-center p-12 text-center space-y-3 bg-white/5 rounded-3xl border border-white/10">
              <div className="w-14 h-14 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400">
                <FileCheck className="w-7 h-7" />
              </div>
              <div className="space-y-1">
                <h4 className="text-base font-bold text-white">Assessment Tracker is Ready</h4>
                <p className="text-xs text-neutral-400 max-w-md">
                  No deliverables recorded yet. Use the left form to add your first milestone, or ingest a document in Idleboard to extract requirements automatically.
                </p>
              </div>
            </div>
          ) : (
            <div className="space-y-3">
              {filteredItems.map((item) => (
                <div
                  key={item.id}
                  className="p-4 rounded-2xl bg-[#121522] border border-white/10 hover:border-emerald-500/30 transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-4"
                >
                  <div className="space-y-1 flex-1">
                    <div className="flex items-center space-x-2">
                      <span
                        className={`text-[9px] font-black uppercase px-2 py-0.5 rounded-full border ${
                          item.priority === 'High'
                            ? 'bg-rose-500/20 text-rose-300 border-rose-500/40'
                            : item.priority === 'Med'
                            ? 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                            : 'bg-sky-500/20 text-sky-300 border-sky-500/40'
                        }`}
                      >
                        {item.priority} Priority
                      </span>
                      <h4 className="font-bold text-sm text-white tracking-tight">{item.title}</h4>
                    </div>

                    <div className="flex items-center space-x-3 text-xs text-neutral-400">
                      <span>Assignee: <strong className="text-neutral-200">{item.assignee}</strong></span>
                      <span>•</span>
                      <span>Due: <strong className="text-neutral-200">{item.dueDate}</strong></span>
                    </div>

                    {item.notes && <p className="text-xs text-neutral-300">{item.notes}</p>}
                  </div>

                  <div className="flex items-center space-x-2 self-end sm:self-center">
                    <select
                      value={item.status}
                      onChange={(e) => handleStatusChange(item.id, e.target.value as any)}
                      className={`px-3 py-1.5 rounded-xl text-xs font-bold border transition-all cursor-pointer ${
                        item.status === 'Passed'
                          ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                          : item.status === 'Submitted'
                          ? 'bg-sky-500/20 text-sky-300 border-sky-500/40'
                          : 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                      }`}
                    >
                      <option value="Pending" className="bg-[#121522] text-amber-300">Pending</option>
                      <option value="Submitted" className="bg-[#121522] text-sky-300">Submitted</option>
                      <option value="Passed" className="bg-[#121522] text-emerald-300">Passed</option>
                    </select>

                    <button
                      onClick={() => handleDeleteItem(item.id)}
                      className="p-2 rounded-xl text-neutral-500 hover:text-rose-400 hover:bg-rose-500/10 transition-colors cursor-pointer"
                      title="Delete Deliverable"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
