import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';
import { AvatarSkin, ScooterConfig, UserState } from '../types';
import { createVoxelAvatarMesh, AvatarMeshGroup } from '../game/avatarBuilder';

interface Avatar3DPreviewProps {
  skin: AvatarSkin;
  hoodieColor: string;
  hairColor: string;
  skinTone: string;
  name: string;
  pantsColor?: string;
  shoesColor?: string;
  capColor?: string;
  scarfColor?: string;
  isRidingScooter?: boolean;
  scooterConfig?: ScooterConfig;
}

export const Avatar3DPreview: React.FC<Avatar3DPreviewProps> = ({
  skin,
  hoodieColor,
  hairColor,
  skinTone,
  name,
  pantsColor,
  shoesColor,
  capColor,
  scarfColor,
  isRidingScooter = false,
  scooterConfig,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const avatarRef = useRef<AvatarMeshGroup | null>(null);
  const animFrameRef = useRef<number | null>(null);
  const isDraggingRef = useRef(false);
  const previousMousePositionRef = useRef({ x: 0, y: 0 });
  const rotationYRef = useRef<number>(0.2);
  const isRidingScooterRef = useRef(isRidingScooter);
  isRidingScooterRef.current = isRidingScooter;

  // Initialize ThreeJS Scene
  useEffect(() => {
    if (!containerRef.current) return;
    const container = containerRef.current;
    const width = container.clientWidth || 400;
    const height = container.clientHeight || 400;

    const scene = new THREE.Scene();
    sceneRef.current = scene;

    // Optimized 30° FOV and pulled-back camera distance (5.5m) to ensure the avatar (cap, headphones, outfit) and the circular spinner platform fit completely with generous breathing room
    const camera = new THREE.PerspectiveCamera(30, width / height, 0.1, 100);
    camera.position.set(0, 1.16, 5.5);
    camera.lookAt(0, 0.90, 0);
    cameraRef.current = camera;

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setClearColor(0x000000, 0); // 100% transparent canvas background
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    rendererRef.current = renderer;

    container.appendChild(renderer.domElement);

    // Warm & Inviting Studio Lighting matching San Francisco Golden Hour Sunset
    const ambientLight = new THREE.AmbientLight(0xffffff, 1.35);
    scene.add(ambientLight);

    // Warm key sunlight from upper right
    const keyLight = new THREE.DirectionalLight(0xffedd5, 2.2);
    keyLight.position.set(3, 4.5, 3.5);
    keyLight.castShadow = true;
    keyLight.shadow.mapSize.width = 1024;
    keyLight.shadow.mapSize.height = 1024;
    keyLight.shadow.bias = -0.001;
    scene.add(keyLight);

    // Soft cool sky fill light from left
    const fillLight = new THREE.DirectionalLight(0xbae6fd, 1.0);
    fillLight.position.set(-3.5, 2.5, 2.5);
    scene.add(fillLight);

    // Warm golden-hour rim light from behind character
    const rimLight = new THREE.DirectionalLight(0xfb923c, 1.9);
    rimLight.position.set(-2, 3.5, -3.5);
    scene.add(rimLight);

    // Soft Floor Shadow Plane (Canvas Texture)
    const shadowCanvas = document.createElement('canvas');
    shadowCanvas.width = 256;
    shadowCanvas.height = 256;
    const sCtx = shadowCanvas.getContext('2d');
    if (sCtx) {
      const grad = sCtx.createRadialGradient(128, 128, 0, 128, 128, 120);
      grad.addColorStop(0, 'rgba(15, 23, 42, 0.7)');
      grad.addColorStop(0.35, 'rgba(15, 23, 42, 0.38)');
      grad.addColorStop(0.7, 'rgba(15, 23, 42, 0.1)');
      grad.addColorStop(1, 'rgba(0, 0, 0, 0)');
      sCtx.fillStyle = grad;
      sCtx.fillRect(0, 0, 256, 256);
    }
    const shadowTexture = new THREE.CanvasTexture(shadowCanvas);
    const shadowGeo = new THREE.PlaneGeometry(2.5, 2.5);
    const shadowMat = new THREE.MeshBasicMaterial({
      map: shadowTexture,
      transparent: true,
      depthWrite: false,
      opacity: 0.85,
    });
    const shadowMesh = new THREE.Mesh(shadowGeo, shadowMat);
    shadowMesh.rotation.x = -Math.PI / 2;
    shadowMesh.position.set(0, 0.003, 0);
    scene.add(shadowMesh);

    // Polished Circular Spinner Platform Pedestal
    const stageGeo = new THREE.CylinderGeometry(1.05, 1.15, 0.06, 48);
    const stageMat = new THREE.MeshStandardMaterial({
      color: 0x1e293b,
      roughness: 0.45,
      metalness: 0.35,
    });
    const stageMesh = new THREE.Mesh(stageGeo, stageMat);
    stageMesh.position.set(0, -0.03, 0);
    stageMesh.receiveShadow = true;
    scene.add(stageMesh);

    // Glowing Accent Ring along platform rim
    const rimRingGeo = new THREE.TorusGeometry(1.06, 0.015, 16, 64);
    const rimRingMat = new THREE.MeshBasicMaterial({
      color: 0xf59e0b,
      transparent: true,
      opacity: 0.75,
    });
    const rimRingMesh = new THREE.Mesh(rimRingGeo, rimRingMat);
    rimRingMesh.rotation.x = Math.PI / 2;
    rimRingMesh.position.set(0, 0.002, 0);
    scene.add(rimRingMesh);

    // Resize handling
    const handleResize = () => {
      if (!container || !renderer || !camera) return;
      const w = container.clientWidth;
      const h = container.clientHeight;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };

    const resizeObserver = new ResizeObserver(handleResize);
    resizeObserver.observe(container);

    // Render loop
    let lastTime = performance.now();
    const animate = (time: number) => {
      const delta = (time - lastTime) / 1000;
      lastTime = time;

      if (!isDraggingRef.current) {
        rotationYRef.current += 0.45 * delta;
      }

      if (avatarRef.current) {
        avatarRef.current.group.rotation.y = rotationYRef.current;
        avatarRef.current.updateAnimation(
          time * 0.001,
          false,
          false,
          false,
          false,
          false,
          undefined,
          false,
          undefined,
          isRidingScooterRef.current,
          0,
          0,
          delta
        );
      }

      renderer.render(scene, camera);
      animFrameRef.current = requestAnimationFrame(animate);
    };

    animFrameRef.current = requestAnimationFrame(animate);

    // Interactive Drag to Rotate
    const handleMouseDown = (e: MouseEvent) => {
      isDraggingRef.current = true;
      previousMousePositionRef.current = { x: e.clientX, y: e.clientY };
    };

    const handleMouseMove = (e: MouseEvent) => {
      if (!isDraggingRef.current) return;
      const deltaX = e.clientX - previousMousePositionRef.current.x;
      rotationYRef.current += deltaX * 0.015;
      previousMousePositionRef.current = { x: e.clientX, y: e.clientY };
    };

    const handleMouseUp = () => {
      isDraggingRef.current = false;
    };

    const handleTouchStart = (e: TouchEvent) => {
      if (e.touches.length === 1) {
        isDraggingRef.current = true;
        previousMousePositionRef.current = { x: e.touches[0].clientX, y: e.touches[0].clientY };
      }
    };

    const handleTouchMove = (e: TouchEvent) => {
      if (!isDraggingRef.current || e.touches.length !== 1) return;
      const deltaX = e.touches[0].clientX - previousMousePositionRef.current.x;
      rotationYRef.current += deltaX * 0.015;
      previousMousePositionRef.current = { x: e.touches[0].clientX, y: e.touches[0].clientY };
    };

    const handleTouchEnd = () => {
      isDraggingRef.current = false;
    };

    container.addEventListener('mousedown', handleMouseDown);
    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('mouseup', handleMouseUp);
    container.addEventListener('touchstart', handleTouchStart);
    window.addEventListener('touchmove', handleTouchMove);
    window.addEventListener('touchend', handleTouchEnd);

    return () => {
      resizeObserver.disconnect();
      if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current);
      container.removeEventListener('mousedown', handleMouseDown);
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleMouseUp);
      container.removeEventListener('touchstart', handleTouchStart);
      window.removeEventListener('touchmove', handleTouchMove);
      window.removeEventListener('touchend', handleTouchEnd);
      if (renderer.domElement && container.contains(renderer.domElement)) {
        container.removeChild(renderer.domElement);
      }
      renderer.dispose();
    };
  }, []);

  // Update Avatar Model when props change
  useEffect(() => {
    if (!sceneRef.current) return;
    const scene = sceneRef.current;

    // Remove previous avatar
    if (avatarRef.current) {
      scene.remove(avatarRef.current.group);
      avatarRef.current = null;
    }

    // Build dummy user for avatar builder
    const previewUser: UserState = {
      id: 'preview_user',
      name: name || 'Preview Avatar',
      skin: skin,
      color: hoodieColor,
      hoodieColor: hoodieColor,
      hairColor: hairColor,
      ethnicity: skinTone,
      skinTone: skinTone,
      pantsColor: pantsColor,
      shoesColor: shoesColor,
      capColor: capColor,
      scarfColor: scarfColor,
      isRidingScooter: isRidingScooter,
      scooterConfig: scooterConfig,
      department: 'Engineering',
      position: { x: 0, y: 0, z: 0 },
      rotationY: 0,
      isMoving: false,
      isSpeaking: false,
      isMuted: false,
      isScreenSharing: false,
      claimedDeskId: null,
      statusText: 'Available',
    };

    const newAvatar = createVoxelAvatarMesh(previewUser);
    newAvatar.group.position.set(0, 0, 0);
    newAvatar.group.rotation.y = rotationYRef.current;
    
    // Explicitly hide and remove overhead floating player badge tag ("Preview Avatar • Engineering") & floor audio wave
    if (newAvatar.badgeSprite) {
      newAvatar.badgeSprite.visible = false;
      newAvatar.group.remove(newAvatar.badgeSprite);
    }
    if (newAvatar.audioWaveMesh) {
      newAvatar.audioWaveMesh.visible = false;
      newAvatar.group.remove(newAvatar.audioWaveMesh);
    }

    // Enable shadows on all child meshes
    newAvatar.group.traverse((child) => {
      if ((child as THREE.Mesh).isMesh) {
        child.castShadow = true;
        child.receiveShadow = true;
      }
    });

    scene.add(newAvatar.group);
    avatarRef.current = newAvatar;
  }, [skin, hoodieColor, hairColor, skinTone, name, pantsColor, shoesColor, capColor, scarfColor, isRidingScooter, scooterConfig]);

  return (
    <div className="relative w-full h-full min-h-[300px] flex items-center justify-center select-none overflow-hidden rounded-2xl bg-transparent">
      {/* Warm Ambient Sunset Glow Behind Avatar (Transparent & Non-Obstructive) */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          background:
            'radial-gradient(circle at 50% 52%, rgba(251, 146, 60, 0.22) 0%, rgba(99, 102, 241, 0.12) 35%, transparent 68%)',
        }}
      />
      <div ref={containerRef} className="w-full h-full cursor-grab active:cursor-grabbing relative z-10 bg-transparent" />
    </div>
  );
};
