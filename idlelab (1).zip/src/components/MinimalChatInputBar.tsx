import React, { useState, useRef } from 'react';
import {
  Wand2,
  Mic,
  MicOff,
  ArrowUp,
  ChevronDown,
  Sparkles,
  Bot,
  LayoutGrid,
} from 'lucide-react';
import { simulatorEngine } from '../lib/simulatorEngine';
import { chloeVoice } from '../lib/chloeVoice';
import { soundEffects } from '../lib/soundEffects';
import { chloeAgentClient } from '../lib/chloeAgentClient';

interface MinimalChatInputBarProps {
  currentUserName?: string;
  onOpenAgentFlow: () => void;
  onChloeSpeakingChange?: (speaking: boolean) => void;
  onChloeWave?: () => void;
}

const BUSINESS_COMPLEX_KEYWORDS = [
  'business',
  'strategy',
  'revenue',
  'analytics',
  'pipeline',
  'kubernetes',
  'deploy',
  'audit',
  'metrics',
  'architecture',
  'cluster',
  'infrastructure',
  'q3',
  'saas',
  'auth',
  'optimization',
  'complex',
  'scale',
  'database',
  'cloud',
  'enterprise',
  'production',
  'agent',
  'system',
];

export const MinimalChatInputBar: React.FC<MinimalChatInputBarProps> = ({
  currentUserName,
  onOpenAgentFlow,
  onChloeSpeakingChange,
  onChloeWave,
}) => {
  const displayName =
    currentUserName && currentUserName !== 'there' && currentUserName.trim()
      ? currentUserName.trim()
      : 'Colleague';

  const [inputText, setInputText] = useState<string>('');
  const [isListening, setIsListening] = useState<boolean>(false);
  const [isExecuting, setIsExecuting] = useState<boolean>(false);
  const [selectedMode, setSelectedMode] = useState<string>('Build');
  const [selectedModel, setSelectedModel] = useState<string>('Default');
  const [showModeDropdown, setShowModeDropdown] = useState<boolean>(false);
  const [showModelDropdown, setShowModelDropdown] = useState<boolean>(false);

  const speechRecognitionRef = useRef<any>(null);

  const handleSubmit = async (textToRun?: string) => {
    const text = (textToRun !== undefined ? textToRun : inputText).trim();
    if (!text || isExecuting) return;

    // Pop up Multiagent workspace UI when user types and hits enter / submits
    if (onOpenAgentFlow) {
      onOpenAgentFlow();
    }

    setInputText('');
    setIsExecuting(true);
    soundEffects.play('confirm');
    if (onChloeWave) onChloeWave();

    // (Business complex tab auto-opening disabled based on user request)

    try {
      const response = await simulatorEngine.executeAutonomousCommand(
        text,
        displayName,
        () => {
          if (onChloeSpeakingChange) onChloeSpeakingChange(true);
        },
        () => {
          if (onChloeSpeakingChange) onChloeSpeakingChange(false);
        }
      );

      const reply = response.text || `I've processed your request regarding "${text}". All autonomous systems are operating normally.`;
      
      // Chloe speaks response via voice
      simulatorEngine.ttsAudioStreamer(
        reply,
        () => {
          if (onChloeSpeakingChange) onChloeSpeakingChange(true);
        },
        () => {
          if (onChloeSpeakingChange) onChloeSpeakingChange(false);
        }
      );
    } catch (err: any) {
      console.error(err);
    } finally {
      setIsExecuting(false);
    }
  };

  const handleRefine = async () => {
    const raw = inputText.trim();
    if (!raw) return;
    try {
      const res = await chloeAgentClient.refinePrompt(raw, displayName, 'auto');
      if (res.success && res.refinedPrompt) {
        setInputText(res.refinedPrompt);
      }
    } catch {
      // fallback
    }
  };

  const toggleSpeechRecognition = () => {
    if (typeof window === 'undefined') return;
    const SpeechRec = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRec) {
      alert('Speech recognition is not supported in this browser.');
      return;
    }

    if (isListening) {
      if (speechRecognitionRef.current) speechRecognitionRef.current.stop();
      setIsListening(false);
      return;
    }

    try {
      const rec = new SpeechRec();
      rec.lang = 'en-US';
      rec.continuous = false;
      rec.interimResults = true;

      rec.onstart = () => setIsListening(true);
      rec.onresult = (event: any) => {
        let transcript = '';
        for (let i = event.resultIndex; i < event.results.length; ++i) {
          transcript += event.results[i][0].transcript;
        }
        if (transcript.trim()) {
          setInputText(transcript.trim());
        }
      };
      rec.onerror = () => setIsListening(false);
      rec.onend = () => {
        setIsListening(false);
        if (inputText.trim()) {
          handleSubmit(inputText.trim());
        }
      };

      speechRecognitionRef.current = rec;
      rec.start();
    } catch {
      setIsListening(false);
    }
  };

  return (
    <div className="fixed bottom-22 sm:bottom-24 left-1/2 -translate-x-1/2 w-[92vw] sm:w-[680px] max-w-3xl z-45 pointer-events-auto">
      <div className="bg-[#121624]/95 border border-white/15 rounded-full shadow-[0_20px_60px_rgba(0,0,0,0.85)] backdrop-blur-2xl p-2 sm:p-2.5 flex items-center space-x-2 sm:space-x-3 text-slate-100">
        
        {/* Show/Hide Multiagent Workspace Button */}
        <button
          type="button"
          onClick={() => {
            soundEffects.play('pop');
            if (onOpenAgentFlow) onOpenAgentFlow();
          }}
          className="px-2.5 h-9 rounded-full bg-gradient-to-r from-sky-500/20 to-indigo-500/20 hover:from-sky-500/30 hover:to-indigo-500/30 border border-sky-400/30 flex items-center space-x-1.5 text-sky-300 hover:text-sky-100 transition-all cursor-pointer shrink-0 shadow-sm"
          title="Show / Hide Multiagent Workspace"
        >
          <Bot className="w-4 h-4 text-sky-400" />
          <span className="text-xs font-semibold hidden md:inline">Workspace</span>
        </button>

        {/* AI Magic Refine Button */}
        <button
          type="button"
          onClick={handleRefine}
          className="w-9 h-9 rounded-full bg-white/5 hover:bg-white/15 border border-white/10 flex items-center justify-center text-sky-400 hover:text-sky-300 transition-colors cursor-pointer shrink-0"
          title="Refine prompt with Chloe AI Agent"
        >
          <Wand2 className="w-4 h-4" />
        </button>

        {/* Text Input */}
        <input
          type="text"
          value={inputText}
          onChange={(e) => {
            const val = e.target.value;
            setInputText(val);
          }}
          onKeyDown={(e) => {
            if (e.key === 'Enter') handleSubmit();
          }}
          placeholder={isListening ? 'Listening to your voice...' : 'Describe your idea. Attach a design to guide the result.'}
          className="flex-1 bg-transparent border-none px-2 text-sm text-slate-100 placeholder-slate-400 focus:outline-none"
        />

        {/* Mode Selector Pill */}
        <div className="relative hidden sm:block">
          <button
            type="button"
            onClick={() => {
              setShowModeDropdown(!showModeDropdown);
              setShowModelDropdown(false);
            }}
            className="px-3 py-1.5 rounded-full bg-white/5 hover:bg-white/10 border border-white/10 text-xs font-medium text-slate-300 flex items-center space-x-1 cursor-pointer"
          >
            <span>{selectedMode}</span>
            <ChevronDown className="w-3 h-3 text-slate-400" />
          </button>
          {showModeDropdown && (
            <div className="absolute bottom-full mb-2 right-0 w-32 bg-[#0b0f19] border border-white/15 rounded-xl shadow-2xl py-1 z-50 text-xs">
              {['Build', 'Chat', 'Analyze', 'Design'].map((m) => (
                <button
                  key={m}
                  onClick={() => {
                    setSelectedMode(m);
                    setShowModeDropdown(false);
                  }}
                  className="w-full text-left px-3 py-1.5 hover:bg-white/10 text-slate-300 hover:text-white transition-colors"
                >
                  {m}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Model Selector Pill */}
        <div className="relative hidden sm:block">
          <button
            type="button"
            onClick={() => {
              setShowModelDropdown(!showModelDropdown);
              setShowModeDropdown(false);
            }}
            className="px-3 py-1.5 rounded-full bg-white/5 hover:bg-white/10 border border-white/10 text-xs font-medium text-slate-300 flex items-center space-x-1 cursor-pointer"
          >
            <span>{selectedModel}</span>
            <ChevronDown className="w-3 h-3 text-slate-400" />
          </button>
          {showModelDropdown && (
            <div className="absolute bottom-full mb-2 right-0 w-36 bg-[#0b0f19] border border-white/15 rounded-xl shadow-2xl py-1 z-50 text-xs">
              {['Default', 'Gemini Pro', 'Claude Sonnet', 'Agent Mesh'].map((m) => (
                <button
                  key={m}
                  onClick={() => {
                    setSelectedModel(m);
                    setShowModelDropdown(false);
                  }}
                  className="w-full text-left px-3 py-1.5 hover:bg-white/10 text-slate-300 hover:text-white transition-colors"
                >
                  {m}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Microphone Voice Toggle */}
        <button
          type="button"
          onClick={toggleSpeechRecognition}
          className={`w-9 h-9 rounded-full flex items-center justify-center transition-colors cursor-pointer shrink-0 border ${
            isListening
              ? 'bg-rose-500 text-white border-rose-400 animate-pulse'
              : 'bg-white/5 hover:bg-white/15 border-white/10 text-slate-300 hover:text-white'
          }`}
          title={isListening ? 'Stop listening' : 'Speak to Chloe'}
        >
          {isListening ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
        </button>

        {/* Send Button */}
        <button
          type="button"
          onClick={() => handleSubmit()}
          disabled={!inputText.trim() || isExecuting}
          className={`w-9 h-9 rounded-full flex items-center justify-center transition-all cursor-pointer shrink-0 ${
            inputText.trim() && !isExecuting
              ? 'bg-sky-500 hover:bg-sky-400 text-slate-950 shadow-lg shadow-sky-500/30'
              : 'bg-white/10 text-slate-500 cursor-not-allowed'
          }`}
          title="Send message to Chloe"
        >
          <ArrowUp className="w-4 h-4 font-bold" />
        </button>

      </div>
    </div>
  );
};
