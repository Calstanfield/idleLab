import React, { useState, useEffect } from 'react';
import { audioManager } from '../lib/audioManager';
import { soundEffects } from '../lib/soundEffects';
import { GestureType } from '../types';
import {
  MousePointer,
  MessageSquare,
  Square,
  PenTool,
  Type,
  Mic,
  MicOff,
  Video,
  VideoOff,
  Monitor,
  Contact,
  CheckSquare,
  Eye,
  Armchair,
  Bot,
  Users,
  ArrowUpDown,
  ChevronDown,
  ChevronUp,
  Code2,
  Volume2,
  VolumeX,
  Music,
  Tv,
  X,
  Check,
  PanelLeft,
  PanelRight,
  Smile,
  Sparkles,
  Settings,
  LayoutGrid,
} from 'lucide-react';

interface ControlBarProps {
  isMuted: boolean;
  isCameraOn?: boolean;
  isScreenSharing?: boolean;
  cameraMode: 'third_person' | 'first_person' | 'isometric';
  onToggleMic: () => void;
  onToggleCamera?: () => void;
  onToggleScreenShare?: () => void;
  onStartScreenShareWithOptions?: (options: { includeAudio: boolean; preferTab: boolean }) => void;
  onStopScreenShare?: () => void;
  onChangeCameraMode: () => void;
  onTeleportDesk: () => void;
  onTeleportMeetingRoom?: () => void;
  onTeleportSushiBar?: () => void;
  onToggleElevator?: () => void;
  currentFloor?: number | string;
  onOpenSavedContacts: () => void;
  onOpenChecklist: () => void;
  onOpenPingPong?: () => void;
  onOpenWhiteboard?: () => void;
  onTeleportTennisCourt?: () => void;
  onToggleLayersPanel?: () => void;
  onToggleInspectorPanel?: () => void;
  isLayersPanelOpen?: boolean;
  isInspectorPanelOpen?: boolean;
  onlineCount: number;
  isChatOpen?: boolean;
  onToggleChat?: () => void;
  unreadCount?: number;
  onOpenChloeModal?: () => void;
  onOpenWorkspace?: () => void;
  onOpenAiMeetingAgent?: () => void;
  isMeetingActive?: boolean;
  onPerformGesture?: (gesture: GestureType) => void;
  onSendEmojiReaction?: (emoji: string, gesture?: GestureType) => void;
  onOpenEmoteWheel?: () => void;
  onOpenSettings?: () => void;
  onOpenSwiftNote?: () => void;
}

const AVATAR_EMOTES: Array<{
  num: number;
  gesture: GestureType;
  label: string;
  emoji: string;
}> = [
  { num: 1, gesture: 'wave', label: 'Wave', emoji: '👋' },
  { num: 2, gesture: 'dance', label: 'Dance', emoji: '🎉' },
  { num: 3, gesture: 'clap', label: 'Clap', emoji: '👏' },
  { num: 4, gesture: 'think', label: 'Think', emoji: '🤔' },
  { num: 5, gesture: 'bow', label: 'Bow', emoji: '🙇' },
  { num: 6, gesture: 'cheer', label: 'Cheer', emoji: '🔥' },
  { num: 7, gesture: 'heart', label: 'Heart', emoji: '❤️' },
  { num: 8, gesture: 'facepalm', label: 'Facepalm', emoji: '🤦' },
];

export const ControlBar: React.FC<ControlBarProps> = ({
  isMuted,
  isCameraOn = false,
  isScreenSharing = false,
  cameraMode,
  onToggleMic,
  onToggleCamera,
  onToggleScreenShare,
  onStartScreenShareWithOptions,
  onStopScreenShare,
  onChangeCameraMode,
  onTeleportDesk,
  onTeleportMeetingRoom,
  onTeleportSushiBar,
  onToggleElevator,
  currentFloor = 1,
  onOpenSavedContacts,
  onOpenChecklist,
  onOpenPingPong,
  onOpenWhiteboard,
  onTeleportTennisCourt,
  onToggleLayersPanel,
  onToggleInspectorPanel,
  isLayersPanelOpen = false,
  isInspectorPanelOpen = false,
  onlineCount,
  isChatOpen = false,
  onToggleChat,
  unreadCount = 0,
  onOpenWorkspace,
  onOpenAiMeetingAgent,
  onOpenChloeModal,
  isMeetingActive = false,
  onPerformGesture,
  onSendEmojiReaction,
  onOpenEmoteWheel,
  onOpenSettings,
  onOpenSwiftNote,
}) => {
  const [activeTool, setActiveTool] = useState<'cursor' | 'chat' | 'desk' | 'whiteboard'>('cursor');
  const [isShareMenuOpen, setIsShareMenuOpen] = useState(false);
  const [isAppsMenuOpen, setIsAppsMenuOpen] = useState(false);
  const [isEmotesOpen, setIsEmotesOpen] = useState(false);
  const [isRoomAudioOn, setIsRoomAudioOn] = useState(true);
  const [includeTabAudio, setIncludeTabAudio] = useState(true);
  const [isSfxMuted, setIsSfxMuted] = useState(soundEffects.isMuted());

  useEffect(() => {
    const unsub = soundEffects.onMuteChange((muted) => {
      setIsSfxMuted(muted);
    });
    return unsub;
  }, []);

  const handleToggleSfx = () => {
    soundEffects.toggleMute();
  };

  const toggleRoomAudio = () => {
    const nextState = !isRoomAudioOn;
    setIsRoomAudioOn(nextState);
    audioManager.setRoomAudioEnabled(nextState);
  };

  const handleEmoteSelect = (emote: typeof AVATAR_EMOTES[0]) => {
    soundEffects.playEmote();
    if (onPerformGesture) onPerformGesture(emote.gesture);
    if (onSendEmojiReaction) onSendEmojiReaction(emote.emoji, emote.gesture);
    setIsEmotesOpen(false);
  };

  const handleDebugAllEmotes = () => {
    soundEffects.playEmote();
    setIsEmotesOpen(false);
    AVATAR_EMOTES.forEach((emote, idx) => {
      setTimeout(() => {
        soundEffects.playEmote();
        if (onPerformGesture) onPerformGesture(emote.gesture);
        if (onSendEmojiReaction) onSendEmojiReaction(emote.emoji, emote.gesture);
      }, idx * 1500);
    });
  };

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (['INPUT', 'TEXTAREA'].includes((e.target as HTMLElement)?.tagName)) return;
      const num = parseInt(e.key, 10);
      if (num >= 1 && num <= 8) {
        const found = AVATAR_EMOTES.find((m) => m.num === num);
        if (found) {
          if (onPerformGesture) onPerformGesture(found.gesture);
          if (onSendEmojiReaction) onSendEmojiReaction(found.emoji, found.gesture);
        }
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [onPerformGesture, onSendEmojiReaction]);

  const handleShareClick = (preferTab: boolean) => {
    setIsShareMenuOpen(false);
    if (onStartScreenShareWithOptions) {
      onStartScreenShareWithOptions({ includeAudio: includeTabAudio, preferTab });
    } else if (onToggleScreenShare) {
      onToggleScreenShare();
    }
  };

  return (
    <>
      {/* Software Style Bottom Floating Toolbar */}
      <div className="fixed bottom-[max(0.75rem,env(safe-area-inset-bottom))] left-1/2 -translate-x-1/2 z-40 max-w-[calc(100vw-1rem)] sm:max-w-none flex items-center space-x-1 sm:space-x-1.5 p-1.5 bg-[#121216]/90 backdrop-blur-2xl border border-white/15 rounded-2xl shadow-[0_20px_50px_rgba(0,0,0,0.8)] text-neutral-200 pointer-events-auto overflow-x-auto no-scrollbar transition-all duration-200">
        
        {/* 1. Streamlined Unified A/V Pill Dock (Left Side: Mic, Cam, Settings) */}
        <div className="flex items-center space-x-1 p-1 bg-white/5 border border-white/10 rounded-xl">
          {/* Mic Tool */}
          <button
            onClick={onToggleMic}
            className={`flex items-center space-x-1.5 px-2.5 py-1.5 rounded-lg border text-xs font-medium transition-all cursor-pointer ${
              isMuted
                ? 'bg-rose-500/15 text-rose-300 border-rose-500/30 hover:bg-rose-500/25'
                : 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30 hover:bg-emerald-500/25'
            }`}
            title={isMuted ? 'Unmute Microphone' : 'Mute Microphone'}
          >
            {isMuted ? <MicOff className="w-3.5 h-3.5" /> : <Mic className="w-3.5 h-3.5" />}
            <span className="hidden sm:inline">{isMuted ? 'Muted' : 'Mic On'}</span>
          </button>

          {/* Camera Tool */}
          {onToggleCamera && (
            <button
              onClick={onToggleCamera}
              className={`flex items-center space-x-1.5 px-2.5 py-1.5 rounded-lg border text-xs font-medium transition-all cursor-pointer ${
                !isCameraOn
                  ? 'bg-white/5 hover:bg-white/10 text-neutral-400 hover:text-white border-white/5'
                  : 'bg-sky-500/20 text-sky-300 border-sky-500/40 hover:bg-sky-500/30'
              }`}
              title={isCameraOn ? 'Turn Off Camera' : 'Turn On Camera'}
            >
              {isCameraOn ? <Video className="w-3.5 h-3.5" /> : <VideoOff className="w-3.5 h-3.5" />}
              <span className="hidden sm:inline">{isCameraOn ? 'Cam On' : 'Cam Off'}</span>
            </button>
          )}

          {/* Settings & Preferences */}
          {onOpenSettings && (
            <button
              onClick={onOpenSettings}
              className="flex items-center space-x-1.5 px-2.5 py-1.5 rounded-lg border border-white/10 bg-white/5 hover:bg-white/10 text-neutral-300 hover:text-white text-xs font-medium transition-all cursor-pointer"
              title="Open Settings & Preferences"
            >
              <Settings className="w-3.5 h-3.5 text-sky-400 shrink-0" />
              <span className="hidden md:inline">Settings</span>
            </button>
          )}
        </div>

        {/* Divider */}
        <div className="h-5 w-px bg-white/10 shrink-0 mx-0.5" />

        {/* 2. Primary Actions Priority: Dedicated Buttons for Share Screen and Live Projection */}
        <div className="flex items-center space-x-1">
          {/* Screen Share Button */}
          <div className="relative">
            {isScreenSharing ? (
              <button
                type="button"
                onClick={() => {
                  if (onStopScreenShare) {
                    onStopScreenShare();
                  } else if (onToggleScreenShare) {
                    onToggleScreenShare();
                  }
                }}
                className="flex items-center space-x-1.5 px-3 py-1.5 rounded-xl border text-xs font-semibold bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 border-rose-500/40 cursor-pointer transition-all shadow-md shadow-rose-950/40"
                title="Click to stop sharing screen immediately"
              >
                <span className="w-2 h-2 rounded-full bg-rose-400 animate-ping shrink-0" />
                <span>Stop Sharing</span>
              </button>
            ) : (
              <div className="flex items-center space-x-0.5 bg-white/5 hover:bg-white/10 text-neutral-300 hover:text-white border border-white/10 rounded-xl px-1 py-0.5 transition-all">
                <button
                  type="button"
                  onClick={() => {
                    if (onToggleScreenShare) {
                      onToggleScreenShare();
                    } else if (onStartScreenShareWithOptions) {
                      onStartScreenShareWithOptions({ includeAudio: includeTabAudio, preferTab: true });
                    }
                  }}
                  className="flex items-center space-x-1.5 px-2 py-1 cursor-pointer font-medium text-xs hover:text-white transition-colors"
                  title="Share Screen (Browser Tab or Window)"
                >
                  <Monitor className="w-3.5 h-3.5 text-neutral-300 shrink-0" />
                  <span className="hidden sm:inline">Share Screen</span>
                </button>
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    setIsShareMenuOpen(!isShareMenuOpen);
                  }}
                  className="p-1 hover:bg-white/15 rounded-lg cursor-pointer text-neutral-400 hover:text-white transition-colors"
                  title="Screen Sharing Options"
                >
                  <ChevronDown className="w-3 h-3" />
                </button>
              </div>
            )}

            {/* Screen Share Dropdown Menu */}
            {isShareMenuOpen && !isScreenSharing && (
              <div className="absolute bottom-full mb-2 left-0 sm:left-auto sm:right-0 w-72 bg-[#121216]/95 backdrop-blur-2xl border border-white/15 rounded-2xl shadow-2xl p-3 z-50 text-xs text-neutral-200">
                <div className="flex items-center justify-between pb-2 border-b border-white/10">
                  <span className="font-bold text-white flex items-center space-x-1.5">
                    <Monitor className="w-4 h-4 text-sky-400" />
                    <span>Screen Presentation</span>
                  </span>
                  <button
                    onClick={() => setIsShareMenuOpen(false)}
                    className="p-1 hover:bg-white/10 rounded-md text-neutral-400 hover:text-white cursor-pointer"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>

                {/* Tab Audio Option Toggle Switch */}
                <div className="mt-2.5 p-2 bg-white/5 border border-white/10 rounded-xl flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <Music className="w-4 h-4 text-emerald-400 shrink-0" />
                    <div>
                      <div className="font-semibold text-neutral-200 text-[11px]">Share Tab Audio</div>
                      <div className="text-[10px] text-neutral-400">Stream audio from browser tab</div>
                    </div>
                  </div>
                  <button
                    onClick={() => setIncludeTabAudio(!includeTabAudio)}
                    className={`w-9 h-5 rounded-full transition-colors relative cursor-pointer ${
                      includeTabAudio ? 'bg-[#0c8ce9]' : 'bg-neutral-700'
                    }`}
                  >
                    <div
                      className={`w-3.5 h-3.5 bg-white rounded-full absolute top-0.75 transition-transform ${
                        includeTabAudio ? 'left-4.5' : 'left-0.75'
                      }`}
                    />
                  </button>
                </div>

                <div className="mt-3 space-y-1.5">
                  <button
                    onClick={() => handleShareClick(true)}
                    className="w-full p-2.5 rounded-xl bg-[#0c8ce9] hover:bg-[#007be5] text-white font-semibold flex items-center justify-between transition-all cursor-pointer shadow-md shadow-sky-900/30"
                  >
                    <div className="flex items-center space-x-2">
                      <Tv className="w-4 h-4" />
                      <div className="text-left">
                        <div className="text-xs font-bold">Share Chrome / Browser Tab</div>
                        <div className="text-[10px] opacity-80">With Tab Audio Enabled</div>
                      </div>
                    </div>
                    <span className="bg-white/20 text-[9px] uppercase px-1.5 py-0.5 rounded font-bold">Best</span>
                  </button>

                  <button
                    onClick={() => handleShareClick(false)}
                    className="w-full p-2.5 rounded-xl bg-white/5 hover:bg-white/10 text-neutral-200 font-medium flex items-center space-x-2 transition-all cursor-pointer border border-white/5"
                  >
                    <Monitor className="w-4 h-4 text-neutral-400" />
                    <div className="text-left">
                      <div className="text-xs font-semibold">Share Window or Display</div>
                      <div className="text-[10px] text-neutral-400">Entire desktop or app window</div>
                    </div>
                  </button>
                </div>
              </div>
            )}
          </div>


        </div>

        {/* Divider */}
        <div className="h-5 w-px bg-white/10 shrink-0 mx-0.5" />

        {/* 4. Chat & Emotes Buttons */}
        <div className="flex items-center space-x-1">
          {/* Chat Tool */}
          <button
            onClick={() => {
              setActiveTool('chat');
              if (onToggleChat) onToggleChat();
            }}
            className={`flex items-center space-x-1.5 px-2.5 py-1.5 rounded-xl text-xs font-medium transition-all cursor-pointer relative ${
              isChatOpen
                ? 'bg-[#0c8ce9] text-white shadow-md shadow-sky-600/30 font-semibold'
                : 'bg-white/5 hover:bg-white/10 text-neutral-300 hover:text-white border border-white/5'
            }`}
            title="Office Chat (C)"
          >
            <MessageSquare className="w-3.5 h-3.5 text-amber-400 shrink-0" />
            <span className="hidden sm:inline">Chat</span>
            {unreadCount > 0 && (
              <span className="bg-amber-500 text-slate-950 font-bold text-[10px] px-1.5 py-0.2 rounded-full min-w-[16px] text-center">
                {unreadCount}
              </span>
            )}
          </button>

          {/* Avatar Emotes Drawer */}
          <div className="relative">
            <button
              onClick={() => {
                if (onOpenEmoteWheel) {
                  onOpenEmoteWheel();
                } else {
                  setIsEmotesOpen(!isEmotesOpen);
                }
              }}
              className={`flex items-center space-x-1.5 px-2.5 py-1.5 rounded-xl text-xs font-medium transition-all cursor-pointer ${
                isEmotesOpen
                  ? 'bg-amber-500/20 text-amber-300 border-amber-500/40 shadow-md font-semibold'
                  : 'bg-white/5 hover:bg-white/10 text-neutral-300 hover:text-white border border-white/5'
              }`}
              title="Double-Tap Avatar or Click for Emote Wheel"
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-400 shrink-0" />
              <span className="hidden sm:inline">Emotes</span>
              {isEmotesOpen ? <ChevronUp className="w-3 h-3 opacity-70" /> : <ChevronDown className="w-3 h-3 opacity-60" />}
            </button>

            {/* Docked Emotes Menu Popover */}
            {isEmotesOpen && (
              <div className="absolute bottom-full left-0 mb-2 w-72 bg-[#121216]/95 backdrop-blur-2xl border border-white/15 rounded-2xl shadow-[0_20px_50px_rgba(0,0,0,0.8)] p-2.5 z-50 animate-in zoom-in-95 duration-150">
                <div className="flex items-center justify-between px-1.5 pb-2 border-b border-white/10 mb-2">
                  <div className="flex items-center space-x-1.5">
                    <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                    <span className="text-xs font-bold text-white">Avatar Emotes</span>
                  </div>
                  <span className="text-[10px] text-sky-400 font-medium bg-sky-500/10 px-2 py-0.5 rounded-full border border-sky-500/20">Double-Tap Avatar</span>
                </div>

                <div className="grid grid-cols-4 gap-1.5">
                  {AVATAR_EMOTES.map((emote) => (
                    <button
                      key={emote.num}
                      onClick={() => handleEmoteSelect(emote)}
                      className="group flex flex-col items-center justify-center p-2 rounded-xl bg-white/5 hover:bg-sky-500/20 border border-white/5 hover:border-sky-500/40 transition-all cursor-pointer text-center relative"
                      title={`Press ${emote.num} for ${emote.label}`}
                    >
                      <span className="absolute top-1 left-1.5 text-[9px] font-mono text-neutral-400 group-hover:text-sky-300">
                        {emote.num}
                      </span>
                      <span className="text-xl mb-1 transition-transform group-hover:scale-125">
                        {emote.emoji}
                      </span>
                      <span className="text-[10px] text-neutral-300 group-hover:text-white font-medium truncate w-full">
                        {emote.label}
                      </span>
                    </button>
                  ))}
                </div>

                {/* Debug All Emotes Button */}
                <div className="mt-2 pt-2 border-t border-white/10">
                  <button
                    type="button"
                    onClick={handleDebugAllEmotes}
                    className="w-full py-1.5 px-2 bg-amber-500/15 hover:bg-amber-500/25 border border-amber-500/30 rounded-xl text-amber-300 hover:text-white font-semibold text-xs transition-all flex items-center justify-center space-x-1.5 cursor-pointer"
                    title="Run sequence test across all 8 avatar emotes"
                  >
                    <span>🛠️</span>
                    <span>Debug / Test All Emotes</span>
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Divider */}
        <div className="h-5 w-px bg-white/10 shrink-0 mx-0.5" />

        {/* 5. Navigation, Camera View & Inspector Toggles */}
        <div className="flex items-center space-x-1">
          <button
            onClick={onChangeCameraMode}
            className="flex items-center space-x-1 px-2 py-1.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-neutral-300 hover:text-white text-xs font-medium transition-all cursor-pointer"
            title={`3D Camera: ${cameraMode}`}
          >
            <Eye className="w-3.5 h-3.5 text-neutral-400 shrink-0" />
            <span className="capitalize text-xs hidden sm:inline">{cameraMode.replace('_', ' ')}</span>
          </button>

          {onToggleElevator && (
            <button
              onClick={onToggleElevator}
              className="flex items-center space-x-1 px-2 py-1.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-neutral-300 hover:text-white text-xs font-medium transition-all cursor-pointer"
              title="Ride Elevator"
            >
              <ArrowUpDown className="w-3.5 h-3.5 text-neutral-400 shrink-0" />
              <span className="text-xs hidden xl:inline">{typeof currentFloor === 'string' ? currentFloor : `${currentFloor}F`}</span>
            </button>
          )}

          {/* Figma Layers Panel Toggle */}
          {onToggleLayersPanel && (
            <button
              onClick={onToggleLayersPanel}
              className={`p-1.5 rounded-xl transition-all cursor-pointer ${
                isLayersPanelOpen ? 'bg-[#0c8ce9] text-white' : 'bg-white/5 hover:bg-white/10 text-neutral-400 hover:text-white border border-white/5'
              }`}
              title="Toggle Layers & Pages Sidebar"
            >
              <PanelLeft className="w-3.5 h-3.5 shrink-0" />
            </button>
          )}

          {/* Figma Inspector Property Panel Toggle */}
          {onToggleInspectorPanel && (
            <button
              onClick={onToggleInspectorPanel}
              className={`p-1.5 rounded-xl transition-all cursor-pointer ${
                isInspectorPanelOpen ? 'bg-[#0c8ce9] text-white' : 'bg-white/5 hover:bg-white/10 text-neutral-400 hover:text-white border border-white/5'
              }`}
              title="Toggle Design Inspector Panel"
            >
              <PanelRight className="w-3.5 h-3.5 shrink-0" />
            </button>
          )}
        </div>
      </div>
    </>
  );
};
