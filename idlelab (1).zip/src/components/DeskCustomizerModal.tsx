import React, { useState } from 'react';
import { DeskData, DeskGear, DeskTheme } from '../types';
import { X, Check, Laptop, Sparkles, Monitor, Coffee, Gamepad2, PenTool } from 'lucide-react';

interface DeskCustomizerModalProps {
  isOpen: boolean;
  onClose: () => void;
  desk: DeskData | null;
  currentUserId: string;
  onClaim: (deskId: string, theme: DeskTheme, gear: DeskGear, customStatus: string) => void;
  onUnclaim: (deskId: string) => void;
}

const THEMES: Array<{ id: DeskTheme; name: string; color: string }> = [
  { id: 'dark_oak', name: 'Dark Oak Wood', color: '#78350f' },
  { id: 'spruce', name: 'Spruce Wood', color: '#5c3d2e' },
  { id: 'cherry', name: 'Mahogany Cherry', color: '#881337' },
  { id: 'white_marble', name: 'White Marble', color: '#cbd5e1' },
  { id: 'cyber_neon', name: 'Cyber Neon', color: '#06b6d4' },
];

const GEAR_OPTIONS: Array<{ id: DeskGear; name: string; icon: React.ReactNode; desc: string }> = [
  { id: 'dual_monitors', name: 'Dual 4K Displays', icon: <Monitor className="w-5 h-5" />, desc: 'For maximum code output' },
  { id: 'pixel_laptop', name: 'Pixel Laptop', icon: <Laptop className="w-5 h-5" />, desc: 'Portable power station' },
  { id: 'coffee_plant', name: 'Espresso & Bonsai', icon: <Coffee className="w-5 h-5" />, desc: 'Caffeine & greenery vibes' },
  { id: 'retro_arcade', name: 'Mini Arcade Machine', icon: <Gamepad2 className="w-5 h-5" />, desc: 'Play pacman between PRs' },
  { id: 'designer_tablet', name: 'Designer Drawing Pad', icon: <PenTool className="w-5 h-5" />, desc: 'For UI/UX craft' },
];

export const DeskCustomizerModal: React.FC<DeskCustomizerModalProps> = ({
  isOpen,
  onClose,
  desk,
  currentUserId,
  onClaim,
  onUnclaim,
}) => {
  const [theme, setTheme] = useState<DeskTheme>(desk?.theme || 'dark_oak');
  const [gear, setGear] = useState<DeskGear>(desk?.gear || 'dual_monitors');
  const [status, setStatus] = useState<string>(desk?.customStatus || 'Deep Work');

  // Sync state when selected desk changes
  React.useEffect(() => {
    if (desk) {
      setTheme(desk.theme || 'dark_oak');
      setGear(desk.gear || 'dual_monitors');
      setStatus(desk.customStatus || 'Deep Work');
    }
  }, [desk]);

  if (!isOpen || !desk) return null;

  const isOwner = desk.ownerId === currentUserId;

  const handleSave = () => {
    onClaim(desk.id, theme, gear, status);
    onClose();
  };

  const handleUnclaim = () => {
    onUnclaim(desk.id);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-md p-4">
      <div className="w-full max-w-lg bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-2xl text-slate-100 space-y-6">
        <div className="flex items-center justify-between border-b border-slate-800 pb-4">
          <div className="flex items-center space-x-2">
            <Sparkles className="w-6 h-6 text-amber-400" />
            <div>
              <h2 className="text-xl font-bold text-white">{desk.label} Customization</h2>
              <p className="text-xs text-slate-400">
                {desk.ownerName ? `Occupied by ${desk.ownerName}` : 'Unclaimed Workstation'}
              </p>
            </div>
          </div>

          <button onClick={onClose} className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="space-y-4">
          {/* Desk Material Theme */}
          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-2">
              Desk Wood & Material Skin
            </label>
            <div className="grid grid-cols-3 gap-2">
              {THEMES.map((t) => (
                <button
                  key={t.id}
                  onClick={() => setTheme(t.id)}
                  className={`flex items-center space-x-2 p-2.5 rounded-xl border text-xs text-left transition-all ${
                    theme === t.id ? 'border-amber-500 bg-amber-500/10 text-white font-bold' : 'border-slate-800 bg-slate-950/50 text-slate-400'
                  }`}
                >
                  <span className="w-4 h-4 rounded-full border border-slate-700 shrink-0" style={{ backgroundColor: t.color }} />
                  <span className="truncate">{t.name}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Desk Equipment Gear */}
          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-2">
              Desk Equipment Gear
            </label>
            <div className="grid grid-cols-1 gap-2">
              {GEAR_OPTIONS.map((g) => (
                <button
                  key={g.id}
                  onClick={() => setGear(g.id)}
                  className={`flex items-center justify-between p-3 rounded-xl border text-left transition-all ${
                    gear === g.id ? 'border-amber-500 bg-amber-500/10 text-white font-bold' : 'border-slate-800 bg-slate-950/50 text-slate-400'
                  }`}
                >
                  <div className="flex items-center space-x-3">
                    <div className={`p-2 rounded-lg ${gear === g.id ? 'bg-amber-500/20 text-amber-400' : 'bg-slate-900 text-slate-400'}`}>
                      {g.icon}
                    </div>
                    <div>
                      <p className="text-sm text-white">{g.name}</p>
                      <p className="text-xs text-slate-400 font-normal">{g.desc}</p>
                    </div>
                  </div>
                  {gear === g.id && <Check className="w-5 h-5 text-amber-400" />}
                </button>
              ))}
            </div>
          </div>

          {/* Status Badge Line */}
          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-1.5">
              Desk Status Plaque Text
            </label>
            <input
              type="text"
              maxLength={24}
              value={status}
              onChange={(e) => setStatus(e.target.value)}
              placeholder="e.g. Deep Work, Coffee break, In Meeting"
              className="w-full px-4 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-white text-sm focus:outline-none focus:border-amber-500"
            />
          </div>
        </div>

        <div className="flex items-center justify-end space-x-3 pt-4 border-t border-slate-800">
          {isOwner && (
            <button
              onClick={handleUnclaim}
              className="px-4 py-2.5 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 border border-rose-500/20 text-sm font-semibold"
            >
              Unclaim Desk
            </button>
          )}

          <button
            onClick={handleSave}
            className="px-6 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-sm shadow-lg shadow-amber-500/20"
          >
            {isOwner ? 'Save Customization' : 'Claim This Desk'}
          </button>
        </div>
      </div>
    </div>
  );
};
