import React, { useState, useEffect, useCallback, useRef } from 'react';
import { Droplet, X, Clock, Check, Sparkles, Sliders } from 'lucide-react';
import { soundEffects } from '../lib/soundEffects';

interface HydrationReminderToastProps {
  onOpenSettings?: () => void;
  onOpenPomodoro?: () => void;
  onRewardXP?: (xp: number) => void;
}

export const HydrationReminderToast: React.FC<HydrationReminderToastProps> = ({
  onOpenSettings,
  onOpenPomodoro,
  onRewardXP,
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [justLoggedDrink, setJustLoggedDrink] = useState(false);
  const [totalDrinksToday, setTotalDrinksToday] = useState<number>(() => {
    try {
      const saved = localStorage.getItem('idlelab_hydration_count_today');
      return saved ? parseInt(saved, 10) : 0;
    } catch {
      return 0;
    }
  });

  const [intervalMins, setIntervalMins] = useState<number>(() => {
    try {
      const saved = localStorage.getItem('idlelab_hydration_interval_mins');
      return saved !== null ? parseInt(saved, 10) : 5; // Default 5 minutes
    } catch {
      return 5;
    }
  });

  const [isEnabled, setIsEnabled] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem('idlelab_hydration_enabled');
      return saved !== null ? saved === 'true' : true;
    } catch {
      return true;
    }
  });

  const [isSoundEnabled, setIsSoundEnabled] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem('idlelab_hydration_sound');
      return saved !== null ? saved === 'true' : true;
    } catch {
      return true;
    }
  });

  const timerRef = useRef<NodeJS.Timeout | null>(null);

  // Sync settings when storage changes or custom event fires
  const syncSettings = useCallback(() => {
    try {
      const savedMins = localStorage.getItem('idlelab_hydration_interval_mins');
      const savedEnabled = localStorage.getItem('idlelab_hydration_enabled');
      const savedSound = localStorage.getItem('idlelab_hydration_sound');

      if (savedMins !== null) setIntervalMins(parseInt(savedMins, 10));
      if (savedEnabled !== null) setIsEnabled(savedEnabled === 'true');
      if (savedSound !== null) setIsSoundEnabled(savedSound === 'true');
    } catch {}
  }, []);

  useEffect(() => {
    const handleSettingsChanged = () => syncSettings();
    window.addEventListener('storage', handleSettingsChanged);
    window.addEventListener('idlelab_hydration_settings_changed', handleSettingsChanged);
    return () => {
      window.removeEventListener('storage', handleSettingsChanged);
      window.removeEventListener('idlelab_hydration_settings_changed', handleSettingsChanged);
    };
  }, [syncSettings]);

  // Main Background Reminder Timer Loop
  const startTimer = useCallback(() => {
    if (timerRef.current) clearTimeout(timerRef.current);
    if (!isEnabled || intervalMins <= 0) return;

    const durationMs = intervalMins * 60 * 1000;
    timerRef.current = setTimeout(() => {
      setIsOpen(true);
      if (isSoundEnabled) {
        soundEffects.playPomodoroChime();
      }
    }, durationMs);
  }, [isEnabled, intervalMins, isSoundEnabled]);

  useEffect(() => {
    startTimer();
    return () => {
      if (timerRef.current) clearTimeout(timerRef.current);
    };
  }, [startTimer]);

  const handleDismiss = () => {
    setIsOpen(false);
    setJustLoggedDrink(false);
    startTimer();
  };

  const handleDrinkLogged = () => {
    const newCount = totalDrinksToday + 1;
    setTotalDrinksToday(newCount);
    try {
      localStorage.setItem('idlelab_hydration_count_today', newCount.toString());
    } catch {}

    setJustLoggedDrink(true);
    soundEffects.playChime();
    if (onRewardXP) onRewardXP(50);

    setTimeout(() => {
      setIsOpen(false);
      setJustLoggedDrink(false);
      startTimer();
    }, 2000);
  };

  const handleSnooze = (minutes: number = 5) => {
    setIsOpen(false);
    if (timerRef.current) clearTimeout(timerRef.current);
    timerRef.current = setTimeout(() => {
      setIsOpen(true);
      if (isSoundEnabled) {
        soundEffects.playPomodoroChime();
      }
    }, minutes * 60 * 1000);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed top-5 right-5 z-[9999] max-w-sm w-full animate-in slide-in-from-top-6 fade-in duration-300 pointer-events-auto">
      <div className="relative p-4 rounded-3xl bg-[#10131c]/95 border border-sky-500/30 shadow-[0_15px_45px_rgba(0,162,255,0.25)] backdrop-blur-xl text-white overflow-hidden">
        {/* Ambient Top Glow */}
        <div className="absolute -top-12 -right-12 w-32 h-32 bg-sky-500/20 rounded-full blur-2xl pointer-events-none" />

        {/* Header Bar */}
        <div className="flex items-start justify-between relative z-10">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-sky-400/20 to-blue-600/30 border border-sky-400/40 flex items-center justify-center text-sky-300 shadow-inner">
              <Droplet className={`w-5 h-5 ${justLoggedDrink ? 'animate-bounce text-emerald-400' : 'animate-pulse text-sky-300'}`} />
            </div>
            <div>
              <div className="flex items-center space-x-1.5">
                <h4 className="text-sm font-bold tracking-tight text-white flex items-center gap-1.5">
                  <span>WisdomWell Hydration Alert</span>
                </h4>
                <span className="text-[10px] bg-sky-500/20 text-sky-300 px-1.5 py-0.5 rounded-full border border-sky-500/30 font-medium">
                  {intervalMins}m loop
                </span>
              </div>
              <p className="text-xs text-neutral-400 mt-0.5">
                {justLoggedDrink ? 'Hydration logged! Great job!' : 'Time to take a sip & rest your eyes.'}
              </p>
            </div>
          </div>

          <button
            onClick={handleDismiss}
            className="p-1.5 rounded-xl bg-white/5 hover:bg-white/15 text-neutral-400 hover:text-white transition-colors cursor-pointer"
            title="Dismiss"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Dynamic Body State */}
        {justLoggedDrink ? (
          <div className="mt-3 p-3 rounded-2xl bg-emerald-500/15 border border-emerald-500/30 flex items-center space-x-2 text-emerald-300 text-xs font-semibold animate-in fade-in">
            <Check className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>Hydration recorded! +50 XP awarded to your wellness score!</span>
          </div>
        ) : (
          <div className="mt-3.5 space-y-2.5 relative z-10">
            <div className="flex items-center justify-between text-[11px] text-neutral-400 px-1">
              <span>Today's Hydration: <strong className="text-sky-300 font-semibold">{totalDrinksToday} cups</strong></span>
              <span className="flex items-center gap-1 text-amber-300 font-medium">
                <Sparkles className="w-3 h-3" /> +50 XP reward
              </span>
            </div>

            {/* Action Buttons */}
            <div className="flex items-center space-x-2">
              <button
                onClick={handleDrinkLogged}
                className="flex-1 py-2 px-3 rounded-xl bg-gradient-to-r from-sky-500 to-blue-600 hover:from-sky-400 hover:to-blue-500 text-white font-semibold text-xs transition-all shadow-md shadow-sky-500/20 flex items-center justify-center space-x-1.5 cursor-pointer"
              >
                <Droplet className="w-3.5 h-3.5" />
                <span>I Drank Water 💧</span>
              </button>

              <button
                onClick={() => handleSnooze(5)}
                className="py-2 px-3 rounded-xl bg-white/10 hover:bg-white/20 text-neutral-300 hover:text-white font-medium text-xs transition-all border border-white/10 flex items-center space-x-1 cursor-pointer"
                title="Remind in 5 minutes"
              >
                <Clock className="w-3.5 h-3.5" />
                <span>Snooze 5m</span>
              </button>
            </div>

            {/* Footer Quick Links */}
            <div className="pt-1 flex items-center justify-between text-[10px] text-neutral-500 px-1">
              {onOpenPomodoro && (
                <button
                  onClick={() => {
                    setIsOpen(false);
                    onOpenPomodoro();
                  }}
                  className="text-neutral-400 hover:text-sky-300 transition-colors cursor-pointer"
                >
                  Open Pomodoro Companion →
                </button>
              )}
              {onOpenSettings && (
                <button
                  onClick={() => {
                    setIsOpen(false);
                    onOpenSettings();
                  }}
                  className="flex items-center gap-1 text-neutral-400 hover:text-sky-300 transition-colors cursor-pointer ml-auto"
                >
                  <Sliders className="w-3 h-3" />
                  <span>Adjust Interval</span>
                </button>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
