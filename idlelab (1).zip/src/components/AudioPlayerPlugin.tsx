import React, { useState, useEffect } from 'react';
import {
  Play,
  Pause,
  SkipForward,
  SkipBack,
  Volume2,
  VolumeX,
  ChevronDown,
  X,
  Radio,
  Disc3,
  Wifi,
  Shuffle,
  Music2,
  Sparkles,
} from 'lucide-react';
import { lofiAudioEngine, AMBIENT_TRACKS, AmbientTrack } from '../lib/lofiAudioEngine';
import { soundEffects } from '../lib/soundEffects';

interface AudioPlayerPluginProps {
  isCompact?: boolean;
}

export const AudioPlayerPlugin: React.FC<AudioPlayerPluginProps> = ({ isCompact = false }) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTrack, setCurrentTrack] = useState<AmbientTrack>(AMBIENT_TRACKS[0]);
  const [volume, setVolume] = useState(0.55);
  const [isMuffled, setIsMuffled] = useState(false);
  const [isStreaming, setIsStreaming] = useState(false);
  const [isExpanded, setIsExpanded] = useState(false);
  const [showTrackList, setShowTrackList] = useState(true);
  const [selectedCategory, setSelectedCategory] = useState<'all' | 'vocal' | 'acoustic' | 'lofi' | 'ambient'>('all');

  useEffect(() => {
    const unsub = lofiAudioEngine.subscribe((playing, track, vol, muffled, streaming) => {
      setIsPlaying(playing);
      setCurrentTrack(track);
      setVolume(vol);
      setIsMuffled(muffled);
      setIsStreaming(streaming);
    });
    return unsub;
  }, []);

  const handleTogglePlay = () => {
    soundEffects.playPop();
    lofiAudioEngine.toggle();
  };

  const handleNext = () => {
    soundEffects.playPop();
    lofiAudioEngine.nextTrack();
  };

  const handlePrev = () => {
    soundEffects.playPop();
    lofiAudioEngine.prevTrack();
  };

  const handleShuffle = () => {
    soundEffects.playPop();
    const randIdx = Math.floor(Math.random() * AMBIENT_TRACKS.length);
    lofiAudioEngine.selectTrack(randIdx);
  };

  const handleSelectTrack = (idx: number) => {
    soundEffects.playPop();
    lofiAudioEngine.selectTrack(idx);
  };

  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = parseFloat(e.target.value);
    setVolume(val);
    lofiAudioEngine.setVolume(val);
  };

  const handleToggleMuffledRadio = () => {
    soundEffects.playPop();
    lofiAudioEngine.toggleMuffledRadio();
  };

  const filteredTracks = selectedCategory === 'all'
    ? AMBIENT_TRACKS
    : AMBIENT_TRACKS.filter((t) => t.category === selectedCategory);

  return (
    <div className="relative select-none text-xs font-sans">
      {/* Mini Control in Header */}
      <div className="flex items-center space-x-1.5 bg-slate-900/95 hover:bg-slate-900 border border-slate-700/80 backdrop-blur-md px-2 py-1 rounded-xl shadow-lg transition-all">
        <button
          onClick={handleTogglePlay}
          className={`p-1.5 rounded-lg transition-all cursor-pointer flex items-center justify-center ${
            isPlaying
              ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/30 font-bold'
              : 'bg-slate-800 hover:bg-slate-700 text-slate-200'
          }`}
          title={isPlaying ? 'Pause Broadcast' : 'Play Pixabay Acoustic Broadcast'}
        >
          {isPlaying ? <Pause className="w-3 h-3 fill-current" /> : <Play className="w-3 h-3 fill-current" />}
        </button>

        <button
          onClick={() => setIsExpanded(!isExpanded)}
          className="flex items-center space-x-1.5 text-slate-200 hover:text-white transition-colors cursor-pointer px-1"
          title="Click to open Acoustic Playlist & Controls"
        >
          <div className="flex items-center space-x-1.5">
            <Disc3 className={`w-3.5 h-3.5 ${isPlaying ? 'text-amber-400 animate-spin' : 'text-slate-400'}`} />
            <span className="font-semibold text-[11px] truncate max-w-[95px] sm:max-w-[130px]">
              {currentTrack.name}
            </span>
          </div>

          {isPlaying && (
            <div className="flex items-end space-x-0.5 h-3">
              <div className="w-0.5 bg-amber-400 h-2.5 animate-bounce" />
              <div className="w-0.5 bg-amber-400 h-3 animate-bounce [animation-delay:0.15s]" />
              <div className="w-0.5 bg-amber-400 h-1.5 animate-bounce [animation-delay:0.3s]" />
            </div>
          )}

          {isMuffled && (
            <span className="text-[9px] bg-amber-500/20 text-amber-300 font-mono px-1 py-0.2 rounded border border-amber-500/30">
              📻
            </span>
          )}

          <ChevronDown className={`w-2.5 h-2.5 transition-transform text-slate-400 ${isExpanded ? 'rotate-180' : ''}`} />
        </button>
      </div>

      {/* Expanded Audio Player Menu */}
      {isExpanded && (
        <div className="absolute top-full right-0 mt-2 w-88 bg-[#0f172a]/98 backdrop-blur-2xl border border-slate-700/90 rounded-2xl shadow-[0_20px_50px_rgba(0,0,0,0.8)] p-3.5 z-50 text-slate-200 space-y-3 animate-in fade-in zoom-in-95 duration-100">
          {/* Header */}
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <div className="flex items-center space-x-2">
              <div className="w-7 h-7 rounded-lg bg-amber-500/20 border border-amber-500/30 flex items-center justify-center text-amber-400">
                <Radio className="w-4 h-4" />
              </div>
              <div>
                <div className="font-bold text-white text-xs flex items-center space-x-1.5">
                  <span> Music Plugin </span>
                  <span className="text-[9px] px-1.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 font-mono flex items-center space-x-1">
                    <Wifi className="w-2.5 h-2.5" />
                    <span>HD Live</span>
                  </span>
                </div>
                <div className="text-[10px] text-slate-400">Royalty-Free Acoustic Guitar, Piano & Strings</div>
              </div>
            </div>

            <button
              onClick={() => setIsExpanded(false)}
              className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 cursor-pointer"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Current Track Info */}
          <div className="p-2.5 rounded-xl bg-slate-800/80 border border-slate-700/60 space-y-1 shadow-inner">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-1.5 truncate">
                <span className="font-bold text-amber-300 text-xs truncate">{currentTrack.name}</span>
              </div>
              <span className="text-[9px] uppercase px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-300 font-mono border border-amber-500/30 shrink-0">
                {currentTrack.instrument}
              </span>
            </div>
            <div className="flex items-center justify-between text-[10px] text-slate-400">
              <span>{currentTrack.artist || 'Pixabay Music'}</span>
              <span className="font-mono text-slate-500">{currentTrack.bpm} BPM</span>
            </div>
            <p className="text-[10px] text-slate-400 leading-relaxed pt-0.5">{currentTrack.description}</p>
          </div>

          {/* Transport Controls & Crossfader */}
          <div className="flex items-center justify-between px-2 pt-1">
            <button
              onClick={handleShuffle}
              className="p-2 rounded-xl bg-slate-800/60 hover:bg-slate-800 text-slate-400 hover:text-amber-300 cursor-pointer transition-colors"
              title="Shuffle Track"
            >
              <Shuffle className="w-3.5 h-3.5" />
            </button>

            <div className="flex items-center space-x-3">
              <button
                onClick={handlePrev}
                className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white cursor-pointer transition-colors"
                title="Previous Track (300ms Crossfade)"
              >
                <SkipBack className="w-4 h-4" />
              </button>

              <button
                onClick={handleTogglePlay}
                className={`p-3 rounded-2xl transition-all cursor-pointer ${
                  isPlaying
                    ? 'bg-gradient-to-r from-amber-500 to-amber-400 text-slate-950 shadow-lg shadow-amber-500/30 font-bold scale-105'
                    : 'bg-slate-800 hover:bg-slate-700 text-white'
                }`}
                title={isPlaying ? 'Pause' : 'Play'}
              >
                {isPlaying ? <Pause className="w-4 h-4 fill-current" /> : <Play className="w-4 h-4 fill-current" />}
              </button>

              <button
                onClick={handleNext}
                className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white cursor-pointer transition-colors"
                title="Next Track (300ms Crossfade)"
              >
                <SkipForward className="w-4 h-4" />
              </button>
            </div>

            <button
              onClick={handleToggleMuffledRadio}
              className={`p-2 rounded-xl border text-[10px] font-bold transition-all cursor-pointer ${
                isMuffled
                  ? 'bg-amber-500/20 text-amber-300 border-amber-500/40 shadow-sm'
                  : 'bg-slate-800/60 text-slate-400 border-slate-700 hover:text-slate-200'
              }`}
              title="Low-Pass Filter (1.2kHz Muffled Warmth)"
            >
              📻 {isMuffled ? '1.2k' : 'HiFi'}
            </button>
          </div>

          {/* Master Volume Gain Slider */}
          <div className="flex items-center space-x-2 pt-1 border-t border-slate-800">
            {volume === 0 ? (
              <VolumeX className="w-3.5 h-3.5 text-slate-400 shrink-0" />
            ) : (
              <Volume2 className="w-3.5 h-3.5 text-amber-400 shrink-0" />
            )}
            <input
              type="range"
              min="0"
              max="1"
              step="0.02"
              value={volume}
              onChange={handleVolumeChange}
              className="w-full h-1.5 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-amber-400"
            />
            <span className="text-[10px] text-slate-400 font-mono w-7 text-right">
              {Math.round(volume * 100)}%
            </span>
          </div>

          {/* Acoustic Category Filter Tabs */}
          <div className="space-y-1.5 pt-1 border-t border-slate-800">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                Pixabay Acoustic Playlist ({AMBIENT_TRACKS.length})
              </span>
              <span className="text-[9px] text-amber-400 font-medium">Auto-Cycle On</span>
            </div>

            <div className="flex items-center space-x-1 overflow-x-auto pb-1 no-scrollbar text-[10px]">
              {[
                { id: 'all', label: 'All Tracks' },
                { id: 'vocal', label: '🎙️ Singing' },
                { id: 'acoustic', label: '🎸 Acoustic' },
                { id: 'lofi', label: '☕ Lo-Fi' },
                { id: 'ambient', label: '🌊 Ambient' },
              ].map((cat) => (
                <button
                  key={cat.id}
                  onClick={() => setSelectedCategory(cat.id as any)}
                  className={`px-2 py-0.5 rounded-lg whitespace-nowrap transition-all cursor-pointer ${
                    selectedCategory === cat.id
                      ? 'bg-amber-500 text-slate-950 font-bold shadow-sm'
                      : 'bg-slate-800/80 hover:bg-slate-800 text-slate-300'
                  }`}
                >
                  {cat.label}
                </button>
              ))}
            </div>

            {/* Track Selection Switcher Drawer */}
            <div className="space-y-1 max-h-44 overflow-y-auto pr-1">
              {filteredTracks.map((t) => {
                const originalIndex = AMBIENT_TRACKS.findIndex((x) => x.id === t.id);
                const isCurrent = currentTrack.id === t.id;
                return (
                  <button
                    key={t.id}
                    onClick={() => handleSelectTrack(originalIndex)}
                    className={`w-full text-left p-2 rounded-xl flex items-center justify-between transition-all cursor-pointer ${
                      isCurrent
                        ? 'bg-amber-500/20 border border-amber-500/40 text-amber-200 font-bold shadow-sm'
                        : 'bg-slate-800/60 hover:bg-slate-800 text-slate-300 border border-transparent'
                    }`}
                  >
                    <div className="truncate pr-2 flex-1">
                      <div className="text-[11px] truncate flex items-center space-x-1.5">
                        {isCurrent && <span className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-pulse shrink-0" />}
                        <span className="truncate">{t.name}</span>
                      </div>
                      <div className="text-[9px] text-slate-400 flex items-center space-x-1.5 mt-0.5">
                        <span>{t.artist}</span>
                        <span>·</span>
                        <span className="text-slate-500">{t.instrument}</span>
                      </div>
                    </div>
                    <span className="text-[9px] text-amber-400 font-mono bg-slate-900/80 px-1.5 py-0.5 rounded shrink-0 border border-white/5">
                      {t.bpm} BPM
                    </span>
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
