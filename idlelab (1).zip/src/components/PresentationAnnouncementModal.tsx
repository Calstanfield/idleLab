import React, { useState } from 'react';
import {
  Monitor,
  Megaphone,
  Share2,
  Tv,
  X,
  Play,
  Sparkles,
  Layers,
  Radio,
  Clock,
  Check,
} from 'lucide-react';

interface PresentationAnnouncementModalProps {
  isOpen: boolean;
  onClose: () => void;
  onStartScreenShare: () => void;
  onBroadcastAnnouncement?: (title: string, message: string) => void;
  isScreenSharing: boolean;
}

const PRESET_ANNOUNCEMENTS = [
  {
    id: 'ann-1',
    title: '🚀 Q3 All-Hands Engineering Sprint Demo',
    body: 'Team showcase in B1 Main Open Collaboration Hall. Presenting 3D spatial audio, WebRTC clusters, and latency benchmarks.',
    author: 'VP of Engineering',
    time: 'Today at 4:30 PM',
  },
  {
    id: 'ann-2',
    title: '🎉 Production v2.8 Deployed with Zero Downtime',
    body: 'US-East1 Kubernetes nodes transitioned successfully. Check Grafana & Data Center links for live latency metrics.',
    author: 'DevOps Pod',
    time: '15 mins ago',
  },
  {
    id: 'ann-3',
    title: '☕ Robotic Barista Specialty Single-Origin Roast Online',
    body: 'Fresh Colombian Supremo and Nitro Cold Brew now ready at the B1 Robotic Arm Station. Stop by for caffeine buffs!',
    author: 'Office Ops',
    time: '1 hour ago',
  },
];

export function PresentationAnnouncementModal({
  isOpen,
  onClose,
  onStartScreenShare,
  onBroadcastAnnouncement,
  isScreenSharing,
}: PresentationAnnouncementModalProps) {
  const [announcements, setAnnouncements] = useState(PRESET_ANNOUNCEMENTS);
  const [customTitle, setCustomTitle] = useState('');
  const [customBody, setCustomBody] = useState('');
  const [isBroadcasting, setIsBroadcasting] = useState(false);
  const [broadcastSuccess, setBroadcastSuccess] = useState(false);

  if (!isOpen) return null;

  const handleBroadcast = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customTitle.trim() || !customBody.trim()) return;

    const newAnn = {
      id: `ann-${Date.now()}`,
      title: customTitle.trim(),
      body: customBody.trim(),
      author: 'You (Presenter)',
      time: 'Just now',
    };

    setAnnouncements([newAnn, ...announcements]);
    if (onBroadcastAnnouncement) {
      onBroadcastAnnouncement(customTitle.trim(), customBody.trim());
    }

    setIsBroadcasting(false);
    setBroadcastSuccess(true);
    setCustomTitle('');
    setCustomBody('');
    setTimeout(() => setBroadcastSuccess(false), 3000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-200">
      <div
        id="presentation-modal-card"
        className="relative w-full max-w-2xl max-h-[90vh] flex flex-col bg-slate-900 border border-slate-700/80 rounded-2xl shadow-[0_25px_60px_-15px_rgba(0,0,0,0.9)] overflow-hidden"
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-950/60">
          <div className="flex items-center space-x-3">
            <div className="p-2.5 rounded-xl bg-purple-500/10 border border-purple-500/30 text-purple-400">
              <Monitor className="w-6 h-6 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h2 className="text-lg font-bold text-slate-100 tracking-tight">
                  B1 Presentation & Announcement Video Wall
                </h2>
                <span className="px-2 py-0.5 rounded-full bg-purple-500/10 border border-purple-500/30 text-[11px] font-semibold text-purple-400">
                  8K LED Display Wall
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Broadcast announcements or share your live screen across the main B1 monitor.
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-slate-800/80 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Action Hero Bar: Screen Share */}
        <div className="p-5 bg-gradient-to-r from-purple-950/30 via-slate-900 to-indigo-950/30 border-b border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center space-x-3.5">
            <div className="p-3 rounded-xl bg-purple-500/20 text-purple-300 border border-purple-500/30">
              <Tv className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-100">
                {isScreenSharing ? 'Live Screen Share Active' : 'Start Presentation Screen Cast'}
              </h3>
              <p className="text-xs text-slate-400">
                {isScreenSharing
                  ? 'Your screen is streaming live on the B1 Huge Monitor Wall.'
                  : 'Stream slides, browser tabs, Figma, or code directly to the 3D room display.'}
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={() => {
              onStartScreenShare();
              onClose();
            }}
            className={`flex items-center space-x-2 px-5 py-2.5 rounded-xl text-xs font-bold transition-all shadow-lg active:scale-95 cursor-pointer whitespace-nowrap ${
              isScreenSharing
                ? 'bg-rose-600 hover:bg-rose-500 text-white shadow-rose-900/30'
                : 'bg-purple-600 hover:bg-purple-500 text-white shadow-purple-900/30'
            }`}
          >
            <Share2 className="w-4 h-4" />
            <span>{isScreenSharing ? 'Stop Screen Share' : 'Cast Screen to Wall'}</span>
          </button>
        </div>

        {/* Content: Broadcast Announcements List & Form */}
        <div className="flex-1 overflow-y-auto p-6 space-y-4 max-h-[420px]">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center space-x-1.5">
              <Megaphone className="w-3.5 h-3.5 text-purple-400" />
              <span>Live Room Announcements & Schedule</span>
            </span>

            <button
              type="button"
              onClick={() => setIsBroadcasting(!isBroadcasting)}
              className="text-xs text-purple-400 hover:text-purple-300 font-semibold cursor-pointer"
            >
              {isBroadcasting ? 'Cancel' : '+ Broadcast Announcement'}
            </button>
          </div>

          {broadcastSuccess && (
            <div className="p-3 rounded-xl bg-emerald-950/30 border border-emerald-500/40 text-xs text-emerald-300 flex items-center space-x-2">
              <Check className="w-4 h-4 text-emerald-400" />
              <span>Announcement broadcasted to the B1 Monitor Screen!</span>
            </div>
          )}

          {isBroadcasting && (
            <form
              onSubmit={handleBroadcast}
              className="p-4 bg-slate-950/90 border border-purple-500/40 rounded-xl space-y-3 animate-in slide-in-from-top duration-200"
            >
              <div>
                <label className="block text-[11px] font-medium text-slate-300 mb-1">
                  Headline / Title *
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Design Critique at 3:00 PM"
                  value={customTitle}
                  onChange={(e) => setCustomTitle(e.target.value)}
                  className="w-full px-3 py-1.5 bg-slate-900 border border-slate-700 rounded-lg text-xs text-slate-200 focus:outline-none focus:border-purple-500"
                />
              </div>

              <div>
                <label className="block text-[11px] font-medium text-slate-300 mb-1">
                  Message Details *
                </label>
                <textarea
                  rows={2}
                  required
                  placeholder="Details for employees and attendees..."
                  value={customBody}
                  onChange={(e) => setCustomBody(e.target.value)}
                  className="w-full px-3 py-1.5 bg-slate-900 border border-slate-700 rounded-lg text-xs text-slate-200 focus:outline-none focus:border-purple-500"
                />
              </div>

              <div className="flex justify-end space-x-2">
                <button
                  type="button"
                  onClick={() => setIsBroadcasting(false)}
                  className="px-3 py-1.5 bg-slate-800 text-slate-300 text-xs font-medium rounded-lg"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold rounded-lg shadow-md"
                >
                  Publish to Monitor
                </button>
              </div>
            </form>
          )}

          {/* Announcement Cards */}
          <div className="space-y-3">
            {announcements.map((ann) => (
              <div
                key={ann.id}
                className="p-4 rounded-xl bg-slate-950/40 border border-slate-800 space-y-1.5"
              >
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-bold text-slate-100">{ann.title}</h4>
                  <span className="text-[10px] text-slate-500 flex items-center space-x-1">
                    <Clock className="w-2.5 h-2.5" />
                    <span>{ann.time}</span>
                  </span>
                </div>
                <p className="text-xs text-slate-300 leading-relaxed">{ann.body}</p>
                <div className="text-[10px] text-purple-400/80 font-medium">
                  Posted by {ann.author}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between px-6 py-3 border-t border-slate-800 bg-slate-950/60 text-xs text-slate-400">
          <span>Synced with B1 3D Screen Mesh display</span>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold rounded-lg transition-colors cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
}
