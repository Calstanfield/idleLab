import React, { useEffect, useRef, useState } from 'react';
import {
  Maximize2,
  Minimize2,
  Minus,
  ChevronUp,
  Monitor,
  Volume2,
  VolumeX,
  X,
  Sparkles,
} from 'lucide-react';
import { soundEffects } from '../lib/soundEffects';

interface ScreenShareOverlayProps {
  isOpen: boolean;
  onClose: () => void;
  stream: MediaStream | null;
  screenFrame?: string | null;
  presenterName?: string;
  onStopShare?: () => void;
  onStartScreenShare?: () => void;
}

export const ScreenShareOverlay: React.FC<ScreenShareOverlayProps> = ({
  isOpen,
  onClose,
  stream,
  screenFrame,
  presenterName = 'You',
  onStopShare,
  onStartScreenShare,
}) => {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const [isExpanded, setIsExpanded] = useState(false);
  const [isMinimized, setIsMinimized] = useState(false);
  const [isAudioMuted, setIsAudioMuted] = useState(true);

  const hasAudioTrack = Boolean(stream && stream.getAudioTracks().length > 0);
  const hasActiveScreenContent = Boolean(stream || screenFrame);

  useEffect(() => {
    if (videoRef.current && stream) {
      videoRef.current.srcObject = stream;
    }
  }, [stream, isMinimized]);

  if (!isOpen) return null;

  // Compact floating pill bar when mini tab is minimized/hidden during stream
  if (isMinimized) {
    return (
      <div className="fixed bottom-24 right-6 z-50 flex items-center space-x-2 bg-[#121216]/95 backdrop-blur-2xl border border-sky-500/40 rounded-full px-3.5 py-2 shadow-[0_15px_35px_rgba(0,0,0,0.85)] animate-in fade-in slide-in-from-bottom-2 duration-200">
        <div className="flex items-center space-x-2 text-xs font-semibold text-white">
          <span className="relative flex h-2.5 w-2.5 shrink-0">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
            <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500" />
          </span>
          <Monitor className="w-3.5 h-3.5 text-sky-400 shrink-0" />
          <span className="truncate max-w-[140px] sm:max-w-[200px]">
            Screen Share: <span className="text-sky-300 font-bold">{presenterName}</span>
          </span>
        </div>

        {hasAudioTrack && (
          <button
            onClick={() => {
              setIsAudioMuted(!isAudioMuted);
              soundEffects.playPop();
            }}
            className={`p-1 rounded-lg transition-colors cursor-pointer ${
              isAudioMuted ? 'text-neutral-400 hover:text-white bg-white/5' : 'text-emerald-400 bg-emerald-500/20'
            }`}
            title={isAudioMuted ? 'Unmute Stream Audio' : 'Mute Stream Audio'}
          >
            {isAudioMuted ? <VolumeX className="w-3.5 h-3.5" /> : <Volume2 className="w-3.5 h-3.5" />}
          </button>
        )}

        <button
          onClick={() => {
            setIsMinimized(false);
            soundEffects.playPop();
          }}
          className="flex items-center space-x-1 px-2.5 py-1 rounded-full bg-sky-500/20 hover:bg-sky-500/30 text-sky-300 text-xs font-semibold border border-sky-500/40 transition-colors cursor-pointer"
          title="Open Mini Tab Preview"
        >
          <ChevronUp className="w-3.5 h-3.5" />
          <span>Open Mini Tab</span>
        </button>

        {onStopShare && (
          <button
            onClick={() => {
              onStopShare();
              soundEffects.playPop();
            }}
            className="p-1 rounded-full bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 text-xs font-semibold border border-rose-500/40 transition-colors cursor-pointer"
            title="Stop Screen Share"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        )}

        {/* Hidden video element to keep stream active while mini tab is hidden */}
        {stream && (
          <video
            ref={videoRef}
            autoPlay
            playsInline
            muted={isAudioMuted}
            className="hidden"
          />
        )}
      </div>
    );
  }

  return (
    <div
      className={`fixed z-50 transition-all duration-300 ${
        isExpanded
          ? 'inset-6 bg-[#121216]/98 backdrop-blur-2xl border border-white/15 rounded-3xl p-5 flex flex-col shadow-[0_25px_60px_rgba(0,0,0,0.95)]'
          : 'bottom-24 right-6 w-96 md:w-[32rem] lg:w-[36rem] bg-[#121216]/98 backdrop-blur-2xl border border-white/15 rounded-2xl overflow-hidden shadow-[0_20px_50px_rgba(0,0,0,0.85)]'
      }`}
    >
      {/* Top Header Bar */}
      <div className="flex items-center justify-between p-3 bg-white/5 border-b border-white/10 text-xs font-semibold text-neutral-200">
        <div className="flex items-center space-x-2">
          <div className="p-1.5 rounded-xl bg-sky-500/20 text-sky-400 border border-sky-500/30">
            <Monitor className="w-4 h-4 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center space-x-1.5">
              <span className="font-bold text-white">Live Screen Share</span>
              <span className="text-[10px] bg-emerald-500/20 text-emerald-300 px-2 py-0.5 rounded-full border border-emerald-500/30">
                {presenterName}
              </span>
            </div>
            <p className="text-[10px] text-neutral-400">Broadcasting active workspace display</p>
          </div>
        </div>

        <div className="flex items-center space-x-1.5">
          {hasAudioTrack && (
            <button
              onClick={() => {
                setIsAudioMuted(!isAudioMuted);
                soundEffects.playPop();
              }}
              className={`p-1.5 rounded-lg transition-colors cursor-pointer ${
                isAudioMuted ? 'text-neutral-400 hover:text-white bg-white/5' : 'text-emerald-400 bg-emerald-500/20 border border-emerald-500/30'
              }`}
              title={isAudioMuted ? 'Unmute Stream Audio' : 'Mute Stream Audio'}
            >
              {isAudioMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
            </button>
          )}

          {onStopShare && (
            <button
              onClick={onStopShare}
              className="px-2.5 py-1 rounded-lg bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 text-xs font-semibold border border-rose-500/40 transition-colors cursor-pointer"
            >
              Stop Sharing
            </button>
          )}

          <button
            onClick={() => {
              setIsMinimized(true);
              soundEffects.playPop();
            }}
            className="p-1.5 rounded-lg text-neutral-400 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
            title="Hide Mini Tab (Stream continues in background)"
          >
            <Minus className="w-4 h-4" />
          </button>

          <button
            onClick={() => setIsExpanded(!isExpanded)}
            className="p-1.5 rounded-lg text-neutral-400 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
            title={isExpanded ? 'Restore View' : 'Fullscreen View'}
          >
            {isExpanded ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
          </button>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-neutral-400 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
            title="Close Panel"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Main Viewport Content */}
      <div
        className={`relative bg-black/90 flex-1 overflow-hidden flex flex-col items-center justify-center ${
          isExpanded ? 'h-full min-h-[400px]' : 'h-64 md:h-72'
        }`}
      >
        <div className="w-full h-full flex items-center justify-center">
          {stream ? (
            <video
              ref={videoRef}
              autoPlay
              playsInline
              muted={isAudioMuted}
              onLoadedMetadata={() => {
                videoRef.current?.play().catch(() => {});
              }}
              className="w-full h-full object-contain"
            />
          ) : screenFrame ? (
            <img
              src={screenFrame}
              alt="Screen Share Projection"
              className="w-full h-full object-contain"
            />
          ) : (
            <div className="p-6 text-center flex flex-col items-center justify-center space-y-3 text-neutral-400">
              <div className="p-3 rounded-2xl bg-white/5 border border-white/10 text-sky-400">
                <Monitor className="w-8 h-8 opacity-80" />
              </div>
              <div>
                <div className="text-sm font-bold text-neutral-200">No Active Screen Stream</div>
                <div className="text-xs text-neutral-400 mt-1 max-w-xs">
                  Click the "Share Screen" button in the bottom control bar to begin broadcasting your screen or browser tab.
                </div>
              </div>
              {onStartScreenShare && (
                <button
                  onClick={onStartScreenShare}
                  className="px-4 py-2 rounded-xl bg-sky-500 hover:bg-sky-600 text-white font-bold text-xs shadow-lg transition-all cursor-pointer"
                >
                  Start Screen Share
                </button>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Bottom Status Bar */}
      <div className="p-3 bg-[#161822] border-t border-white/10 flex items-center justify-between text-xs text-neutral-400">
        <span>{hasActiveScreenContent ? `${presenterName} • HD Stream Active` : 'Ready to broadcast'}</span>
        <span className="text-[10px] text-sky-400 font-mono">IdleLab Secure WebRTC</span>
      </div>
    </div>
  );
};
