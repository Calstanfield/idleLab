import React, { useState, useEffect } from 'react';
import { GestureType } from '../types';
import { Sparkles, X, ChevronUp, ChevronDown } from 'lucide-react';

interface GestureEmojiBarProps {
  onPerformGesture: (gesture: GestureType) => void;
  onSendEmojiReaction: (emoji: string, gesture?: GestureType) => void;
}

const AVATAR_EMOTES: Array<{
  num: number;
  gesture: GestureType;
  label: string;
  emoji: string;
  svgIcon: React.ReactNode;
}> = [
  {
    num: 1,
    gesture: 'wave',
    label: 'Wave',
    emoji: '👋',
    svgIcon: (
      <svg className="w-6 h-6 fill-current" viewBox="0 0 24 24">
        <path d="M12 2a2 2 0 012 2v7.5a.5.5 0 001 0V4a2 2 0 014 0v9a7 7 0 01-14 0V8a2 2 0 014 0v3.5a.5.5 0 001 0V3a2 2 0 012-1z" />
      </svg>
    ),
  },
  {
    num: 2,
    gesture: 'dance',
    label: 'Dance',
    emoji: '🎉',
    svgIcon: (
      <svg className="w-6 h-6 fill-current" viewBox="0 0 24 24">
        <path d="M12 2a2 2 0 100 4 2 2 0 000-4zm-3 7a1 1 0 00-1 1v5a1 1 0 002 0v-2h1v6a1 1 0 002 0v-4h2v4a1 1 0 002 0v-6h1v2a1 1 0 002 0v-5a1 1 0 00-1-1H9z" />
      </svg>
    ),
  },
  {
    num: 3,
    gesture: 'clap',
    label: 'Clap',
    emoji: '👏',
    svgIcon: (
      <svg className="w-6 h-6 fill-current" viewBox="0 0 24 24">
        <path d="M18 7a2 2 0 00-2 2v5a1 1 0 01-2 0V5a2 2 0 00-4 0v7a1 1 0 01-2 0V8a2 2 0 00-4 0v8a6 6 0 0012 0V9a2 2 0 00-2-2z" />
      </svg>
    ),
  },
  {
    num: 4,
    gesture: 'think',
    label: 'Point / Think',
    emoji: '🤔',
    svgIcon: (
      <svg className="w-6 h-6 fill-current" viewBox="0 0 24 24">
        <path d="M4 11a2 2 0 012-2h8a1 1 0 000-2H6a4 4 0 00-4 4v2a4 4 0 004 4h8a2 2 0 002-2v-4a2 2 0 00-2-2H6a2 2 0 01-2-2z" />
      </svg>
    ),
  },
  {
    num: 5,
    gesture: 'bow',
    label: 'Bow / Respect',
    emoji: '🙇',
    svgIcon: (
      <svg className="w-6 h-6 fill-current" viewBox="0 0 24 24">
        <path d="M12 2a2 2 0 100 4 2 2 0 000-4zm-4 6a1 1 0 00-1 1v4a1 1 0 001 1h8a1 1 0 001-1V9a1 1 0 00-1-1H8zm1 7v5a1 1 0 002 0v-5H9zm4 0v5a1 1 0 002 0v-5h-2z" />
      </svg>
    ),
  },
  {
    num: 6,
    gesture: 'cheer',
    label: 'Cheer',
    emoji: '🔥',
    svgIcon: (
      <svg className="w-6 h-6 fill-current" viewBox="0 0 24 24">
        <path d="M12 2a2 2 0 100 4 2 2 0 000-4zm-5 6a1 1 0 00-1 1v3a1 1 0 002 0V9a1 1 0 00-1-1zm10 0a1 1 0 00-1 1v3a1 1 0 002 0V9a1 1 0 00-1-1zm-6 2a1 1 0 00-1 1v8a1 1 0 002 0v-8a1 1 0 00-1-1z" />
      </svg>
    ),
  },
  {
    num: 7,
    gesture: 'heart',
    label: 'Heart',
    emoji: '❤️',
    svgIcon: (
      <svg className="w-6 h-6 fill-current" viewBox="0 0 24 24">
        <path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z" />
      </svg>
    ),
  },
  {
    num: 8,
    gesture: 'facepalm',
    label: 'Facepalm',
    emoji: '🤦',
    svgIcon: (
      <svg className="w-6 h-6 fill-current" viewBox="0 0 24 24">
        <path d="M12 2a2 2 0 100 4 2 2 0 000-4zm-6 5a2 2 0 00-2 2v3a2 2 0 002 2h2v6a1 1 0 002 0v-8H8V9a1 1 0 011-1h6a1 1 0 011 1v3h-2v8a1 1 0 002 0v-6h2a2 2 0 002-2V9a2 2 0 00-2-2H6z" />
      </svg>
    ),
  },
];

export const GestureEmojiBar: React.FC<GestureEmojiBarProps> = ({
  onPerformGesture,
  onSendEmojiReaction,
}) => {
  const [isOpen, setIsOpen] = useState<boolean>(false);
  const [hoveredEmote, setHoveredEmote] = useState<number | null>(null);

  const handleEmoteClick = (emote: typeof AVATAR_EMOTES[0]) => {
    onPerformGesture(emote.gesture);
    onSendEmojiReaction(emote.emoji, emote.gesture);
    setIsOpen(false);
  };

  const handleDebugAll = () => {
    setIsOpen(false);
    AVATAR_EMOTES.forEach((emote, idx) => {
      setTimeout(() => {
        onPerformGesture(emote.gesture);
        onSendEmojiReaction(emote.emoji, emote.gesture);
      }, idx * 1500);
    });
  };

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (['INPUT', 'TEXTAREA'].includes((e.target as HTMLElement)?.tagName)) return;
      const num = parseInt(e.key, 10);
      if (num >= 1 && num <= 8) {
        const found = AVATAR_EMOTES.find((m) => m.num === num);
        if (found) {
          onPerformGesture(found.gesture);
          onSendEmojiReaction(found.emoji, found.gesture);
        }
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [onPerformGesture, onSendEmojiReaction]);

  return (
    <div className="fixed bottom-20 left-1/2 -translate-x-1/2 z-50 flex flex-col items-center pointer-events-auto select-none">
      {/* Semi-Translucent Radial Emote Wheel */}
      {isOpen && (
        <div className="relative mb-3 w-[290px] h-[290px] sm:w-[320px] sm:h-[320px] flex items-center justify-center animate-in zoom-in-95 duration-150">
          {/* Radial Wheel Background Outer Ring */}
          <div className="absolute inset-0 rounded-full bg-slate-950/65 backdrop-blur-md border border-slate-700/60 shadow-[0_0_50px_rgba(0,0,0,0.6)] overflow-hidden">
            {/* 8 Radial Divider Lines */}
            <svg className="absolute inset-0 w-full h-full stroke-slate-500/40" viewBox="0 0 100 100">
              <line x1="50" y1="0" x2="50" y2="100" strokeWidth="0.5" />
              <line x1="0" y1="50" x2="100" y2="50" strokeWidth="0.5" />
              <line x1="14.6" y1="14.6" x2="85.4" y2="85.4" strokeWidth="0.5" />
              <line x1="85.4" y1="14.6" x2="14.6" y2="85.4" strokeWidth="0.5" />
            </svg>
          </div>

          {/* 8 Radial Slice Buttons */}
          {AVATAR_EMOTES.map((emote, idx) => {
            const angles = [270, 315, 0, 45, 90, 135, 180, 225];
            const angle = angles[idx];
            const radiusPercent = 38;
            const x = 50 + radiusPercent * Math.cos((angle * Math.PI) / 180);
            const y = 50 + radiusPercent * Math.sin((angle * Math.PI) / 180);

            const isHovered = hoveredEmote === emote.num;

            return (
              <button
                key={emote.num}
                onClick={() => handleEmoteClick(emote)}
                onMouseEnter={() => setHoveredEmote(emote.num)}
                onMouseLeave={() => setHoveredEmote(null)}
                style={{
                  left: `${x}%`,
                  top: `${y}%`,
                  transform: 'translate(-50%, -50%)',
                }}
                className={`absolute z-20 flex flex-col items-center justify-center transition-all duration-150 cursor-pointer ${
                  isHovered ? 'scale-125 text-white filter drop-shadow-[0_0_12px_rgba(56,189,248,0.8)]' : 'text-slate-300 opacity-90'
                }`}
                title={`Press ${emote.num}: ${emote.label}`}
              >
                <div className={`p-2 rounded-full transition-colors ${isHovered ? 'bg-sky-500/30' : ''}`}>
                  {emote.svgIcon}
                </div>
                <span className="text-[13px] font-black text-white tracking-widest drop-shadow">
                  {emote.num}
                </span>
              </button>
            );
          })}

          {/* Center Hub Circle ("Select an Emote") */}
          <div className="absolute z-30 w-32 h-32 sm:w-36 sm:h-36 rounded-full bg-[#18181b]/90 border border-slate-600/80 shadow-2xl flex flex-col items-center justify-center p-2 text-center">
            <span className="text-white font-black text-xs sm:text-sm tracking-wide leading-tight">
              {hoveredEmote
                ? AVATAR_EMOTES.find((m) => m.num === hoveredEmote)?.label
                : 'Select an Emote'}
            </span>
            <span className="text-[10px] text-slate-400 mt-1 font-mono">
              Press 1 - 8
            </span>
            <button
              onClick={() => setIsOpen(false)}
              className="mt-1.5 p-1 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      )}

      {/* Trigger Button Pill */}
      <div className="flex items-center space-x-2 px-3 py-1.5 bg-slate-900/85 border border-slate-700/80 rounded-full shadow-2xl backdrop-blur-md">
        <button
          onClick={() => setIsOpen(!isOpen)}
          className={`flex items-center space-x-1.5 px-3 py-1 rounded-full text-xs font-bold transition-all cursor-pointer ${
            isOpen
              ? 'bg-[#0c8ce9] text-white shadow-lg shadow-sky-600/40'
              : 'bg-slate-800/90 hover:bg-slate-700 text-slate-200'
          }`}
        >
          <Sparkles className="w-3.5 h-3.5 text-amber-400" />
          <span>Avatar Emotes</span>
          {isOpen ? <ChevronDown className="w-3.5 h-3.5" /> : <ChevronUp className="w-3.5 h-3.5" />}
        </button>

        <div className="h-4 w-px bg-slate-700/60" />

        <div className="flex items-center space-x-1">
          {AVATAR_EMOTES.slice(0, 5).map((e) => (
            <button
              key={e.num}
              onClick={() => handleEmoteClick(e)}
              className="px-2 py-0.5 rounded-md hover:bg-slate-800 text-xs font-bold text-slate-300 hover:text-white transition-all cursor-pointer"
              title={`${e.num}: ${e.label}`}
            >
              {e.emoji}
            </button>
          ))}
          <button
            onClick={handleDebugAll}
            className="px-2 py-0.5 rounded-md bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 text-xs font-bold transition-all cursor-pointer border border-amber-500/30"
            title="Debug / Test All Emotes"
          >
            🛠️ Debug
          </button>
        </div>
      </div>
    </div>
  );
};
