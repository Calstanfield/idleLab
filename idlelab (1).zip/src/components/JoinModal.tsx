import React, { useState, useEffect } from 'react';
import { AvatarSkin, Department } from '../types';
import {
  User,
  Building,
  Play,
  Palette,
  Check,
  Sparkles,
  ArrowRight,
  ArrowLeft,
  Sliders,
  ShieldCheck,
  Globe,
  Radio,
  Quote,
  Compass,
  AlertTriangle,
  Info,
  ChevronRight,
  ChevronLeft,
  Flame,
  Lightbulb,
} from 'lucide-react';
import { Avatar3DPreview } from './Avatar3DPreview';
import goldenGateImgUrl from '../assets/images/golden_gate_pixel_1786433260687.jpg';

interface JoinModalProps {
  onJoin: (
    name: string,
    skin: AvatarSkin,
    department: Department,
    ethnicity?: string,
    hairColor?: string,
    hoodieColor?: string,
    pantsColor?: string,
    shoesColor?: string,
    capColor?: string,
    scarfColor?: string
  ) => void;
}

export const SKIN_TONE_OPTIONS = [
  { id: 'east_asian_1', name: 'Ivory', color: '#fde2cd' },
  { id: 'caucasian_1', name: 'Porcelain', color: '#ffd8c9' },
  { id: 'latino_1', name: 'Golden', color: '#e2a26f' },
  { id: 'mixed_1', name: 'Amber', color: '#d9945c' },
  { id: 'south_asian_1', name: 'Caramel', color: '#b06c3b' },
  { id: 'black_1', name: 'Bronze', color: '#603417' },
  { id: 'black_2', name: 'Deep', color: '#3c1e0c' },
];

export const HAIR_COLOR_OPTIONS = [
  { name: 'Espresso', hex: '#0f0f11', color: '#0f0f11' },
  { name: 'Chestnut', hex: '#1c120c', color: '#3d2010' },
  { name: 'Caramel', hex: '#5c2b0e', color: '#854317' },
  { name: 'Blonde', hex: '#c89849', color: '#fde047' },
  { name: 'Auburn', hex: '#882e10', color: '#c2410c' },
  { name: 'Lilac', hex: '#9333ea', color: '#d8b4fe' },
  { name: 'Cyber Rose', hex: '#db2777', color: '#f472b6' },
  { name: 'Silver', hex: '#94a3b8', color: '#f1f5f9' },
];

export const HOODIE_COLOR_PALETTES = [
  { name: 'Sunset Orange', hex: '#ea580c' },
  { name: 'Electric Cyan', hex: '#06b6d4' },
  { name: 'Indigo Blue', hex: '#4f46e5' },
  { name: 'Cobalt Blue', hex: '#2563eb' },
  { name: 'Emerald Green', hex: '#16a34a' },
  { name: 'Hot Pink', hex: '#ec4899' },
  { name: 'Royal Purple', hex: '#9333ea' },
  { name: 'Crimson Red', hex: '#dc2626' },
  { name: 'Golden Amber', hex: '#eab308' },
  { name: 'Midnight Charcoal', hex: '#334155' },
  { name: 'Mint Teal', hex: '#0d9488' },
  { name: 'Pure White', hex: '#f8fafc' },
];

export const JEANS_COLOR_PALETTES = [
  { name: 'Classic Blue', hex: '#1d4ed8' },
  { name: 'Midnight Black', hex: '#18181b' },
  { name: 'Dark Indigo', hex: '#1e1b4b' },
  { name: 'Faded Denim', hex: '#3b82f6' },
  { name: 'Khaki Beige', hex: '#d97706' },
  { name: 'Slate Gray', hex: '#475569' },
  { name: 'Olive Green', hex: '#3f6212' },
  { name: 'Charcoal Wash', hex: '#334155' },
];

export const SNEAKER_COLOR_PALETTES = [
  { name: 'Crisp White', hex: '#ffffff' },
  { name: 'Classic Red', hex: '#dc2626' },
  { name: 'Triple Black', hex: '#18181b' },
  { name: 'Electric Cyan', hex: '#06b6d4' },
  { name: 'Volt Lime', hex: '#84cc16' },
  { name: 'Solar Yellow', hex: '#eab308' },
  { name: 'Royal Purple', hex: '#9333ea' },
  { name: 'Hot Orange', hex: '#ea580c' },
];

// Curated Baseball Cap Palette - Excludes Green for Asian cultural etiquette
export const BASEBALL_CAP_PALETTES = [
  { name: 'Crisp White', hex: '#ffffff' },
  { name: 'Stealth Black', hex: '#18181b' },
  { name: 'Vintage Navy', hex: '#1e3a8a' },
  { name: 'Crimson Red', hex: '#dc2626' },
  { name: 'Amber Gold', hex: '#d97706' },
  { name: 'Royal Purple', hex: '#7e22ce' },
  { name: 'Cyber Blue', hex: '#0284c7' },
  { name: 'Slate Gray', hex: '#64748b' },
  { name: 'Hot Orange', hex: '#ea580c' },
  { name: 'Rose Pink', hex: '#ec4899' },
  { name: 'Charcoal Wash', hex: '#334155' },
];

/**
 * Checks whether a hex color lies in the green hue spectrum.
 * In Asian / Chinese culture, 'wearing a green hat' (戴绿帽子) is a cultural taboo.
 */
export function isGreenTone(hex: string): boolean {
  if (!hex || typeof hex !== 'string') return false;
  let cleanHex = hex.trim().replace('#', '');
  if (cleanHex.length === 3) {
    cleanHex = cleanHex.split('').map((c) => c + c).join('');
  }
  if (cleanHex.length !== 6) return false;
  const num = parseInt(cleanHex, 16);
  if (isNaN(num)) return false;
  const r = (num >> 16) & 255;
  const g = (num >> 8) & 255;
  const b = num & 255;

  const max = Math.max(r, g, b);
  const min = Math.min(r, g, b);
  const d = max - min;
  if (d === 0) return false;

  let h = 0;
  if (max === r) {
    h = ((g - b) / d) % 6;
  } else if (max === g) {
    h = (b - r) / d + 2;
  } else {
    h = (r - g) / d + 4;
  }
  h = Math.round(h * 60);
  if (h < 0) h += 360;

  const s = max === 0 ? 0 : d / max;
  const v = max / 255;

  // Hue between 65° (yellow-green) and 165° (green-cyan) with saturation > 18% and brightness > 15%
  return h >= 65 && h <= 165 && s > 0.18 && v > 0.15;
}

export interface WisdomFactItem {
  id: string;
  type: 'sf_fact' | 'quote';
  title: string;
  authorOrTopic: string;
  content: string;
  badge: string;
  tagline: string;
}

export const SF_FACTS_AND_WISDOM: WisdomFactItem[] = [
  {
    id: 'edison_perseverance',
    type: 'quote',
    title: 'Genius & Perseverance',
    authorOrTopic: 'Thomas Edison',
    content: '“Our greatest weakness lies in giving up. The most certain way to succeed is always to try just one more time. Genius is 1% inspiration and 99% perspiration.”',
    badge: 'Innovation',
    tagline: 'Short Motivational Poem & Creed',
  },
  {
    id: 'lao_tze_journey',
    type: 'quote',
    title: 'The Way & The Step',
    authorOrTopic: 'Lao Tzu (老子)',
    content: '“A journey of a thousand miles begins with a single step. Nature does not hurry, yet everything is accomplished. Master others and you are strong; master yourself and you are true power.”',
    badge: 'Eastern Wisdom',
    tagline: 'Tao Te Ching Reflection',
  },
  {
    id: 'sf_golden_gate',
    type: 'sf_fact',
    title: 'International Orange',
    authorOrTopic: 'San Francisco Fact',
    content: 'The Golden Gate Bridge was originally planned by the U.S. Navy to have black and yellow stripes for visibility. Consulting architect Irving Morrow chose "International Orange" to glow against SF’s rolling Pacific fog.',
    badge: 'SF History',
    tagline: 'Bay Area Engineering Marvel',
  },
  {
    id: 'washington_perseverance',
    type: 'quote',
    title: 'Steadfast Character',
    authorOrTopic: 'George Washington',
    content: '“Perseverance and spirit have done wonders in all ages. Let your heart feel for the distress of everyone, and let your hand give in proportion to your purse. Character is forged in quiet resolve.”',
    badge: 'Leadership',
    tagline: 'Timeless American Wisdom',
  },
  {
    id: 'sf_cable_cars',
    type: 'sf_fact',
    title: 'Moving National Monument',
    authorOrTopic: 'San Francisco Fact',
    content: 'San Francisco operates the world’s only manually operated cable car transit network. Designated an official National Historic Landmark in 1964, its gripmen control the 9.5 mph steel cables purely by hand.',
    badge: 'SF Transit',
    tagline: 'Living Historic Landmark',
  },
  {
    id: 'sf_fortune_cookie',
    type: 'sf_fact',
    title: 'Birthplace of the Fortune Cookie',
    authorOrTopic: 'San Francisco Fact',
    content: 'The modern fortune cookie was popularized in San Francisco in the 1890s at the Japanese Tea Garden in Golden Gate Park by landscape designer Makoto Hagiwara, before spreading across global Chinatown culture.',
    badge: 'SF Culture',
    tagline: 'Golden Gate Park Tradition',
  },
  {
    id: 'emerson_trail',
    type: 'quote',
    title: 'Trailblazer Spirit',
    authorOrTopic: 'Ralph Waldo Emerson',
    content: '“Do not go where the path may lead; go instead where there is no path and leave a trail. What lies behind us and what lies before us are tiny matters compared to what lies within us.”',
    badge: 'Poetry & Vision',
    tagline: 'Transcendentalist Verse',
  },
  {
    id: 'sf_fog_karl',
    type: 'sf_fact',
    title: 'The Legendary Fog (Karl)',
    authorOrTopic: 'San Francisco Fact',
    content: 'San Francisco’s legendary sea fog creates its famous microclimates — temperatures can differ by up to 15°F between Ocean Beach and the Mission District on the exact same afternoon.',
    badge: 'SF Microclimates',
    tagline: 'Pacific Ocean Breeze',
  },
];

const GENDER_OPTIONS: Array<{
  id: AvatarSkin;
  name: string;
  desc: string;
  gender: 'male' | 'female';
  defaultHoodie: string;
}> = [
  {
    id: 'college_dev_m',
    name: 'Male',
    desc: 'Classic Cap & Headphones',
    gender: 'male',
    defaultHoodie: '#ea580c',
  },
  {
    id: 'college_dev_f',
    name: 'Female',
    desc: 'Beanie & Headset',
    gender: 'female',
    defaultHoodie: '#06b6d4',
  },
];

const DEPARTMENTS: Array<{ name: Department; desc: string }> = [
  { name: 'Engineering', desc: 'Code & Architecture' },
  { name: 'Design', desc: 'UI/UX & 3D Assets' },
  { name: 'Product', desc: 'Roadmap & Specs' },
  { name: 'Marketing', desc: 'Growth & Outreach' },
  { name: 'Executive', desc: 'Strategy & Ops' },
  { name: 'Operations', desc: 'Infra & Support' },
];

type OnboardingStep = 'profile' | 'styling' | 'department';

export const JoinModal: React.FC<JoinModalProps> = ({ onJoin }) => {
  const [name, setName] = useState('Benz Carlton');
  const [selectedSkin, setSelectedSkin] = useState<AvatarSkin>('college_dev_m');
  const [selectedDept, setSelectedDept] = useState<Department>('Engineering');
  const [selectedSkinTone, setSelectedSkinTone] = useState<string>('east_asian_1');
  const [selectedHair, setSelectedHair] = useState<string>('#0f0f11');
  const [hoodieColor, setHoodieColor] = useState<string>('#ea580c');
  const [pantsColor, setPantsColor] = useState<string>('#1d4ed8');
  const [shoesColor, setShoesColor] = useState<string>('#dc2626');
  const [capColor, setCapColor] = useState<string>('#ffffff');
  const [scarfColor, setScarfColor] = useState<string>('#dc2626');
  const [currentStep, setCurrentStep] = useState<OnboardingStep>('profile');

  // Green cap taboo warning state & active fact index
  const [greenTabooWarning, setGreenTabooWarning] = useState<string | null>(null);
  const [activeFactIdx, setActiveFactIdx] = useState<number>(0);
  const [isHoveringGreenTaboo, setIsHoveringGreenTaboo] = useState<boolean>(false);

  // Auto-rotate the SF facts & wisdom cards every 5 minutes (300,000 ms)
  useEffect(() => {
    const timer = setInterval(() => {
      setActiveFactIdx((prev) => (prev + 1) % SF_FACTS_AND_WISDOM.length);
    }, 5 * 60 * 1000); // 5 minutes
    return () => clearInterval(timer);
  }, []);

  const handleSkinSelect = (skinId: AvatarSkin) => {
    setSelectedSkin(skinId);
    if (skinId === 'college_dev_f') {
      if (hoodieColor === '#ea580c') setHoodieColor('#06b6d4');
      if (pantsColor === '#1d4ed8') setPantsColor('#18181b');
      if (shoesColor === '#dc2626') setShoesColor('#ffffff');
    } else if (skinId === 'college_dev_m') {
      if (hoodieColor === '#06b6d4') setHoodieColor('#ea580c');
      if (pantsColor === '#18181b') setPantsColor('#1d4ed8');
      if (shoesColor === '#ffffff') setShoesColor('#dc2626');
    }
  };

  const handleCapColorChange = (newHex: string) => {
    if (isGreenTone(newHex)) {
      setGreenTabooWarning(
        "🚫 Cultural Taboo: In East Asian and Chinese traditions, 'wearing a green hat' (戴绿帽子) symbolizes an unfaithful partner. Green caps are excluded to maintain cultural etiquette."
      );
      // Auto-clear notice after 6 seconds
      setTimeout(() => setGreenTabooWarning(null), 6000);
      return;
    }
    setGreenTabooWarning(null);
    setCapColor(newHex);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      setCurrentStep('profile');
      return;
    }
    onJoin(
      name.trim(),
      selectedSkin,
      selectedDept,
      selectedSkinTone,
      selectedHair,
      hoodieColor,
      pantsColor,
      shoesColor,
      capColor,
      scarfColor
    );
  };

  const currentFact = SF_FACTS_AND_WISDOM[activeFactIdx];

  const stepsList: Array<{ id: OnboardingStep; label: string; num: string }> = [
    { id: 'profile', label: 'Identity', num: '01' },
    { id: 'styling', label: 'Avatar Styling', num: '02' },
    { id: 'department', label: 'Department', num: '03' },
  ];

  return (
    <div id="join-onboarding-modal" className="fixed inset-0 z-50 min-h-screen bg-slate-950 text-slate-100 overflow-hidden flex flex-col font-sans">
      <div className="grid grid-cols-1 lg:grid-cols-12 flex-1 w-full h-full overflow-hidden">
        {/* Left Canvas: Live 3D Interactive Avatar Preview Arena + SF Facts & Wisdom Ticker (7 cols) */}
        <div className="lg:col-span-7 relative flex flex-col justify-between border-b lg:border-b-0 lg:border-r border-slate-800/80 p-4 sm:p-6 overflow-hidden bg-slate-950">
          {/* Pixelated San Francisco Golden Gate Sunset Background Asset Layer */}
          <div className="absolute inset-0 overflow-hidden pointer-events-none select-none">
            <img
              src={goldenGateImgUrl}
              alt="San Francisco Sunset Pixel Art"
              className="w-full h-full object-cover object-center scale-105 filter brightness-95 contrast-105"
              style={{ imageRendering: 'pixelated' }}
            />
            {/* Friendly Warm Sunset Ambiance & Atmospheric Depth Gradient Overlays */}
            <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/45 to-slate-950/65" />
            <div className="absolute inset-0 bg-gradient-to-r from-amber-500/15 via-rose-500/10 to-indigo-950/50 mix-blend-color-dodge" />
            <div className="absolute inset-0 bg-radial-gradient from-transparent via-slate-950/20 to-slate-950/80" />
            {/* Subtle retro pixel scanline / grid texture */}
            <div
              className="absolute inset-0 opacity-15"
              style={{
                backgroundImage:
                  'linear-gradient(rgba(255, 255, 255, 0.05) 1px, transparent 1px), linear-gradient(90deg, rgba(255, 255, 255, 0.05) 1px, transparent 1px)',
                backgroundSize: '24px 24px',
              }}
            />
          </div>

          {/* Top Brand Header */}
          <div className="relative z-10 flex items-center justify-between">
            <div className="flex items-center space-x-3">
              {/* Official Original 4-Color Cluster Logo */}
              <div className="w-9 h-9 rounded-xl bg-slate-900/90 border border-white/15 p-2 flex items-center justify-center shadow-xl shadow-indigo-950/40 backdrop-blur-md">
                <div className="w-5 h-5 grid grid-cols-2 gap-1">
                  <div className="w-2 h-2 rounded-[3px] bg-rose-500 shadow-sm shadow-rose-500/50" />
                  <div className="w-2 h-2 rounded-[3px] bg-amber-500 shadow-sm shadow-amber-500/50" />
                  <div className="w-2 h-2 rounded-[3px] bg-purple-500 shadow-sm shadow-purple-500/50" />
                  <div className="w-2 h-2 rounded-[3px] bg-sky-500 shadow-sm shadow-sky-500/50" />
                </div>
              </div>
              <div>
                <h1 className="text-base sm:text-lg font-bold text-white tracking-tight drop-shadow-md">IdleLab Workspace</h1>
                <p className="text-xs text-amber-100/70 drop-shadow">Interactive 3D Virtual Office by Benz-Carlton</p>
              </div>
            </div>

            <div className="hidden sm:flex items-center space-x-2 text-[11px] font-mono text-amber-300/90 bg-slate-950/70 px-3 py-1 rounded-full border border-amber-500/30 backdrop-blur-md">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <span>San Francisco Server</span>
            </div>
          </div>

          {/* Center 3D Interactive Character Arena */}
          <div className="relative z-10 flex-1 my-1 flex items-center justify-center min-h-[280px] sm:min-h-[340px]">
            <div className="w-full h-full max-w-xl aspect-square flex items-center justify-center relative">
              <Avatar3DPreview
                skin={selectedSkin}
                hoodieColor={hoodieColor}
                hairColor={selectedHair}
                skinTone={selectedSkinTone}
                name={name}
                pantsColor={pantsColor}
                shoesColor={shoesColor}
                capColor={capColor}
                scarfColor={scarfColor}
              />
            </div>
          </div>

          {/* Bottom Onboarding Spotlight: San Francisco Facts & Motivational Quotes Carousel */}
          <div className="relative z-10 w-full mt-2">
            <div className="p-3.5 sm:p-4 rounded-2xl bg-slate-950/75 border border-amber-500/25 backdrop-blur-xl shadow-xl transition-all duration-300 relative overflow-hidden group">
              {/* Top Row: Tag / Author & Nav Controls */}
              <div className="flex items-center justify-between mb-1.5">
                <div className="flex items-center space-x-2">
                  <span className="p-1 rounded-lg bg-amber-500/20 text-amber-300 border border-amber-500/40">
                    {currentFact.type === 'quote' ? (
                      <Quote className="w-3.5 h-3.5" />
                    ) : (
                      <Compass className="w-3.5 h-3.5" />
                    )}
                  </span>
                  <span className="text-xs font-bold text-amber-200 tracking-wide">
                    {currentFact.authorOrTopic}
                  </span>
                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-amber-400/15 text-amber-300 border border-amber-400/25 font-mono">
                    {currentFact.badge}
                  </span>
                </div>

                {/* Carousel Navigation Buttons */}
                <div className="flex items-center space-x-1.5">
                  <span className="text-[10px] font-mono text-slate-400 mr-1">
                    {activeFactIdx + 1}/{SF_FACTS_AND_WISDOM.length}
                  </span>
                  <button
                    type="button"
                    onClick={() =>
                      setActiveFactIdx(
                        (prev) => (prev - 1 + SF_FACTS_AND_WISDOM.length) % SF_FACTS_AND_WISDOM.length
                      )
                    }
                    className="p-1 rounded-lg bg-white/5 hover:bg-white/15 text-slate-300 hover:text-white border border-white/10 transition-all cursor-pointer"
                    title="Previous fact / poem"
                  >
                    <ChevronLeft className="w-3.5 h-3.5" />
                  </button>
                  <button
                    type="button"
                    onClick={() =>
                      setActiveFactIdx((prev) => (prev + 1) % SF_FACTS_AND_WISDOM.length)
                    }
                    className="p-1 rounded-lg bg-white/5 hover:bg-white/15 text-slate-300 hover:text-white border border-white/10 transition-all cursor-pointer"
                    title="Next fact / poem"
                  >
                    <ChevronRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              {/* Fact / Quote Content */}
              <p className="text-xs sm:text-[13px] text-slate-200 leading-relaxed font-normal italic drop-shadow-sm">
                {currentFact.content}
              </p>
              <div className="mt-1 text-[10px] text-slate-400 font-medium tracking-wide">
                {currentFact.tagline}
              </div>
            </div>
          </div>
        </div>

        {/* Right Panel: Onboarding & Configuration Workflow (5 cols) */}
        <div className="lg:col-span-5 flex flex-col h-full bg-slate-900/95 backdrop-blur-xl border-l border-white/10 overflow-hidden">
          {/* Sleek Segmented Tab Bar */}
          <div className="p-4 sm:p-5 border-b border-white/10 shrink-0 bg-slate-950/40">
            <div className="flex p-1 bg-slate-950/80 border border-white/10 rounded-xl shadow-inner">
              {stepsList.map((step) => {
                const isActive = currentStep === step.id;
                return (
                  <button
                    key={step.id}
                    type="button"
                    onClick={() => setCurrentStep(step.id)}
                    className={`flex-1 flex items-center justify-center space-x-1.5 py-2 px-2 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                      isActive
                        ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/40'
                        : 'text-slate-400 hover:text-white hover:bg-white/5'
                    }`}
                  >
                    <span
                      className={`text-[10px] font-mono px-1.5 py-0.5 rounded ${
                        isActive ? 'bg-white/20 text-white' : 'text-slate-500'
                      }`}
                    >
                      {step.num}
                    </span>
                    <span>{step.label}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Form Scroll Container */}
          <form
            id="onboarding-form"
            onSubmit={handleSubmit}
            className="flex-1 overflow-y-auto p-5 sm:p-6 space-y-6"
          >
            {/* Step 1: Identity & Gender Profile */}
            {currentStep === 'profile' && (
              <div className="space-y-5 animate-fadeIn">
                <div className="space-y-1">
                  <h2 className="text-lg font-bold text-white tracking-tight">Welcome to IdleLab Office</h2>
                  <p className="text-xs text-slate-400">
                    Set your display name and choose your mascot archetype to get started.
                  </p>
                </div>

                {/* Display Name Input */}
                <div className="space-y-2">
                  <label
                    htmlFor="user-display-name"
                    className="block text-xs font-semibold uppercase tracking-wider text-slate-300"
                  >
                    Display Name <span className="text-rose-400">*</span>
                  </label>
                  <div className="relative">
                    <input
                      id="user-display-name"
                      type="text"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter' && name.trim()) {
                          e.preventDefault();
                          setCurrentStep('styling');
                        }
                      }}
                      placeholder="e.g. Californian Roll, Fortune Cookie"
                      maxLength={24}
                      autoFocus
                      className="w-full px-4 py-3 bg-slate-950/70 border border-white/10 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20 text-sm font-medium transition-all"
                    />
                    <div className="absolute right-3 top-3 text-slate-500 text-xs font-mono">
                      {name.length}/24
                    </div>
                  </div>
                </div>

                {/* Select Gender (Male / Female with Logo Icons) */}
                <div className="space-y-3 pt-1">
                  <div className="flex items-center justify-between">
                    <label className="block text-xs font-semibold uppercase tracking-wider text-slate-300">
                      Select Gender
                    </label>
                    <span className="text-[11px] text-slate-400">Customizable anytime later</span>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    {GENDER_OPTIONS.map((opt) => {
                      const isSelected = selectedSkin === opt.id;
                      const isMale = opt.gender === 'male';
                      return (
                        <button
                          key={opt.id}
                          type="button"
                          onClick={() => handleSkinSelect(opt.id)}
                          className={`p-4 rounded-2xl border text-left transition-all cursor-pointer relative overflow-hidden backdrop-blur-sm ${
                            isSelected
                              ? isMale
                                ? 'bg-blue-600/15 border-blue-500 text-white ring-2 ring-blue-500 shadow-[0_0_20px_rgba(59,130,246,0.3)]'
                                : 'bg-pink-600/15 border-pink-500 text-white ring-2 ring-pink-500 shadow-[0_0_20px_rgba(236,72,153,0.3)]'
                              : 'bg-white/[0.03] border-white/10 text-slate-300 hover:border-white/20'
                          }`}
                        >
                          <div className="flex items-center justify-between mb-2">
                            <div
                              className={`w-9 h-9 rounded-xl flex items-center justify-center border shadow-inner ${
                                isMale
                                  ? 'bg-blue-500/20 border-blue-500/40 text-blue-400'
                                  : 'bg-pink-500/20 border-pink-500/40 text-pink-400'
                              }`}
                            >
                              {isMale ? (
                                <svg
                                  className="w-5 h-5"
                                  viewBox="0 0 24 24"
                                  fill="none"
                                  stroke="currentColor"
                                  strokeWidth="2.5"
                                  strokeLinecap="round"
                                  strokeLinejoin="round"
                                >
                                  <circle cx="10" cy="14" r="5" />
                                  <path d="M19 5L13.5 10.5" />
                                  <path d="M14 5h5v5" />
                                </svg>
                              ) : (
                                <svg
                                  className="w-5 h-5"
                                  viewBox="0 0 24 24"
                                  fill="none"
                                  stroke="currentColor"
                                  strokeWidth="2.5"
                                  strokeLinecap="round"
                                  strokeLinejoin="round"
                                >
                                  <circle cx="12" cy="9" r="5" />
                                  <path d="M12 14v7" />
                                  <path d="M9 18h6" />
                                </svg>
                              )}
                            </div>

                            {isSelected && (
                              <span
                                className={`w-5 h-5 rounded-full flex items-center justify-center text-white shadow-md ${
                                  isMale ? 'bg-blue-500' : 'bg-pink-500'
                                }`}
                              >
                                <Check className="w-3 h-3 stroke-[3]" />
                              </span>
                            )}
                          </div>
                          <div className="text-sm font-bold text-white flex items-center space-x-1.5">
                            <span>{opt.name}</span>
                            <span
                              className={`text-[10px] px-1.5 py-0.2 rounded font-mono ${
                                isMale
                                  ? 'bg-blue-500/20 text-blue-300'
                                  : 'bg-pink-500/20 text-pink-300'
                              }`}
                            >
                              {isMale ? 'He/Him' : 'She/Her'}
                            </span>
                          </div>
                          <div className="text-[11px] text-slate-400 mt-1 leading-relaxed">{opt.desc}</div>
                        </button>
                      );
                    })}
                  </div>

                  {/* Aftermath Customization Tip Notice */}
                  <div className="p-3 rounded-xl bg-slate-900/60 border border-white/10 flex items-start space-x-2.5 text-xs text-slate-300">
                    <Sparkles className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                    <p className="text-[11px] leading-relaxed text-slate-300">
                      <span className="font-semibold text-white">Aftermath Customization:</span> Full wardrobe, cap colors, hoodie styling, complexion tones, and sneakers can be modified anytime later inside <span className="text-amber-300 font-medium">Settings → Profile</span> or by clicking your avatar in-office.
                    </p>
                  </div>
                </div>

                <div className="pt-2 flex items-center justify-between">
                  <div className="text-[11px] text-slate-400">
                    {name.trim() ? (
                      <span className="text-emerald-400 flex items-center space-x-1 font-medium">
                        <Check className="w-3.5 h-3.5 stroke-[3]" />
                        <span>Display name ready</span>
                      </span>
                    ) : (
                      <span className="text-slate-500">Insert your name to proceed</span>
                    )}
                  </div>
                  <button
                    type="button"
                    disabled={!name.trim()}
                    onClick={() => {
                      if (name.trim()) setCurrentStep('styling');
                    }}
                    className={`flex items-center space-x-2 px-5 py-2.5 rounded-xl font-bold text-xs transition-all cursor-pointer ${
                      name.trim()
                        ? 'bg-gradient-to-r from-emerald-500 to-green-600 hover:from-emerald-400 hover:to-green-500 text-white shadow-lg shadow-emerald-600/35 border border-emerald-400/40 active:scale-[0.98]'
                        : 'bg-white/5 text-slate-500 border border-white/10 opacity-50 cursor-not-allowed'
                    }`}
                  >
                    <span>Next</span>
                    <ArrowRight className="w-3.5 h-3.5 stroke-[2.5]" />
                  </button>
                </div>
              </div>
            )}

            {/* Step 2: Avatar Styling (Baseball Cap, Hoodie, Skin Tone, Hair, Pants, Shoes) */}
            {currentStep === 'styling' && (
              <div className="space-y-4 animate-fadeIn">
                <div className="space-y-1">
                  <h2 className="text-lg font-bold text-white tracking-tight">Customize Avatar Appearance</h2>
                  <p className="text-xs text-slate-400">
                    Fine-tune your baseball cap, hoodie color, complexion, and sneaker style in real-time.
                  </p>
                </div>

                {/* Baseball Cap Color Swatches (With Green Taboo Notice) */}
                <div className="bg-slate-950/40 border border-white/10 rounded-2xl p-4 transition-all space-y-2.5">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-semibold uppercase tracking-wider text-slate-300 flex items-center space-x-1.5">
                      <span className="text-sm">🧢</span>
                      <span>Baseball Cap Color</span>
                    </label>
                    <span className="text-[11px] font-mono text-slate-400 uppercase">{capColor}</span>
                  </div>

                  <div className="grid grid-cols-6 gap-2">
                    {BASEBALL_CAP_PALETTES.map((swatch) => {
                      const isActive = capColor.toLowerCase() === swatch.hex.toLowerCase();
                      return (
                        <button
                          key={swatch.hex}
                          type="button"
                          onClick={() => handleCapColorChange(swatch.hex)}
                          className={`relative w-8 h-8 rounded-xl flex items-center justify-center border transition-all cursor-pointer ${
                            isActive
                              ? 'border-indigo-400 ring-2 ring-indigo-500 ring-offset-2 ring-offset-slate-900 scale-105 shadow-md z-10'
                              : 'border-white/10 hover:scale-105 hover:border-white/30'
                          }`}
                          style={{ backgroundColor: swatch.hex }}
                          title={`${swatch.name} (${swatch.hex})`}
                        >
                          {isActive && (
                            <Check
                              className={`w-3.5 h-3.5 stroke-[3] ${
                                ['#ffffff', '#fef3c7', '#d97706'].includes(swatch.hex)
                                  ? 'text-slate-950'
                                  : 'text-white'
                              }`}
                            />
                          )}
                        </button>
                      );
                    })}

                    {/* Excluded Green Taboo Button Swatch */}
                    <button
                      type="button"
                      onMouseEnter={() => setIsHoveringGreenTaboo(true)}
                      onMouseLeave={() => setIsHoveringGreenTaboo(false)}
                      onClick={() => {
                        setGreenTabooWarning(
                          "🚫 Green Hat Cultural Taboo: In East Asian and Chinese culture, 'wearing a green hat' (戴绿帽子) is a recognized cultural taboo symbolizing an unfaithful partner. Green caps are excluded to maintain cultural etiquette."
                        );
                      }}
                      className="relative w-8 h-8 rounded-xl flex items-center justify-center border border-emerald-500/40 bg-emerald-700/40 text-emerald-300 opacity-60 hover:opacity-100 hover:scale-105 hover:border-rose-400 hover:bg-rose-950/40 transition-all cursor-not-allowed group"
                      title="Green Cap Excluded (Asian Cultural Taboo)"
                    >
                      <span className="text-xs font-bold text-rose-400 group-hover:scale-110 transition-transform">
                        🚫
                      </span>
                    </button>
                  </div>

                  {/* Cultural Taboo Hover / Trigger Info Banner */}
                  {(isHoveringGreenTaboo || greenTabooWarning) && (
                    <div className="p-3 rounded-xl bg-amber-950/40 border border-amber-500/30 flex items-start space-x-2 text-xs text-amber-200 animate-fadeIn">
                      <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                      <div className="space-y-0.5">
                        <span className="font-semibold text-amber-300 block">Green Hat Cultural Taboo (戴绿帽子)</span>
                        <p className="text-[11px] leading-relaxed text-amber-200/90">
                          {greenTabooWarning ||
                            "In East Asian culture, 'wearing a green hat' carries a significant cultural taboo regarding infidelity. Green caps are purposefully excluded from the headwear options."}
                        </p>
                      </div>
                    </div>
                  )}

                  {/* Custom Hex Selector with Taboo Guard */}
                  <div className="flex items-center space-x-2 pt-2 border-t border-white/5">
                    <span className="text-[11px] text-slate-400">Custom Cap:</span>
                    <div className="flex items-center space-x-1.5">
                      <input
                        type="color"
                        value={capColor}
                        onChange={(e) => handleCapColorChange(e.target.value)}
                        className="w-6 h-6 rounded-md border border-white/20 bg-transparent cursor-pointer p-0"
                      />
                      <input
                        type="text"
                        value={capColor}
                        onChange={(e) => handleCapColorChange(e.target.value)}
                        placeholder="#ffffff"
                        className="px-2 py-0.5 bg-slate-950/70 border border-white/10 rounded-lg text-[11px] font-mono text-white w-20 focus:outline-none focus:border-indigo-400 focus:ring-1 focus:ring-indigo-500/25"
                      />
                    </div>
                  </div>
                </div>

                {/* Knitted Scarf Swatches */}
                <div className="bg-slate-950/40 border border-white/10 rounded-2xl p-4 transition-all space-y-2.5">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-semibold uppercase tracking-wider text-slate-300 flex items-center space-x-1.5">
                      <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                      <span>Knitted Scarf Color</span>
                    </label>
                    <span className="text-[11px] font-mono text-slate-400 uppercase">{scarfColor}</span>
                  </div>

                  <div className="grid grid-cols-6 gap-2">
                    {[
                      { name: 'Crimson Red', hex: '#dc2626' },
                      { name: 'Royal Blue', hex: '#2563eb' },
                      { name: 'Emerald Green', hex: '#16a34a' },
                      { name: 'Warm Mustard', hex: '#d97706' },
                      { name: 'Cosmopolitan Pink', hex: '#db2777' },
                      { name: 'Plum Violet', hex: '#7c3aed' },
                      { name: 'Cozy Cream', hex: '#fef3c7' },
                      { name: 'Midnight Charcoal', hex: '#374151' },
                      { name: 'Snow White', hex: '#ffffff' },
                      { name: 'Cyan Breeze', hex: '#0891b2' },
                      { name: 'Amber Sunset', hex: '#f97316' },
                      { name: 'Forest Teal', hex: '#0d9488' },
                    ].map((swatch) => {
                      const isActive = scarfColor.toLowerCase() === swatch.hex.toLowerCase();
                      return (
                        <button
                          key={swatch.hex}
                          type="button"
                          onClick={() => setScarfColor(swatch.hex)}
                          className={`relative w-8 h-8 rounded-xl flex items-center justify-center border transition-all cursor-pointer ${
                            isActive
                              ? 'border-amber-400 ring-2 ring-amber-500 ring-offset-2 ring-offset-slate-900 scale-105 shadow-md z-10'
                              : 'border-white/10 hover:scale-105 hover:border-white/30'
                          }`}
                          style={{ backgroundColor: swatch.hex }}
                          title={`${swatch.name} (${swatch.hex})`}
                        >
                          {isActive && (
                            <Check className={`w-3.5 h-3.5 stroke-[3] ${['#fef3c7', '#ffffff'].includes(swatch.hex) ? 'text-slate-950' : 'text-white'}`} />
                          )}
                        </button>
                      );
                    })}
                  </div>

                  <div className="flex items-center space-x-2 pt-2 border-t border-white/5">
                    <span className="text-[11px] text-slate-400">Custom Scarf:</span>
                    <div className="flex items-center space-x-1.5">
                      <input
                        type="color"
                        value={scarfColor}
                        onChange={(e) => setScarfColor(e.target.value)}
                        className="w-6 h-6 rounded-md border border-white/20 bg-transparent cursor-pointer p-0"
                      />
                      <input
                        type="text"
                        value={scarfColor}
                        onChange={(e) => setScarfColor(e.target.value)}
                        placeholder="#dc2626"
                        className="px-2 py-0.5 bg-slate-950/70 border border-white/10 rounded-lg text-[11px] font-mono text-white w-20 focus:outline-none focus:border-amber-400 focus:ring-1 focus:ring-amber-500/25"
                      />
                    </div>
                  </div>
                </div>

                {/* Hoodie Swatches */}
                <div className="bg-slate-950/40 border border-white/10 rounded-2xl p-4 transition-all space-y-2.5">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-semibold uppercase tracking-wider text-slate-300 flex items-center space-x-1.5">
                      <Palette className="w-3.5 h-3.5 text-indigo-400" />
                      <span>Hoodie Color</span>
                    </label>
                    <span className="text-[11px] font-mono text-slate-400 uppercase">{hoodieColor}</span>
                  </div>

                  <div className="grid grid-cols-6 gap-2">
                    {HOODIE_COLOR_PALETTES.map((swatch) => {
                      const isActive = hoodieColor.toLowerCase() === swatch.hex.toLowerCase();
                      return (
                        <button
                          key={swatch.hex}
                          type="button"
                          onClick={() => setHoodieColor(swatch.hex)}
                          className={`relative w-8 h-8 rounded-xl flex items-center justify-center border transition-all cursor-pointer ${
                            isActive
                              ? 'border-indigo-400 ring-2 ring-indigo-500 ring-offset-2 ring-offset-slate-900 scale-105 shadow-md z-10'
                              : 'border-white/10 hover:scale-105 hover:border-white/30'
                          }`}
                          style={{ backgroundColor: swatch.hex }}
                          title={`${swatch.name} (${swatch.hex})`}
                        >
                          {isActive && (
                            <Check
                              className={`w-3.5 h-3.5 stroke-[3] ${
                                ['#f8fafc', '#eab308'].includes(swatch.hex) ? 'text-slate-950' : 'text-white'
                              }`}
                            />
                          )}
                        </button>
                      );
                    })}
                  </div>

                  {/* Custom Hex Selector */}
                  <div className="flex items-center space-x-2 pt-2 border-t border-white/5">
                    <span className="text-[11px] text-slate-400">Custom Color:</span>
                    <div className="flex items-center space-x-1.5">
                      <input
                        type="color"
                        value={hoodieColor}
                        onChange={(e) => setHoodieColor(e.target.value)}
                        className="w-6 h-6 rounded-md border border-white/20 bg-transparent cursor-pointer p-0"
                      />
                      <input
                        type="text"
                        value={hoodieColor}
                        onChange={(e) => setHoodieColor(e.target.value)}
                        placeholder="#4f46e5"
                        className="px-2 py-0.5 bg-slate-950/70 border border-white/10 rounded-lg text-[11px] font-mono text-white w-20 focus:outline-none focus:border-indigo-400 focus:ring-1 focus:ring-indigo-500/25"
                      />
                    </div>
                  </div>
                </div>

                {/* Skin Tone Swatches */}
                <div className="bg-slate-950/40 border border-white/10 rounded-2xl p-4 transition-all space-y-2">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-semibold uppercase tracking-wider text-slate-300">
                      Skin Tone
                    </label>
                    <span className="text-xs text-slate-400 font-medium">
                      {SKIN_TONE_OPTIONS.find((s) => s.id === selectedSkinTone)?.name || 'Shade'}
                    </span>
                  </div>
                  <div className="grid grid-cols-7 gap-1.5">
                    {SKIN_TONE_OPTIONS.map((tone) => {
                      const isActive = selectedSkinTone === tone.id;
                      return (
                        <button
                          key={tone.id}
                          type="button"
                          onClick={() => setSelectedSkinTone(tone.id)}
                          className={`group flex flex-col items-center p-1.5 rounded-xl border transition-all cursor-pointer ${
                            isActive
                              ? 'bg-indigo-600/20 border-indigo-500 text-white ring-2 ring-indigo-500'
                              : 'bg-white/[0.02] border-white/10 text-slate-400 hover:border-white/20'
                          }`}
                          title={tone.name}
                        >
                          <span
                            className="w-5 h-5 rounded-full border border-white/20 shadow-sm flex items-center justify-center shrink-0 mb-1"
                            style={{ backgroundColor: tone.color }}
                          >
                            {isActive && <Check className="w-3 h-3 text-slate-900 stroke-[3]" />}
                          </span>
                          <span className="text-[9px] font-medium leading-none truncate w-full text-center">
                            {tone.name}
                          </span>
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Hair Color Swatches */}
                <div className="bg-slate-950/40 border border-white/10 rounded-2xl p-4 transition-all space-y-2">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-semibold uppercase tracking-wider text-slate-300">
                      Hair Color
                    </label>
                    <span className="text-xs text-slate-400 font-medium">
                      {HAIR_COLOR_OPTIONS.find((h) => h.hex === selectedHair)?.name || 'Hair'}
                    </span>
                  </div>
                  <div className="grid grid-cols-4 sm:grid-cols-8 gap-1.5">
                    {HAIR_COLOR_OPTIONS.map((hair) => {
                      const isActive = selectedHair === hair.hex;
                      return (
                        <button
                          key={hair.hex}
                          type="button"
                          onClick={() => setSelectedHair(hair.hex)}
                          className={`flex items-center justify-center space-x-1 p-1.5 rounded-xl border text-[10px] transition-all cursor-pointer ${
                            isActive
                              ? 'bg-indigo-600/20 border-indigo-500 text-indigo-300 ring-2 ring-indigo-500 font-semibold'
                              : 'bg-white/[0.02] border-white/10 text-slate-400 hover:border-white/20'
                          }`}
                          title={hair.name}
                        >
                          <span
                            className="w-3.5 h-3.5 rounded-full shrink-0 border border-white/20 flex items-center justify-center"
                            style={{ backgroundColor: hair.color }}
                          >
                            {isActive && <Check className="w-2.5 h-2.5 text-white stroke-[3]" />}
                          </span>
                          <span className="truncate text-[9px]">{hair.name}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Jeans / Pants Color Swatches */}
                <div className="bg-slate-950/40 border border-white/10 rounded-2xl p-4 transition-all space-y-2.5">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-semibold uppercase tracking-wider text-slate-300 flex items-center space-x-1.5">
                      <Sliders className="w-3.5 h-3.5 text-indigo-400" />
                      <span>Jeans & Pants Color</span>
                    </label>
                    <span className="text-[11px] font-mono text-slate-400 uppercase">{pantsColor}</span>
                  </div>

                  <div className="grid grid-cols-4 sm:grid-cols-8 gap-1.5">
                    {JEANS_COLOR_PALETTES.map((swatch) => {
                      const isActive = pantsColor.toLowerCase() === swatch.hex.toLowerCase();
                      return (
                        <button
                          key={swatch.hex}
                          type="button"
                          onClick={() => setPantsColor(swatch.hex)}
                          className={`relative h-7 rounded-xl flex items-center justify-center border transition-all cursor-pointer ${
                            isActive
                              ? 'border-indigo-400 ring-2 ring-indigo-500 ring-offset-1 ring-offset-slate-900 scale-105 shadow-md z-10'
                              : 'border-white/10 hover:scale-105 hover:border-white/30'
                          }`}
                          style={{ backgroundColor: swatch.hex }}
                          title={`${swatch.name} (${swatch.hex})`}
                        >
                          {isActive && (
                            <Check className="w-3 h-3 text-white stroke-[3]" />
                          )}
                        </button>
                      );
                    })}
                  </div>

                  <div className="flex items-center space-x-2 pt-1 border-t border-white/5">
                    <span className="text-[11px] text-slate-400">Custom:</span>
                    <div className="flex items-center space-x-1.5">
                      <input
                        type="color"
                        value={pantsColor}
                        onChange={(e) => setPantsColor(e.target.value)}
                        className="w-6 h-6 rounded-md border border-white/20 bg-transparent cursor-pointer p-0"
                      />
                      <input
                        type="text"
                        value={pantsColor}
                        onChange={(e) => setPantsColor(e.target.value)}
                        placeholder="#1d4ed8"
                        className="px-2 py-0.5 bg-slate-950/70 border border-white/10 rounded-lg text-[11px] font-mono text-white w-20 focus:outline-none focus:border-indigo-400 focus:ring-1 focus:ring-indigo-500/25"
                      />
                    </div>
                  </div>
                </div>

                {/* Sneakers / Shoes Color Swatches */}
                <div className="bg-slate-950/40 border border-white/10 rounded-2xl p-4 transition-all space-y-2.5">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-semibold uppercase tracking-wider text-slate-300 flex items-center space-x-1.5">
                      <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
                      <span>Sneakers & Shoes Color</span>
                    </label>
                    <span className="text-[11px] font-mono text-slate-400 uppercase">{shoesColor}</span>
                  </div>

                  <div className="grid grid-cols-4 sm:grid-cols-8 gap-1.5">
                    {SNEAKER_COLOR_PALETTES.map((swatch) => {
                      const isActive = shoesColor.toLowerCase() === swatch.hex.toLowerCase();
                      return (
                        <button
                          key={swatch.hex}
                          type="button"
                          onClick={() => setShoesColor(swatch.hex)}
                          className={`relative h-7 rounded-xl flex items-center justify-center border transition-all cursor-pointer ${
                            isActive
                              ? 'border-indigo-400 ring-2 ring-indigo-500 ring-offset-1 ring-offset-slate-900 scale-105 shadow-md z-10'
                              : 'border-white/10 hover:scale-105 hover:border-white/30'
                          }`}
                          style={{ backgroundColor: swatch.hex }}
                          title={`${swatch.name} (${swatch.hex})`}
                        >
                          {isActive && (
                            <Check className={`w-3 h-3 stroke-[3] ${['#ffffff', '#eab308', '#84cc16'].includes(swatch.hex) ? 'text-slate-950' : 'text-white'}`} />
                          )}
                        </button>
                      );
                    })}
                  </div>

                  <div className="flex items-center space-x-2 pt-1 border-t border-white/5">
                    <span className="text-[11px] text-slate-400">Custom:</span>
                    <div className="flex items-center space-x-1.5">
                      <input
                        type="color"
                        value={shoesColor}
                        onChange={(e) => setShoesColor(e.target.value)}
                        className="w-6 h-6 rounded-md border border-white/20 bg-transparent cursor-pointer p-0"
                      />
                      <input
                        type="text"
                        value={shoesColor}
                        onChange={(e) => setShoesColor(e.target.value)}
                        placeholder="#dc2626"
                        className="px-2 py-0.5 bg-slate-950/70 border border-white/10 rounded-lg text-[11px] font-mono text-white w-20 focus:outline-none focus:border-indigo-400 focus:ring-1 focus:ring-indigo-500/25"
                      />
                    </div>
                  </div>
                </div>

                <div className="pt-2 flex items-center justify-between">
                  <button
                    type="button"
                    onClick={() => setCurrentStep('profile')}
                    className="flex items-center space-x-1.5 px-3.5 py-2 text-slate-400 hover:text-white text-xs font-medium transition-all cursor-pointer"
                  >
                    <ArrowLeft className="w-3.5 h-3.5" />
                    <span>Back</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setCurrentStep('department')}
                    className="flex items-center space-x-1.5 px-4 py-2 bg-white/5 hover:bg-white/10 text-white text-xs font-semibold rounded-xl border border-white/10 transition-all cursor-pointer"
                  >
                    <span>Next: Department</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            )}

            {/* Step 3: Department Team Assignment */}
            {currentStep === 'department' && (
              <div className="space-y-4 animate-fadeIn">
                <div className="space-y-1">
                  <h2 className="text-lg font-bold text-white tracking-tight">Select Department Team</h2>
                  <p className="text-xs text-slate-400">
                    Choose your squad to locate nearby coworkers and desks on the office floor.
                  </p>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  {DEPARTMENTS.map((dept) => {
                    const isActive = selectedDept === dept.name;
                    return (
                      <button
                        key={dept.name}
                        type="button"
                        onClick={() => setSelectedDept(dept.name)}
                        className={`p-4 rounded-2xl border text-left transition-all cursor-pointer relative backdrop-blur-md ${
                          isActive
                            ? 'bg-indigo-600/15 border-indigo-500/90 text-white ring-1 ring-indigo-400/60 shadow-[0_0_20px_rgba(99,102,241,0.25)]'
                            : 'bg-white/[0.03] border-white/10 text-slate-300 hover:border-white/20'
                        }`}
                      >
                        <div className="flex items-center justify-between mb-1">
                          <span className="text-xs font-bold text-white">{dept.name}</span>
                          {isActive && (
                            <span className="w-4 h-4 rounded-full bg-indigo-500 text-white flex items-center justify-center shadow-md">
                              <Check className="w-2.5 h-2.5 stroke-[3]" />
                            </span>
                          )}
                        </div>
                        <span className="text-[11px] text-slate-400 block leading-relaxed">{dept.desc}</span>
                      </button>
                    );
                  })}
                </div>

                {/* Final Onboarding Review Box */}
                <div className="p-4 rounded-2xl bg-indigo-950/20 border border-indigo-500/20 text-xs space-y-1.5 backdrop-blur-sm">
                  <div className="flex items-center space-x-1.5 text-indigo-400 font-semibold">
                    <ShieldCheck className="w-4 h-4" />
                    <span>Ready for Spatial Collaboration</span>
                  </div>
                  <p className="text-slate-300 text-[11px] leading-relaxed">
                    You will spawn at the elevator reception lobby with spatial audio and interactive desk customization enabled.
                  </p>
                </div>

                <div className="pt-2 flex items-center justify-between">
                  <button
                    type="button"
                    onClick={() => setCurrentStep('styling')}
                    className="flex items-center space-x-1.5 px-3.5 py-2 text-slate-400 hover:text-white text-xs font-medium transition-all cursor-pointer"
                  >
                    <ArrowLeft className="w-3.5 h-3.5" />
                    <span>Back to Styling</span>
                  </button>
                </div>
              </div>
            )}
          </form>

          {/* Sticky Primary CTA Footer */}
          <div className="p-5 sm:p-6 bg-slate-950/95 backdrop-blur-xl border-t border-white/10 shrink-0 sticky bottom-0 z-20">
            <button
              type="submit"
              form="onboarding-form"
              disabled={!name.trim()}
              className="w-full py-3.5 px-6 bg-gradient-to-r from-indigo-500 via-indigo-600 to-sky-500 hover:from-indigo-400 hover:to-sky-400 active:scale-[0.99] disabled:opacity-40 disabled:cursor-not-allowed text-white font-bold rounded-2xl transition-all shadow-[0_4px_25px_rgba(99,102,241,0.35)] flex items-center justify-center space-x-2 text-sm sm:text-base cursor-pointer"
            >
              <Play className="w-4 h-4 fill-current" />
              <span>Enter IdleLab Office</span>
            </button>
            {!name.trim() && (
              <p className="text-[11px] text-amber-400/90 text-center mt-2 font-medium">
                Please enter a Display Name in Step 01 to join.
              </p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
