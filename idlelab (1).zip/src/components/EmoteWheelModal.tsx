import React, { useEffect } from 'react';
import { X, Sparkles, Smile } from 'lucide-react';
import { GestureType } from '../types';

interface EmoteWheelModalProps {
  isOpen: boolean;
  onClose: () => void;
  onPerformGesture: (gesture: GestureType) => void;
  onSendEmojiReaction: (emoji: string, gesture?: GestureType) => void;
  userName?: string;
}

export const AVATAR_WHEEL_EMOTES: Array<{
  gesture: GestureType;
  emoji: string;
  label: string;
}> = [
  { gesture: 'wave', emoji: '👋', label: 'Wave' },
  { gesture: 'dance', emoji: '🎉', label: 'Dance' },
  { gesture: 'clap', emoji: '👏', label: 'Clap' },
  { gesture: 'bow', emoji: '🙇', label: 'Bow' },
  { gesture: 'think', emoji: '🤔', label: 'Point' },
  { gesture: 'cheer', emoji: '🔥', label: 'Cheer' },
  { gesture: 'heart', emoji: '❤️', label: 'Heart' },
  { gesture: 'facepalm', emoji: '🤦', label: 'Facepalm' },
];

export const EmoteWheelModal: React.FC<EmoteWheelModalProps> = ({
  isOpen,
  onClose,
  onPerformGesture,
  onSendEmojiReaction,
  userName = 'Avatar',
}) => {
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      }
    };
    if (isOpen) {
      window.addEventListener('keydown', handleKeyDown);
    }
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const handleSelectEmote = (emote: (typeof AVATAR_WHEEL_EMOTES)[0]) => {
    // Immediately trigger 3D gesture and emoji particle animation on avatar
    onPerformGesture(emote.gesture);
    onSendEmojiReaction(emote.emoji, emote.gesture);
    // Instantly hide/close the emote wheel so the 3D avatar view remains completely unobstructed!
    onClose();
  };

  return (
    <div
      className="fixed inset-0 z-[100] flex items-center justify-center bg-black/40 backdrop-blur-md animate-in fade-in duration-150 p-4"
      onClick={onClose}
    >
      <div
        className="relative flex flex-col items-center justify-center p-6 bg-[#121216]/95 border border-white/20 rounded-3xl shadow-[0_25px_60px_rgba(0,0,0,0.85)] max-w-sm w-full text-center animate-in zoom-in-95 duration-150"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between w-full pb-3 mb-4 border-b border-white/10">
          <div className="flex items-center space-x-2">
            <div className="p-1.5 rounded-xl bg-amber-500/20 text-amber-400 border border-amber-500/30">
              <Sparkles className="w-4 h-4" />
            </div>
            <div className="text-left">
              <h3 className="text-sm font-bold text-white tracking-tight">{userName}'s Emote Wheel</h3>
              <p className="text-[11px] text-slate-400">Double-tap your avatar anytime to open</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full bg-white/5 hover:bg-white/15 text-slate-400 hover:text-white transition-all cursor-pointer"
            title="Close (Esc)"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* 8-Slice Interactive Radial Grid */}
        <div className="grid grid-cols-4 gap-3 w-full my-2">
          {AVATAR_WHEEL_EMOTES.map((item) => (
            <button
              key={item.gesture}
              onClick={() => handleSelectEmote(item)}
              className="group flex flex-col items-center justify-center p-3 rounded-2xl bg-white/5 hover:bg-sky-500/25 border border-white/10 hover:border-sky-400/50 hover:shadow-[0_0_20px_rgba(56,189,248,0.35)] transition-all transform hover:scale-110 active:scale-95 cursor-pointer relative"
            >
              <span className="text-3xl mb-1 group-hover:scale-125 transition-transform duration-150">
                {item.emoji}
              </span>
              <span className="text-xs font-semibold text-slate-200 group-hover:text-white truncate max-w-full">
                {item.label}
              </span>
            </button>
          ))}
        </div>

        <div className="mt-4 text-[11px] text-slate-400 flex items-center justify-center space-x-1.5 bg-white/5 py-1.5 px-3 rounded-full border border-white/5">
          <Smile className="w-3.5 h-3.5 text-sky-400" />
          <span>Click any emote to trigger & instant-close wheel</span>
        </div>
      </div>
    </div>
  );
};
