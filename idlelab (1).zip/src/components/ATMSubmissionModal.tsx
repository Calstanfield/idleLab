import React, { useState, useEffect, useRef } from 'react';
import {
  X,
  CreditCard,
  DollarSign,
  Upload,
  CheckCircle2,
  AlertTriangle,
  FileText,
  Building2,
  Calendar,
  Mail,
  ShieldCheck,
  RefreshCw,
  Award,
  Sparkles,
  ArrowRight,
  TrendingUp,
  Users,
  Briefcase,
  Layers,
  Cpu,
  Printer,
  ChevronRight,
  ChevronLeft,
  ChevronDown,
  ExternalLink,
  Lock,
  User,
  Send,
  Truck,
  Zap,
  Clock,
  MapPin,
  Search,
  ShoppingBag,
  Wifi,
  SlidersHorizontal,
  Check,
  Edit3,
  Save,
  HelpCircle,
  FolderCode,
  ThumbsUp,
  AlertCircle,
  Copy,
} from 'lucide-react';
import { soundEffects } from '../lib/soundEffects';

interface ATMSubmissionModalProps {
  isOpen: boolean;
  onClose: () => void;
  userName?: string;
  currentUserName?: string;
  onRewardCash?: (amount: number) => void;
  onPayoutReceived?: (amount: number) => void;
}

interface AdminRules {
  assignmentTitle: string;
  submissionRules: string;
  recipientName: string;
  recipientEmail: string;
  recipientRole: string;
  deadline: string;
  payoutRate: number;
}

interface BankStatusData {
  success: boolean;
  vaultBalance: number;
  totalPaidOut: number;
  totalSubmissionsCount: number;
  weeklyTopUpAmount: number;
  nextTopUpTime?: number;
  adminRules: AdminRules;
  recentSubmissions: Array<{
    id: string;
    userName: string;
    fileTitle: string;
    score: number;
    isReady: boolean;
    payout: number;
    xpEarned?: number;
    timestamp: number;
    receiptId: string;
  }>;
  hiringEvaluation?: {
    recommendedRemoteHires: number;
    weeklyDeliverableCapacity: number;
    costPerDeliverable: number;
    weeklyBudget: number;
    treasuryHealth: string;
  };
}

interface GradeResult {
  score: number;
  letterGrade: string;
  isReadyForEmployer: boolean;
  verdictSummary: string;
  chloeFeedback: string;
  workspaceAutomatorNotes: string;
  techFixNotes: string;
  strengths: string[];
  improvements: string[];
  payoutEligible: boolean;
  payoutAmount: number;
  xpEarned?: number;
  rulesBreakdown?: Array<{ rule: string; passed: boolean }>;
}

export const ATMSubmissionModal: React.FC<ATMSubmissionModalProps> = ({
  isOpen,
  onClose,
  userName,
  currentUserName,
  onRewardCash,
  onPayoutReceived,
}) => {
  // User Default: Benz Carlton
  const activeUserName = currentUserName || userName || 'Benz Carlton';
  const nameParts = activeUserName.trim().split(' ');
  const defaultFirstName = nameParts[0] || 'Benz';
  const defaultLastName = nameParts.slice(1).join(' ') || 'Carlton';

  // Navigation Sections requested: Grading, Submission, Transaction, Recipient, Treasury
  const [activeSection, setActiveSection] = useState<
    'grading' | 'submission' | 'transaction' | 'recipient' | 'treasury'
  >('grading');

  // Server Bank & Rules State
  const [bankStatus, setBankStatus] = useState<BankStatusData | null>(null);
  const [isLoadingStatus, setIsLoadingStatus] = useState<boolean>(true);

  // User Profile Form State
  const [firstName, setFirstName] = useState<string>(defaultFirstName);
  const [lastName, setLastName] = useState<string>(defaultLastName);
  const [email, setEmail] = useState<string>('benz.carlton@idlelab.ai');
  const [phoneNumber, setPhoneNumber] = useState<string>('+1 (555) 839-2041');
  const [countryCode, setCountryCode] = useState<string>('+1');
  const [countryFlag, setCountryFlag] = useState<string>('🇺🇸');

  // Deliverable Payload
  const [fileName, setFileName] = useState<string>('Portfolio_Engineering_Assignment.ts');
  const [fileSize, setFileSize] = useState<string>('1.4 MB');
  const [submissionContent, setSubmissionContent] = useState<string>(
    `// =========================================================================\n// Benz Carlton - Portfolio & Engineering Project Deliverable\n// Architecture: Production-Ready React + Node Multiagent Gateway\n// =========================================================================\n\nexport interface DeliverableTask {\n  id: string;\n  title: string;\n  status: 'draft' | 'verified' | 'deployed';\n  employerScore: number;\n}\n\nexport async function executeEmployerHandIn(payload: DeliverableTask) {\n  console.log("Validating state bounds and recipient integrity for Benz-Carlton...");\n  // Verified zero runtime regressions\n  return { success: true, processedAt: new Date().toISOString() };\n}`
  );
  const [showCodeEditor, setShowCodeEditor] = useState<boolean>(false);

  // Agreement & Submission Status
  const [hasAgreedToRules, setHasAgreedToRules] = useState<boolean>(true);

  // Grading State
  const [isGrading, setIsGrading] = useState<boolean>(false);
  const [gradeResult, setGradeResult] = useState<GradeResult | null>(null);
  const [gradingError, setGradingError] = useState<string | null>(null);

  // Submission Payout State
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [submissionSuccess, setSubmissionSuccess] = useState<boolean>(false);
  const [latestReceipt, setLatestReceipt] = useState<{
    receiptId: string;
    payout: number;
    xpReward: number;
    newVaultBalance: number;
    timestamp: number;
    recipientName: string;
    recipientEmail: string;
  } | null>(null);

  // Admin / Chloe Editable Rules State
  const [isEditingAdminRules, setIsEditingAdminRules] = useState<boolean>(false);
  const [adminAssignmentTitle, setAdminAssignmentTitle] = useState<string>(
    'Portfolio & Engineering Project Assignment'
  );
  const [adminSubmissionRules, setAdminSubmissionRules] = useState<string>(
    '1. Clean modular architecture with zero runtime errors\n2. Adhere strictly to employer guidelines and project rubrics\n3. Include test coverage and complete interactive handlers\n4. Verified documentation & production deliverable readiness'
  );
  const [adminRecipientName, setAdminRecipientName] = useState<string>('Benz-Carlton');
  const [adminRecipientEmail, setAdminRecipientEmail] = useState<string>(
    'benzcarltonheinz@gmail.com'
  );
  const [adminRecipientRole, setAdminRecipientRole] = useState<string>('Employer');
  const [adminDeadline, setAdminDeadline] = useState<string>('2026-09-02T18:00');
  const [adminPayoutRate, setAdminPayoutRate] = useState<number>(5.0);
  const [isSavingRules, setIsSavingRules] = useState<boolean>(false);
  const [rulesSaveMessage, setRulesSaveMessage] = useState<string | null>(null);

  // File Upload Ref
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  // Fetch Bank & Rules Data
  const fetchStatus = async () => {
    try {
      setIsLoadingStatus(true);
      const res = await fetch('/api/atm/bank-status');
      if (res.ok) {
        const data: BankStatusData = await res.json();
        setBankStatus(data);
        if (data.adminRules) {
          setAdminAssignmentTitle(data.adminRules.assignmentTitle || 'Portfolio & Engineering Project Assignment');
          setAdminSubmissionRules(data.adminRules.submissionRules || '');
          setAdminRecipientName(data.adminRules.recipientName || 'Benz-Carlton');
          setAdminRecipientEmail(data.adminRules.recipientEmail || 'benzcarltonheinz@gmail.com');
          setAdminRecipientRole(data.adminRules.recipientRole || 'Employer');
          setAdminDeadline(data.adminRules.deadline || '2026-09-02T18:00');
          setAdminPayoutRate(data.adminRules.payoutRate || 5.0);
        }
      }
    } catch (err) {
      console.error('Failed to fetch Mitari Bank status:', err);
    } finally {
      setIsLoadingStatus(false);
    }
  };

  useEffect(() => {
    if (isOpen) {
      fetchStatus();
      soundEffects.play('pop');
    }
  }, [isOpen]);

  if (!isOpen) return null;

  // Handle File Input
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setFileName(file.name);
    setFileSize(`${(file.size / 1024).toFixed(1)} KB`);

    const reader = new FileReader();
    reader.onload = (ev) => {
      const text = (ev.target?.result as string) || '';
      setSubmissionContent(text);
      setShowCodeEditor(true);
      soundEffects.play('confirm');
    };
    reader.readAsText(file);
  };

  // Run AI Grading with Gemini + Chloe Subagents
  const handleRunGrading = async () => {
    if (!submissionContent.trim()) return;
    setIsGrading(true);
    setGradingError(null);
    soundEffects.play('confirm');

    try {
      const res = await fetch('/api/atm/grade-submission', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userName: `${firstName} ${lastName}`.trim(),
          assignmentTitle: adminAssignmentTitle,
          submissionContent,
          fileName,
          fileSize,
        }),
      });

      if (res.ok) {
        const data = await res.json();
        if (data.success && data.evaluation) {
          setGradeResult(data.evaluation);
          if (data.evaluation.isReadyForEmployer) {
            soundEffects.playChime(true);
          } else {
            soundEffects.play('pop');
          }
        } else {
          setGradingError(data.error || 'Unable to complete AI evaluation.');
        }
      } else {
        setGradingError('Server error while reaching Gemini grading service.');
      }
    } catch (err: any) {
      console.error('Grading error:', err);
      setGradingError(err.message || 'Failed to grade submission.');
    } finally {
      setIsGrading(false);
    }
  };

  // Submit Deliverable & Claim $5 Payout
  const handleSubmitAndClaim = async () => {
    if (isSubmitting) return;

    if (!gradeResult) {
      // Auto-run grading first
      await handleRunGrading();
      return;
    }

    if (!gradeResult.isReadyForEmployer) {
      alert('The deliverable requires revisions (minimum 70% score) before submitting to employer.');
      return;
    }

    if (!hasAgreedToRules) {
      alert('Please check the box to confirm agreement with the submission guidelines.');
      return;
    }

    setIsSubmitting(true);
    soundEffects.play('confirm');

    try {
      const res = await fetch('/api/atm/submit-and-payout', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userName: `${firstName} ${lastName}`.trim(),
          assignmentTitle: adminAssignmentTitle,
          score: gradeResult.score,
          isReady: gradeResult.isReadyForEmployer,
        }),
      });

      if (res.ok) {
        const data = await res.json();
        if (data.success) {
          setSubmissionSuccess(true);
          const payoutAmount = data.payout || adminPayoutRate || 5.0;
          setLatestReceipt({
            receiptId: data.receiptId,
            payout: payoutAmount,
            xpReward: data.xpReward || 150,
            newVaultBalance: data.newVaultBalance,
            timestamp: Date.now(),
            recipientName: adminRecipientName,
            recipientEmail: adminRecipientEmail,
          });

          if (onRewardCash) onRewardCash(payoutAmount);
          if (onPayoutReceived) onPayoutReceived(payoutAmount);

          soundEffects.playChime(true);
          await fetchStatus();
          setActiveSection('transaction');
        } else {
          alert(data.error || 'Failed to submit and dispense payout.');
        }
      }
    } catch (err: any) {
      console.error('Failed to submit deliverable:', err);
      alert('Failed to submit deliverable: ' + err.message);
    } finally {
      setIsSubmitting(false);
    }
  };

  // Save Admin / Chloe Rules
  const handleSaveAdminRules = async () => {
    setIsSavingRules(true);
    setRulesSaveMessage(null);

    try {
      const res = await fetch('/api/atm/update-rules', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          assignmentTitle: adminAssignmentTitle,
          submissionRules: adminSubmissionRules,
          recipientName: adminRecipientName,
          recipientEmail: adminRecipientEmail,
          recipientRole: adminRecipientRole,
          deadline: adminDeadline,
          payoutRate: adminPayoutRate,
        }),
      });

      if (res.ok) {
        setRulesSaveMessage('Rules & Recipient successfully updated!');
        soundEffects.playChime(true);
        setIsEditingAdminRules(false);
        await fetchStatus();
        setTimeout(() => setRulesSaveMessage(null), 3500);
      }
    } catch (err) {
      console.error('Failed to save rules:', err);
      setRulesSaveMessage('Failed to save rules.');
    } finally {
      setIsSavingRules(false);
    }
  };

  // Top Up Treasury
  const handleTopUpTreasury = async (amount: number = 100) => {
    try {
      const res = await fetch('/api/atm/top-up', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ amount }),
      });
      if (res.ok) {
        soundEffects.playChime(true);
        await fetchStatus();
      }
    } catch (err) {
      console.error('Failed to top up:', err);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 md:p-6 bg-slate-900/60 backdrop-blur-md animate-in fade-in duration-200">
      {/* Mitari Modal Card (Clean Light Aesthetic: Royal Blue + Pure White) */}
      <div className="relative w-full max-w-[1140px] max-h-[95vh] bg-white rounded-3xl shadow-[0_25px_70px_-15px_rgba(0,0,0,0.18)] border border-slate-100 flex flex-col overflow-hidden text-slate-800 font-sans">
        
        {/* ========================================================================= */}
        {/* TOP NAVBAR: BRAND LOGO + SECTION TABS + USER BADGE (Matching image.png) */}
        {/* ========================================================================= */}
        <header className="px-6 md:px-8 py-4 border-b border-slate-100 flex items-center justify-between bg-white select-none shrink-0">
          
          {/* Mitari Geometric Logo */}
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 rounded-lg bg-[#2546e8] flex items-center justify-center shadow-md shadow-blue-500/20 text-white">
              <svg className="w-5 h-5 fill-current" viewBox="0 0 24 24">
                <path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z" />
              </svg>
            </div>
            <div className="flex items-baseline space-x-1">
              <span className="text-lg font-black tracking-tight text-slate-900">Mitari</span>
              <span className="text-xl font-black text-[#2546e8]">.</span>
            </div>
            <span className="hidden sm:inline-block px-2.5 py-0.5 rounded-full bg-blue-50 border border-blue-100 text-[#2546e8] text-[10px] font-bold uppercase tracking-wider">
              Autonomous Terminal
            </span>
          </div>

          {/* Core Requested Section Tabs: Grading, Submission, Transaction, Recipient, Treasury */}
          <nav className="flex items-center space-x-1 sm:space-x-2 text-xs font-semibold text-slate-600">
            <button
              onClick={() => setActiveSection('grading')}
              className={`px-3 py-1.5 rounded-xl transition-all cursor-pointer flex items-center gap-1.5 ${
                activeSection === 'grading'
                  ? 'bg-[#2546e8] text-white shadow-sm shadow-blue-500/20'
                  : 'hover:bg-slate-100 text-slate-700'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>Grading</span>
            </button>

            <button
              onClick={() => setActiveSection('submission')}
              className={`px-3 py-1.5 rounded-xl transition-all cursor-pointer flex items-center gap-1.5 ${
                activeSection === 'submission'
                  ? 'bg-[#2546e8] text-white shadow-sm shadow-blue-500/20'
                  : 'hover:bg-slate-100 text-slate-700'
              }`}
            >
              <FileText className="w-3.5 h-3.5" />
              <span>Submission</span>
            </button>

            <button
              onClick={() => setActiveSection('transaction')}
              className={`px-3 py-1.5 rounded-xl transition-all cursor-pointer flex items-center gap-1.5 ${
                activeSection === 'transaction'
                  ? 'bg-[#2546e8] text-white shadow-sm shadow-blue-500/20'
                  : 'hover:bg-slate-100 text-slate-700'
              }`}
            >
              <CreditCard className="w-3.5 h-3.5" />
              <span>Transaction</span>
            </button>

            <button
              onClick={() => setActiveSection('recipient')}
              className={`px-3 py-1.5 rounded-xl transition-all cursor-pointer flex items-center gap-1.5 ${
                activeSection === 'recipient'
                  ? 'bg-[#2546e8] text-white shadow-sm shadow-blue-500/20'
                  : 'hover:bg-slate-100 text-slate-700'
              }`}
            >
              <Mail className="w-3.5 h-3.5" />
              <span>Recipient</span>
            </button>

            <button
              onClick={() => setActiveSection('treasury')}
              className={`px-3 py-1.5 rounded-xl transition-all cursor-pointer flex items-center gap-1.5 ${
                activeSection === 'treasury'
                  ? 'bg-[#2546e8] text-white shadow-sm shadow-blue-500/20'
                  : 'hover:bg-slate-100 text-slate-700'
              }`}
            >
              <DollarSign className="w-3.5 h-3.5" />
              <span>Treasury</span>
            </button>
          </nav>

          {/* Right Colleague Badge & Close */}
          <div className="flex items-center space-x-3">
            <div className="hidden md:flex items-center space-x-2 pl-2 border-l border-slate-200 text-xs">
              <div className="w-7 h-7 rounded-full bg-slate-900 text-white font-bold flex items-center justify-center text-[10px]">
                BC
              </div>
              <div className="text-left leading-tight">
                <div className="font-bold text-slate-900">Benz Carlton</div>
                <div className="text-[10px] text-slate-400">Colleague</div>
              </div>
            </div>

            <button
              onClick={onClose}
              className="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-500 hover:text-slate-800 flex items-center justify-center transition-all cursor-pointer"
              title="Close Mitari Terminal"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </header>

        {/* ========================================================================= */}
        {/* MAIN BODY: SECTION-BASED WORKFLOW WITH LIVE METRICS & SUBAGENTS */}
        {/* ========================================================================= */}
        <div className="flex-1 overflow-y-auto p-6 md:p-8 custom-scrollbar bg-[#fafbfe]">
          
          {/* ===================================================================== */}
          {/* 1. SECTION: GRADING (AI Scoring + Strengths + Areas of Improvement) */}
          {/* ===================================================================== */}
          {activeSection === 'grading' && (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 lg:gap-8 items-start max-w-6xl mx-auto">
              
              {/* Left Column: File Upload & Code Deliverable */}
              <div className="lg:col-span-7 space-y-5">
                <div>
                  <div className="flex items-center space-x-2 text-xs font-semibold text-[#2546e8] mb-1">
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>Autonomous AI Evaluator</span>
                  </div>
                  <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
                    Homework & Portfolio Grading
                  </h1>
                  <p className="text-xs text-slate-500 mt-1">
                    Upload your assignment or portfolio deliverable. Chloe Becker's subagents (Workspace Automator & TechFix) will audit the submission and determine employer readiness.
                  </p>
                </div>

                {/* File Attachment & Editor Card */}
                <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-sm space-y-4">
                  <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-slate-100">
                    <div className="flex items-center space-x-2.5">
                      <div className="p-2 rounded-xl bg-blue-50 text-[#2546e8]">
                        <FolderCode className="w-4 h-4" />
                      </div>
                      <div>
                        <div className="text-xs font-bold text-slate-900">{fileName}</div>
                        <div className="text-[10px] text-slate-400">{fileSize} • TypeScript / React</div>
                      </div>
                    </div>

                    <div className="flex items-center space-x-2">
                      <button
                        type="button"
                        onClick={() => fileInputRef.current?.click()}
                        className="px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
                      >
                        <Upload className="w-3.5 h-3.5" />
                        <span>Upload File</span>
                      </button>
                      <input
                        ref={fileInputRef}
                        type="file"
                        onChange={handleFileUpload}
                        className="hidden"
                      />

                      <button
                        type="button"
                        onClick={() => setShowCodeEditor(!showCodeEditor)}
                        className="px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold transition-colors cursor-pointer"
                      >
                        {showCodeEditor ? 'Hide Code Editor' : 'Open Code Editor'}
                      </button>
                    </div>
                  </div>

                  {/* Editable Code Box */}
                  {showCodeEditor && (
                    <div className="space-y-1.5">
                      <label className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">
                        Source Payload / Deliverable Content
                      </label>
                      <textarea
                        rows={7}
                        value={submissionContent}
                        onChange={(e) => setSubmissionContent(e.target.value)}
                        placeholder="Paste code or deliverable markdown..."
                        className="w-full p-3.5 rounded-xl bg-slate-50 border border-slate-200 text-xs font-mono text-slate-800 focus:outline-none focus:border-[#2546e8] resize-none leading-relaxed"
                      />
                    </div>
                  )}

                  {/* Grading Action Button */}
                  <button
                    type="button"
                    onClick={handleRunGrading}
                    disabled={isGrading || !submissionContent.trim()}
                    className={`w-full py-3.5 rounded-xl font-bold text-xs flex items-center justify-center space-x-2 transition-all cursor-pointer shadow-md shadow-blue-500/20 ${
                      isGrading
                        ? 'bg-blue-100 text-[#2546e8] cursor-wait'
                        : 'bg-[#2546e8] hover:bg-[#1d3cb8] text-white active:scale-[0.99]'
                    }`}
                  >
                    {isGrading ? (
                      <>
                        <RefreshCw className="w-4 h-4 animate-spin text-[#2546e8]" />
                        <span>Gemini & Chloe Becker Subagents Evaluating Deliverable...</span>
                      </>
                    ) : (
                      <>
                        <Sparkles className="w-4 h-4 text-amber-300" />
                        <span>Run AI Grading & Employer Readiness Audit</span>
                      </>
                    )}
                  </button>

                  {gradingError && (
                    <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs flex items-center gap-2">
                      <AlertCircle className="w-4 h-4 shrink-0" />
                      <span>{gradingError}</span>
                    </div>
                  )}
                </div>

                {/* Subagent Evaluation Breakdown */}
                {gradeResult && (
                  <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-sm space-y-4">
                    <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center gap-1.5">
                      <Cpu className="w-3.5 h-3.5 text-[#2546e8]" />
                      <span>Subagent Multi-Perspective Audit</span>
                    </h3>

                    <div className="space-y-3 text-xs">
                      {/* Chloe Becker Feedback */}
                      <div className="p-3 rounded-xl bg-blue-50/60 border border-blue-100">
                        <div className="font-bold text-[#2546e8] mb-0.5 flex items-center gap-1">
                          <span>👩‍💼 Chloe Becker (Manager & Evaluator)</span>
                        </div>
                        <p className="text-slate-700 leading-relaxed text-[11px]">
                          {gradeResult.chloeFeedback}
                        </p>
                      </div>

                      {/* Workspace Automator Subagent */}
                      <div className="p-3 rounded-xl bg-slate-50 border border-slate-200">
                        <div className="font-bold text-slate-800 mb-0.5 flex items-center gap-1">
                          <Zap className="w-3.5 h-3.5 text-amber-500" />
                          <span>Workspace Automater (Packaging & Recipient Check)</span>
                        </div>
                        <p className="text-slate-600 leading-relaxed text-[11px]">
                          {gradeResult.workspaceAutomatorNotes}
                        </p>
                      </div>

                      {/* TechFix Subagent */}
                      <div className="p-3 rounded-xl bg-slate-50 border border-slate-200">
                        <div className="font-bold text-slate-800 mb-0.5 flex items-center gap-1">
                          <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                          <span>TechFix Logic (Regression & Error Bounds)</span>
                        </div>
                        <p className="text-slate-600 leading-relaxed text-[11px]">
                          {gradeResult.techFixNotes}
                        </p>
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* Right Column: Score Card, Employer Readiness, Strengths & Areas of Improvement */}
              <div className="lg:col-span-5 space-y-5">
                
                {/* Score & Verdict Card */}
                <div className="p-6 rounded-2xl bg-white border border-slate-200 shadow-sm space-y-4 text-center">
                  <div className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
                    Assignment Score & Readiness
                  </div>

                  <div className="flex items-center justify-center space-x-3">
                    <div className="text-5xl font-black text-slate-900 font-mono tracking-tight">
                      {gradeResult ? gradeResult.score : '94'}
                    </div>
                    <div className="text-left">
                      <div className="text-xs font-bold text-slate-400">/ 100</div>
                      <div className="text-sm font-black text-[#2546e8]">
                        Grade {gradeResult ? gradeResult.letterGrade : 'A'}
                      </div>
                    </div>
                  </div>

                  {/* Employer Ready Badge */}
                  <div className="inline-flex items-center space-x-1.5 px-3 py-1 rounded-full text-xs font-bold bg-emerald-50 text-emerald-700 border border-emerald-200">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                    <span>
                      {gradeResult
                        ? gradeResult.isReadyForEmployer
                          ? 'Ready to Submit to Employer'
                          : 'Needs Revisions (<70%)'
                        : 'Ready to Submit to Employer'}
                    </span>
                  </div>

                  <p className="text-xs text-slate-500">
                    {gradeResult
                      ? gradeResult.verdictSummary
                      : 'Deliverable satisfies all architectural standards and is ready for immediate employer hand-in.'}
                  </p>

                  <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-xs">
                    <span className="text-slate-500">Instant Cash Payout:</span>
                    <span className="font-mono font-bold text-emerald-600">
                      +${adminPayoutRate.toFixed(2)} USD
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-slate-500">Career XP Reward:</span>
                    <span className="font-mono font-bold text-[#2546e8]">+150 XP</span>
                  </div>

                  {/* Quick Jump to Submission Tab Button */}
                  <button
                    type="button"
                    onClick={() => setActiveSection('submission')}
                    className="w-full py-3 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs flex items-center justify-center gap-1.5 transition-all cursor-pointer"
                  >
                    <span>Proceed to Submission & Hand-In</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>

                {/* Key Strengths & Areas of Improvement */}
                <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-sm space-y-4">
                  {/* Strengths */}
                  <div className="space-y-2">
                    <div className="flex items-center space-x-1.5 text-xs font-bold text-emerald-700">
                      <ThumbsUp className="w-3.5 h-3.5" />
                      <span>Key Strengths</span>
                    </div>
                    <ul className="space-y-1.5 text-xs text-slate-600">
                      {(gradeResult?.strengths || [
                        'Modular code structure and clean separation of concerns',
                        'Strict compliance with employer submission guidelines',
                        'Robust interaction handling and zero unhandled errors',
                      ]).map((st, i) => (
                        <li key={i} className="flex items-start gap-1.5">
                          <Check className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                          <span>{st}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  {/* Areas of Improvement */}
                  <div className="pt-3 border-t border-slate-100 space-y-2">
                    <div className="flex items-center space-x-1.5 text-xs font-bold text-amber-700">
                      <AlertTriangle className="w-3.5 h-3.5" />
                      <span>Areas of Improvement</span>
                    </div>
                    <ul className="space-y-1.5 text-xs text-slate-600">
                      {(gradeResult?.improvements || [
                        'Consider augmenting inline documentation for asynchronous helpers',
                        'Optional: Add unit tests for edge-case boundary states',
                      ]).map((imp, i) => (
                        <li key={i} className="flex items-start gap-1.5">
                          <span className="w-1.5 h-1.5 rounded-full bg-amber-500 shrink-0 mt-1.5" />
                          <span>{imp}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>

              </div>

            </div>
          )}

          {/* ===================================================================== */}
          {/* 2. SECTION: SUBMISSION (Rules, Deadline, Agreement Checkbox & Submit) */}
          {/* ===================================================================== */}
          {activeSection === 'submission' && (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 lg:gap-8 items-start max-w-6xl mx-auto">
              
              {/* Left Column: Guidelines, Deadline, Agreement */}
              <div className="lg:col-span-7 space-y-5">
                <div className="flex items-center justify-between">
                  <div>
                    <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
                      Submission & Hand-In Rules
                    </h1>
                    <p className="text-xs text-slate-500 mt-1">
                      Review the official requirements and deadline set by host & employer before final hand-in.
                    </p>
                  </div>

                  {/* Toggle Admin Editing for Chloe / Host */}
                  <button
                    type="button"
                    onClick={() => setIsEditingAdminRules(!isEditingAdminRules)}
                    className="px-3 py-1.5 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
                  >
                    <Edit3 className="w-3.5 h-3.5 text-[#2546e8]" />
                    <span>{isEditingAdminRules ? 'View Mode' : 'Edit Rules (Admin)'}</span>
                  </button>
                </div>

                {rulesSaveMessage && (
                  <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-700 text-xs flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4" />
                    <span>{rulesSaveMessage}</span>
                  </div>
                )}

                {/* Edit Form or Display of Guidelines */}
                {isEditingAdminRules ? (
                  <div className="p-5 rounded-2xl bg-white border border-blue-200 shadow-sm space-y-4">
                    <div className="flex items-center justify-between text-xs font-bold text-[#2546e8]">
                      <span>Chloe Becker / Admin Rule Configuration</span>
                      <span className="text-[10px] text-slate-400">Saved to company server</span>
                    </div>

                    <div className="space-y-3 text-xs">
                      <div>
                        <label className="block font-semibold text-slate-700 mb-1">Assignment Title</label>
                        <input
                          type="text"
                          value={adminAssignmentTitle}
                          onChange={(e) => setAdminAssignmentTitle(e.target.value)}
                          className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-slate-900 focus:outline-none focus:border-[#2546e8]"
                        />
                      </div>

                      <div>
                        <label className="block font-semibold text-slate-700 mb-1">Submission Rules & Rubric</label>
                        <textarea
                          rows={4}
                          value={adminSubmissionRules}
                          onChange={(e) => setAdminSubmissionRules(e.target.value)}
                          className="w-full p-3 rounded-xl bg-slate-50 border border-slate-200 text-slate-900 focus:outline-none focus:border-[#2546e8] resize-none"
                        />
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        <div>
                          <label className="block font-semibold text-slate-700 mb-1">Submission Deadline</label>
                          <input
                            type="datetime-local"
                            value={adminDeadline}
                            onChange={(e) => setAdminDeadline(e.target.value)}
                            className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-slate-900 focus:outline-none focus:border-[#2546e8]"
                          />
                        </div>

                        <div>
                          <label className="block font-semibold text-slate-700 mb-1">Payout Rate ($ / file)</label>
                          <input
                            type="number"
                            step="0.5"
                            value={adminPayoutRate}
                            onChange={(e) => setAdminPayoutRate(parseFloat(e.target.value) || 5.0)}
                            className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-slate-900 focus:outline-none focus:border-[#2546e8]"
                          />
                        </div>
                      </div>

                      <button
                        type="button"
                        onClick={handleSaveAdminRules}
                        disabled={isSavingRules}
                        className="w-full py-2.5 rounded-xl bg-[#2546e8] hover:bg-[#1d3cb8] text-white font-bold text-xs flex items-center justify-center gap-1.5 transition-all cursor-pointer"
                      >
                        {isSavingRules ? (
                          <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                        ) : (
                          <Save className="w-3.5 h-3.5" />
                        )}
                        <span>Save Admin Submission Rules</span>
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-sm space-y-4">
                    {/* Header info */}
                    <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-slate-100">
                      <div>
                        <div className="text-xs text-slate-400 font-semibold uppercase">Assignment</div>
                        <div className="text-sm font-bold text-slate-900">{adminAssignmentTitle}</div>
                      </div>
                      <div className="text-right">
                        <div className="text-xs text-slate-400 font-semibold uppercase">Deadline</div>
                        <div className="text-xs font-bold text-slate-800 flex items-center gap-1">
                          <Calendar className="w-3.5 h-3.5 text-[#2546e8]" />
                          <span>{new Date(adminDeadline).toLocaleDateString([], { month: 'short', day: 'numeric', year: 'numeric' })} at {new Date(adminDeadline).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                        </div>
                      </div>
                    </div>

                    {/* Rules List */}
                    <div className="space-y-2">
                      <div className="text-xs font-bold text-slate-800 uppercase tracking-wider">
                        Official Criteria & Rubric:
                      </div>
                      <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-700 whitespace-pre-line leading-relaxed font-sans">
                        {adminSubmissionRules}
                      </div>
                    </div>

                    {/* Colleague Details */}
                    <div className="grid grid-cols-2 gap-3 pt-1 text-xs">
                      <div className="p-3 rounded-xl bg-slate-50 border border-slate-100">
                        <div className="text-[10px] text-slate-400 font-semibold uppercase">Candidate</div>
                        <div className="font-bold text-slate-900">{firstName} {lastName}</div>
                      </div>
                      <div className="p-3 rounded-xl bg-slate-50 border border-slate-100">
                        <div className="text-[10px] text-slate-400 font-semibold uppercase">Approved Payout</div>
                        <div className="font-bold text-emerald-600 font-mono">${adminPayoutRate.toFixed(2)} USD / file</div>
                      </div>
                    </div>

                    {/* Agreement Checkbox (Explicitly Requested) */}
                    <label className="flex items-start space-x-3 p-3.5 rounded-xl bg-blue-50/70 border border-blue-200 cursor-pointer select-none">
                      <input
                        type="checkbox"
                        checked={hasAgreedToRules}
                        onChange={(e) => setHasAgreedToRules(e.target.checked)}
                        className="mt-0.5 w-4 h-4 text-[#2546e8] rounded border-slate-300 focus:ring-[#2546e8]"
                      />
                      <span className="text-xs text-slate-700 font-medium leading-relaxed">
                        I confirm that I have read the rules and deadline above, and that my deliverable has been tested and cleared by Chloe Becker's AI subagents for employer delivery.
                      </span>
                    </label>
                  </div>
                )}
              </div>

              {/* Right Column: Hand-In Action & Recipient Confirmation */}
              <div className="lg:col-span-5 space-y-5">
                
                {/* Hand-In Action Box */}
                <div className="p-6 rounded-2xl bg-white border border-slate-200 shadow-sm space-y-4">
                  <div className="text-xs font-bold uppercase tracking-wider text-slate-400 text-center">
                    Final Submission Hand-In
                  </div>

                  <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-2 text-xs">
                    <div className="flex justify-between items-center">
                      <span className="text-slate-500">Deliverable:</span>
                      <span className="font-mono font-bold text-slate-800">{fileName}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-slate-500">Grading Status:</span>
                      <span className="font-bold text-emerald-600">
                        {gradeResult ? `${gradeResult.score}/100 (Passed)` : '94/100 (Passed)'}
                      </span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-slate-500">Employer:</span>
                      <span className="font-bold text-slate-800">{adminRecipientName}</span>
                    </div>
                    <div className="pt-2 border-t border-slate-200 flex justify-between items-baseline">
                      <span className="font-bold text-slate-900">Total Payout:</span>
                      <span className="text-xl font-black text-emerald-600 font-mono">
                        +${adminPayoutRate.toFixed(2)} USD
                      </span>
                    </div>
                  </div>

                  {/* Primary Hand-In Button */}
                  <button
                    type="button"
                    onClick={handleSubmitAndClaim}
                    disabled={isSubmitting || !hasAgreedToRules}
                    className={`w-full py-4 rounded-xl font-bold text-sm flex items-center justify-center space-x-2 transition-all cursor-pointer shadow-lg shadow-blue-600/25 ${
                      !hasAgreedToRules
                        ? 'bg-slate-300 text-slate-500 cursor-not-allowed'
                        : isSubmitting
                        ? 'bg-blue-600 text-white cursor-wait'
                        : 'bg-[#2546e8] hover:bg-[#1d3cb8] text-white active:scale-[0.99]'
                    }`}
                  >
                    {isSubmitting ? (
                      <>
                        <RefreshCw className="w-4 h-4 animate-spin text-white" />
                        <span>Processing & Dispensing $5.00 Payout...</span>
                      </>
                    ) : (
                      <>
                        <CheckCircle2 className="w-4 h-4 text-white" />
                        <span>Submit to Employer & Claim $5 Pay →</span>
                      </>
                    )}
                  </button>

                  <div className="text-center text-[10px] text-slate-400">
                    Hand-in transmits directly to {adminRecipientEmail}
                  </div>
                </div>

                {/* Recipient Snapshot Card */}
                <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-sm space-y-2 text-xs">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-slate-800 flex items-center gap-1.5">
                      <Building2 className="w-3.5 h-3.5 text-[#2546e8]" />
                      <span>Target Employer Recipient</span>
                    </span>
                    <button
                      onClick={() => setActiveSection('recipient')}
                      className="text-[#2546e8] font-semibold text-[11px] hover:underline"
                    >
                      View Details
                    </button>
                  </div>
                  <p className="text-slate-600 text-[11px]">
                    <strong>{adminRecipientName}</strong> ({adminRecipientRole})<br />
                    <span className="text-slate-400">{adminRecipientEmail}</span>
                  </p>
                </div>

              </div>

            </div>
          )}

          {/* ===================================================================== */}
          {/* 3. SECTION: TRANSACTION (Payment Details, $5 Dispensed, XP, Card) */}
          {/* ===================================================================== */}
          {activeSection === 'transaction' && (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 lg:gap-8 items-start max-w-6xl mx-auto">
              
              {/* Left Column: Transaction Details, XP Rewarded, User Account */}
              <div className="lg:col-span-7 space-y-5">
                <div>
                  <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
                    Transaction & Payout Details
                  </h1>
                  <p className="text-xs text-slate-500 mt-1">
                    Receipts, earnings, and XP rewards processed autonomously through the Mitari Terminal.
                  </p>
                </div>

                {/* Latest Dispensed Receipt Box */}
                <div className="p-6 rounded-2xl bg-white border border-slate-200 shadow-sm space-y-4">
                  <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                    <div className="flex items-center space-x-2">
                      <div className="p-2 rounded-xl bg-emerald-50 text-emerald-600">
                        <CheckCircle2 className="w-4 h-4" />
                      </div>
                      <div>
                        <div className="text-xs font-bold text-slate-900">
                          {latestReceipt ? 'Payout Dispensed Successfully' : 'Ready for Payout'}
                        </div>
                        <div className="text-[10px] text-slate-400 font-mono">
                          Receipt: {latestReceipt?.receiptId || 'MITARI-5478-ACTIVE'}
                        </div>
                      </div>
                    </div>

                    <span className="px-2.5 py-1 rounded-full bg-emerald-50 text-emerald-700 font-bold text-[10px] uppercase">
                      Settled
                    </span>
                  </div>

                  {/* Key Transaction Figures */}
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-100 space-y-1">
                      <div className="text-[10px] font-bold text-slate-400 uppercase">Payout Dispensed</div>
                      <div className="text-2xl font-black text-emerald-600 font-mono">
                        ${(latestReceipt?.payout || 5.0).toFixed(2)}
                      </div>
                      <div className="text-[10px] text-slate-500">Per passed file</div>
                    </div>

                    <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-100 space-y-1">
                      <div className="text-[10px] font-bold text-slate-400 uppercase">XP Rewarded</div>
                      <div className="text-2xl font-black text-[#2546e8] font-mono">
                        +{latestReceipt?.xpReward || 150} XP
                      </div>
                      <div className="text-[10px] text-slate-500">Career Level progress</div>
                    </div>

                    <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-100 space-y-1">
                      <div className="text-[10px] font-bold text-slate-400 uppercase">Beneficiary</div>
                      <div className="text-sm font-bold text-slate-900 truncate">
                        {firstName} {lastName}
                      </div>
                      <div className="text-[10px] text-slate-500">Colleague Account</div>
                    </div>
                  </div>

                  {/* Account Summary */}
                  <div className="p-3.5 rounded-xl bg-blue-50/60 border border-blue-100 text-xs text-blue-900 space-y-1">
                    <div className="font-bold flex items-center gap-1.5">
                      <ShieldCheck className="w-3.5 h-3.5 text-[#2546e8]" />
                      <span>Autonomous IdleLab Payroll Verification</span>
                    </div>
                    <p className="text-[11px] text-blue-800 leading-snug">
                      Funds disbursed from IdleLab Company Bank Treasury ($100.00 base, +$100/wk auto top-up). Zero fees applied.
                    </p>
                  </div>
                </div>

                {/* Submissions Ledger */}
                <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-sm space-y-3">
                  <div className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                    Recent Payout History
                  </div>

                  <div className="divide-y divide-slate-100 text-xs">
                    {bankStatus?.recentSubmissions && bankStatus.recentSubmissions.length > 0 ? (
                      bankStatus.recentSubmissions.slice(0, 5).map((sub) => (
                        <div key={sub.id} className="py-2.5 flex items-center justify-between">
                          <div>
                            <div className="font-bold text-slate-900">{sub.fileTitle}</div>
                            <div className="text-[10px] text-slate-400">
                              {sub.userName} • Score: {sub.score}/100 • {new Date(sub.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                            </div>
                          </div>
                          <div className="text-right">
                            <div className="font-mono font-bold text-emerald-600">+${sub.payout.toFixed(2)}</div>
                            <div className="text-[10px] text-[#2546e8] font-bold">+{sub.xpEarned || 150} XP</div>
                          </div>
                        </div>
                      ))
                    ) : (
                      <div className="py-4 text-center text-xs text-slate-400">
                        No prior transactions found. Complete your first submission to see history!
                      </div>
                    )}
                  </div>
                </div>
              </div>

              {/* Right Column: Virtual Card & Account Details (Matching image.png) */}
              <div className="lg:col-span-5 space-y-5">
                
                {/* Royal Blue Virtual Card */}
                <div className="relative w-full aspect-[1.58/1] rounded-2xl p-6 text-white shadow-xl shadow-blue-600/20 flex flex-col justify-between overflow-hidden bg-gradient-to-br from-[#2546e8] via-[#2d52f2] to-[#1e3cb8]">
                  <div className="absolute inset-0 opacity-15 pointer-events-none bg-[radial-gradient(#fff_1px,transparent_1px)] [background-size:16px_16px]" />

                  {/* Top Row: Chip & Contactless */}
                  <div className="relative flex items-center justify-between z-10">
                    <div className="w-11 h-8 rounded-md bg-gradient-to-br from-amber-200 via-amber-300 to-amber-400 border border-amber-500/40 p-1 flex flex-col justify-between shadow-inner">
                      <div className="h-0.5 w-full bg-amber-600/30 rounded" />
                      <div className="h-0.5 w-2/3 bg-amber-600/30 rounded" />
                      <div className="h-0.5 w-full bg-amber-600/30 rounded" />
                    </div>
                    <div className="text-white/80 transform rotate-90">
                      <Wifi className="w-5 h-5" />
                    </div>
                  </div>

                  {/* Bottom Row: Expiry, Number, Benz Carlton */}
                  <div className="relative z-10 space-y-1">
                    <div className="text-[10px] text-white/70 font-mono tracking-widest uppercase">
                      Exp 09 / 27
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="text-lg font-bold font-mono tracking-wider text-white">
                        •••• 5478
                      </div>
                      <div className="text-xs font-semibold text-white/90">
                        {firstName} {lastName}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Account Credentials Summary */}
                <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-sm space-y-3 text-xs">
                  <div className="font-bold text-slate-900 uppercase tracking-wider text-[11px]">
                    User Account Configuration
                  </div>
                  <div className="space-y-2 text-slate-600">
                    <div className="flex justify-between">
                      <span>Account Holder:</span>
                      <span className="font-bold text-slate-900">{firstName} {lastName}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Email:</span>
                      <span className="text-slate-800">{email}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Phone:</span>
                      <span className="text-slate-800">{phoneNumber}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Payroll Status:</span>
                      <span className="font-bold text-emerald-600">Instant Automated Direct</span>
                    </div>
                  </div>
                </div>

              </div>

            </div>
          )}

          {/* ===================================================================== */}
          {/* 4. SECTION: RECIPIENT (Benz-Carlton, benzcarltonheinz@gmail.com, Employer) */}
          {/* ===================================================================== */}
          {activeSection === 'recipient' && (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 lg:gap-8 items-start max-w-6xl mx-auto">
              
              {/* Left Column: Recipient Specifications & Editable Form */}
              <div className="lg:col-span-7 space-y-5">
                <div className="flex items-center justify-between">
                  <div>
                    <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
                      Recipient & Employer Target
                    </h1>
                    <p className="text-xs text-slate-500 mt-1">
                      Deliverable dispatch target and employer inbox credentials configured by Chloe Becker.
                    </p>
                  </div>

                  <button
                    type="button"
                    onClick={() => setIsEditingAdminRules(!isEditingAdminRules)}
                    className="px-3 py-1.5 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
                  >
                    <Edit3 className="w-3.5 h-3.5 text-[#2546e8]" />
                    <span>{isEditingAdminRules ? 'Done' : 'Edit Recipient'}</span>
                  </button>
                </div>

                {rulesSaveMessage && (
                  <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-700 text-xs flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4" />
                    <span>{rulesSaveMessage}</span>
                  </div>
                )}

                {/* Recipient Profile Box */}
                <div className="p-6 rounded-2xl bg-white border border-slate-200 shadow-sm space-y-4">
                  {isEditingAdminRules ? (
                    <div className="space-y-3 text-xs">
                      <div>
                        <label className="block font-semibold text-slate-700 mb-1">Recipient Name</label>
                        <input
                          type="text"
                          value={adminRecipientName}
                          onChange={(e) => setAdminRecipientName(e.target.value)}
                          placeholder="Benz-Carlton"
                          className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-slate-900 focus:outline-none focus:border-[#2546e8]"
                        />
                      </div>

                      <div>
                        <label className="block font-semibold text-slate-700 mb-1">Recipient Email</label>
                        <input
                          type="email"
                          value={adminRecipientEmail}
                          onChange={(e) => setAdminRecipientEmail(e.target.value)}
                          placeholder="benzcarltonheinz@gmail.com"
                          className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-slate-900 focus:outline-none focus:border-[#2546e8]"
                        />
                      </div>

                      <div>
                        <label className="block font-semibold text-slate-700 mb-1">Role / Designation</label>
                        <input
                          type="text"
                          value={adminRecipientRole}
                          onChange={(e) => setAdminRecipientRole(e.target.value)}
                          placeholder="Employer"
                          className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-slate-900 focus:outline-none focus:border-[#2546e8]"
                        />
                      </div>

                      <button
                        type="button"
                        onClick={handleSaveAdminRules}
                        disabled={isSavingRules}
                        className="w-full py-2.5 rounded-xl bg-[#2546e8] hover:bg-[#1d3cb8] text-white font-bold text-xs flex items-center justify-center gap-1.5 transition-all cursor-pointer"
                      >
                        {isSavingRules ? (
                          <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                        ) : (
                          <Save className="w-3.5 h-3.5" />
                        )}
                        <span>Update Recipient Information</span>
                      </button>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {/* Recipient Showcase */}
                      <div className="flex items-center space-x-4 p-4 rounded-xl bg-blue-50/60 border border-blue-100">
                        <div className="w-12 h-12 rounded-2xl bg-[#2546e8] text-white font-black text-lg flex items-center justify-center shadow-md shadow-blue-500/20">
                          BC
                        </div>
                        <div>
                          <div className="text-base font-extrabold text-slate-900">
                            {adminRecipientName}
                          </div>
                          <div className="text-xs text-[#2546e8] font-bold">
                            Role: {adminRecipientRole}
                          </div>
                          <div className="text-xs text-slate-500 font-mono mt-0.5">
                            {adminRecipientEmail}
                          </div>
                        </div>
                      </div>

                      {/* Delivery Verification Badges */}
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                        <div className="p-3 rounded-xl bg-slate-50 border border-slate-100 space-y-1">
                          <div className="text-[10px] text-slate-400 font-semibold uppercase">Inbox Protocol</div>
                          <div className="font-bold text-slate-800 flex items-center gap-1">
                            <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                            <span>Verified TLS & GSuite Route</span>
                          </div>
                        </div>

                        <div className="p-3 rounded-xl bg-slate-50 border border-slate-100 space-y-1">
                          <div className="text-[10px] text-slate-400 font-semibold uppercase">Dispatch Trigger</div>
                          <div className="font-bold text-slate-800 flex items-center gap-1">
                            <Zap className="w-3.5 h-3.5 text-amber-500" />
                            <span>Instant on Submission Agree</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </div>

              {/* Right Column: Workflow Automater Summary */}
              <div className="lg:col-span-5 space-y-5">
                <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-sm space-y-3">
                  <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center gap-1.5">
                    <Cpu className="w-3.5 h-3.5 text-[#2546e8]" />
                    <span>Workspace Automater Integration</span>
                  </h3>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    Chloe Becker's <strong>Workspace Automater</strong> subagent monitors incoming hand-ins for <strong>{adminRecipientName}</strong>. When a file is graded with score ≥ 70%, the automated agent packages the artifact, signs the verification hash, and pushes the delivery notification to <strong>{adminRecipientEmail}</strong>.
                  </p>
                </div>
              </div>

            </div>
          )}

          {/* ===================================================================== */}
          {/* 5. SECTION: TREASURY (Bank $100, +$100/wk, Remote Hiring Logic) */}
          {/* ===================================================================== */}
          {activeSection === 'treasury' && (
            <div className="max-w-4xl mx-auto space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
                    IdleLab Company Bank & Hiring Logic
                  </h1>
                  <p className="text-xs text-slate-500 mt-1">
                    Autonomous treasury management, weekly replenishment, and remote contractor capacity evaluation.
                  </p>
                </div>

                <button
                  type="button"
                  onClick={() => handleTopUpTreasury(100)}
                  className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer shadow-sm"
                >
                  <DollarSign className="w-3.5 h-3.5" />
                  <span>Manual Top-Up ($100.00)</span>
                </button>
              </div>

              {/* 4 Metrics Cards */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-sm space-y-1">
                  <div className="text-[11px] font-semibold text-slate-400 uppercase">Bank Vault Balance</div>
                  <div className="text-2xl font-black text-slate-900 font-mono">
                    ${(bankStatus?.vaultBalance ?? 100).toFixed(2)}
                  </div>
                  <div className="text-[10px] text-emerald-600 font-bold">
                    +${(bankStatus?.weeklyTopUpAmount ?? 100).toFixed(2)} / week replenish
                  </div>
                </div>

                <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-sm space-y-1">
                  <div className="text-[11px] font-semibold text-slate-400 uppercase">Total Paid to Users</div>
                  <div className="text-2xl font-black text-emerald-600 font-mono">
                    ${(bankStatus?.totalPaidOut ?? 0).toFixed(2)}
                  </div>
                  <div className="text-[10px] text-slate-400">
                    {bankStatus?.totalSubmissionsCount ?? 0} approved deliverables
                  </div>
                </div>

                <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-sm space-y-1">
                  <div className="text-[11px] font-semibold text-slate-400 uppercase">Recommended Remote Hires</div>
                  <div className="text-2xl font-black text-[#2546e8] font-mono">
                    {bankStatus?.hiringEvaluation?.recommendedRemoteHires ?? 4} Remote Staff
                  </div>
                  <div className="text-[10px] text-slate-400">
                    Workspace Automator & TechFix logic
                  </div>
                </div>

                <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-sm space-y-1">
                  <div className="text-[11px] font-semibold text-slate-400 uppercase">Deliverable Capacity</div>
                  <div className="text-2xl font-black text-amber-600 font-mono">
                    {bankStatus?.hiringEvaluation?.weeklyDeliverableCapacity ?? 20} files / wk
                  </div>
                  <div className="text-[10px] text-slate-400">
                    At ${adminPayoutRate.toFixed(2)} / file
                  </div>
                </div>
              </div>

              {/* Subagents Hiring Logic Explanation */}
              <div className="p-6 rounded-2xl bg-white border border-slate-200 shadow-sm space-y-3">
                <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                  <Cpu className="w-4 h-4 text-[#2546e8]" />
                  <span>Chloe's Subagent "Workspace Automater" & TechFix Hiring Strategy</span>
                </h3>
                <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-700 leading-relaxed space-y-2 font-sans">
                  <p>
                    <strong>Treasury Replenishment Model:</strong> IdleLab maintains a <strong>$100.00 / week</strong> liquidity injection schedule. At the standard rate of <strong>$5.00 / approved deliverable</strong>, the company can comfortably fund <strong>20 completed assignment files per week</strong>.
                  </p>
                  <p>
                    <strong>Remote Contractor Sizing:</strong> Based on an average output of 5 verified deliverables per contractor weekly, <strong>Workspace Automater</strong> and <strong>TechFix</strong> recommend sustaining <strong>4 active remote contractors</strong>. This maximizes pipeline velocity while guaranteeing zero cashflow deficit.
                  </p>
                </div>
              </div>
            </div>
          )}

        </div>

        {/* ========================================================================= */}
        {/* FOOTER BAR: SUMMARY + DISPATCH (Matching Modernist Design) */}
        {/* ========================================================================= */}
        <footer className="px-6 md:px-8 py-3.5 border-t border-slate-100 bg-white flex flex-wrap items-center justify-between text-xs text-slate-500 gap-3 shrink-0 select-none">
          <div className="flex items-center space-x-2">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            <span>IdleLab Bank Vault: <strong className="text-slate-900 font-mono">${(bankStatus?.vaultBalance ?? 100).toFixed(2)}</strong></span>
            <span className="text-slate-300">•</span>
            <span>Payout: <strong className="text-emerald-600 font-mono">${adminPayoutRate.toFixed(2)} / file</strong></span>
          </div>

          <div className="flex items-center space-x-3">
            <span className="text-[11px] text-slate-400">Recipient: <strong>{adminRecipientName}</strong> ({adminRecipientEmail})</span>
            <button
              onClick={onClose}
              className="px-4 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold transition-colors cursor-pointer"
            >
              Exit Terminal
            </button>
          </div>
        </footer>

      </div>
    </div>
  );
};
