/**
 * Office Collaborative Whiteboard & Document Canvas
 * Completely empty collaborative whiteboard canvas with subtle dot grid,
 * ready for the user to place their own text, documents, notes, and drawings.
 */

export function drawOfficeWhiteboard(ctx: CanvasRenderingContext2D, w: number, h: number) {
  // Clear canvas with crisp, pure off-white surface
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(0, 0, w, h);

  // Subtle clean dot grid pattern (empty workspace)
  ctx.fillStyle = '#e2e8f0';
  const gridStep = Math.max(20, Math.floor(w / 32));
  for (let gx = gridStep; gx < w; gx += gridStep) {
    for (let gy = gridStep; gy < h; gy += gridStep) {
      ctx.fillRect(gx - 1, gy - 1, 2, 2);
    }
  }
}

// Backwards-compatible export mapping
export const drawArtistPortraits = drawOfficeWhiteboard;
