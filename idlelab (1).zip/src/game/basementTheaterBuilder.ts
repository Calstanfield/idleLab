import * as THREE from 'three';
import { UserState, Department } from '../types';
import { createVoxelAvatarMesh } from './avatarBuilder';

export interface BasementTheaterMeshes {
  basementGroup: THREE.Group;
  basementScreenMesh: THREE.Mesh;
  interactiveObjects: THREE.Object3D[];
  updateBasementTheater?: (time: number, delta: number) => void;
}

// =========================================================================
// 1. PROCEDURAL TEXTURE GENERATORS (Directly Matching image.png!)
// =========================================================================

// Modernist Mitari Touchscreen Display Texture
export function createAtmTouchscreenTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 384;
  const ctx = canvas.getContext('2d')!;

  // Clean Light Modernist Fintech Aesthetic
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(0, 0, 512, 384);

  // Top Modernist Header Strip
  ctx.fillStyle = '#2546e8';
  ctx.fillRect(0, 0, 512, 54);

  // Geometric Logo Mark
  ctx.fillStyle = '#ffffff';
  ctx.beginPath();
  ctx.moveTo(24, 18);
  ctx.lineTo(36, 12);
  ctx.lineTo(30, 26);
  ctx.lineTo(40, 26);
  ctx.lineTo(26, 42);
  ctx.lineTo(30, 30);
  ctx.lineTo(22, 30);
  ctx.closePath();
  ctx.fill();

  ctx.fillStyle = '#ffffff';
  ctx.font = 'bold 20px -apple-system, BlinkMacSystemFont, sans-serif';
  ctx.textAlign = 'left';
  ctx.fillText('Mitari .', 48, 35);

  ctx.fillStyle = '#93c5fd';
  ctx.font = '12px sans-serif';
  ctx.textAlign = 'right';
  ctx.fillText('MANAGED BY CHLOE BECKER', 490, 34);

  // Center Card & Checkout Summary Box
  ctx.fillStyle = '#f8fafc';
  ctx.strokeStyle = '#e2e8f0';
  ctx.lineWidth = 2;
  ctx.roundRect(24, 70, 464, 150, 16);
  ctx.fill();
  ctx.stroke();

  // Card Graphic inside screen
  ctx.fillStyle = '#2546e8';
  ctx.roundRect(40, 86, 140, 90, 10);
  ctx.fill();
  ctx.fillStyle = '#ffffff';
  ctx.font = 'bold 10px sans-serif';
  ctx.fillText('•••• 5478', 50, 150);
  ctx.font = '8px sans-serif';
  ctx.fillText('Mitari Corporate', 50, 164);

  // Treasury Vault Info
  ctx.fillStyle = '#64748b';
  ctx.font = '12px sans-serif';
  ctx.fillText('COMPANY TREASURY', 200, 104);

  ctx.fillStyle = '#0f172a';
  ctx.font = 'bold 30px -apple-system, sans-serif';
  ctx.fillText('$100.00', 200, 138);

  ctx.fillStyle = '#16a34a';
  ctx.font = 'bold 12px sans-serif';
  ctx.fillText('+$5.00 Payout / Approved File  •  +$100/wk', 200, 162);
  ctx.fillStyle = '#64748b';
  ctx.font = '11px sans-serif';
  ctx.fillText('Subagents: Workspace Automater & TechFix', 200, 180);

  // Touch Action Button
  ctx.fillStyle = '#2546e8';
  ctx.roundRect(24, 238, 464, 52, 12);
  ctx.fill();
  ctx.fillStyle = '#ffffff';
  ctx.font = 'bold 16px -apple-system, sans-serif';
  ctx.textAlign = 'center';
  ctx.fillText('CHECKOUT & CLAIM PAYOUT →', 256, 270);

  // Status Bar Bottom
  ctx.fillStyle = '#f1f5f9';
  ctx.fillRect(0, 334, 512, 50);
  ctx.fillStyle = '#475569';
  ctx.font = '12px sans-serif';
  ctx.textAlign = 'center';
  ctx.fillText('CLICK MACHINE OR PRESS [E] TO OPEN MITARI TERMINAL', 256, 364);

  const texture = new THREE.CanvasTexture(canvas);
  return texture;
}

// Linear Acoustic Commercial Woven Carpet Tile Texture (Matching floor in image.png)
export function createLinearCarpetTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 512;
  const ctx = canvas.getContext('2d')!;

  // Base Warm Neutral Grey-Taupe
  ctx.fillStyle = '#6e6963';
  ctx.fillRect(0, 0, 512, 512);

  // Linear Striations running longitudinally
  const colors = ['#8a8279', '#57524c', '#7d766d', '#48433e', '#9b9287', '#5f5953'];
  for (let x = 0; x < 512; x += 3) {
    const col = colors[Math.floor(Math.random() * colors.length)];
    ctx.fillStyle = col;
    const w = 2 + Math.floor(Math.random() * 4);
    ctx.fillRect(x, 0, w, 512);

    // Subtle micro-weave noise
    for (let y = 0; y < 512; y += 8) {
      if (Math.random() > 0.6) {
        ctx.fillStyle = 'rgba(255,255,255,0.06)';
        ctx.fillRect(x, y, w, 4);
      } else if (Math.random() > 0.6) {
        ctx.fillStyle = 'rgba(0,0,0,0.08)';
        ctx.fillRect(x, y, w, 4);
      }
    }
  }

  const texture = new THREE.CanvasTexture(canvas);
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.RepeatWrapping;
  texture.repeat.set(6, 6);
  return texture;
}

// Illuminated Warm Oak Library Bookshelf (Matching executive suite in image.png)
export function createIlluminatedOakLibraryTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 1024;
  canvas.height = 1024;
  const ctx = canvas.getContext('2d')!;

  // Warm Honey Oak Wood Base
  ctx.fillStyle = '#b6834d';
  ctx.fillRect(0, 0, 1024, 1024);

  // 4 Shelves
  const shelfCount = 4;
  const shelfHeight = 180;
  const startY = 80;

  for (let s = 0; s < shelfCount; s++) {
    const sy = startY + s * (shelfHeight + 36);

    // Shelf back shadow
    ctx.fillStyle = '#7a4f22';
    ctx.fillRect(40, sy, 944, shelfHeight);

    // Warm LED Under-Shelf Glow Strip (Golden Warm Glow)
    const ledGrad = ctx.createLinearGradient(0, sy, 0, sy + 65);
    ledGrad.addColorStop(0, 'rgba(254, 240, 138, 0.95)');
    ledGrad.addColorStop(0.3, 'rgba(253, 224, 71, 0.55)');
    ledGrad.addColorStop(1, 'rgba(253, 224, 71, 0.0)');
    ctx.fillStyle = ledGrad;
    ctx.fillRect(40, sy, 944, 65);

    // Warm LED emitter line
    ctx.fillStyle = '#fef08a';
    ctx.fillRect(40, sy, 944, 5);

    // Horizontal Thick Oak Shelf Beam
    ctx.fillStyle = '#d49b5c';
    ctx.fillRect(30, sy + shelfHeight, 964, 28);
    ctx.fillStyle = '#8f5926';
    ctx.fillRect(30, sy + shelfHeight + 24, 964, 4);

    // Books & Accessories along the shelf
    let bx = 60;
    const bookColors = ['#f8fafc', '#1e293b', '#64748b', '#cbd5e1', '#d97706', '#0f766e', '#e2e8f0', '#334155'];

    while (bx < 860) {
      if (Math.random() > 0.45 && bx > 400 && bx < 650) {
        // Decorative Ceramic Vases (matching image.png)
        ctx.fillStyle = '#ffffff';
        ctx.beginPath();
        ctx.ellipse(bx + 40, sy + shelfHeight - 45, 24, 45, 0, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = '#e2e8f0';
        ctx.beginPath();
        ctx.ellipse(bx + 95, sy + shelfHeight - 35, 18, 35, 0, 0, Math.PI * 2);
        ctx.fill();
        bx += 160;
      } else {
        // Book Stacks & Vertical Books
        const groupWidth = 60 + Math.floor(Math.random() * 80);
        let currX = bx;
        while (currX < bx + groupWidth && currX < 920) {
          const bw = 10 + Math.floor(Math.random() * 14);
          const bh = 95 + Math.floor(Math.random() * 45);
          ctx.fillStyle = bookColors[Math.floor(Math.random() * bookColors.length)];
          ctx.fillRect(currX, sy + shelfHeight - bh, bw, bh);

          // Book spine details
          ctx.fillStyle = '#fef08a';
          ctx.fillRect(currX + 2, sy + shelfHeight - bh + 12, bw - 4, 3);
          currX += bw + 2;
        }
        bx = currX + 40;
      }
    }
  }

  // Lower Oak Storage Cabinets with Doors & Handles
  const cabY = startY + shelfCount * (shelfHeight + 36) + 10;
  ctx.fillStyle = '#99632f';
  ctx.fillRect(30, cabY, 964, 1024 - cabY);

  for (let c = 0; c < 4; c++) {
    const cx = 40 + c * 240;
    ctx.fillStyle = '#c58d53';
    ctx.fillRect(cx, cabY + 10, 225, 1024 - cabY - 20);
    ctx.strokeStyle = '#7c4618';
    ctx.lineWidth = 4;
    ctx.strokeRect(cx, cabY + 10, 225, 1024 - cabY - 20);

    // Sleek minimal brass handle
    ctx.fillStyle = '#fef08a';
    ctx.fillRect(cx + 100, cabY + 40, 25, 6);
  }

  const texture = new THREE.CanvasTexture(canvas);
  return texture;
}

// Modernist Abstract Diagonal Geometric Canvas Art (Matching image.png artwork on green wall)
export function createAbstractDiagonalArtTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 768;
  canvas.height = 1024;
  const ctx = canvas.getContext('2d')!;

  // Off-white canvas base
  ctx.fillStyle = '#f4f4f5';
  ctx.fillRect(0, 0, 768, 1024);

  // Diagonal Color Blocks (Orange, Charcoal, Black, Cream)
  // 1. Vibrant Orange Triangle
  ctx.fillStyle = '#ea580c';
  ctx.beginPath();
  ctx.moveTo(80, 180);
  ctx.lineTo(680, 520);
  ctx.lineTo(260, 920);
  ctx.closePath();
  ctx.fill();

  // 2. Deep Charcoal & Black Geometric Overlay
  ctx.fillStyle = '#18181b';
  ctx.beginPath();
  ctx.moveTo(340, 80);
  ctx.lineTo(680, 260);
  ctx.lineTo(520, 680);
  ctx.lineTo(180, 500);
  ctx.closePath();
  ctx.fill();

  // 3. Warm Ochre / Cream Wedge
  ctx.fillStyle = '#d97706';
  ctx.beginPath();
  ctx.moveTo(120, 480);
  ctx.lineTo(440, 620);
  ctx.lineTo(220, 960);
  ctx.closePath();
  ctx.fill();

  // 4. Clean crisp diagonal dividing stroke
  ctx.strokeStyle = '#ffffff';
  ctx.lineWidth = 14;
  ctx.beginPath();
  ctx.moveTo(80, 180);
  ctx.lineTo(680, 520);
  ctx.stroke();

  // Thin Black Gallery Edge
  ctx.strokeStyle = '#09090b';
  ctx.lineWidth = 16;
  ctx.strokeRect(8, 8, 752, 1008);

  const texture = new THREE.CanvasTexture(canvas);
  return texture;
}

// Chartreuse / Sage Green Acoustic Fabric Texture (Matching desk partition in image.png)
export function createChartreuseFabricTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 256;
  canvas.height = 256;
  const ctx = canvas.getContext('2d')!;

  ctx.fillStyle = '#8fa242'; // Fresh Lime/Chartreuse
  ctx.fillRect(0, 0, 256, 256);

  // Micro fabric woven texture
  for (let x = 0; x < 256; x += 4) {
    for (let y = 0; y < 256; y += 4) {
      if ((x + y) % 8 === 0) {
        ctx.fillStyle = '#9cb04d';
        ctx.fillRect(x, y, 2, 2);
      } else {
        ctx.fillStyle = '#7a8c32';
        ctx.fillRect(x, y, 2, 2);
      }
    }
  }

  const texture = new THREE.CanvasTexture(canvas);
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.RepeatWrapping;
  texture.repeat.set(4, 2);
  return texture;
}

// Horizontal Window Micro-Blinds Texture (Matching windows in image.png)
export function createWindowBlindsTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 512;
  const ctx = canvas.getContext('2d')!;

  // Soft diffused daylight background
  ctx.fillStyle = '#e2e8f0';
  ctx.fillRect(0, 0, 512, 512);

  // Horizontal louvers
  for (let y = 0; y < 512; y += 12) {
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, y, 512, 8);
    ctx.fillStyle = '#cbd5e1';
    ctx.fillRect(0, y + 8, 512, 4);
  }

  const texture = new THREE.CanvasTexture(canvas);
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.RepeatWrapping;
  texture.repeat.set(2, 6);
  return texture;
}

// Giant 8K Presentation Screen Texture with Click to Share Screen Prompt
export function createGiantBlackMonitorTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 1536;
  canvas.height = 768;
  const ctx = canvas.getContext('2d')!;

  // Deep OLED Black Canvas
  ctx.fillStyle = '#020617';
  ctx.fillRect(0, 0, 1536, 768);

  // Neon Ambient Glow Frame
  ctx.strokeStyle = '#38bdf8';
  ctx.lineWidth = 8;
  ctx.strokeRect(6, 6, 1524, 756);

  // Top Bar
  ctx.fillStyle = '#0f172a';
  ctx.fillRect(10, 10, 1516, 90);
  ctx.fillStyle = '#38bdf8';
  ctx.font = 'bold 32px monospace';
  ctx.fillText('🖥️ B1 8K ULTRA-WIDE DISPLAY • AIRPLAY & HDMI BROADCAST', 48, 64);

  // Status Pill
  ctx.fillStyle = '#22c55e';
  ctx.beginPath();
  ctx.arc(1420, 55, 12, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = '#ffffff';
  ctx.font = 'bold 20px sans-serif';
  ctx.fillText('READY', 1445, 62);

  // Center Presentation Box
  ctx.fillStyle = '#0b1120';
  ctx.strokeStyle = '#334155';
  ctx.lineWidth = 4;
  ctx.fillRect(120, 160, 1296, 420);
  ctx.strokeRect(120, 160, 1296, 420);

  // Center Screen Sharing Icon
  ctx.fillStyle = '#38bdf8';
  ctx.font = 'bold 56px sans-serif';
  ctx.textAlign = 'center';
  ctx.fillText('📺 SCREEN SHARE ACTIVE', 768, 280);

  ctx.fillStyle = '#e2e8f0';
  ctx.font = '32px sans-serif';
  ctx.fillText('Click this monitor to cast your screen or app window in real-time', 768, 360);

  // Interactive Button graphic
  ctx.fillStyle = '#2563eb';
  ctx.fillRect(520, 430, 496, 90);
  ctx.strokeStyle = '#60a5fa';
  ctx.lineWidth = 4;
  ctx.strokeRect(520, 430, 496, 90);

  ctx.fillStyle = '#ffffff';
  ctx.font = 'bold 36px sans-serif';
  ctx.fillText('✨ CLICK TO SHARE SCREEN', 768, 488);

  // Footer Info
  ctx.fillStyle = '#64748b';
  ctx.font = '22px monospace';
  ctx.textAlign = 'left';
  ctx.fillText('Resolution: 7680x2160 • 120Hz Ultra-Low Latency • Spatial Audio Ready', 120, 660);

  const texture = new THREE.CanvasTexture(canvas);
  return texture;
}

// =========================================================================
// 2. MAIN B1 CORPORATE WORKSPACE BUILDER (MATCHING IMAGE.PNG)
// =========================================================================
export function buildBasementTheater(): BasementTheaterMeshes {
  const basementGroup = new THREE.Group();
  basementGroup.name = 'B1CorporateOfficeSpace';

  const interactiveObjects: THREE.Object3D[] = [];

  const FLOOR_Y = -6.0;
  const ROOM_W = 24.0;
  const ROOM_D = 18.0;
  const ROOM_H = 4.4;

  // Shared Standard Materials
  const darkTrimMat = new THREE.MeshStandardMaterial({ color: 0x18181b, metalness: 0.8, roughness: 0.2 });
  const whiteDeskMat = new THREE.MeshStandardMaterial({ color: 0xf8fafc, roughness: 0.3 });
  const whiteMetalMat = new THREE.MeshStandardMaterial({ color: 0xf1f5f9, metalness: 0.4, roughness: 0.3 });
  const glassMat = new THREE.MeshStandardMaterial({ color: 0x38bdf8, transparent: true, opacity: 0.3, roughness: 0.1 });
  const sageGreenWallMat = new THREE.MeshStandardMaterial({ color: 0x5a6d4e, roughness: 0.7 }); // Sage green accent wall
  const warmOakMat = new THREE.MeshStandardMaterial({ color: 0xc4935a, roughness: 0.4 });
  const champagneLeatherMat = new THREE.MeshStandardMaterial({ color: 0xb58b5b, roughness: 0.5 }); // High-back chair
  const greyMeshMat = new THREE.MeshStandardMaterial({ color: 0x475569, roughness: 0.6 }); // Mesh chair
  const plantFoliageMat = new THREE.MeshStandardMaterial({ color: 0x15803d, roughness: 0.8 }); // Green hedge
  const darkCeilingMat = new THREE.MeshStandardMaterial({ color: 0x18181b, roughness: 0.9 });
  const whiteCeilingMat = new THREE.MeshStandardMaterial({ color: 0xf1f5f9, roughness: 0.4 });

  // 1. FLOORING: LINEAR COMMERCIAL ACOUSTIC WOVEN CARPET
  const carpetTex = createLinearCarpetTexture();
  const floorMat = new THREE.MeshStandardMaterial({ map: carpetTex, roughness: 0.85 });
  const floorMesh = new THREE.Mesh(new THREE.BoxGeometry(ROOM_W, 0.2, ROOM_D), floorMat);
  floorMesh.position.set(0, FLOOR_Y - 0.1, 0);
  floorMesh.receiveShadow = true;
  basementGroup.add(floorMesh);

  // 2. CEILING: EXPOSED INDUSTRIAL DARK CEILING TRAY WITH SUSPENDED LINEAR BLACK PENDANTS
  // Dark Industrial Center Ceiling
  const darkCeiling = new THREE.Mesh(new THREE.BoxGeometry(ROOM_W - 4.0, 0.15, ROOM_D - 2.0), darkCeilingMat);
  darkCeiling.position.set(2.0, FLOOR_Y + ROOM_H, 0);
  basementGroup.add(darkCeiling);

  // Left White Soffit over Executive Suite
  const leftSoffit = new THREE.Mesh(new THREE.BoxGeometry(5.2, 0.25, ROOM_D), whiteCeilingMat);
  leftSoffit.position.set(-ROOM_W / 2 + 2.6, FLOOR_Y + ROOM_H - 0.05, 0);
  basementGroup.add(leftSoffit);

  // Suspended Linear Black LED Pendant Fixtures (Directly matching image.png)
  const pendantY = FLOOR_Y + ROOM_H - 0.9;
  const pendantPositions = [
    { x: 3.5, z: -3.5, len: 7.2 },
    { x: 3.5, z: 0.0, len: 7.2 },
    { x: 3.5, z: 3.5, len: 7.2 },
    { x: 8.5, z: -3.5, len: 5.0 },
    { x: 8.5, z: 0.0, len: 5.0 },
    { x: 8.5, z: 3.5, len: 5.0 },
  ];

  pendantPositions.forEach((pend) => {
    const pendBar = new THREE.Mesh(
      new THREE.BoxGeometry(pend.len, 0.08, 0.12),
      darkTrimMat
    );
    pendBar.position.set(pend.x, pendantY, pend.z);

    // Glowing LED emitter bottom
    const ledGlow = new THREE.Mesh(
      new THREE.BoxGeometry(pend.len - 0.1, 0.02, 0.08),
      new THREE.MeshStandardMaterial({ color: 0xffffff, emissive: 0xfffbeb, emissiveIntensity: 1.2 })
    );
    ledGlow.position.set(pend.x, pendantY - 0.04, pend.z);

    // 2 Hanging wire cables
    for (const cx of [-pend.len / 2 + 0.5, pend.len / 2 - 0.5]) {
      const wire = new THREE.Mesh(
        new THREE.CylinderGeometry(0.008, 0.008, 0.8, 4),
        darkTrimMat
      );
      wire.position.set(pend.x + cx, pendantY + 0.4, pend.z);
      basementGroup.add(wire);
    }

    const downlight = new THREE.PointLight(0xfffbeb, 0.6, 6.0);
    downlight.position.set(pend.x, pendantY - 0.3, pend.z);

    basementGroup.add(pendBar, ledGlow, downlight);
  });

  // 3. RIGHT PERIMETER (EAST WALL) - WINDOWS WITH CENTRAL OPEN PORTAL TO INDOOR TENNIS ARENA
  const blindsTex = createWindowBlindsTexture();
  const blindsMat = new THREE.MeshStandardMaterial({ map: blindsTex, roughness: 0.5 });
  
  // North Window Panel (Z = -8.5 to -3.0)
  const blindsMeshN = new THREE.Mesh(new THREE.PlaneGeometry(5.5, ROOM_H - 0.4), blindsMat);
  blindsMeshN.position.set(ROOM_W / 2 - 0.05, FLOOR_Y + ROOM_H / 2, -5.75);
  blindsMeshN.rotation.y = -Math.PI / 2;

  // South Window Panel (Z = +3.0 to +8.5)
  const blindsMeshS = new THREE.Mesh(new THREE.PlaneGeometry(5.5, ROOM_H - 0.4), blindsMat);
  blindsMeshS.position.set(ROOM_W / 2 - 0.05, FLOOR_Y + ROOM_H / 2, 5.75);
  blindsMeshS.rotation.y = -Math.PI / 2;

  basementGroup.add(blindsMeshN, blindsMeshS);

  // =========================================================================
  // 3b. GRAND OPEN PORTAL DOOR TO INDOOR TENNIS ARENA (X = 12.0, Z = -2.8..2.8)
  // =========================================================================
  const tennisPortalGroup = new THREE.Group();
  tennisPortalGroup.name = 'TennisArenaEntrancePortal';

  // Portal Arch Header Beam (Dark Steel with LED Trim)
  const portalHeader = new THREE.Mesh(new THREE.BoxGeometry(0.35, 0.45, 6.0), darkTrimMat);
  portalHeader.position.set(ROOM_W / 2, FLOOR_Y + ROOM_H - 0.225, 0);

  // Portal Left Jamb (North)
  const portalJambN = new THREE.Mesh(new THREE.BoxGeometry(0.35, ROOM_H, 0.2), darkTrimMat);
  portalJambN.position.set(ROOM_W / 2, FLOOR_Y + ROOM_H / 2, -3.0);

  // Portal Right Jamb (South)
  const portalJambS = new THREE.Mesh(new THREE.BoxGeometry(0.35, ROOM_H, 0.2), darkTrimMat);
  portalJambS.position.set(ROOM_W / 2, FLOOR_Y + ROOM_H / 2, 3.0);

  // Vertical Cyan Neon LED Light Strips on Door Jambs
  const jambLedMat = new THREE.MeshStandardMaterial({ color: 0x00e5ff, emissive: 0x00e5ff, emissiveIntensity: 1.5 });
  const jambLedN = new THREE.Mesh(new THREE.BoxGeometry(0.04, ROOM_H - 0.4, 0.04), jambLedMat);
  jambLedN.position.set(ROOM_W / 2 - 0.15, FLOOR_Y + ROOM_H / 2, -2.9);
  const jambLedS = new THREE.Mesh(new THREE.BoxGeometry(0.04, ROOM_H - 0.4, 0.04), jambLedMat);
  jambLedS.position.set(ROOM_W / 2 - 0.15, FLOOR_Y + ROOM_H / 2, 2.9);

  // Overhead Illuminated Sign: "🎾 INDOOR TENNIS ARENA • DIRECT ACCESS"
  const signCanvas = document.createElement('canvas');
  signCanvas.width = 1024;
  signCanvas.height = 256;
  const sCtx = signCanvas.getContext('2d')!;
  sCtx.fillStyle = '#090d16';
  sCtx.fillRect(0, 0, 1024, 256);
  sCtx.strokeStyle = '#10b981';
  sCtx.lineWidth = 8;
  sCtx.strokeRect(10, 10, 1004, 236);

  sCtx.fillStyle = '#10b981';
  sCtx.font = 'bold 54px sans-serif';
  sCtx.textAlign = 'center';
  sCtx.fillText('🎾 INDOOR TENNIS ARENA', 512, 100);

  sCtx.fillStyle = '#38bdf8';
  sCtx.font = 'bold 36px sans-serif';
  sCtx.fillText('► STEP THROUGH TO PLAY TESLA OPTIMUS BOT ◄', 512, 175);

  const signTex = new THREE.CanvasTexture(signCanvas);
  const signMat = new THREE.MeshBasicMaterial({ map: signTex, side: THREE.DoubleSide });
  const portalSign = new THREE.Mesh(new THREE.PlaneGeometry(4.8, 1.2), signMat);
  portalSign.position.set(ROOM_W / 2 - 0.1, FLOOR_Y + ROOM_H - 0.9, 0);
  portalSign.rotation.y = -Math.PI / 2;

  // Floor LED Runway Strips leading into the arena
  const floorRunnerMat = new THREE.MeshStandardMaterial({ color: 0x10b981, emissive: 0x10b981, emissiveIntensity: 1.2 });
  const runnerN = new THREE.Mesh(new THREE.BoxGeometry(3.0, 0.02, 0.08), floorRunnerMat);
  runnerN.position.set(ROOM_W / 2 + 0.8, FLOOR_Y + 0.02, -2.4);
  const runnerS = new THREE.Mesh(new THREE.BoxGeometry(3.0, 0.02, 0.08), floorRunnerMat);
  runnerS.position.set(ROOM_W / 2 + 0.8, FLOOR_Y + 0.02, 2.4);

  // Warm Gateway Welcome Spotlight
  const portalSpot = new THREE.PointLight(0x38bdf8, 1.5, 7.0);
  portalSpot.position.set(ROOM_W / 2, FLOOR_Y + ROOM_H - 0.5, 0);

  tennisPortalGroup.add(
    portalHeader,
    portalJambN,
    portalJambS,
    jambLedN,
    jambLedS,
    portalSign,
    runnerN,
    runnerS,
    portalSpot
  );
  basementGroup.add(tennisPortalGroup);

  // =========================================================================
  // 4. GLASS-ENCLOSED MANAGER EXECUTIVE SUITE (MATCHING LEFT SIDE OF IMAGE.PNG)
  // =========================================================================
  const execSuiteGroup = new THREE.Group();
  execSuiteGroup.name = 'ManagerExecutiveGlassSuite';

  const EXEC_X = -7.5;
  const EXEC_Z = 0.0;
  const EXEC_W = 8.0;
  const EXEC_D = 12.0;

  // Front Glass Wall with Thin Dark Aluminum Mullions (X = EXEC_X + EXEC_W/2 = -3.5)
  const frontGlassN = new THREE.Mesh(new THREE.BoxGeometry(0.06, ROOM_H, EXEC_D * 0.4), glassMat);
  frontGlassN.position.set(EXEC_X + EXEC_W / 2, FLOOR_Y + ROOM_H / 2, -3.2);

  const frontGlassS = new THREE.Mesh(new THREE.BoxGeometry(0.06, ROOM_H, EXEC_D * 0.4), glassMat);
  frontGlassS.position.set(EXEC_X + EXEC_W / 2, FLOOR_Y + ROOM_H / 2, 3.2);

  // Door Opening in middle with sleek metal header
  const doorTransom = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.4, 2.4), darkTrimMat);
  doorTransom.position.set(EXEC_X + EXEC_W / 2, FLOOR_Y + ROOM_H - 0.2, 0);

  // Sliding Glass Door
  const slidingDoor = new THREE.Mesh(new THREE.BoxGeometry(0.04, ROOM_H - 0.4, 2.2), glassMat);
  slidingDoor.position.set(EXEC_X + EXEC_W / 2 + 0.06, FLOOR_Y + (ROOM_H - 0.4) / 2, 0.4);

  // Sleek Vertical Door Handle
  const doorHandle = new THREE.Mesh(new THREE.CylinderGeometry(0.015, 0.015, 1.2, 8), darkTrimMat);
  doorHandle.position.set(EXEC_X + EXEC_W / 2 + 0.09, FLOOR_Y + 1.2, -0.4);

  // EXTRA GLASS WINDOWS FOR MANAGER OFFICE:
  // 1. South Floor-to-Ceiling Panoramic Glass Window Wall (Z = +6.0, overlooking South corridor)
  const southGlassWall = new THREE.Mesh(new THREE.BoxGeometry(EXEC_W, ROOM_H, 0.06), glassMat);
  southGlassWall.position.set(EXEC_X, FLOOR_Y + ROOM_H / 2, EXEC_D / 2);
  
  // South Dark Aluminum Mullions & Base Frame
  const southMullion1 = new THREE.Mesh(new THREE.BoxGeometry(0.08, ROOM_H, 0.12), darkTrimMat);
  southMullion1.position.set(EXEC_X - EXEC_W / 4, FLOOR_Y + ROOM_H / 2, EXEC_D / 2);
  const southMullion2 = new THREE.Mesh(new THREE.BoxGeometry(0.08, ROOM_H, 0.12), darkTrimMat);
  southMullion2.position.set(EXEC_X + EXEC_W / 4, FLOOR_Y + ROOM_H / 2, EXEC_D / 2);
  const southBaseFrame = new THREE.Mesh(new THREE.BoxGeometry(EXEC_W, 0.12, 0.12), darkTrimMat);
  southBaseFrame.position.set(EXEC_X, FLOOR_Y + 0.06, EXEC_D / 2);

  // 2. North Glass Window Panels flanking green accent wall (Z = -6.0)
  const northGlassE = new THREE.Mesh(new THREE.BoxGeometry(2.2, ROOM_H, 0.06), glassMat);
  northGlassE.position.set(EXEC_X + EXEC_W / 2 - 1.1, FLOOR_Y + ROOM_H / 2, -EXEC_D / 2);
  const northGlassFrame = new THREE.Mesh(new THREE.BoxGeometry(0.08, ROOM_H, 0.12), darkTrimMat);
  northGlassFrame.position.set(EXEC_X + EXEC_W / 2 - 2.2, FLOOR_Y + ROOM_H / 2, -EXEC_D / 2);

  // 3. West Exterior Panoramic Bay Window (X = -ROOM_W/2 + 0.05, looking outside with daylight)
  const westBayGlass = new THREE.Mesh(new THREE.PlaneGeometry(5.8, ROOM_H - 0.4), glassMat);
  westBayGlass.position.set(-ROOM_W / 2 + 0.08, FLOOR_Y + ROOM_H / 2, 2.5);
  westBayGlass.rotation.y = Math.PI / 2;

  // Modern Corner Glass Joint Post
  const cornerPost = new THREE.Mesh(new THREE.BoxGeometry(0.12, ROOM_H, 0.12), darkTrimMat);
  cornerPost.position.set(EXEC_X + EXEC_W / 2, FLOOR_Y + ROOM_H / 2, EXEC_D / 2);

  execSuiteGroup.add(
    frontGlassN,
    frontGlassS,
    doorTransom,
    slidingDoor,
    doorHandle,
    southGlassWall,
    southMullion1,
    southMullion2,
    southBaseFrame,
    northGlassE,
    northGlassFrame,
    westBayGlass,
    cornerPost
  );

  // Left Built-in Wall: Illuminated Oak Wood Library Bookshelf (Matching image.png!)
  const libTex = createIlluminatedOakLibraryTexture();
  const libMat = new THREE.MeshStandardMaterial({ map: libTex, roughness: 0.35 });
  const libMesh = new THREE.Mesh(new THREE.PlaneGeometry(EXEC_D * 0.75, ROOM_H - 0.4), libMat);
  libMesh.position.set(-ROOM_W / 2 + 0.15, FLOOR_Y + ROOM_H / 2, -1.0);
  libMesh.rotation.y = Math.PI / 2;
  execSuiteGroup.add(libMesh);

  // Warm LED light illuminating the library shelves
  const libGlow = new THREE.PointLight(0xfef08a, 1.4, 6.5);
  libGlow.position.set(-ROOM_W / 2 + 1.2, FLOOR_Y + 2.2, -1.0);
  execSuiteGroup.add(libGlow);

  // Back Wall: Sage / Olive Green Accent Wall with Modern Abstract Diagonal Geometric Art
  const backGreenWall = new THREE.Mesh(new THREE.BoxGeometry(EXEC_W, ROOM_H, 0.15), sageGreenWallMat);
  backGreenWall.position.set(EXEC_X, FLOOR_Y + ROOM_H / 2, -EXEC_D / 2);
  execSuiteGroup.add(backGreenWall);

  // Large Framed Modernist Diagonal Art Piece (Matching image.png!)
  const artTex = createAbstractDiagonalArtTexture();
  const artMesh = new THREE.Mesh(new THREE.PlaneGeometry(2.0, 2.6), new THREE.MeshBasicMaterial({ map: artTex }));
  artMesh.position.set(EXEC_X + 0.5, FLOOR_Y + 2.3, -EXEC_D / 2 + 0.12);

  const artFrame = new THREE.Mesh(new THREE.BoxGeometry(2.08, 2.68, 0.05), darkTrimMat);
  artFrame.position.set(EXEC_X + 0.5, FLOOR_Y + 2.3, -EXEC_D / 2 + 0.09);

  const artSpot = new THREE.PointLight(0xfffbeb, 0.9, 4.0);
  artSpot.position.set(EXEC_X + 0.5, FLOOR_Y + 3.4, -EXEC_D / 2 + 0.8);

  execSuiteGroup.add(artFrame, artMesh, artSpot);

  // Low Storage Credenza along the Green Wall
  const lowCredenza = new THREE.Mesh(new THREE.BoxGeometry(EXEC_W - 1.0, 0.75, 0.6), whiteDeskMat);
  lowCredenza.position.set(EXEC_X, FLOOR_Y + 0.375, -EXEC_D / 2 + 0.45);
  execSuiteGroup.add(lowCredenza);

  // Contemporary L-Shaped Executive Desk (Champagne Wood Top + White Modesty Front)
  const DESK_CENTER_X = EXEC_X + 0.6;
  const DESK_CENTER_Z = 0.5;

  const execDeskGroup = new THREE.Group();
  execDeskGroup.position.set(DESK_CENTER_X, FLOOR_Y, DESK_CENTER_Z);

  // Main Desktop (Warm Champagne Oak)
  const deskTopMain = new THREE.Mesh(new THREE.BoxGeometry(2.6, 0.08, 1.2), warmOakMat);
  deskTopMain.position.set(0, 0.75, 0);

  // L-Return Credenza Top
  const deskTopReturn = new THREE.Mesh(new THREE.BoxGeometry(1.0, 0.08, 1.6), warmOakMat);
  deskTopReturn.position.set(-1.4, 0.71, -0.4);

  // White Clean Modesty Front Panel
  const deskFrontModesty = new THREE.Mesh(new THREE.BoxGeometry(2.5, 0.65, 0.05), whiteDeskMat);
  deskFrontModesty.position.set(0, 0.35, 0.55);

  // Under-desk Side Pedestal Cabinet
  const deskSideCab = new THREE.Mesh(new THREE.BoxGeometry(0.95, 0.65, 1.5), whiteDeskMat);
  deskSideCab.position.set(-1.4, 0.35, -0.4);

  execDeskGroup.add(deskTopMain, deskTopReturn, deskFrontModesty, deskSideCab);

  // Manager Laptop / All-in-One Monitor ON EXECUTIVE DESK (Facing Seated Manager!)
  // Manager chair is at Z = -0.3 looking North (+Z is desk front, chair is on -Z side looking +Z or forward)
  const mgrLapBase = new THREE.Mesh(new THREE.BoxGeometry(0.42, 0.015, 0.3), whiteMetalMat);
  mgrLapBase.position.set(0, 0.8, 0.0);

  const mgrLapScreen = new THREE.Mesh(
    new THREE.BoxGeometry(0.42, 0.28, 0.015),
    new THREE.MeshStandardMaterial({ color: 0x0f172a, emissive: 0x38bdf8, emissiveIntensity: 0.5 })
  );
  // Screen faces towards the chair (facing -Z)
  mgrLapScreen.position.set(0, 0.95, 0.12);
  mgrLapScreen.rotation.x = -0.2;

  execDeskGroup.add(mgrLapBase, mgrLapScreen);

  // Ceramic Planter with White Orchid on Executive Desk
  const pot = new THREE.Mesh(new THREE.CylinderGeometry(0.1, 0.08, 0.18, 12), whiteDeskMat);
  pot.position.set(0.9, 0.88, -0.2);
  const plantOrchid = new THREE.Mesh(new THREE.SphereGeometry(0.12, 8, 8), plantFoliageMat);
  plantOrchid.position.set(0.9, 1.05, -0.2);
  execDeskGroup.add(pot, plantOrchid);

  execSuiteGroup.add(execDeskGroup);

  // Executive High-Back Ergonomic Swivel Chair (Champagne Leather, facing desk forward)
  const execChairGroup = new THREE.Group();
  execChairGroup.position.set(DESK_CENTER_X, FLOOR_Y, DESK_CENTER_Z - 0.7);

  const chairBase = new THREE.Mesh(new THREE.CylinderGeometry(0.3, 0.3, 0.08, 6), darkTrimMat);
  chairBase.position.y = 0.15;
  const chairPost = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.04, 0.35, 8), whiteMetalMat);
  chairPost.position.y = 0.35;
  const chairSeat = new THREE.Mesh(new THREE.BoxGeometry(0.55, 0.1, 0.55), champagneLeatherMat);
  chairSeat.position.y = 0.52;
  const chairHighBack = new THREE.Mesh(new THREE.BoxGeometry(0.52, 0.75, 0.08), champagneLeatherMat);
  chairHighBack.position.set(0, 0.9, -0.24);

  execChairGroup.add(chairBase, chairPost, chairSeat, chairHighBack);
  execSuiteGroup.add(execChairGroup);

  // Two Modern Visitor Armchairs facing the Executive Desk
  [-0.6, 0.6].forEach((vx) => {
    const visChair = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.75, 0.5), champagneLeatherMat);
    visChair.position.set(DESK_CENTER_X + vx, FLOOR_Y + 0.375, DESK_CENTER_Z + 1.25);
    visChair.rotation.y = Math.PI;
    execSuiteGroup.add(visChair);
  });

  // Interactive Chair Hitbox for Executive Suite
  const execChairHitbox = new THREE.Mesh(new THREE.BoxGeometry(0.8, 1.2, 0.8), new THREE.MeshBasicMaterial({ visible: false }));
  execChairHitbox.position.set(DESK_CENTER_X, FLOOR_Y + 0.6, DESK_CENTER_Z - 0.7);
  execChairHitbox.userData = {
    isMeetingChair: true,
    seatPos: { x: DESK_CENTER_X, y: FLOOR_Y + 0.1, z: DESK_CENTER_Z - 0.7 },
    rotY: 0,
    title: 'Manager Executive Chair',
  };
  execSuiteGroup.add(execChairHitbox);
  interactiveObjects.push(execChairHitbox);

  // =========================================================================
  // 🏧 MODERN ATM SUBMISSION & PAYROLL KIOSK (MANAGED BY CHLOE BECKER)
  // Placed at the corner of Manager's Office (Executive Suite)
  // =========================================================================
  const atmGroup = new THREE.Group();
  const ATM_X = EXEC_X + EXEC_W / 2 - 1.2; // Corner of manager's office
  const ATM_Z = EXEC_D / 2 - 1.6;
  atmGroup.position.set(ATM_X, FLOOR_Y, ATM_Z);
  atmGroup.rotation.y = -Math.PI * 0.75; // Angled facing inward towards manager office

  // Modern Machine Grey Minimalist Color Palette
  const darkGraphiteMat = new THREE.MeshStandardMaterial({ color: 0x1e293b, roughness: 0.3, metalness: 0.85 });
  const gunmetalMat = new THREE.MeshStandardMaterial({ color: 0x334155, roughness: 0.25, metalness: 0.9 });
  const brushedSteelMat = new THREE.MeshStandardMaterial({ color: 0x64748b, roughness: 0.2, metalness: 0.95 });
  const lightGreyMat = new THREE.MeshStandardMaterial({ color: 0xf1f5f9, roughness: 0.4, metalness: 0.1 });
  const neonCyanGlowMat = new THREE.MeshStandardMaterial({ color: 0x00f0ff, emissive: 0x00f0ff, emissiveIntensity: 1.6, roughness: 0.1 });
  const atmDispenserGreenMat = new THREE.MeshStandardMaterial({ color: 0x22c55e, emissive: 0x22c55e, emissiveIntensity: 1.0 });
  const atmChromeMat = new THREE.MeshStandardMaterial({ color: 0xe2e8f0, roughness: 0.1, metalness: 0.95 });

  // 1. Dual Brushed Steel Base Stand
  const legLeft = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.04, 0.45, 12), brushedSteelMat);
  legLeft.position.set(-0.32, 0.225, 0);
  const legRight = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.04, 0.45, 12), brushedSteelMat);
  legRight.position.set(0.32, 0.225, 0);

  const basePlinth = new THREE.Mesh(new THREE.BoxGeometry(0.88, 0.06, 0.55), darkGraphiteMat);
  basePlinth.position.set(0, 0.03, 0);

  // 2. Main Sleek Gunmetal Body Column
  const bodyColumn = new THREE.Mesh(new THREE.BoxGeometry(0.82, 0.8, 0.48), gunmetalMat);
  bodyColumn.position.set(0, 0.85, 0);

  // Front Minimalist Bevel Accent Strip in Brushed Steel
  const frontAccent = new THREE.Mesh(new THREE.BoxGeometry(0.74, 0.72, 0.04), brushedSteelMat);
  frontAccent.position.set(0, 0.85, 0.24);

  // 3. Slanted Upper Console Head (Dark Graphite Shell)
  const consoleGroup = new THREE.Group();
  consoleGroup.position.set(0, 1.35, 0.05);

  const consoleHousing = new THREE.Mesh(new THREE.BoxGeometry(0.84, 0.65, 0.42), darkGraphiteMat);
  consoleHousing.rotation.x = -0.32; // Ergonomic slant

  // Slanted Touchscreen Monitor with ATM Texture
  const atmScreenTex = createAtmTouchscreenTexture();
  const screenPlane = new THREE.Mesh(
    new THREE.PlaneGeometry(0.72, 0.48),
    new THREE.MeshBasicMaterial({ map: atmScreenTex })
  );
  screenPlane.position.set(0, 0.02, 0.22);
  screenPlane.rotation.x = -0.32;

  // 4. Distinctive Overhead Neon Cyan Curved Light Loop / Arch
  const loopCurve = new THREE.TorusGeometry(0.38, 0.025, 12, 32, Math.PI);
  const topNeonLoop = new THREE.Mesh(loopCurve, neonCyanGlowMat);
  topNeonLoop.position.set(0, 0.42, 0.06);
  topNeonLoop.rotation.z = Math.PI;

  // Loop Base Stems
  const loopStemL = new THREE.Mesh(new THREE.CylinderGeometry(0.025, 0.025, 0.2, 8), brushedSteelMat);
  loopStemL.position.set(-0.38, 0.32, 0.06);
  const loopStemR = new THREE.Mesh(new THREE.CylinderGeometry(0.025, 0.025, 0.2, 8), brushedSteelMat);
  loopStemR.position.set(0.38, 0.32, 0.06);

  consoleGroup.add(consoleHousing, screenPlane, topNeonLoop, loopStemL, loopStemR);

  // 5. Lower Interaction Deck (Card Reader, Receipt Slot, Keypad, Cash Slot)
  const deckShelf = new THREE.Mesh(new THREE.BoxGeometry(0.82, 0.08, 0.3), gunmetalMat);
  deckShelf.position.set(0, 1.05, 0.24);

  // Keypad
  const keypad = new THREE.Mesh(new THREE.BoxGeometry(0.18, 0.02, 0.14), atmChromeMat);
  keypad.position.set(-0.18, 1.1, 0.24);

  // Card Reader Slot
  const cardReader = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.04, 0.08), atmChromeMat);
  cardReader.position.set(0.22, 1.1, 0.24);

  // Receipt Paper Ejection Slot
  const receiptSlot = new THREE.Mesh(new THREE.BoxGeometry(0.2, 0.015, 0.04), darkGraphiteMat);
  receiptSlot.position.set(0.22, 1.12, 0.16);

  // Illuminated Cash Dispenser Slot on lower front
  const cashDispenserFrame = new THREE.Mesh(new THREE.BoxGeometry(0.36, 0.08, 0.06), darkGraphiteMat);
  cashDispenserFrame.position.set(0, 0.65, 0.25);
  const cashSlotGlow = new THREE.Mesh(new THREE.BoxGeometry(0.3, 0.02, 0.02), atmDispenserGreenMat);
  cashSlotGlow.position.set(0, 0.65, 0.28);

  // Side Scanner Cradle Arm (Left side of machine)
  const scannerArm = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.35, 0.15), brushedSteelMat);
  scannerArm.position.set(-0.46, 1.1, 0.1);

  // Ambient Cyan Minimalist Glow Light
  const atmLight = new THREE.PointLight(0x00f0ff, 1.2, 4.5);
  atmLight.position.set(0, 1.6, 0.4);

  atmGroup.add(
    basePlinth,
    legLeft,
    legRight,
    bodyColumn,
    frontAccent,
    consoleGroup,
    deckShelf,
    keypad,
    cardReader,
    receiptSlot,
    cashDispenserFrame,
    cashSlotGlow,
    scannerArm,
    atmLight
  );

  // 6. Overhead Holographic Billboard / Interactive Indicator Sign
  const atmSignCanvas = document.createElement('canvas');
  atmSignCanvas.width = 512;
  atmSignCanvas.height = 128;
  const atmSCtx = atmSignCanvas.getContext('2d')!;
  atmSCtx.fillStyle = 'rgba(15, 23, 42, 0.95)';
  atmSCtx.strokeStyle = '#2546e8';
  atmSCtx.lineWidth = 4;
  atmSCtx.roundRect(8, 8, 496, 112, 16);
  atmSCtx.fill();
  atmSCtx.stroke();

  // Mitari Logo Icon
  atmSCtx.fillStyle = '#38bdf8';
  atmSCtx.font = 'bold 24px -apple-system, sans-serif';
  atmSCtx.textAlign = 'center';
  atmSCtx.fillText('⚡ MITARI .', 256, 42);

  atmSCtx.fillStyle = '#f8fafc';
  atmSCtx.font = '14px sans-serif';
  atmSCtx.fillText('Autonomous Submission & Instant Payout Terminal', 256, 74);

  atmSCtx.fillStyle = '#22c55e';
  atmSCtx.font = 'bold 13px sans-serif';
  atmSCtx.fillText('Managed by Chloe Becker  •  Click or Press [E]', 256, 102);

  const atmSignTex = new THREE.CanvasTexture(atmSignCanvas);
  const signPlane = new THREE.Mesh(
    new THREE.PlaneGeometry(1.4, 0.38),
    new THREE.MeshBasicMaterial({ map: atmSignTex, transparent: true, side: THREE.DoubleSide })
  );
  signPlane.position.set(0, 2.15, 0.1);
  signPlane.userData = {
    isAtmSubmissionBox: true,
    isMitari: true,
    title: 'Mitari Terminal (Click to Open)',
  };
  atmGroup.add(signPlane);
  interactiveObjects.push(signPlane);

  // 7. Interactive Hitbox for Mitari Machine
  const atmHitbox = new THREE.Mesh(
    new THREE.BoxGeometry(1.4, 2.4, 1.2),
    new THREE.MeshBasicMaterial({ visible: false })
  );
  atmHitbox.position.set(0, 1.1, 0);
  atmHitbox.name = 'MitariMachine';
  atmHitbox.userData = {
    isAtmSubmissionBox: true,
    isMitari: true,
    title: 'Mitari Machine (Click to Open)',
  };
  atmGroup.add(atmHitbox);
  interactiveObjects.push(atmHitbox);

  // Tag screen and housing for direct clicks too
  screenPlane.userData = { isAtmSubmissionBox: true, isMitari: true };
  consoleHousing.userData = { isAtmSubmissionBox: true, isMitari: true };
  interactiveObjects.push(screenPlane, consoleHousing);

  execSuiteGroup.add(atmGroup);

  basementGroup.add(execSuiteGroup);

  // =========================================================================
  // 5. OPEN OFFICE WORKSTATION ROWS (DIRECTLY MATCHING RIGHT SIDE OF IMAGE.PNG)
  // =========================================================================
  const workstationsGroup = new THREE.Group();
  workstationsGroup.name = 'OpenOfficeWorkstations';

  // 2 Double-Sided Workstation Pods (North Row and South Row)
  const podConfigs = [
    { x: 4.5, z: -3.2 },
    { x: 4.5, z: 3.2 },
  ];

  podConfigs.forEach((pod, podIdx) => {
    const podGroup = new THREE.Group();
    podGroup.position.set(pod.x, FLOOR_Y, pod.z);

    // Long Shared White Desk Tops (Cantilevered modern frame)
    const deskW = 7.6;
    const deskD = 1.8;

    const deskTop = new THREE.Mesh(new THREE.BoxGeometry(deskW, 0.08, deskD), whiteDeskMat);
    deskTop.position.set(0, 0.75, 0);

    // White Sturdy Steel Legs
    [-deskW / 2 + 0.2, 0, deskW / 2 - 0.2].forEach((lx) => {
      const legFrame = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.75, deskD - 0.2), whiteMetalMat);
      legFrame.position.set(lx, 0.375, 0);
      podGroup.add(legFrame);
    });

    // Chartreuse / Lime Green Acoustic Fabric Privacy Divider Screen (Matching image.png!)
    // For Pod 1 where Chloe works, give Chloe's lead station an open front view so her full 3D avatar mesh renders unobstructed
    const chartreuseTex = createChartreuseFabricTexture();
    const dividerMat = new THREE.MeshStandardMaterial({ map: chartreuseTex, roughness: 0.7 });
    
    if (podIdx === 0) {
      // Open executive clearance for Chloe's station at left (x < -1.0)
      const dividerScreen = new THREE.Mesh(new THREE.BoxGeometry(deskW - 2.6, 0.38, 0.06), dividerMat);
      dividerScreen.position.set(1.2, 0.96, 0);

      // Low-profile sleek acoustic trim in front of Chloe's station for clear sightline
      const chloeTrimMat = new THREE.MeshStandardMaterial({ color: 0x38bdf8, roughness: 0.3, metalness: 0.8 });
      const chloeFrontTrim = new THREE.Mesh(new THREE.BoxGeometry(2.3, 0.08, 0.04), chloeTrimMat);
      chloeFrontTrim.position.set(-2.4, 0.81, 0);

      podGroup.add(deskTop, dividerScreen, chloeFrontTrim);
    } else {
      const dividerScreen = new THREE.Mesh(new THREE.BoxGeometry(deskW - 0.2, 0.38, 0.06), dividerMat);
      dividerScreen.position.set(0, 0.96, 0);
      podGroup.add(deskTop, dividerScreen);
    }

    // 4 Workstation Seats per Pod (2 North Seats, 2 South Seats)
    [-2.2, 0.0, 2.2].forEach((ox, seatCol) => {
      // 1. White Under-Desk 3-Drawer Mobile Pedestals
      const pedN = new THREE.Mesh(new THREE.BoxGeometry(0.42, 0.6, 0.55), whiteMetalMat);
      pedN.position.set(ox + 0.45, 0.3, -0.45);
      const pedS = new THREE.Mesh(new THREE.BoxGeometry(0.42, 0.6, 0.55), whiteMetalMat);
      pedS.position.set(ox + 0.45, 0.3, 0.45);
      podGroup.add(pedN, pedS);

      // 2. EMPLOYEE-FACING LAPTOPS & SCREENS:
      // A. North Employee (Seated at Z = -1.15, facing SOUTH / +Z into desk)
      // Screen MUST FACE NORTH (-Z) directly towards the seated employee's eyes!
      const lapNBase = new THREE.Mesh(new THREE.BoxGeometry(0.4, 0.015, 0.28), whiteMetalMat);
      lapNBase.position.set(ox - 0.2, 0.8, -0.5);

      const lapNScreen = new THREE.Mesh(
        new THREE.BoxGeometry(0.4, 0.26, 0.015),
        new THREE.MeshStandardMaterial({ color: 0x0f172a, emissive: 0x38bdf8, emissiveIntensity: 0.6 })
      );
      // Angled facing North towards seated employee
      lapNScreen.position.set(ox - 0.2, 0.95, -0.62);
      lapNScreen.rotation.x = -0.25;

      // Ergonomic Grey Mesh Chair with White Outer Frame (North)
      const chairNGroup = new THREE.Group();
      chairNGroup.position.set(ox - 0.2, 0, -1.25);
      const cBaseN = new THREE.Mesh(new THREE.CylinderGeometry(0.26, 0.26, 0.06, 6), darkTrimMat);
      cBaseN.position.y = 0.12;
      const cSeatN = new THREE.Mesh(new THREE.BoxGeometry(0.48, 0.08, 0.46), greyMeshMat);
      cSeatN.position.y = 0.45;
      const cBackN = new THREE.Mesh(new THREE.BoxGeometry(0.45, 0.55, 0.06), greyMeshMat);
      cBackN.position.set(0, 0.72, -0.22);
      const cFrameN = new THREE.Mesh(new THREE.BoxGeometry(0.49, 0.59, 0.04), whiteMetalMat);
      cFrameN.position.set(0, 0.72, -0.24);
      chairNGroup.add(cBaseN, cSeatN, cBackN, cFrameN);

      // B. South Employee (Seated at Z = +1.25, facing NORTH / -Z into desk)
      // Screen MUST FACE SOUTH (+Z) directly towards the seated employee's eyes!
      const lapSBase = new THREE.Mesh(new THREE.BoxGeometry(0.4, 0.015, 0.28), whiteMetalMat);
      lapSBase.position.set(ox - 0.2, 0.8, 0.5);

      const lapSScreen = new THREE.Mesh(
        new THREE.BoxGeometry(0.4, 0.26, 0.015),
        new THREE.MeshStandardMaterial({ color: 0x0f172a, emissive: 0x22c55e, emissiveIntensity: 0.6 })
      );
      // Angled facing South towards seated employee
      lapSScreen.position.set(ox - 0.2, 0.95, 0.62);
      lapSScreen.rotation.x = 0.25;

      // Ergonomic Grey Mesh Chair with White Outer Frame (South)
      const chairSGroup = new THREE.Group();
      chairSGroup.position.set(ox - 0.2, 0, 1.25);
      const cBaseS = new THREE.Mesh(new THREE.CylinderGeometry(0.26, 0.26, 0.06, 6), darkTrimMat);
      cBaseS.position.y = 0.12;
      const cSeatS = new THREE.Mesh(new THREE.BoxGeometry(0.48, 0.08, 0.46), greyMeshMat);
      cSeatS.position.y = 0.45;
      const cBackS = new THREE.Mesh(new THREE.BoxGeometry(0.45, 0.55, 0.06), greyMeshMat);
      cBackS.position.set(0, 0.72, 0.22);
      const cFrameS = new THREE.Mesh(new THREE.BoxGeometry(0.49, 0.59, 0.04), whiteMetalMat);
      cFrameS.position.set(0, 0.72, 0.24);
      chairSGroup.add(cBaseS, cSeatS, cBackS, cFrameS);

      podGroup.add(lapNBase, lapNScreen, chairNGroup, lapSBase, lapSScreen, chairSGroup);

      // Interactive Chair Hitboxes
      const deskIdN = `B1_Desk_P${podIdx + 1}_N${seatCol + 1}`;
      const seatHitboxN = new THREE.Mesh(new THREE.BoxGeometry(0.7, 0.8, 0.7), new THREE.MeshBasicMaterial({ visible: false }));
      seatHitboxN.position.set(pod.x + ox - 0.2, FLOOR_Y + 0.4, pod.z - 1.25);
      seatHitboxN.userData = {
        isMeetingChair: true,
        seatPos: { x: pod.x + ox - 0.2, y: FLOOR_Y + 0.1, z: pod.z - 1.25 },
        rotY: 0,
        title: deskIdN,
      };
      basementGroup.add(seatHitboxN);
      interactiveObjects.push(seatHitboxN);

      const deskIdS = `B1_Desk_P${podIdx + 1}_S${seatCol + 1}`;
      const seatHitboxS = new THREE.Mesh(new THREE.BoxGeometry(0.7, 0.8, 0.7), new THREE.MeshBasicMaterial({ visible: false }));
      seatHitboxS.position.set(pod.x + ox - 0.2, FLOOR_Y + 0.4, pod.z + 1.25);
      seatHitboxS.userData = {
        isMeetingChair: true,
        seatPos: { x: pod.x + ox - 0.2, y: FLOOR_Y + 0.1, z: pod.z + 1.25 },
        rotY: Math.PI,
        title: deskIdS,
      };
      basementGroup.add(seatHitboxS);
      interactiveObjects.push(seatHitboxS);
    });

    workstationsGroup.add(podGroup);
  });

  // Long Low Storage Credenzas with Rectangular Planter Trough & Lush Indoor Hedge (Between Pods, matching image.png!)
  const PLANTER_Z = 0.0;
  const PLANTER_X = 4.5;
  const PLANTER_W = 7.6;

  const planterCredenza = new THREE.Mesh(new THREE.BoxGeometry(PLANTER_W, 0.75, 0.65), whiteDeskMat);
  planterCredenza.position.set(PLANTER_X, FLOOR_Y + 0.375, PLANTER_Z);

  // Rectangular Planter Box Trough
  const planterTrough = new THREE.Mesh(new THREE.BoxGeometry(PLANTER_W - 0.2, 0.22, 0.5), darkTrimMat);
  planterTrough.position.set(PLANTER_X, FLOOR_Y + 0.85, PLANTER_Z);

  // Dense Vibrant Green Foliage Hedge (Matching image.png!)
  const hedgeBush = new THREE.Mesh(
    new THREE.BoxGeometry(PLANTER_W - 0.3, 0.32, 0.42),
    plantFoliageMat
  );
  hedgeBush.position.set(PLANTER_X, FLOOR_Y + 1.05, PLANTER_Z);

  workstationsGroup.add(planterCredenza, planterTrough, hedgeBush);
  basementGroup.add(workstationsGroup);

  // =========================================================================
  // 6. GIANT 8K BLACK PRESENTATION SCREEN (ALLOWS "SHARE SCREEN" FOR USER)
  // =========================================================================
  const screenTex = createGiantBlackMonitorTexture();
  const screenMat = new THREE.MeshBasicMaterial({ map: screenTex });

  const SCREEN_W = 9.2;
  const SCREEN_H = 3.6;
  const SCREEN_X = -0.5;
  const SCREEN_Z = -ROOM_D / 2 + 0.2;

  // Ultra-Thin Minimalist Bezel Outer Frame
  const screenFrame = new THREE.Mesh(
    new THREE.BoxGeometry(SCREEN_W + 0.18, SCREEN_H + 0.18, 0.08),
    darkTrimMat
  );
  screenFrame.position.set(SCREEN_X, FLOOR_Y + 2.4, SCREEN_Z);

  // Live Screen Projection Plane (Giant 8K Black Monitor)
  const basementScreenMesh = new THREE.Mesh(
    new THREE.PlaneGeometry(SCREEN_W, SCREEN_H),
    screenMat
  );
  basementScreenMesh.position.set(SCREEN_X, FLOOR_Y + 2.4, SCREEN_Z + 0.05);
  basementScreenMesh.name = 'B1CorporateOfficeScreen';
  basementScreenMesh.userData = {
    isScreen: true,
    isB1Screen: true,
    title: 'Giant 8K Presentation Screen (Click to Share Screen)',
  };

  interactiveObjects.push(basementScreenMesh);
  basementGroup.add(screenFrame, basementScreenMesh);

  // Ambient Screen Glow Light
  const screenGlow = new THREE.PointLight(0x38bdf8, 1.2, 8.0);
  screenGlow.position.set(SCREEN_X, FLOOR_Y + 2.4, SCREEN_Z + 1.0);
  basementGroup.add(screenGlow);

  // =========================================================================
  // 7. B1 WORKSPACE EMPLOYEES (ANIMATED 3D VOXEL AVATARS)
  // Note: Chloe Becker is provided as a live dynamic NPC in connectedUsers / remoteUsers,
  // preventing any duplicate mesh instantiation in the scene.
  // =========================================================================
  const employeeAvatarsGroup = new THREE.Group();
  employeeAvatarsGroup.name = 'B1Employees';

  // 1. Olivia Dubois (Caucasian Brunette Product Designer) at Pod 1 South
  const oliviaUser: UserState = {
    id: 'npc_b1_olivia',
    name: 'Olivia Dubois',
    skin: 'college_dev_f',
    department: 'Design',
    ethnicity: 'caucasian_2',
    hairColor: '#5c2b0e',
    position: { x: 4.5 + 0.0 - 0.2, y: FLOOR_Y, z: -3.2 + 1.25 },
    rotationY: Math.PI,
    isMoving: false,
    isSpeaking: false,
    isMuted: true,
    isScreenSharing: false,
    claimedDeskId: 'B1_Desk_P1_S2',
    statusText: 'Prototyping 3D Spatial Canvas 🎨',
    color: '#a855f7',
  };
  const oliviaAvatar = createVoxelAvatarMesh(oliviaUser);
  oliviaAvatar.group.position.set(4.5 + 0.0 - 0.2, FLOOR_Y, -3.2 + 1.25);
  oliviaAvatar.group.rotation.y = Math.PI; // Face -Z into desk
  oliviaAvatar.updateAnimation(0, false, false, true);
  oliviaAvatar.group.updateMatrixWorld(true);
  employeeAvatarsGroup.add(oliviaAvatar.group);

  // 2. Grace Chen (Asian Cloud & Infrastructure Engineer) at Pod 2 North
  const graceUser: UserState = {
    id: 'npc_b1_grace',
    name: 'Californian Roll',
    skin: 'college_dev_f',
    department: 'Engineering',
    ethnicity: 'east_asian_1',
    hairColor: '#0f0f11',
    position: { x: 4.5 + 0.0 - 0.2, y: FLOOR_Y, z: 3.2 - 1.25 },
    rotationY: 0,
    isMoving: false,
    isSpeaking: false,
    isMuted: true,
    isScreenSharing: false,
    claimedDeskId: 'B1_Desk_P2_N2',
    statusText: 'Zero-downtime cluster scale ⚡',
    color: '#06b6d4',
  };
  const graceAvatar = createVoxelAvatarMesh(graceUser);
  graceAvatar.group.position.set(4.5 + 0.0 - 0.2, FLOOR_Y, 3.2 - 1.25);
  graceAvatar.group.rotation.y = 0; // Face +Z into desk
  graceAvatar.updateAnimation(0, false, false, true);
  graceAvatar.group.updateMatrixWorld(true);
  employeeAvatarsGroup.add(graceAvatar.group);

  // 3. Marcus Washington (African American AI Research Lead) at Pod 2 South
  const marcusUser: UserState = {
    id: 'npc_b1_marcus',
    name: 'Marcus Washington',
    skin: 'college_dev_m',
    department: 'Engineering',
    ethnicity: 'black_1',
    hairColor: '#0f0f11',
    position: { x: 4.5 + 2.2 - 0.2, y: FLOOR_Y, z: 3.2 + 1.25 },
    rotationY: Math.PI,
    isMoving: false,
    isSpeaking: false,
    isMuted: true,
    isScreenSharing: false,
    claimedDeskId: 'B1_Desk_P2_S3',
    statusText: 'Fine-tuning Gemini agents 🧠',
    color: '#f59e0b',
  };
  const marcusAvatar = createVoxelAvatarMesh(marcusUser);
  marcusAvatar.group.position.set(4.5 + 2.2 - 0.2, FLOOR_Y, 3.2 + 1.25);
  marcusAvatar.group.rotation.y = Math.PI; // Face -Z into desk
  marcusAvatar.updateAnimation(0, false, false, true);
  marcusAvatar.group.updateMatrixWorld(true);
  employeeAvatarsGroup.add(marcusAvatar.group);

  // Employee Desk Accessories (Coffee Mugs, Notebooks, Ceramic Tumblers)
  const coffeeMugMat = new THREE.MeshStandardMaterial({ color: 0x38bdf8, roughness: 0.3 });
  const ceramicMugMat = new THREE.MeshStandardMaterial({ color: 0xf43f5e, roughness: 0.4 });
  const notebookMat = new THREE.MeshStandardMaterial({ color: 0xf59e0b, roughness: 0.5 });

  // Mugs & Accessories on Pods
  const mug1 = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.035, 0.08, 8), coffeeMugMat);
  mug1.position.set(4.5 - 2.2 + 0.2, FLOOR_Y + 0.83, -3.2 - 0.4);
  const note1 = new THREE.Mesh(new THREE.BoxGeometry(0.2, 0.01, 0.25), notebookMat);
  note1.position.set(4.5 - 2.2 + 0.2, FLOOR_Y + 0.8, -3.2 - 0.6);

  const mug2 = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.035, 0.08, 8), ceramicMugMat);
  mug2.position.set(4.5 + 0.0 + 0.2, FLOOR_Y + 0.83, -3.2 + 0.4);

  const mug3 = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.035, 0.08, 8), coffeeMugMat);
  mug3.position.set(4.5 + 0.0 + 0.2, FLOOR_Y + 0.83, 3.2 - 0.4);

  const mug4 = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.035, 0.08, 8), ceramicMugMat);
  mug4.position.set(4.5 + 2.2 + 0.2, FLOOR_Y + 0.83, 3.2 + 0.4);

  employeeAvatarsGroup.add(mug1, note1, mug2, mug3, mug4);
  basementGroup.add(employeeAvatarsGroup);

  return {
    basementGroup,
    basementScreenMesh,
    interactiveObjects,
    updateBasementTheater: (
      time: number,
      delta: number,
      playerPos?: { x: number; y: number; z: number },
      isChloeTalking?: boolean
    ) => {
      // Dynamic Typing & Seated Idle Animations for B1 Employees
      oliviaAvatar.updateAnimation(time + 1.2, false, false, true);
      graceAvatar.updateAnimation(time + 2.4, false, false, true);
      marcusAvatar.updateAnimation(time + 3.6, false, false, true);

      oliviaAvatar.headMesh.rotation.y = Math.cos(time * 1.3) * 0.12;
      graceAvatar.headMesh.rotation.y = Math.sin(time * 2.0) * 0.08;
      marcusAvatar.headMesh.rotation.y = Math.cos(time * 1.7) * 0.14;
    },
  };
}
