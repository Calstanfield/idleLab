import { Position3D, UserState, DeskData } from '../types';

export interface EntityCollider {
  id: string;
  name: string;
  x: number;
  y: number;
  z: number;
  radius: number;
  rotY?: number;
  isNPC?: boolean;
  isSeated?: boolean;
  isDeskOrFurniture?: boolean;
  boxBounds?: { minX: number; maxX: number; minZ: number; maxZ: number };
}

// Standard personal space and avatar boundary constants (in 3D world meters)
export const AVATAR_COLLISION_RADIUS = 0.52; // Individual avatar physical radius (~1.04m body barrier)
export const MIN_AVATAR_DISTANCE = 1.05; // Strict minimum distance between two avatar centers
export const SAFE_DISTANCE_BUFFER = 1.8; // Strict safe distance buffer around all NPCs and User Avatars
export const RESPECTFUL_PERSONAL_SPACE = 1.8; // Comfortable conversational & click approach distance
export const SEAT_OCCUPIED_THRESHOLD = 0.65; // Distance to consider a chair/seat occupied

export type OfficeFloorCode = '1F' | '2F' | '3F' | 'B1';

export function getFloorCode(y: number): OfficeFloorCode {
  if (y >= 8.5) return '3F';
  if (y >= 3.0) return '2F';
  if (y <= -3.0) return 'B1';
  return '1F';
}

export interface SpatialCollisionCheckResult {
  current_floor: OfficeFloorCode;
  safe_distance_maintained: boolean;
  target_seat_occupied: boolean;
  navigation_action: 'MOVE' | 'HALT_AND_REROUTE' | 'STANDBY';
  clearance_buffer_units: number;
}

// Known stationary NPCs across all office floors
export const STATIC_OFFICE_NPCS: Array<{
  id: string;
  name: string;
  pos: Position3D;
  rotY: number;
  radius: number;
  isSeated: boolean;
  frontOffset?: { x: number; z: number };
}> = [
  // B1 Corporate Workspace NPCs (Floor Y = -6.0)
  {
    id: 'npc_b1_chloe',
    name: 'Chloe Becker',
    pos: { x: 2.1, y: -6.0, z: -4.15 },
    rotY: 0,
    radius: 0.50,
    isSeated: true,
    frontOffset: { x: 0, z: 1.15 }, // In front of her desk at z = -3.0
  },
  {
    id: 'npc_b1_olivia',
    name: 'Olivia Dubois',
    pos: { x: 4.3, y: -6.0, z: -1.95 },
    rotY: Math.PI,
    radius: 0.48,
    isSeated: true,
    frontOffset: { x: 0, z: -1.05 },
  },
  {
    id: 'npc_b1_grace',
    name: 'Californian Roll',
    pos: { x: 4.3, y: -6.0, z: 1.95 },
    rotY: 0,
    radius: 0.48,
    isSeated: true,
    frontOffset: { x: 0, z: 1.05 },
  },
  {
    id: 'npc_b1_marcus',
    name: 'Marcus Washington',
    pos: { x: 6.5, y: -6.0, z: 4.45 },
    rotY: Math.PI,
    radius: 0.48,
    isSeated: true,
    frontOffset: { x: 0, z: -1.05 },
  },
  {
    id: 'npc_b1_tennis_bot',
    name: 'Tesla Optimus Tennis Bot',
    pos: { x: 35.0, y: -6.0, z: 0.0 },
    rotY: -Math.PI / 2,
    radius: 0.80,
    isSeated: false,
    frontOffset: { x: -1.5, z: 0 },
  },

  // 3F Lofi Study Cafe NPCs (Floor Y = 11.0)
  {
    id: 'npc_lofi_girl',
    name: 'Lofi Girl',
    pos: { x: -8.4, y: 11.0, z: 0.0 },
    rotY: Math.PI / 2,
    radius: 0.50,
    isSeated: true,
    frontOffset: { x: 1.1, z: 0 },
  },
  {
    id: 'npc_barista_alex',
    name: 'Barista Alex',
    pos: { x: 8.6, y: 11.0, z: 0.0 },
    rotY: -Math.PI / 2,
    radius: 0.52,
    isSeated: false,
    frontOffset: { x: -1.2, z: 0 },
  },
  {
    id: 'npc_student_0',
    name: 'Emma Schneider',
    pos: { x: -0.6, y: 11.0, z: -5.5 },
    rotY: -Math.PI / 2,
    radius: 0.48,
    isSeated: true,
    frontOffset: { x: 1.05, z: 0 },
  },
  {
    id: 'npc_student_1',
    name: 'David Tanaka',
    pos: { x: 1.6, y: 11.0, z: -5.5 },
    rotY: Math.PI / 2,
    radius: 0.48,
    isSeated: true,
    frontOffset: { x: -1.05, z: 0 },
  },
  {
    id: 'npc_student_2',
    name: 'Sophie Laurent',
    pos: { x: -0.6, y: 11.0, z: 5.5 },
    rotY: -Math.PI / 2,
    radius: 0.48,
    isSeated: true,
    frontOffset: { x: 1.05, z: 0 },
  },
  {
    id: 'npc_student_3',
    name: 'Ryan Patel',
    pos: { x: 1.6, y: 11.0, z: 5.5 },
    rotY: Math.PI / 2,
    radius: 0.48,
    isSeated: true,
    frontOffset: { x: -1.05, z: 0 },
  },
];

/**
 * Returns all active collidable entities (remote players, NPCs, furniture obstacles)
 * currently on the same floor level as the player.
 */
export function getFloorColliders(
  currentFloorY: number,
  remoteUsers: Map<string, UserState>,
  currentUserId?: string,
  desks?: DeskData[]
): EntityCollider[] {
  const colliders: EntityCollider[] = [];
  const addedIds = new Set<string>();

  // 1. Add all Remote User Avatars on this floor
  remoteUsers.forEach((remoteUser, userId) => {
    if (currentUserId && userId === currentUserId) return;
    const remoteY = remoteUser.position.y || 0;
    if (Math.abs(remoteY - currentFloorY) < 2.0) {
      colliders.push({
        id: userId,
        name: remoteUser.name || 'Colleague',
        x: remoteUser.position.x,
        y: remoteY,
        z: remoteUser.position.z,
        radius: AVATAR_COLLISION_RADIUS,
        rotY: remoteUser.rotationY,
        isNPC: remoteUser.isNPC || userId.startsWith('npc_'),
        isSeated: !!remoteUser.claimedDeskId || (!remoteUser.isMoving && Math.abs(remoteUser.position.x) > 1.5),
      });
      addedIds.add(userId);
    }
  });

  // 2. Add static NPCs on this floor (if not already included in remoteUsers)
  STATIC_OFFICE_NPCS.forEach((npc) => {
    if (Math.abs(npc.pos.y - currentFloorY) < 2.0 && !addedIds.has(npc.id)) {
      colliders.push({
        id: npc.id,
        name: npc.name,
        x: npc.pos.x,
        y: npc.pos.y,
        z: npc.pos.z,
        radius: npc.radius || AVATAR_COLLISION_RADIUS,
        rotY: npc.rotY,
        isNPC: true,
        isSeated: npc.isSeated,
      });
      addedIds.add(npc.id);
    }
  });

  // 3. 1F Main Office: Obstacle-free walking (no furniture or plant collision barriers)

  // 4. Solid Obstacles for B1 (Manager Suite glass partitions & B1 Workstation pods)
  if (Math.abs(currentFloorY - (-6.0)) < 1.5) {
    // Planter hedge between pods
    colliders.push({
      id: 'b1_planter_hedge',
      name: 'Planter Credenza',
      x: 4.5,
      y: -6.0,
      z: 0.0,
      radius: 1.8,
      isDeskOrFurniture: true,
      boxBounds: { minX: 0.6, maxX: 8.4, minZ: -0.4, maxZ: 0.4 },
    });

    // Pod 1 desk table
    colliders.push({
      id: 'b1_pod1_table',
      name: 'B1 Pod 1 Workstations',
      x: 4.5,
      y: -6.0,
      z: -3.2,
      radius: 1.8,
      isDeskOrFurniture: true,
      boxBounds: { minX: 2.0, maxX: 7.0, minZ: -3.7, maxZ: -2.7 },
    });

    // Pod 2 desk table
    colliders.push({
      id: 'b1_pod2_table',
      name: 'B1 Pod 2 Workstations',
      x: 4.5,
      y: -6.0,
      z: 3.2,
      radius: 1.8,
      isDeskOrFurniture: true,
      boxBounds: { minX: 2.0, maxX: 7.0, minZ: 2.7, maxZ: 3.7 },
    });
  }

  return colliders;
}

/**
 * Checks and resolves avatar collisions against all other avatars, NPCs, and obstacles.
 * Uses continuous sliding response so the avatar smoothly glides along the personal space boundary.
 */
export function resolveAvatarCollisions(
  arg1: number,
  arg2: number,
  arg3: number | EntityCollider[],
  arg4?: number | EntityCollider[],
  arg5?: EntityCollider[] | number,
  arg6?: number
): { x: number; z: number; hadCollision: boolean; collidedWith?: EntityCollider } {
  let prevX: number | undefined;
  let prevZ: number | undefined;
  let targetX: number;
  let targetZ: number;
  let colliders: EntityCollider[];
  let myRadius: number = AVATAR_COLLISION_RADIUS;
  let maxIterations: number = 3;

  if (typeof arg3 === 'number' && typeof arg4 === 'number' && Array.isArray(arg5)) {
    // Called as (prevX, prevZ, targetX, targetZ, colliders, myRadius)
    prevX = arg1;
    prevZ = arg2;
    targetX = arg3;
    targetZ = arg4;
    colliders = arg5;
    if (typeof arg6 === 'number') myRadius = arg6;
  } else {
    // Called as (targetX, targetZ, colliders, myRadius, maxIterations)
    targetX = arg1;
    targetZ = arg2;
    colliders = Array.isArray(arg3) ? (arg3 as EntityCollider[]) : [];
    if (typeof arg4 === 'number') myRadius = arg4;
    if (typeof arg5 === 'number') maxIterations = arg5;
  }

  let currX = targetX;
  let currZ = targetZ;
  let hadCollision = false;
  let lastCollided: EntityCollider | undefined = undefined;

  for (let iter = 0; iter < maxIterations; iter++) {
    let movedThisPass = false;

    for (let i = 0; i < colliders.length; i++) {
      const col = colliders[i];

      // 1. Box Bounds Collision (for desks and rectangular tables)
      if (col.boxBounds) {
        const box = col.boxBounds;
        const expandedMinX = box.minX - myRadius;
        const expandedMaxX = box.maxX + myRadius;
        const expandedMinZ = box.minZ - myRadius;
        const expandedMaxZ = box.maxZ + myRadius;

        if (currX > expandedMinX && currX < expandedMaxX && currZ > expandedMinZ && currZ < expandedMaxZ) {
          hadCollision = true;
          lastCollided = col;
          movedThisPass = true;

          // Find shortest push-out vector to the nearest edge
          const distLeft = currX - expandedMinX;
          const distRight = expandedMaxX - currX;
          const distTop = currZ - expandedMinZ;
          const distBottom = expandedMaxZ - currZ;

          const minDist = Math.min(distLeft, distRight, distTop, distBottom);
          if (minDist === distLeft) currX = expandedMinX;
          else if (minDist === distRight) currX = expandedMaxX;
          else if (minDist === distTop) currZ = expandedMinZ;
          else if (minDist === distBottom) currZ = expandedMaxZ;
        }
        continue;
      }

      // 2. Circular / Cylindrical Collision (for Avatars, NPCs, round chairs)
      const requiredDist = myRadius + (col.radius || AVATAR_COLLISION_RADIUS);
      const dx = currX - col.x;
      const dz = currZ - col.z;
      const distSq = dx * dx + dz * dz;

      if (distSq < requiredDist * requiredDist) {
        hadCollision = true;
        lastCollided = col;
        movedThisPass = true;

        if (distSq > 0.0001) {
          const dist = Math.sqrt(distSq);
          const overlap = requiredDist - dist;
          const nx = dx / dist;
          const nz = dz / dist;

          // Push smoothly out to the edge of personal space
          currX += nx * overlap;
          currZ += nz * overlap;
        } else {
          // Exact center overlap: push out in default orientation
          currX += requiredDist;
        }
      }
    }

    if (!movedThisPass) break;
  }

  return { x: currX, z: currZ, hadCollision, collidedWith: lastCollided };
}

/**
 * Validates and adjusts a clicked navigation target to prevent walking directly into,
 * morphing, or overlapping inside an avatar or NPC.
 * If the clicked tile is occupied, projects to a respectful conversation spot in front of the entity.
 */
export function adjustClickDestinationForPersonalSpace(
  myPos: Position3D,
  targetPos: Position3D,
  colliders: EntityCollider[],
  personalSpaceDist: number = RESPECTFUL_PERSONAL_SPACE
): { safeTarget: Position3D; wasAdjusted: boolean; targetEntity?: EntityCollider } {
  for (const col of colliders) {
    // If clicking on a box furniture (desk), stand right at the user side
    if (col.boxBounds) {
      const box = col.boxBounds;
      const inBox =
        targetPos.x >= box.minX - 0.3 &&
        targetPos.x <= box.maxX + 0.3 &&
        targetPos.z >= box.minZ - 0.3 &&
        targetPos.z <= box.maxZ + 0.3;

      if (inBox) {
        // Approach from player's direction
        const dx = myPos.x - col.x;
        const dz = myPos.z - col.z;
        const dist = Math.hypot(dx, dz);
        if (dist > 0.1) {
          const nx = dx / dist;
          const nz = dz / dist;
          return {
            safeTarget: {
              x: col.x + nx * (col.radius + 0.4),
              y: targetPos.y,
              z: col.z + nz * (col.radius + 0.4),
            },
            wasAdjusted: true,
            targetEntity: col,
          };
        }
      }
      continue;
    }

    // Avatar / NPC Personal Space Boundary Check
    const effectiveRadius = col.radius || AVATAR_COLLISION_RADIUS;
    const boundaryDist = effectiveRadius + personalSpaceDist;
    const dx = targetPos.x - col.x;
    const dz = targetPos.z - col.z;
    const dist = Math.hypot(dx, dz);

    if (dist < boundaryDist) {
      // The clicked point is inside the personal space boundary of an avatar/NPC!
      // Check if this NPC has a preconfigured front approach point
      const staticNpc = STATIC_OFFICE_NPCS.find((n) => n.id === col.id);
      if (staticNpc?.frontOffset) {
        return {
          safeTarget: {
            x: col.x + staticNpc.frontOffset.x,
            y: targetPos.y,
            z: col.z + staticNpc.frontOffset.z,
          },
          wasAdjusted: true,
          targetEntity: col,
        };
      }

      // If entity is facing a direction, prefer standing in front of them if player is generally in front
      if (typeof col.rotY === 'number') {
        const facingX = Math.sin(col.rotY);
        const facingZ = -Math.cos(col.rotY);
        const toPlayerX = myPos.x - col.x;
        const toPlayerZ = myPos.z - col.z;
        const playerDist = Math.hypot(toPlayerX, toPlayerZ);

        // If player is within line of sight, approach along ray towards player
        if (playerDist > 0.1) {
          const px = toPlayerX / playerDist;
          const pz = toPlayerZ / playerDist;
          return {
            safeTarget: {
              x: col.x + px * boundaryDist,
              y: targetPos.y,
              z: col.z + pz * boundaryDist,
            },
            wasAdjusted: true,
            targetEntity: col,
          };
        }
      }

      // Default: project along line from avatar to player
      const dirX = myPos.x - col.x;
      const dirZ = myPos.z - col.z;
      const dirDist = Math.hypot(dirX, dirZ);

      const nx = dirDist > 0.01 ? dirX / dirDist : 1;
      const nz = dirDist > 0.01 ? dirZ / dirDist : 0;

      return {
        safeTarget: {
          x: col.x + nx * boundaryDist,
          y: targetPos.y,
          z: col.z + nz * boundaryDist,
        },
        wasAdjusted: true,
        targetEntity: col,
      };
    }
  }

  // Target is clear of all personal space boundaries
  return { safeTarget: { ...targetPos }, wasAdjusted: false };
}

/**
 * Checks if a specific seat position is currently occupied by any avatar or NPC.
 */
export function isSeatOccupied(
  seatPos: Position3D,
  colliders: EntityCollider[],
  threshold: number = SEAT_OCCUPIED_THRESHOLD
): { occupied: boolean; occupant?: EntityCollider } {
  for (const col of colliders) {
    if (col.isDeskOrFurniture) continue;
    const dist = Math.hypot(seatPos.x - col.x, seatPos.z - col.z);
    if (dist < threshold) {
      return { occupied: true, occupant: col };
    }
  }
  return { occupied: false };
}

/**
 * Evaluates the full Spatial Safety & Anti-Collision Matrix across floors (3F, 2F, 1F, B1):
 * - Rule 1 (Physical Bounding): 1.5u safe distance buffer around all NPCs & Avatars
 * - Rule 2 (Seat/Furniture Reservation): Check occupied seat state
 * - Rule 3 (Dynamic Rerouting): Flag HALT_AND_REROUTE when encroaching on the 1.5u zone
 */
export function evaluateSpatialSafetyMatrix(
  currentPos: Position3D,
  targetPos?: Position3D | null,
  targetSeatPos?: Position3D | null,
  colliders: EntityCollider[] = [],
  isMoving: boolean = false
): SpatialCollisionCheckResult {
  const currentFloor = getFloorCode(currentPos.y);
  let safeDistanceMaintained = true;
  let targetSeatOccupied = false;

  // Check seat reservation rule
  if (targetSeatPos) {
    const seatCheck = isSeatOccupied(targetSeatPos, colliders);
    targetSeatOccupied = seatCheck.occupied;
  }

  // Check 1.5u clearance buffer against all active colliders
  for (const col of colliders) {
    if (col.isDeskOrFurniture) continue;
    const dist = Math.hypot(currentPos.x - col.x, currentPos.z - col.z);
    if (dist < SAFE_DISTANCE_BUFFER) {
      safeDistanceMaintained = false;
      break;
    }
  }

  let navigationAction: 'MOVE' | 'HALT_AND_REROUTE' | 'STANDBY' = 'STANDBY';
  if (isMoving) {
    if (!safeDistanceMaintained || (targetSeatPos && targetSeatOccupied)) {
      navigationAction = 'HALT_AND_REROUTE';
    } else {
      navigationAction = 'MOVE';
    }
  } else {
    navigationAction = 'STANDBY';
  }

  return {
    current_floor: currentFloor,
    safe_distance_maintained: safeDistanceMaintained,
    target_seat_occupied: targetSeatOccupied,
    navigation_action: navigationAction,
    clearance_buffer_units: SAFE_DISTANCE_BUFFER,
  };
}

