import * as THREE from 'three';
import { ScooterConfig } from '../types';

export interface ScooterMeshGroup {
  group: THREE.Group;
  steeringGroup: THREE.Group;
  frontWheelGroup: THREE.Group;
  rearWheelGroup: THREE.Group;
  updateScooter: (isMoving: boolean, dt: number, turnAngle: number, speed: number) => void;
  updateColors: (config: ScooterConfig) => void;
  dispose: () => void;
}

export function createScooterMesh(initialConfig: Partial<ScooterConfig> = {}): ScooterMeshGroup {
  const scooterGroup = new THREE.Group();

  const config: ScooterConfig = {
    frameColor: initialConfig.frameColor || '#00e676',
    deckColor: initialConfig.deckColor || '#111111',
    rimColor: initialConfig.rimColor || '#222222',
    gripColor: initialConfig.gripColor || '#00e676',
    underglowColor: initialConfig.underglowColor || '#00e676',
    accentColor: initialConfig.accentColor || '#ffffff',
  };

  // Materials
  const frameMat = new THREE.MeshStandardMaterial({
    color: config.frameColor,
    metalness: 0.6,
    roughness: 0.3,
  });

  const blackMetalMat = new THREE.MeshStandardMaterial({
    color: 0x1a1a1a,
    metalness: 0.8,
    roughness: 0.2,
  });

  const rubberMat = new THREE.MeshStandardMaterial({
    color: 0x111111,
    roughness: 0.9,
  });

  const rimMat = new THREE.MeshStandardMaterial({
    color: config.rimColor,
    metalness: 0.7,
    roughness: 0.3,
  });

  const gripMat = new THREE.MeshStandardMaterial({
    color: config.gripColor,
    roughness: 0.6,
  });

  const brakelightMat = new THREE.MeshStandardMaterial({
    color: 0xff0000,
    emissive: 0xcc0000,
    emissiveIntensity: 0.8,
  });

  const shroudMat = new THREE.MeshStandardMaterial({
    color: 0x1e293b,
    metalness: 0.4,
    roughness: 0.4,
  });

  // 1. MAIN DECK & CHASSIS ASSEMBLY
  const deckGroup = new THREE.Group();

  const chassisGeo = new THREE.BoxGeometry(0.22, 0.05, 1.15);
  const chassisMesh = new THREE.Mesh(chassisGeo, blackMetalMat);
  chassisMesh.position.set(0, 0.06, -0.01);
  deckGroup.add(chassisMesh);

  const deckMatGeo = new THREE.BoxGeometry(0.20, 0.015, 0.90);
  const deckMatMesh = new THREE.Mesh(deckMatGeo, frameMat);
  deckMatMesh.position.set(0, 0.088, -0.01);
  deckGroup.add(deckMatMesh);

  const gripTapeGeo = new THREE.BoxGeometry(0.18, 0.005, 0.82);
  const gripTapeMesh = new THREE.Mesh(gripTapeGeo, rubberMat);
  gripTapeMesh.position.set(0, 0.098, -0.01);
  deckGroup.add(gripTapeMesh);

  const underglowLight = new THREE.PointLight(config.underglowColor, 1.5, 2.0);
  underglowLight.position.set(0, 0.02, 0);
  deckGroup.add(underglowLight);

  // 2. REAR AXLE & WHEEL ASSEMBLY
  const rearAxleGroup = new THREE.Group();
  const rearWheelGroup = new THREE.Group();

  const tireGeo = new THREE.CylinderGeometry(0.099, 0.099, 0.05, 24);
  tireGeo.rotateZ(Math.PI / 2);
  const rearTire = new THREE.Mesh(tireGeo, rubberMat);
  rearWheelGroup.add(rearTire);

  const rimGeo = new THREE.CylinderGeometry(0.07, 0.07, 0.052, 16);
  rimGeo.rotateZ(Math.PI / 2);
  const rearRim = new THREE.Mesh(rimGeo, rimMat);
  rearWheelGroup.add(rearRim);

  rearAxleGroup.add(rearWheelGroup);

  const rearFenderGeo = new THREE.CylinderGeometry(0.105, 0.105, 0.06, 16, 1, true, 0, Math.PI * 0.65);
  rearFenderGeo.rotateZ(Math.PI / 2);
  rearFenderGeo.rotateY(-Math.PI * 0.32);
  const rearFender = new THREE.Mesh(rearFenderGeo, blackMetalMat);
  rearFender.position.set(0, 0.01, 0.02);
  rearAxleGroup.add(rearFender);

  const brakelightGeo = new THREE.BoxGeometry(0.06, 0.025, 0.018);
  const brakelightMesh = new THREE.Mesh(brakelightGeo, brakelightMat);
  brakelightMesh.position.set(0, 0.08, -0.06);
  rearAxleGroup.add(brakelightMesh);

  const armGeo = new THREE.BoxGeometry(0.015, 0.025, 0.14);
  const leftArm = new THREE.Mesh(armGeo, blackMetalMat);
  leftArm.position.set(-0.045, 0, 0.04);
  const rightArm = new THREE.Mesh(armGeo, blackMetalMat);
  rightArm.position.set(0.045, 0, 0.04);
  rearAxleGroup.add(leftArm);
  rearAxleGroup.add(rightArm);

  rearAxleGroup.position.set(0, 0.099, -0.56);
  deckGroup.add(rearAxleGroup);

  const kickstandGeo = new THREE.CylinderGeometry(0.008, 0.008, 0.12, 8);
  kickstandGeo.rotateZ(Math.PI / 3);
  const kickstand = new THREE.Mesh(kickstandGeo, blackMetalMat);
  kickstand.position.set(-0.13, 0.05, -0.15);
  deckGroup.add(kickstand);

  scooterGroup.add(deckGroup);

  // 3. FRONT STEERING COLUMN & REDESIGNED FRONT ASSEMBLY
  const steeringGroup = new THREE.Group();
  steeringGroup.position.set(0, 0.099, 0.58);

  // 2) Thick angled neck block connecting deck nose to steering stem base
  const neckBlockGeo = new THREE.BoxGeometry(0.09, 0.16, 0.22);
  const neckBlock = new THREE.Mesh(neckBlockGeo, frameMat);
  neckBlock.position.set(0, 0.08, -0.02);
  neckBlock.rotation.x = -0.35;
  steeringGroup.add(neckBlock);

  // 4) Tilt the stem slightly forward (+Z) so handlebars sit comfortably in front of avatar's hands
  const stemGeo = new THREE.CylinderGeometry(0.025, 0.03, 1.10, 16);
  const stemMesh = new THREE.Mesh(stemGeo, frameMat);
  stemMesh.position.set(0, 0.60, 0.04);
  stemMesh.rotation.x = 0.08; // Slightly tilted forward (+Z)
  steeringGroup.add(stemMesh);

  // Front Wheel Assembly
  const frontWheelGroup = new THREE.Group();
  const frontTire = new THREE.Mesh(tireGeo, rubberMat);
  const frontRim = new THREE.Mesh(rimGeo, rimMat);
  frontWheelGroup.add(frontTire);
  frontWheelGroup.add(frontRim);
  frontWheelGroup.position.set(0, 0, 0);
  steeringGroup.add(frontWheelGroup);

  // 1) Dual front wheel fork arms flanking the front tire
  const forkArmGeo = new THREE.BoxGeometry(0.018, 0.22, 0.035);
  const leftFork = new THREE.Mesh(forkArmGeo, frameMat);
  leftFork.position.set(-0.042, 0.11, 0);
  const rightFork = new THREE.Mesh(forkArmGeo, frameMat);
  rightFork.position.set(0.042, 0.11, 0);
  steeringGroup.add(leftFork);
  steeringGroup.add(rightFork);

  // Front mudguard over wheel
  const frontFenderGeo = new THREE.CylinderGeometry(0.105, 0.105, 0.05, 16, 1, true, 0, Math.PI * 0.6);
  frontFenderGeo.rotateZ(Math.PI / 2);
  const frontFender = new THREE.Mesh(frontFenderGeo, blackMetalMat);
  frontFender.position.set(0, 0.04, 0);
  steeringGroup.add(frontFender);

  // 3) Sleek front plastic housing/shroud for headlight and dashboard at top of stem
  const dashboardGroup = new THREE.Group();
  dashboardGroup.position.set(0, 1.10, 0.04);

  const shroudGeo = new THREE.BoxGeometry(0.12, 0.07, 0.10);
  const shroudMesh = new THREE.Mesh(shroudGeo, shroudMat);
  dashboardGroup.add(shroudMesh);

  // Digital dashboard screen inset
  const screenGeo = new THREE.BoxGeometry(0.07, 0.008, 0.05);
  const screenMat = new THREE.MeshBasicMaterial({ color: 0x38bdf8 });
  const screenMesh = new THREE.Mesh(screenGeo, screenMat);
  screenMesh.position.set(0, 0.036, 0.01);
  dashboardGroup.add(screenMesh);

  // Horizontal T-Bar Handlebar
  const barGeo = new THREE.CylinderGeometry(0.015, 0.015, 0.55, 16);
  barGeo.rotateZ(Math.PI / 2);
  const barMesh = new THREE.Mesh(barGeo, blackMetalMat);
  dashboardGroup.add(barMesh);

  // Left & Right Grips
  const gripGeo = new THREE.CylinderGeometry(0.02, 0.02, 0.12, 16);
  gripGeo.rotateZ(Math.PI / 2);
  const leftGrip = new THREE.Mesh(gripGeo, gripMat);
  leftGrip.position.set(-0.22, 0, 0);
  const rightGrip = new THREE.Mesh(gripGeo, gripMat);
  rightGrip.position.set(0.22, 0, 0);
  dashboardGroup.add(leftGrip);
  dashboardGroup.add(rightGrip);

  // Headlight built into front shroud with small circular glowing white lens mesh & three spotlight
  const headlightLight = new THREE.SpotLight(0xffffff, 2.0, 12, Math.PI / 5, 0.4);
  headlightLight.position.set(0, -0.02, 0.06);

  const headlightLensGeo = new THREE.CylinderGeometry(0.022, 0.022, 0.015, 20);
  headlightLensGeo.rotateX(Math.PI / 2);
  const headlightLensMat = new THREE.MeshStandardMaterial({
    color: 0xffffff,
    emissive: 0xffffff,
    emissiveIntensity: 3.5,
    roughness: 0.1,
  });
  const headlightLensMesh = new THREE.Mesh(headlightLensGeo, headlightLensMat);
  headlightLensMesh.position.set(0, -0.02, 0.065);
  dashboardGroup.add(headlightLensMesh);

  const lightTarget = new THREE.Object3D();
  lightTarget.position.set(0, -0.6, 5.0);
  dashboardGroup.add(lightTarget);

  headlightLight.target = lightTarget;
  dashboardGroup.add(headlightLight);

  steeringGroup.add(dashboardGroup);
  scooterGroup.add(steeringGroup);

  let wheelRotationAngle = 0;

  const updateScooter = (isMoving: boolean, dt: number, turnAngle: number, speed: number) => {
    if (isMoving) {
      const angularSpeed = Math.max(8.0, speed * 2.2);
      wheelRotationAngle += angularSpeed * dt;
      frontWheelGroup.rotation.x = wheelRotationAngle;
      rearWheelGroup.rotation.x = wheelRotationAngle;
    }

    const targetTurn = Math.max(-0.45, Math.min(0.45, turnAngle));
    steeringGroup.rotation.y = THREE.MathUtils.lerp(steeringGroup.rotation.y, targetTurn, Math.min(1.0, dt * 14));

    const targetBank = Math.max(-0.18, Math.min(0.18, -turnAngle * 0.35));
    scooterGroup.rotation.z = THREE.MathUtils.lerp(scooterGroup.rotation.z, targetBank, Math.min(1.0, dt * 10));
  };

  const updateColors = (newConfig: ScooterConfig) => {
    if (newConfig.frameColor) {
      frameMat.color.set(newConfig.frameColor);
    }
    if (newConfig.gripColor) {
      gripMat.color.set(newConfig.gripColor);
    }
    if (newConfig.rimColor) {
      rimMat.color.set(newConfig.rimColor);
    }
    if (newConfig.underglowColor) {
      if (newConfig.underglowColor === 'none') {
        underglowLight.intensity = 0;
      } else {
        underglowLight.color.set(newConfig.underglowColor);
        underglowLight.intensity = 1.5;
      }
    }
  };

  const dispose = () => {
    frameMat.dispose();
    blackMetalMat.dispose();
    rubberMat.dispose();
    rimMat.dispose();
    gripMat.dispose();
    brakelightMat.dispose();
    shroudMat.dispose();
  };

  return {
    group: scooterGroup,
    steeringGroup,
    frontWheelGroup,
    rearWheelGroup,
    updateScooter,
    updateColors,
    dispose,
  };
}
