import * as THREE from 'three';
import goldenGateImgUrl from '../assets/images/golden_gate_pixel_1786433260687.jpg';

export interface SceneryController {
  updateTraffic: (time: number) => void;
}

interface VehicleMesh {
  group: THREE.Group;
  speed: number;
  laneZ: number;
  direction: number; // 1 for +X, -1 for -X
  startX: number;
  endX: number;
}

export function buildGoldenGateScenery(sceneGroup: THREE.Group): SceneryController {
  const sceneryGroup = new THREE.Group();
  sceneryGroup.name = 'GoldenGateScenery';

  // 1. BACKDROP PANORAMA (Pixel Art Golden Gate Sunset) - EXTREMELY ENLARGED to eliminate cropping on 3F
  const textureLoader = new THREE.TextureLoader();
  const ggTexture = textureLoader.load(goldenGateImgUrl);
  ggTexture.magFilter = THREE.NearestFilter; // Sharp pixel art look
  ggTexture.minFilter = THREE.LinearFilter;

  const backdropMat = new THREE.MeshBasicMaterial({
    map: ggTexture,
    side: THREE.DoubleSide,
  });

  // Giant Panoramic Backdrop Plane behind the back window (Z = -45, Y = 18m, 180m wide x 65m tall)
  const backdropMeshBack = new THREE.Mesh(new THREE.PlaneGeometry(180, 65), backdropMat);
  backdropMeshBack.position.set(0, 18, -45);
  sceneryGroup.add(backdropMeshBack);

  // Giant Backdrop Plane behind the west window (X = -42, Y = 18m, 180m wide x 65m tall)
  const backdropMeshWest = new THREE.Mesh(new THREE.PlaneGeometry(180, 65), backdropMat);
  backdropMeshWest.position.set(-42, 18, 0);
  backdropMeshWest.rotation.y = Math.PI / 2;
  sceneryGroup.add(backdropMeshWest);

  // 2. SAN FRANCISCO BAY OCEAN WATER PLANE (Expanded to cover B1 to 3F horizon)
  const bayWaterMat = new THREE.MeshStandardMaterial({
    color: 0x1e3a5f,
    roughness: 0.2,
    metalness: 0.5,
  });
  const bayWaterPlane = new THREE.Mesh(new THREE.PlaneGeometry(220, 220), bayWaterMat);
  bayWaterPlane.rotation.x = -Math.PI / 2;
  bayWaterPlane.position.set(-10, -6.1, -25);
  sceneryGroup.add(bayWaterPlane);

  // 3. 3D GRAND GOLDEN GATE BRIDGE STRUCTURE (Positioned further back at Z = -38, perfectly aligned with image)
  const bridgeDeckY = 2.8;
  const bridgeDeckZ = -38;

  const ggOrangeMat = new THREE.MeshStandardMaterial({ color: 0xc2410c, roughness: 0.6 }); // International Orange
  const roadAsphaltMat = new THREE.MeshStandardMaterial({ color: 0x334155, roughness: 0.8 }); // Slate Asphalt
  const yellowLineMat = new THREE.MeshBasicMaterial({ color: 0xfacc15 }); // Yellow divider line
  const whiteLineMat = new THREE.MeshBasicMaterial({ color: 0xf8fafc });

  // Roadbed Base Structure (160m long span connecting directly into the backdrop picture)
  const roadbedGeo = new THREE.BoxGeometry(160, 0.6, 5.0);
  const roadbedMesh = new THREE.Mesh(roadbedGeo, roadAsphaltMat);
  roadbedMesh.position.set(-5, bridgeDeckY, bridgeDeckZ);

  // Yellow Center Double Line
  const yellowLine = new THREE.Mesh(new THREE.BoxGeometry(160, 0.02, 0.16), yellowLineMat);
  yellowLine.position.set(-5, bridgeDeckY + 0.31, bridgeDeckZ);

  // Side Guardrails
  const railNorth = new THREE.Mesh(new THREE.BoxGeometry(160, 0.5, 0.12), ggOrangeMat);
  railNorth.position.set(-5, bridgeDeckY + 0.5, bridgeDeckZ - 2.4);
  const railSouth = new THREE.Mesh(new THREE.BoxGeometry(160, 0.5, 0.12), ggOrangeMat);
  railSouth.position.set(-5, bridgeDeckY + 0.5, bridgeDeckZ + 2.4);

  sceneryGroup.add(roadbedMesh, yellowLine, railNorth, railSouth);

  // Dashed lane lines
  for (let lx = -78; lx <= 68; lx += 3.5) {
    const dash1 = new THREE.Mesh(new THREE.BoxGeometry(1.8, 0.02, 0.08), whiteLineMat);
    dash1.position.set(lx, bridgeDeckY + 0.31, bridgeDeckZ - 1.0);
    const dash2 = new THREE.Mesh(new THREE.BoxGeometry(1.8, 0.02, 0.08), whiteLineMat);
    dash2.position.set(lx, bridgeDeckY + 0.31, bridgeDeckZ + 1.0);
    sceneryGroup.add(dash1, dash2);
  }

  // Iconic Golden Gate Towers - ENLARGED to 30 Meters High (reaching top of 3F & above!)
  const towerPositionsX = [-26, 14];
  const towerBeaconLights: THREE.Mesh[] = [];

  towerPositionsX.forEach((tx) => {
    const towerGroup = new THREE.Group();
    towerGroup.position.set(tx, bridgeDeckY, bridgeDeckZ);

    // Dual vertical legs of the tower (30m tall)
    for (const tz of [-2.0, 2.0]) {
      const legGeo = new THREE.BoxGeometry(1.8, 30.0, 1.4);
      const legMesh = new THREE.Mesh(legGeo, ggOrangeMat);
      legMesh.position.set(0, 15.0, tz);
      towerGroup.add(legMesh);
    }

    // Cross Bracing X-frames between tower legs
    for (let ty = 4.0; ty <= 28.0; ty += 4.0) {
      const crossBeam = new THREE.Mesh(new THREE.BoxGeometry(1.5, 0.8, 3.8), ggOrangeMat);
      crossBeam.position.set(0, ty, 0);
      towerGroup.add(crossBeam);
    }

    // Tower Arch Tops
    const archTop = new THREE.Mesh(new THREE.BoxGeometry(2.0, 1.5, 4.2), ggOrangeMat);
    archTop.position.set(0, 30.4, 0);
    towerGroup.add(archTop);

    // Flashing Red Aviation Beacon on tower tops
    const beaconLightMat = new THREE.MeshBasicMaterial({ color: 0xef4444 });
    const beaconMesh = new THREE.Mesh(new THREE.BoxGeometry(0.6, 0.6, 0.6), beaconLightMat);
    beaconMesh.position.set(0, 31.4, 0);
    towerBeaconLights.push(beaconMesh);
    towerGroup.add(beaconMesh);

    sceneryGroup.add(towerGroup);
  });

  // Main Sweeping Suspension Cables - Soaring 30 meters high
  const cableMat = new THREE.MeshStandardMaterial({ color: 0xc2410c, roughness: 0.5 });
  for (const sideZ of [-2.0, 2.0]) {
    const curvePoints: THREE.Vector3[] = [];
    const minX = -52;
    const maxX = 42;
    for (let x = minX; x <= maxX; x += 1.5) {
      let y = 30.0;
      if (x < -26) {
        // Anchorage side span
        const t = (x - (-52)) / (-26 - (-52));
        y = 2.0 + Math.pow(t, 2) * 28.0;
      } else if (x <= 14) {
        // Main center span
        const midX = -6;
        const normX = (x - midX) / 20; // -1 to 1
        y = 6.0 + Math.pow(normX, 2) * 24.0;
      } else {
        // North side span
        const t = (42 - x) / (42 - 14);
        y = 2.0 + Math.pow(t, 2) * 28.0;
      }
      curvePoints.push(new THREE.Vector3(x, bridgeDeckY + y, bridgeDeckZ + sideZ));
    }

    const catenaryCurve = new THREE.CatmullRomCurve3(curvePoints);
    const cableGeo = new THREE.TubeGeometry(catenaryCurve, 80, 0.18, 8, false);
    const cableMesh = new THREE.Mesh(cableGeo, cableMat);
    sceneryGroup.add(cableMesh);

    // Vertical Suspender Ropes
    for (let rx = -48; rx <= 38; rx += 3.0) {
      let ropeTopY = 30.0;
      if (rx < -26) {
        const t = (rx - (-52)) / (-26 - (-52));
        ropeTopY = 2.0 + Math.pow(t, 2) * 28.0;
      } else if (rx <= 14) {
        const normX = (rx - (-6)) / 20;
        ropeTopY = 6.0 + Math.pow(normX, 2) * 24.0;
      } else {
        const t = (42 - rx) / (42 - 14);
        ropeTopY = 2.0 + Math.pow(t, 2) * 28.0;
      }

      if (ropeTopY > 2.5) {
        const ropeHeight = ropeTopY - 0.3;
        const ropeGeo = new THREE.BoxGeometry(0.06, ropeHeight, 0.06);
        const ropeMesh = new THREE.Mesh(ropeGeo, cableMat);
        ropeMesh.position.set(rx, bridgeDeckY + ropeHeight / 2 + 0.3, bridgeDeckZ + sideZ);
        sceneryGroup.add(ropeMesh);
      }
    }
  }

  // 4. ANIMATED TRAFFIC FLEET across extended bridge
  const vehicles: VehicleMesh[] = [];

  const carColors = [
    0xef4444, // Red Sports Car
    0x3b82f6, // Blue Sedan
    0xeab308, // SF Yellow Taxi Cab
    0x10b981, // Emerald Hatchback
    0xf8fafc, // White SUV
    0x64748b, // Grey Delivery Van
  ];

  const headlightMat = new THREE.MeshBasicMaterial({ color: 0xfffde7 });
  const taillightMat = new THREE.MeshBasicMaterial({ color: 0xff1744 });

  for (let i = 0; i < 18; i++) {
    const isSouthbound = i % 2 === 0;
    const laneZ = bridgeDeckZ + (isSouthbound ? -1.2 : 1.2);
    const direction = isSouthbound ? -1 : 1;
    const color = carColors[i % carColors.length];
    const isBus = i === 3 || i === 9 || i === 15;

    const carGroup = new THREE.Group();

    const bodyW = isBus ? 2.2 : 1.3;
    const bodyH = isBus ? 0.8 : 0.5;
    const bodyD = isBus ? 0.9 : 0.7;

    const bodyMat = new THREE.MeshStandardMaterial({ color, roughness: 0.5 });
    const bodyMesh = new THREE.Mesh(new THREE.BoxGeometry(bodyW, bodyH, bodyD), bodyMat);
    bodyMesh.position.y = bodyH / 2 + 0.1;
    carGroup.add(bodyMesh);

    if (!isBus) {
      const cabinMesh = new THREE.Mesh(
        new THREE.BoxGeometry(0.7, 0.4, 0.6),
        new THREE.MeshStandardMaterial({ color: 0x1e293b, roughness: 0.2 })
      );
      cabinMesh.position.set(-0.05, bodyH + 0.18, 0);
      carGroup.add(cabinMesh);
    }

    const frontX = (bodyW / 2 + 0.02) * direction;
    const backX = (-bodyW / 2 - 0.02) * direction;

    for (const lz of [-0.25, 0.25]) {
      const headL = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.14, 0.14), headlightMat);
      headL.position.set(frontX, bodyH / 2, lz);

      const tailL = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.14, 0.14), taillightMat);
      tailL.position.set(backX, bodyH / 2, lz);

      carGroup.add(headL, tailL);
    }

    const startX = -75 + (i * 7.5);
    carGroup.position.set(startX, bridgeDeckY + 0.3, laneZ);

    sceneryGroup.add(carGroup);

    vehicles.push({
      group: carGroup,
      speed: 16.0 + (i % 4) * 3.5,
      laneZ,
      direction,
      startX: -78,
      endX: 68,
    });
  }

  sceneGroup.add(sceneryGroup);

  return {
    updateTraffic: (time: number) => {
      const delta = 0.016;
      vehicles.forEach((v) => {
        v.group.position.x += v.speed * v.direction * delta;

        if (v.direction === 1 && v.group.position.x > v.endX) {
          v.group.position.x = v.startX;
        } else if (v.direction === -1 && v.group.position.x < v.startX) {
          v.group.position.x = v.endX;
        }
      });

      const beaconOpacity = 0.6 + Math.sin(time * 5) * 0.4;
      towerBeaconLights.forEach((b) => {
        (b.material as THREE.MeshBasicMaterial).opacity = beaconOpacity;
      });
    },
  };
}
