import { Position3D } from '../types';
import { EntityCollider } from './collisionSystem';

export interface Waypoint {
  x: number;
  z: number;
  label: string;
}

export const FLOOR_CIRCUITS: Record<string, Waypoint[]> = {
  floor_1: [
    { x: 0, z: 5.5, label: 'Lobby & Reception Center (Floor 1)' },
    { x: 5.2, z: 3.8, label: 'East Engineering Bay' },
    { x: 5.8, z: 0.0, label: 'Design & Collaboration Pod' },
    { x: 5.2, z: -4.2, label: 'Espresso & Nitro Coffee Bar' },
    { x: 2.0, z: -6.0, label: 'Elevator & North Corridor' },
    { x: -2.0, z: -6.0, label: 'Executive Boardroom Gallery' },
    { x: -5.5, z: -4.0, label: 'West Product Hub' },
    { x: -5.8, z: 0.5, label: 'Open Workspace Atrium' },
    { x: -5.2, z: 4.2, label: 'Table Tennis & Recreation Arena' },
    { x: -2.0, z: 5.8, label: 'South Promenade' },
  ],
  floor_2: [
    { x: 0, z: 5.0, label: 'Level 2 Central Rotunda' },
    { x: 5.5, z: 2.5, label: 'Executive Suites Wing' },
    { x: 5.0, z: -4.5, label: 'Skyline Terrace Lounge' },
    { x: 0, z: -5.5, label: 'Glass Boardroom Nexus' },
    { x: -5.0, z: -4.5, label: 'Quiet Focus Library' },
    { x: -5.5, z: 2.5, label: 'AI Strategy Studio' },
  ],
  floor_3: [
    { x: 0, z: 4.5, label: 'Penthouse Panorama Deck (Floor 3)' },
    { x: 4.8, z: 2.0, label: 'Bistro Cafe & Juice Bar' },
    { x: 4.5, z: -4.0, label: 'Zen Garden Sunroom' },
    { x: 0, z: -5.0, label: 'Keynote Amphitheater' },
    { x: -4.5, z: -4.0, label: 'Creative VR Lab' },
    { x: -4.8, z: 2.0, label: 'Rooftop Pergola' },
  ],
  floor_b1: [
    { x: 0, z: 4.5, label: 'Tennis Court Concourse (Basement B1)' },
    { x: 8.0, z: 3.5, label: 'Player Bench & Warmup Zone' },
    { x: 16.0, z: 0.0, label: 'Grand Tennis Arena Baseline' },
    { x: 8.0, z: -3.5, label: 'Locker & Fitness Annex' },
    { x: -4.0, z: -4.0, label: 'Data Center Cyber Corridor' },
    { x: -8.0, z: 0.0, label: 'Server Matrix Vault' },
    { x: -4.0, z: 4.0, label: 'Underground Arcade Lounge' },
  ],
};

export function getFloorCircuitKey(curY: number): string {
  if (curY <= -3.0) return 'floor_b1';
  if (curY >= 8.5) return 'floor_3';
  if (curY >= 3.0) return 'floor_2';
  return 'floor_1';
}

export function getNextTourFloorY(currentY: number): number {
  if (currentY <= -3.0) return 0.0;     // B1 -> Floor 1
  if (currentY >= 8.5) return -6.0;    // Floor 3 -> Basement B1
  if (currentY >= 3.0) return 11.0;    // Floor 2 -> Floor 3
  return 4.0;                           // Floor 1 -> Floor 2
}

export type HazardStatus = 'Safe' | 'Caution' | 'Emergency Stop';

export interface AutoRideStepResult {
  nextPos: Position3D;
  targetRotationY: number;
  turnAngle: number;
  speed: number;
  currentWaypointIdx: number;
  currentLabel: string;
  completedCircuit: boolean;
  hazardStatus: HazardStatus;
  telemetryJson: string;
}

export function stepAutoRide(
  curPos: Position3D,
  curRotationY: number,
  targetWaypointIdx: number,
  dt: number,
  customSpeed = 8.5,
  colliders: EntityCollider[] = []
): AutoRideStepResult {
  const circuitKey = getFloorCircuitKey(curPos.y || 0);
  const circuit = FLOOR_CIRCUITS[circuitKey] || FLOOR_CIRCUITS.floor_1;

  let wpIdx = targetWaypointIdx % circuit.length;
  if (wpIdx < 0) wpIdx = 0;

  const targetWp = circuit[wpIdx];
  const dx = targetWp.x - curPos.x;
  const dz = targetWp.z - curPos.z;
  const dist = Math.hypot(dx, dz);

  let completedCircuit = false;
  if (dist < 1.2) {
    const nextIdx = wpIdx + 1;
    if (nextIdx >= circuit.length) {
      completedCircuit = true;
      wpIdx = 0;
    } else {
      wpIdx = nextIdx;
    }
  }

  const activeWp = circuit[wpIdx];
  let targetDx = activeWp.x - curPos.x;
  let targetDz = activeWp.z - curPos.z;
  let activeDist = Math.hypot(targetDx, targetDz);

  let desiredAngle = Math.atan2(targetDx, targetDz);

  // EV Autopilot Environment Perception & Collision Risk Classification
  let avoidanceSteer = 0;
  let speedMultiplier = 1.0;
  let hazardStatus: HazardStatus = 'Safe';
  let nearestObstacleDist = 999;
  let obstaclesCount = 0;

  for (const col of colliders) {
    if (col.isDeskOrFurniture && Math.hypot(col.x - curPos.x, col.z - curPos.z) > 4.0) continue;
    const toColX = col.x - curPos.x;
    const toColZ = col.z - curPos.z;
    const colDist = Math.hypot(toColX, toColZ);
    if (colDist < nearestObstacleDist) {
      nearestObstacleDist = colDist;
    }
    obstaclesCount++;

    if (colDist < 2.5) {
      const colAngle = Math.atan2(toColX, toColZ);
      let diff = colAngle - curRotationY;
      while (diff > Math.PI) diff -= Math.PI * 2;
      while (diff < -Math.PI) diff += Math.PI * 2;

      if (Math.abs(diff) < Math.PI * 0.5) {
        if (colDist < 1.0) {
          // Emergency Stop when obstacle crosses within 1 meter
          hazardStatus = 'Emergency Stop';
          speedMultiplier = 0.0;
          avoidanceSteer += (diff > 0 ? -1.8 : 1.8);
        } else if (colDist < 2.0) {
          // Caution: reduce speed by 50% when within 2 meters
          if (hazardStatus !== 'Emergency Stop') hazardStatus = 'Caution';
          speedMultiplier = Math.min(speedMultiplier, 0.5);
          avoidanceSteer += (diff > 0 ? -1.2 : 1.2) * (2.0 - colDist);
        }
      }
    }
  }

  if (nearestObstacleDist < 1.0) {
    hazardStatus = 'Emergency Stop';
    speedMultiplier = 0.0;
  } else if (nearestObstacleDist < 2.0 && hazardStatus !== 'Emergency Stop') {
    hazardStatus = 'Caution';
    speedMultiplier = Math.min(speedMultiplier, 0.5);
  }

  desiredAngle += avoidanceSteer;

  let angleDiff = desiredAngle - curRotationY;
  while (angleDiff > Math.PI) angleDiff -= Math.PI * 2;
  while (angleDiff < -Math.PI) angleDiff += Math.PI * 2;

  const turnSharpness = Math.abs(angleDiff);
  const effectiveSpeed = speedMultiplier === 0 ? 0 : Math.max(1.5, customSpeed * speedMultiplier * (1.0 - Math.min(0.5, turnSharpness * 0.35)));

  const turnRate = 4.5 * dt;
  const clampedTurn = Math.max(-turnRate, Math.min(turnRate, angleDiff));
  const newRotationY = curRotationY + clampedTurn;

  const moveDistance = speedMultiplier === 0 ? 0 : Math.min(effectiveSpeed * dt, Math.max(0.1, activeDist));
  const forwardDx = Math.sin(newRotationY) * moveDistance;
  const forwardDz = Math.cos(newRotationY) * moveDistance;

  const nextPos: Position3D = {
    x: curPos.x + forwardDx,
    y: curPos.y || 0,
    z: curPos.z + forwardDz,
  };

  const turnAngleDeg = (clampedTurn / Math.max(0.001, dt)) * (180 / Math.PI);
  const telemetryObj = {
    timestamp: new Date().toISOString(),
    system: "EV_AV_AUTOPILOT_INTELLIGENCE",
    destination: activeWp.label,
    currentSpeed: Number(effectiveSpeed.toFixed(2)),
    throttle: Number(speedMultiplier.toFixed(2)),
    steeringAngle: Number(turnAngleDeg.toFixed(1)),
    hazardStatus,
    nearestObstacleDistance: Number(nearestObstacleDist.toFixed(2)),
    environmentPerception: {
      obstaclesScanned: obstaclesCount,
      circuit: circuitKey
    }
  };

  return {
    nextPos,
    targetRotationY: newRotationY,
    turnAngle: clampedTurn / Math.max(0.001, dt),
    speed: effectiveSpeed,
    currentWaypointIdx: wpIdx,
    currentLabel: activeWp.label,
    completedCircuit,
    hazardStatus,
    telemetryJson: JSON.stringify(telemetryObj, null, 2),
  };
}
