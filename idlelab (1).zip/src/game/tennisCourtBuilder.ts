import * as THREE from 'three';
import { UserState } from '../types';
import { createVoxelAvatarMesh, AvatarMeshGroup } from './avatarBuilder';

export interface TennisMatchState {
  playerScore: number;
  botScore: number;
  playerGames: number;
  botGames: number;
  playerSets: number;
  botSets: number;
  rallyCount: number;
  isServing: 'player' | 'bot' | 'free';
  lastCallText: string;
  isBallInPlay: boolean;
  lastHitType?: 'smash' | 'forehand' | 'backhand' | 'serve' | 'slice' | 'fireball';
  ballSpeedKmh?: number;
  gameMode: 'training' | 'competition';
  tacticalTactic?: string;
  isAudioMuted: boolean;
  isFireballActive?: boolean;
  isFireballQueued?: boolean;
  autoPlayerPos?: {
    x: number;
    z: number;
    swingAction?: 'forehand' | 'backhand' | 'smash' | null;
    isFireball?: boolean;
  };
}

export interface TennisCourtController {
  courtGroup: THREE.Group;
  tennisBallMesh: THREE.Mesh;
  tennisBotGroup: AvatarMeshGroup;
  interactiveObjects: THREE.Object3D[];
  updateTennisMatch: (
    delta: number,
    time: number,
    playerPos?: { x: number; y: number; z: number },
    isPlayerSwinging?: boolean,
    swingType?: 'forehand' | 'backhand' | 'smash' | 'serve',
    isJumping?: boolean,
    isFireballSmash?: boolean
  ) => TennisMatchState;
  triggerFireballSmash: () => void;
  resetServe: () => void;
  setGameMode: (mode: 'training' | 'competition') => void;
  getMatchState: () => TennisMatchState;
}

export function buildTennisCourt(interactiveObjects: THREE.Object3D[]): TennisCourtController {
  const courtGroup = new THREE.Group();
  courtGroup.name = 'ExecutiveIndoorTennisArena';

  // Spatial Dimensions: East of B1 Open Office (X: 15.0 to 43.0, Y: -6.0, Z: -8.0 to 8.0)
  const COURT_CENTER_X = 29.0;
  const COURT_CENTER_Z = 0.0;
  const FLOOR_Y = -6.0;
  const COURT_LENGTH_X = 26.0; // 26m along X
  const COURT_WIDTH_Z = 14.4;  // 14.4m along Z
  const NET_X = COURT_CENTER_X; // 29.0
  const ARENA_HEIGHT = 7.4;
  const ARCH_PEAK_HEIGHT = 9.2;

  // =========================================================================
  // 1. ARCHITECTURAL INTERIOR DESIGN (Glulam Timber Arches, Fabric Roof, Dual-tone Walls)
  // Matching the real modern indoor tennis hall from the uploaded reference photo
  // =========================================================================
  const arenaWallsGroup = new THREE.Group();

  // Premium Architectural Materials
  // Warm pine/glulam timber columns and trusses
  const glulamWoodMat = new THREE.MeshStandardMaterial({
    color: 0xc8863b,
    roughness: 0.55,
    metalness: 0.05,
  });
  const darkGlulamMat = new THREE.MeshStandardMaterial({
    color: 0x9a5b22,
    roughness: 0.6,
  });
  // Upper white clean acoustic panels
  const upperWhiteWallMat = new THREE.MeshStandardMaterial({
    color: 0xf8fafc,
    roughness: 0.9,
  });
  // Lower horizontal corrugated light grey cladding panels
  const lowerGreyPanelMat = new THREE.MeshStandardMaterial({
    color: 0xcfd8dc,
    roughness: 0.5,
    metalness: 0.15,
  });
  // Translucent tensile fabric roof canopy
  const fabricCanopyMat = new THREE.MeshStandardMaterial({
    color: 0xfafafa,
    roughness: 0.95,
    side: THREE.DoubleSide,
  });
  // Steel tension rods and bracket hardware
  const steelRodMat = new THREE.MeshStandardMaterial({
    color: 0x64748b,
    metalness: 0.85,
    roughness: 0.25,
  });
  const glassPortalMat = new THREE.MeshStandardMaterial({
    color: 0x38bdf8,
    transparent: true,
    opacity: 0.35,
    roughness: 0.1,
  });

  const NORTH_WALL_Z = -COURT_WIDTH_Z / 2 - 1.8; // Z = -9.0
  const SOUTH_WALL_Z = COURT_WIDTH_Z / 2 + 1.8;  // Z = +9.0
  const EAST_WALL_X = COURT_CENTER_X + COURT_LENGTH_X / 2 + 2.5; // X = 44.5
  const WEST_WALL_X = 14.2;

  // --- A. DUAL-TONE NORTH & SOUTH WALLS ---
  // North Wall (Z = -9.0): Lower 2.4m corrugated grey + Upper 5.0m crisp white
  const northLower = new THREE.Mesh(
    new THREE.BoxGeometry(COURT_LENGTH_X + 6.2, 2.4, 0.3),
    lowerGreyPanelMat
  );
  northLower.position.set(COURT_CENTER_X, FLOOR_Y + 1.2, NORTH_WALL_Z);

  const northUpper = new THREE.Mesh(
    new THREE.BoxGeometry(COURT_LENGTH_X + 6.2, ARENA_HEIGHT - 2.4, 0.25),
    upperWhiteWallMat
  );
  northUpper.position.set(COURT_CENTER_X, FLOOR_Y + 2.4 + (ARENA_HEIGHT - 2.4) / 2, NORTH_WALL_Z);

  // South Wall (Z = +9.0): Lower 2.4m corrugated grey + Upper 5.0m crisp white
  const southLower = new THREE.Mesh(
    new THREE.BoxGeometry(COURT_LENGTH_X + 6.2, 2.4, 0.3),
    lowerGreyPanelMat
  );
  southLower.position.set(COURT_CENTER_X, FLOOR_Y + 1.2, SOUTH_WALL_Z);

  const southUpper = new THREE.Mesh(
    new THREE.BoxGeometry(COURT_LENGTH_X + 6.2, ARENA_HEIGHT - 2.4, 0.25),
    upperWhiteWallMat
  );
  southUpper.position.set(COURT_CENTER_X, FLOOR_Y + 2.4 + (ARENA_HEIGHT - 2.4) / 2, SOUTH_WALL_Z);

  // East End Wall (X = 44.5): Full height dual-tone gable wall
  const eastLower = new THREE.Mesh(
    new THREE.BoxGeometry(0.3, 2.4, COURT_WIDTH_Z + 3.8),
    lowerGreyPanelMat
  );
  eastLower.position.set(EAST_WALL_X, FLOOR_Y + 1.2, COURT_CENTER_Z);

  const eastUpper = new THREE.Mesh(
    new THREE.BoxGeometry(0.25, ARENA_HEIGHT - 2.4, COURT_WIDTH_Z + 3.8),
    upperWhiteWallMat
  );
  eastUpper.position.set(EAST_WALL_X, FLOOR_Y + 2.4 + (ARENA_HEIGHT - 2.4) / 2, COURT_CENTER_Z);

  // Gable Peak Triangle Wall on East End
  const eastGableGeo = new THREE.BufferGeometry();
  const gableW = COURT_WIDTH_Z + 3.8;
  const gableH = ARCH_PEAK_HEIGHT - ARENA_HEIGHT;
  const gableVertices = new Float32Array([
    0, 0, -gableW / 2,
    0, 0, gableW / 2,
    0, gableH, 0,
  ]);
  eastGableGeo.setAttribute('position', new THREE.BufferAttribute(gableVertices, 3));
  eastGableGeo.computeVertexNormals();
  const eastGableMesh = new THREE.Mesh(eastGableGeo, upperWhiteWallMat);
  eastGableMesh.position.set(EAST_WALL_X, FLOOR_Y + ARENA_HEIGHT, COURT_CENTER_Z);

  // =========================================================================
  // EAST WALL 3D STADIUM SCOREBOARD & INSTRUCTIONS LED BILLBOARD
  // Directly mounted on the back wall behind Dolly Bot (facing -X towards player)
  // =========================================================================
  const scoreboardCanvas = document.createElement('canvas');
  scoreboardCanvas.width = 1536;
  scoreboardCanvas.height = 768;
  const sCtx = scoreboardCanvas.getContext('2d');

  const scoreboardTexture = new THREE.CanvasTexture(scoreboardCanvas);
  scoreboardTexture.minFilter = THREE.LinearFilter;
  scoreboardTexture.magFilter = THREE.LinearFilter;

  const scoreboardMat = new THREE.MeshBasicMaterial({
    map: scoreboardTexture,
    toneMapped: false,
  });

  const scoreboardMesh = new THREE.Mesh(
    new THREE.PlaneGeometry(10.8, 4.4),
    scoreboardMat
  );
  // Positioned at X = 44.3, Y = FLOOR_Y + 3.4 (-2.6m), Z = 0, facing West (-X) towards player
  scoreboardMesh.position.set(EAST_WALL_X - 0.18, FLOOR_Y + 3.4, COURT_CENTER_Z);
  scoreboardMesh.rotation.y = -Math.PI / 2;

  // Bezel frame for the Stadium LED display
  const bezelMat = new THREE.MeshStandardMaterial({
    color: 0x0f172a,
    roughness: 0.3,
    metalness: 0.7,
  });
  const bezelMesh = new THREE.Mesh(
    new THREE.BoxGeometry(0.12, 4.6, 11.0),
    bezelMat
  );
  bezelMesh.position.set(EAST_WALL_X - 0.12, FLOOR_Y + 3.4, COURT_CENTER_Z);

  // Soft ambient LED backlight glow
  const glowGeo = new THREE.PlaneGeometry(11.2, 4.8);
  const glowMat = new THREE.MeshBasicMaterial({
    color: 0x0284c7,
    transparent: true,
    opacity: 0.15,
    side: THREE.DoubleSide,
  });
  const glowMesh = new THREE.Mesh(glowGeo, glowMat);
  glowMesh.position.set(EAST_WALL_X - 0.22, FLOOR_Y + 3.4, COURT_CENTER_Z);
  glowMesh.rotation.y = -Math.PI / 2;

  arenaWallsGroup.add(bezelMesh, glowMesh, scoreboardMesh);

  // Function to render clean 2F-style TV monitor presentation display
  const renderWallScoreboard = (state: TennisMatchState) => {
    if (!sCtx) return;
    const W = scoreboardCanvas.width;
    const H = scoreboardCanvas.height;

    // Background: Executive Boardroom 2F-style Sleek Gradient (Dark Blue to Charcoal)
    const grad = sCtx.createRadialGradient(W / 2, H / 2, 80, W / 2, H / 2, W * 0.7);
    grad.addColorStop(0, '#0284c7');
    grad.addColorStop(0.5, '#0f172a');
    grad.addColorStop(1, '#090d16');
    sCtx.fillStyle = grad;
    sCtx.fillRect(0, 0, W, H);

    // Sleek Outer Glass Border
    sCtx.strokeStyle = '#38bdf8';
    sCtx.lineWidth = 4;
    sCtx.strokeRect(16, 16, W - 32, H - 32);

    // --- TOP HEADER BAR ---
    sCtx.fillStyle = 'rgba(15, 23, 42, 0.85)';
    sCtx.fillRect(32, 32, W - 64, 80);
    sCtx.strokeStyle = '#0284c7';
    sCtx.lineWidth = 2;
    sCtx.strokeRect(32, 32, W - 64, 80);

    sCtx.fillStyle = '#38bdf8';
    sCtx.font = 'bold 36px sans-serif';
    sCtx.textAlign = 'left';
    sCtx.textBaseline = 'middle';
    sCtx.fillText('🖥️ IDLELAB EXECUTIVE TENNIS BROADCAST MONITOR', 64, 72);

    // Mode Badge
    const isTraining = (state.gameMode ?? 'training') === 'training';
    sCtx.fillStyle = isTraining ? '#047857' : '#0369a1';
    sCtx.beginPath();
    sCtx.roundRect(W - 420, 47, 360, 50, 10);
    sCtx.fill();

    sCtx.fillStyle = '#ffffff';
    sCtx.font = 'bold 22px sans-serif';
    sCtx.textAlign = 'center';
    sCtx.fillText(isTraining ? '🤖 DOLLY BOT TRAINING' : '👥 PVP COMPETITION', W - 240, 72);

    // --- SCORE & METRICS DISPLAY (Middle Section) ---
    // Left Box: Player 1 Score
    sCtx.fillStyle = 'rgba(15, 23, 42, 0.9)';
    sCtx.beginPath();
    sCtx.roundRect(50, 135, 430, 290, 16);
    sCtx.fill();
    sCtx.strokeStyle = '#34d399';
    sCtx.lineWidth = 3;
    sCtx.stroke();

    sCtx.fillStyle = '#34d399';
    sCtx.font = 'bold 28px sans-serif';
    sCtx.textAlign = 'center';
    sCtx.fillText('PLAYER 1 (YOU)', 265, 175);

    const scoreMap = ['0', '15', '30', '40', 'AD'];
    const pPoints = scoreMap[Math.min(state.playerScore, 4)] || `${state.playerScore}`;
    sCtx.fillStyle = '#ffffff';
    sCtx.font = 'bold 110px sans-serif';
    sCtx.fillText(pPoints, 265, 275);

    sCtx.fillStyle = '#94a3b8';
    sCtx.font = 'bold 24px sans-serif';
    sCtx.fillText(`GAMES: ${state.playerGames}   SETS: ${state.playerSets}`, 265, 365);

    // Right Box: Dolly Bot / Opponent Score
    sCtx.fillStyle = 'rgba(15, 23, 42, 0.9)';
    sCtx.beginPath();
    sCtx.roundRect(W - 480, 135, 430, 290, 16);
    sCtx.fill();
    sCtx.strokeStyle = isTraining ? '#38bdf8' : '#f59e0b';
    sCtx.lineWidth = 3;
    sCtx.stroke();

    sCtx.fillStyle = isTraining ? '#38bdf8' : '#f59e0b';
    sCtx.font = 'bold 28px sans-serif';
    sCtx.textAlign = 'center';
    sCtx.fillText(isTraining ? 'DOLLY BOT 🤖' : 'OPPONENT', W - 265, 175);

    const bPoints = scoreMap[Math.min(state.botScore, 4)] || `${state.botScore}`;
    sCtx.fillStyle = '#ffffff';
    sCtx.font = 'bold 110px sans-serif';
    sCtx.fillText(bPoints, W - 265, 275);

    sCtx.fillStyle = '#94a3b8';
    sCtx.font = 'bold 24px sans-serif';
    sCtx.fillText(`GAMES: ${state.botGames}   SETS: ${state.botSets}`, W - 265, 365);

    // Center Box: Live Match Telemetry & Status
    sCtx.fillStyle = 'rgba(15, 23, 42, 0.85)';
    sCtx.beginPath();
    sCtx.roundRect(505, 135, W - 1010, 290, 16);
    sCtx.fill();
    sCtx.strokeStyle = '#0284c7';
    sCtx.lineWidth = 2;
    sCtx.stroke();

    sCtx.fillStyle = '#fbbf24';
    sCtx.font = 'bold 44px sans-serif';
    sCtx.textAlign = 'center';
    sCtx.fillText(`⚡ ${state.ballSpeedKmh || 95} KM/H`, W / 2, 195);

    sCtx.fillStyle = '#38bdf8';
    sCtx.font = 'bold 30px sans-serif';
    sCtx.fillText(`🔥 RALLY: ${state.rallyCount} SHOTS`, W / 2, 255);

    sCtx.fillStyle = '#f8fafc';
    sCtx.font = 'bold 22px sans-serif';
    sCtx.fillText(state.lastCallText || 'READY TO SERVE', W / 2, 315);

    if (state.tacticalTactic) {
      sCtx.fillStyle = '#38bdf8';
      sCtx.font = 'bold 20px sans-serif';
      sCtx.fillText(`🎯 AI TACTIC: ${state.tacticalTactic}`, W / 2, 375);
    }

    // --- BOTTOM SECTION: CLEAN CONTROLS & STATUS GUIDE ---
    sCtx.fillStyle = 'rgba(15, 23, 42, 0.9)';
    sCtx.beginPath();
    sCtx.roundRect(50, 445, W - 100, 280, 16);
    sCtx.fill();
    sCtx.strokeStyle = '#334155';
    sCtx.lineWidth = 2;
    sCtx.stroke();

    sCtx.fillStyle = '#38bdf8';
    sCtx.font = 'bold 26px sans-serif';
    sCtx.textAlign = 'center';
    sCtx.fillText('🕹️ STADIUM CONTROLS & PRO TENNIS RULES', W / 2, 485);

    sCtx.fillStyle = '#e2e8f0';
    sCtx.font = '19px monospace';
    sCtx.textAlign = 'left';
    sCtx.fillText('• AUTO LOCOMOTION: Step on tennis court for automated pro rallies & tracking', 80, 535);
    sCtx.fillText('• [SPACEBAR] FIREBALL SMASH: Ignite supersonic 220+ KM/H blazing comet shots', 80, 575);
    sCtx.fillText('• [R] KEY: Reset tennis serve immediately', 80, 615);
    sCtx.fillText('• [CLICK DOLLY]: Switch between Training AI and PvP Multiplayer Mode', 80, 655);
    sCtx.fillText('• RULES: 1 Bounce allowed per side • Double bounce or out awards point', 80, 695);

    scoreboardTexture.needsUpdate = true;
  };

  // Initial draw of the scoreboard
  renderWallScoreboard({
    playerScore: 0,
    botScore: 0,
    playerGames: 0,
    botGames: 0,
    playerSets: 0,
    botSets: 0,
    rallyCount: 0,
    isServing: 'player',
    lastCallText: 'READY! Right-Click to Serve, [Z] Power Smash, [Space] Jump',
    isBallInPlay: true,
    lastHitType: 'forehand',
    ballSpeedKmh: 98,
    gameMode: 'training',
    tacticalTactic: 'Crosscourt Law',
    isAudioMuted: true,
  });

  // West Portal Facing B1 Office (X = 14.2)
  const westGlassN = new THREE.Mesh(new THREE.BoxGeometry(0.15, ARENA_HEIGHT, 5.2), glassPortalMat);
  westGlassN.position.set(WEST_WALL_X, FLOOR_Y + ARENA_HEIGHT / 2, -6.4);
  const westGlassS = new THREE.Mesh(new THREE.BoxGeometry(0.15, ARENA_HEIGHT, 5.2), glassPortalMat);
  westGlassS.position.set(WEST_WALL_X, FLOOR_Y + ARENA_HEIGHT / 2, 6.4);

  arenaWallsGroup.add(
    northLower, northUpper,
    southLower, southUpper,
    eastLower, eastUpper, eastGableMesh,
    westGlassN, westGlassS
  );

  // --- B. GLULAM TIMBER VERTICAL COLUMNS & X-CROSS BRACING ---
  const columnPositionsX = [15.2, 19.8, 24.4, 29.0, 33.6, 38.2, 42.8];

  columnPositionsX.forEach((cx, idx) => {
    // North Timber Column
    const colN = new THREE.Mesh(new THREE.BoxGeometry(0.48, ARENA_HEIGHT, 0.48), glulamWoodMat);
    colN.position.set(cx, FLOOR_Y + ARENA_HEIGHT / 2, NORTH_WALL_Z + 0.35);

    // Steel base bracket
    const baseBracketN = new THREE.Mesh(new THREE.BoxGeometry(0.56, 0.35, 0.56), steelRodMat);
    baseBracketN.position.set(cx, FLOOR_Y + 0.175, NORTH_WALL_Z + 0.35);

    // South Timber Column
    const colS = new THREE.Mesh(new THREE.BoxGeometry(0.48, ARENA_HEIGHT, 0.48), glulamWoodMat);
    colS.position.set(cx, FLOOR_Y + ARENA_HEIGHT / 2, SOUTH_WALL_Z - 0.35);

    const baseBracketS = new THREE.Mesh(new THREE.BoxGeometry(0.56, 0.35, 0.56), steelRodMat);
    baseBracketS.position.set(cx, FLOOR_Y + 0.175, SOUTH_WALL_Z - 0.35);

    arenaWallsGroup.add(colN, baseBracketN, colS, baseBracketS);

    // Diagonal Cross-Bracing Steel Rods between column bays
    if (idx < columnPositionsX.length - 1) {
      const nextX = columnPositionsX[idx + 1];
      const midX = (cx + nextX) / 2;
      const span = nextX - cx;
      const braceH = 3.6;

      // North wall X-brace
      const brace1N = new THREE.Mesh(new THREE.CylinderGeometry(0.02, 0.02, Math.hypot(span, braceH), 6), steelRodMat);
      brace1N.position.set(midX, FLOOR_Y + 2.4 + braceH / 2, NORTH_WALL_Z + 0.2);
      brace1N.rotation.z = Math.atan2(braceH, span) - Math.PI / 2;

      const brace2N = new THREE.Mesh(new THREE.CylinderGeometry(0.02, 0.02, Math.hypot(span, braceH), 6), steelRodMat);
      brace2N.position.set(midX, FLOOR_Y + 2.4 + braceH / 2, NORTH_WALL_Z + 0.2);
      brace2N.rotation.z = -Math.atan2(braceH, span) + Math.PI / 2;

      // South wall X-brace
      const brace1S = new THREE.Mesh(new THREE.CylinderGeometry(0.02, 0.02, Math.hypot(span, braceH), 6), steelRodMat);
      brace1S.position.set(midX, FLOOR_Y + 2.4 + braceH / 2, SOUTH_WALL_Z - 0.2);
      brace1S.rotation.z = Math.atan2(braceH, span) - Math.PI / 2;

      const brace2S = new THREE.Mesh(new THREE.CylinderGeometry(0.02, 0.02, Math.hypot(span, braceH), 6), steelRodMat);
      brace2S.position.set(midX, FLOOR_Y + 2.4 + braceH / 2, SOUTH_WALL_Z - 0.2);
      brace2S.rotation.z = -Math.atan2(braceH, span) + Math.PI / 2;

      arenaWallsGroup.add(brace1N, brace2N, brace1S, brace2S);
    }
  });

  // --- C. CURVED ARCHED GLULAM TIMBER ROOF TRUSSES ---
  // Create graceful curved glulam wooden arches spanning from North Column to South Column
  const archSegments = 16;
  const archSpanZ = Math.abs(SOUTH_WALL_Z - NORTH_WALL_Z) - 0.7; // ~17.3m
  const archBaseY = FLOOR_Y + ARENA_HEIGHT;
  const archRise = ARCH_PEAK_HEIGHT - ARENA_HEIGHT; // ~1.8m rise at center

  columnPositionsX.forEach((cx) => {
    // Generate curved arch curve points
    const curvePoints: THREE.Vector3[] = [];
    for (let i = 0; i <= archSegments; i++) {
      const t = i / archSegments;
      const z = -archSpanZ / 2 + t * archSpanZ;
      // Parabolic arch profile
      const y = archBaseY + Math.sin(t * Math.PI) * archRise;
      curvePoints.push(new THREE.Vector3(cx, y, z));
    }

    const archCurve = new THREE.CatmullRomCurve3(curvePoints);
    const archGeo = new THREE.TubeGeometry(archCurve, 24, 0.16, 8, false);
    const archMesh = new THREE.Mesh(archGeo, glulamWoodMat);
    arenaWallsGroup.add(archMesh);

    // Steel Tension Tie Rod spanning horizontally beneath the arch
    const tieRod = new THREE.Mesh(
      new THREE.CylinderGeometry(0.025, 0.025, archSpanZ, 8),
      steelRodMat
    );
    tieRod.position.set(cx, archBaseY + 0.15, 0);
    tieRod.rotation.x = Math.PI / 2;
    arenaWallsGroup.add(tieRod);

    // Vertical steel hanger rods connecting arch to tie rod
    [-5.5, -2.8, 0, 2.8, 5.5].forEach((hz) => {
      const t = (hz + archSpanZ / 2) / archSpanZ;
      const archY = archBaseY + Math.sin(t * Math.PI) * archRise;
      const rodH = Math.max(0.2, archY - (archBaseY + 0.15));
      const rod = new THREE.Mesh(new THREE.CylinderGeometry(0.015, 0.015, rodH, 6), steelRodMat);
      rod.position.set(cx, archBaseY + 0.15 + rodH / 2, hz);
      arenaWallsGroup.add(rod);
    });
  });

  // Longitudinal Timber Purlins running along X connecting the arches
  const purlinZPositions = [-7.5, -4.8, -2.2, 0, 2.2, 4.8, 7.5];
  purlinZPositions.forEach((pz) => {
    const t = (pz + archSpanZ / 2) / archSpanZ;
    const py = archBaseY + Math.sin(t * Math.PI) * archRise + 0.12;
    const purlin = new THREE.Mesh(
      new THREE.BoxGeometry(COURT_LENGTH_X + 6.0, 0.12, 0.18),
      darkGlulamMat
    );
    purlin.position.set(COURT_CENTER_X, py, pz);
    arenaWallsGroup.add(purlin);
  });

  // --- D. TRANSLUCENT WHITE TENSILE FABRIC CANOPY ROOF ---
  // A curved surface covering the entire arena ceiling
  const roofSegmentsX = 12;
  const roofSegmentsZ = 20;
  const roofGeo = new THREE.PlaneGeometry(
    COURT_LENGTH_X + 6.6,
    archSpanZ + 0.4,
    roofSegmentsX,
    roofSegmentsZ
  );
  roofGeo.rotateX(Math.PI / 2);

  // Deform roof plane vertices to follow the arched parabolic profile
  const posAttr = roofGeo.attributes.position;
  for (let i = 0; i < posAttr.count; i++) {
    const z = posAttr.getZ(i);
    const normalizedZ = (z + (archSpanZ + 0.4) / 2) / (archSpanZ + 0.4);
    const archY = Math.sin(Math.max(0, Math.min(1, normalizedZ)) * Math.PI) * archRise;
    posAttr.setY(i, archBaseY + archY + 0.18);
  }
  roofGeo.computeVertexNormals();
  const roofCanopyMesh = new THREE.Mesh(roofGeo, fabricCanopyMat);
  roofCanopyMesh.position.set(COURT_CENTER_X, 0, 0);
  arenaWallsGroup.add(roofCanopyMesh);

  courtGroup.add(arenaWallsGroup);

  // =========================================================================
  // 2. WELCOME PORTAL SIGN & ENTRANCE RUNNER
  // =========================================================================
  const archCanvas = document.createElement('canvas');
  archCanvas.width = 512;
  archCanvas.height = 128;
  const aCtx = archCanvas.getContext('2d')!;
  aCtx.fillStyle = '#0f172a';
  aCtx.fillRect(0, 0, 512, 128);
  aCtx.fillStyle = '#22c55e';
  aCtx.font = 'bold 26px sans-serif';
  aCtx.textAlign = 'center';
  aCtx.fillText('🎾 B1 INDOOR TENNIS ARENA', 256, 44);
  aCtx.fillStyle = '#38bdf8';
  aCtx.font = 'bold 16px monospace';
  aCtx.fillText('LIVE MATCH • DOLLY TENNIS BOT V.S IDLE USERS', 256, 82);
  aCtx.fillStyle = '#94a3b8';
  aCtx.font = '13px monospace';
  aCtx.fillText('Right-Click Serve/Hit • [Z] Smash • [Space] Jump', 256, 110);
  aCtx.strokeStyle = '#22c55e';
  aCtx.lineWidth = 4;
  aCtx.strokeRect(4, 4, 504, 120);

  const archTex = new THREE.CanvasTexture(archCanvas);
  const archMesh = new THREE.Mesh(new THREE.PlaneGeometry(5.2, 1.25), new THREE.MeshBasicMaterial({ map: archTex }));
  archMesh.position.set(13.6, FLOOR_Y + 3.4, 0);
  archMesh.rotation.y = -Math.PI / 2;
  courtGroup.add(archMesh);

  // Portal Walkway Transition Deck (X: 11.0 to 16.5)
  const portalFloor = new THREE.Mesh(
    new THREE.BoxGeometry(5.8, 0.12, 8.8),
    new THREE.MeshStandardMaterial({ color: 0x1e293b, roughness: 0.6 })
  );
  portalFloor.position.set(13.8, FLOOR_Y - 0.04, 0);
  portalFloor.receiveShadow = true;
  courtGroup.add(portalFloor);

  // =========================================================================
  // 3. PRO TWO-TONE TOURNAMENT HARD COURT (US Open Tournament Slate Blue & Teal Apron)
  // Exact color scheme from the reference photo:
  // - Inner playing court: #334e68 (Deep Slate Navy Blue)
  // - Outer surround apron: #4d7c94 (Soft Teal-Cyan Pro Hardcourt)
  // =========================================================================
  // Outer Apron Deck (Surround Area)
  const apronMat = new THREE.MeshStandardMaterial({
    color: 0x48768e, // Soft Teal-Cyan Pro Hardcourt
    roughness: 0.68,
    metalness: 0.02,
  });
  const courtDeck = new THREE.Mesh(
    new THREE.BoxGeometry(COURT_LENGTH_X + 5.2, 0.25, COURT_WIDTH_Z + 3.2),
    apronMat
  );
  courtDeck.position.set(COURT_CENTER_X, FLOOR_Y - 0.125, COURT_CENTER_Z);
  courtDeck.receiveShadow = true;
  courtGroup.add(courtDeck);

  // Inner Championship Slate-Blue Playing Court (23.77m x 10.97m)
  const innerPlayingCourtMat = new THREE.MeshStandardMaterial({
    color: 0x2e465a, // Deep Tournament Slate Blue
    roughness: 0.65,
    metalness: 0.02,
  });
  const innerCourt = new THREE.Mesh(new THREE.PlaneGeometry(23.77, 10.97), innerPlayingCourtMat);
  innerCourt.rotation.x = -Math.PI / 2;
  innerCourt.position.set(COURT_CENTER_X, FLOOR_Y + 0.01, COURT_CENTER_Z);
  innerCourt.receiveShadow = true;
  courtGroup.add(innerCourt);

  // Regulation White Tennis Court Lines (0.06m - 0.10m crisp white)
  const lineMat = new THREE.MeshBasicMaterial({ color: 0xffffff });
  const addCourtLine = (x: number, z: number, w: number, d: number) => {
    const lineMesh = new THREE.Mesh(new THREE.PlaneGeometry(w, d), lineMat);
    lineMesh.rotation.x = -Math.PI / 2;
    lineMesh.position.set(x, FLOOR_Y + 0.015, z);
    courtGroup.add(lineMesh);
  };

  // Baselines (X = COURT_CENTER_X - 11.885m and + 11.885m)
  addCourtLine(COURT_CENTER_X - 11.885, 0, 0.10, 10.97);
  addCourtLine(COURT_CENTER_X + 11.885, 0, 0.10, 10.97);

  // Doubles Sidelines (Z = -5.485m and +5.485m)
  addCourtLine(COURT_CENTER_X, -5.485, 23.77, 0.08);
  addCourtLine(COURT_CENTER_X, 5.485, 23.77, 0.08);

  // Singles Sidelines (Z = -4.115m and +4.115m)
  addCourtLine(COURT_CENTER_X, -4.115, 23.77, 0.06);
  addCourtLine(COURT_CENTER_X, 4.115, 23.77, 0.06);

  // Service Lines (X = COURT_CENTER_X - 6.40m and +6.40m)
  addCourtLine(COURT_CENTER_X - 6.40, 0, 0.06, 8.23);
  addCourtLine(COURT_CENTER_X + 6.40, 0, 0.06, 8.23);

  // Center Service Line (spanning between service lines along Z = 0)
  addCourtLine(COURT_CENTER_X, 0, 12.80, 0.06);

  // Center Baseline Hash Marks
  addCourtLine(COURT_CENTER_X - 11.75, 0, 0.35, 0.06);
  addCourtLine(COURT_CENTER_X + 11.75, 0, 0.35, 0.06);

  // =========================================================================
  // 4. TOURNAMENT TENNIS NET WITH CABLE & POSTS (At X = COURT_CENTER_X = 29.0)
  // =========================================================================
  const netBoxMat = new THREE.MeshBasicMaterial({ color: 0x1e293b, transparent: true, opacity: 0.65 });
  const netMeshBox = new THREE.Mesh(new THREE.BoxGeometry(0.04, 0.95, 12.4), netBoxMat);
  netMeshBox.position.set(NET_X, FLOOR_Y + 0.48, COURT_CENTER_Z);

  // White Top Band Headband Tape
  const netBandMat = new THREE.MeshBasicMaterial({ color: 0xf8fafc });
  const netBand = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.08, 12.4), netBandMat);
  netBand.position.set(NET_X, FLOOR_Y + 0.96, COURT_CENTER_Z);

  // White Center Strap (0.914m regulation center height)
  const centerStrap = new THREE.Mesh(new THREE.BoxGeometry(0.09, 0.96, 0.12), netBandMat);
  centerStrap.position.set(NET_X, FLOOR_Y + 0.48, COURT_CENTER_Z);

  // Metallic Net Posts with tension crank
  const postMat = new THREE.MeshStandardMaterial({ color: 0x334155, metalness: 0.85, roughness: 0.2 });
  const post1 = new THREE.Mesh(new THREE.CylinderGeometry(0.07, 0.07, 1.15, 12), postMat);
  post1.position.set(NET_X, FLOOR_Y + 0.575, -6.1);
  const post2 = new THREE.Mesh(new THREE.CylinderGeometry(0.07, 0.07, 1.15, 12), postMat);
  post2.position.set(NET_X, FLOOR_Y + 0.575, 6.1);

  courtGroup.add(netMeshBox, netBand, centerStrap, post1, post2);

  // =========================================================================
  // 5. TOURNAMENT COURTSIDE ACCESSORIES (From Reference Photo)
  // - White umpire high chair with ladder
  // - Orange courtside spectator chairs
  // - Ball hopper basket
  // =========================================================================
  // A. White Umpire High Chair with Ladder on North Side (Z = -6.8)
  const umpireGroup = new THREE.Group();
  umpireGroup.position.set(NET_X, FLOOR_Y, -7.0);

  const umpireFrameMat = new THREE.MeshStandardMaterial({ color: 0xe2e8f0, roughness: 0.4 });
  const umpireSeatMat = new THREE.MeshStandardMaterial({ color: 0x0284c7, roughness: 0.5 });

  // A-frame ladder rails
  const ladderRailL = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.03, 2.4, 8), umpireFrameMat);
  ladderRailL.position.set(-0.35, 1.2, -0.2);
  ladderRailL.rotation.z = 0.12;

  const ladderRailR = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.03, 2.4, 8), umpireFrameMat);
  ladderRailR.position.set(0.35, 1.2, -0.2);
  ladderRailR.rotation.z = -0.12;

  // Back legs
  const legBL = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.03, 2.4, 8), umpireFrameMat);
  legBL.position.set(-0.4, 1.2, -0.7);
  const legBR = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.03, 2.4, 8), umpireFrameMat);
  legBR.position.set(0.4, 1.2, -0.7);

  // Rungs
  for (let r = 0.4; r <= 1.8; r += 0.35) {
    const rung = new THREE.Mesh(new THREE.CylinderGeometry(0.02, 0.02, 0.65, 8), umpireFrameMat);
    rung.position.set(0, r, -0.2);
    rung.rotation.z = Math.PI / 2;
    umpireGroup.add(rung);
  }

  // Elevated Umpire Seat
  const umpireSeat = new THREE.Mesh(new THREE.BoxGeometry(0.7, 0.08, 0.65), umpireSeatMat);
  umpireSeat.position.set(0, 2.05, -0.45);
  const umpireBack = new THREE.Mesh(new THREE.BoxGeometry(0.7, 0.6, 0.08), umpireSeatMat);
  umpireBack.position.set(0, 2.38, -0.74);

  umpireGroup.add(ladderRailL, ladderRailR, legBL, legBR, umpireSeat, umpireBack);
  courtGroup.add(umpireGroup);

  // B. Orange Courtside Stack Chairs (Matching the bright orange chairs in reference photo)
  const orangeChairMat = new THREE.MeshStandardMaterial({ color: 0xf97316, roughness: 0.4 });
  const chairLegMat = new THREE.MeshStandardMaterial({ color: 0x64748b, metalness: 0.8 });

  [-8.2, -7.5, -6.8, -6.1].forEach((cz) => {
    const chair = new THREE.Group();
    chair.position.set(16.5, FLOOR_Y, cz);

    const seat = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.05, 0.45), orangeChairMat);
    seat.position.y = 0.45;
    const back = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.4, 0.04), orangeChairMat);
    back.position.set(0, 0.68, -0.2);

    for (const lx of [-0.2, 0.2]) {
      for (const lz of [-0.18, 0.18]) {
        const leg = new THREE.Mesh(new THREE.CylinderGeometry(0.018, 0.018, 0.45, 6), chairLegMat);
        leg.position.set(lx, 0.225, lz);
        chair.add(leg);
      }
    }
    chair.add(seat, back);
    courtGroup.add(chair);
  });

  // C. Tennis Ball Hopper Basket
  const ballBasket = new THREE.Mesh(
    new THREE.CylinderGeometry(0.28, 0.22, 0.65, 10),
    new THREE.MeshStandardMaterial({ color: 0x475569, wireframe: true })
  );
  ballBasket.position.set(22.0, FLOOR_Y + 0.35, -6.0);
  courtGroup.add(ballBasket);

  for (let b = 0; b < 8; b++) {
    const bMesh = new THREE.Mesh(
      new THREE.SphereGeometry(0.07, 8, 8),
      new THREE.MeshStandardMaterial({ color: 0xccff00, emissive: 0x84cc16, emissiveIntensity: 0.3 })
    );
    bMesh.position.set(21.9 + (b % 2) * 0.12, FLOOR_Y + 0.45 + Math.floor(b / 2) * 0.09, -6.0 + (b % 3) * 0.1);
    courtGroup.add(bMesh);
  }

  // =========================================================================
  // 6. DOLLY TENNIS BOT (AI NPC Opponent with Animated 3D Voxel Avatar)
  // =========================================================================
  const botUser: UserState = {
    id: 'dolly_tennis_bot',
    name: 'Dolly Bot 🎾',
    skin: 'college_dev_f',
    department: 'Operations',
    position: { x: 37.0, y: FLOOR_Y, z: 0.0 },
    rotationY: -Math.PI / 2, // Facing player side (-X)
    isMoving: false,
    isSpeaking: false,
    isMuted: true,
    isScreenSharing: false,
    claimedDeskId: null,
    statusText: 'AI Tennis Sparring Partner',
    color: '#38bdf8',
    hoodieColor: '#facc15',
    pantsColor: '#ffffff',
    shoesColor: '#22c55e',
    capColor: '#38bdf8',
    hairColor: '#0f0f11',
  };

  const tennisBotGroup = createVoxelAvatarMesh(botUser) as AvatarMeshGroup;
  tennisBotGroup.group.position.set(37.0, FLOOR_Y, 0.0);
  tennisBotGroup.group.rotation.y = -Math.PI / 2;

  // Bot clickable hitbox
  const botClickGeo = new THREE.BoxGeometry(1.6, 2.4, 1.6);
  const botClickMat = new THREE.MeshBasicMaterial({ visible: false });
  const botClickMesh = new THREE.Mesh(botClickGeo, botClickMat);
  botClickMesh.position.y = 1.2;
  botClickMesh.name = 'DollyTennisBot';
  botClickMesh.userData = { isTeslaTennisBot: true, isDollyBot: true };
  interactiveObjects.push(botClickMesh);
  tennisBotGroup.group.add(botClickMesh);

  courtGroup.add(tennisBotGroup.group);

  // =========================================================================
  // 7. 3D LIVE TENNIS BALL, FIREBALL PARTICLES & IMPACT TRAIL MESHES
  // =========================================================================
  const standardBallMat = new THREE.MeshStandardMaterial({
    color: 0xccff00,
    emissive: 0x84cc16,
    emissiveIntensity: 0.45,
    roughness: 0.35,
  });

  const fireballBallMat = new THREE.MeshStandardMaterial({
    color: 0xffea00,
    emissive: 0xff3b00,
    emissiveIntensity: 2.8,
    roughness: 0.15,
  });

  const tennisBallMesh = new THREE.Mesh(new THREE.SphereGeometry(0.13, 16, 16), standardBallMat);
  tennisBallMesh.position.set(23.5, FLOOR_Y + 1.2, 0);
  tennisBallMesh.castShadow = true;
  courtGroup.add(tennisBallMesh);

  // Fireball Flaming Core / Corona Glow Mesh (attached to ball)
  const fireballAuraMat = new THREE.MeshBasicMaterial({
    color: 0xff5500,
    transparent: true,
    opacity: 0.75,
    blending: THREE.AdditiveBlending,
  });
  const fireballAuraMesh = new THREE.Mesh(new THREE.SphereGeometry(0.24, 12, 12), fireballAuraMat);
  fireballAuraMesh.visible = false;
  tennisBallMesh.add(fireballAuraMesh);

  // Flame Particle Pool for trailing comet tail
  const FLAME_PARTICLE_COUNT = 24;
  interface FlameParticle {
    mesh: THREE.Mesh;
    life: number;
    maxLife: number;
    size: number;
    velY: number;
    velZ: number;
  }
  const flameParticles: FlameParticle[] = [];
  const flameGroup = new THREE.Group();
  courtGroup.add(flameGroup);

  const flameColors = [0xff2200, 0xff5500, 0xff9900, 0xffcc00, 0xffea00];
  for (let i = 0; i < FLAME_PARTICLE_COUNT; i++) {
    const pMat = new THREE.MeshBasicMaterial({
      color: flameColors[i % flameColors.length],
      transparent: true,
      opacity: 0,
      blending: THREE.AdditiveBlending,
    });
    const pMesh = new THREE.Mesh(new THREE.DodecahedronGeometry(0.12, 0), pMat);
    pMesh.visible = false;
    flameGroup.add(pMesh);
    flameParticles.push({
      mesh: pMesh,
      life: 0,
      maxLife: 0.35,
      size: 0.12,
      velY: 0,
      velZ: 0,
    });
  }

  let flameSpawnTimer = 0;
  const spawnFlameParticle = (x: number, y: number, z: number, speedRatio = 1.0) => {
    const p = flameParticles.find((fp) => fp.life <= 0);
    if (!p) return;
    p.life = 0.25 + Math.random() * 0.15;
    p.maxLife = p.life;
    p.size = (0.10 + Math.random() * 0.14) * speedRatio;
    p.velY = 0.8 + Math.random() * 1.2;
    p.velZ = (Math.random() - 0.5) * 1.5;
    p.mesh.position.set(
      x + (Math.random() - 0.5) * 0.1,
      y + (Math.random() - 0.5) * 0.1,
      z + (Math.random() - 0.5) * 0.1
    );
    p.mesh.scale.set(p.size, p.size, p.size);
    p.mesh.visible = true;
    (p.mesh.material as THREE.MeshBasicMaterial).opacity = 0.95;
  };

  // Smash Visual Ring Shockwave (Yellow/Cyan/Fiery Orange)
  const smashRingGeo = new THREE.RingGeometry(0.1, 1.1, 24);
  const smashRingMat = new THREE.MeshBasicMaterial({
    color: 0xfacc15,
    transparent: true,
    opacity: 0,
    side: THREE.DoubleSide,
  });
  const smashRingMesh = new THREE.Mesh(smashRingGeo, smashRingMat);
  smashRingMesh.visible = false;
  courtGroup.add(smashRingMesh);

  // Court Ground Raycast Plane
  const courtGroundGeo = new THREE.BoxGeometry(COURT_LENGTH_X + 8.0, 0.1, COURT_WIDTH_Z + 6.0);
  const courtGroundMat = new THREE.MeshBasicMaterial({ visible: false });
  const courtGroundMesh = new THREE.Mesh(courtGroundGeo, courtGroundMat);
  courtGroundMesh.position.set(COURT_CENTER_X, FLOOR_Y - 0.05, COURT_CENTER_Z);
  courtGroundMesh.name = 'TennisCourtGroundPlane';
  interactiveObjects.push(courtGroundMesh);
  courtGroup.add(courtGroundMesh);

  // =========================================================================
  // 8. TENNIS GAME PHYSICS ENGINE, AUTO-LOCOMOTION & FIREBALL ENGINE
  // =========================================================================
  const ballPos = { x: 23.5, y: FLOOR_Y + 1.2, z: 0.0 };
  const ballVel = { x: 10.0, y: 3.6, z: 0.2 };
  let botTargetZ = 0.0;
  let botTargetX = 37.0;
  let autoPlayerTargetZ = 0.0;
  let autoPlayerTargetX = 22.5;
  let autoPlayerSwingTrigger: 'forehand' | 'backhand' | 'smash' | null = null;
  let lastHitBy: 'player' | 'bot' = 'player';
  let bounceCount = 0;
  let smashRingLife = 0;
  let currentSpin: 'topspin' | 'flat' | 'slice' = 'topspin';
  let isFireballActive = false;
  let isFireballSmashQueued = false;

  const matchState: TennisMatchState = {
    playerScore: 0,
    botScore: 0,
    playerGames: 0,
    botGames: 0,
    playerSets: 0,
    botSets: 0,
    rallyCount: 0,
    isServing: 'player',
    lastCallText: 'READY! Step on court to Auto-Play, [Space] Fireball Smash!',
    isBallInPlay: true,
    lastHitType: 'forehand',
    ballSpeedKmh: 105,
    gameMode: 'training',
    tacticalTactic: 'Crosscourt Law',
    isAudioMuted: true,
    isFireballActive: false,
    isFireballQueued: false,
    autoPlayerPos: {
      x: 22.5,
      z: 0.0,
      swingAction: null,
      isFireball: false,
    },
  };

  const triggerSmashVisual = (x: number, y: number, z: number, color = 0xfacc15, initialScale = 1.0) => {
    smashRingMesh.position.set(x, y, z);
    smashRingMesh.rotation.y = Math.PI / 2;
    (smashRingMesh.material as THREE.MeshBasicMaterial).color.setHex(color);
    (smashRingMesh.material as THREE.MeshBasicMaterial).opacity = 0.95;
    smashRingMesh.scale.set(initialScale, initialScale, initialScale);
    smashRingMesh.visible = true;
    smashRingLife = 0.32;
  };

  const triggerFireballSmash = () => {
    isFireballSmashQueued = true;
    matchState.isFireballQueued = true;
    matchState.lastCallText = '🔥 FIREBALL SMASH ARMED! (Next Hit Explodes)';
    triggerWallScoreboardUpdate(true);
  };

  const resetServe = () => {
    bounceCount = 0;
    matchState.rallyCount = 0;
    isFireballActive = false;
    isFireballSmashQueued = false;
    matchState.isFireballActive = false;
    matchState.isFireballQueued = false;
    tennisBallMesh.material = standardBallMat;
    fireballAuraMesh.visible = false;

    if (matchState.isServing === 'player' || matchState.gameMode === 'competition') {
      ballPos.x = 22.5;
      ballPos.y = FLOOR_Y + 1.25;
      ballPos.z = 0.5;
      ballVel.x = 10.5;
      ballVel.y = 3.6;
      ballVel.z = 0.15;
      lastHitBy = 'player';
      currentSpin = 'topspin';
    } else {
      ballPos.x = 37.0;
      ballPos.y = FLOOR_Y + 1.25;
      ballPos.z = -0.5;
      ballVel.x = -10.5;
      ballVel.y = 3.6;
      ballVel.z = -0.15;
      lastHitBy = 'bot';
      currentSpin = 'topspin';
      tennisBotGroup.triggerTennisSwing('forehand');
    }
    triggerWallScoreboardUpdate(true);
  };

  let lastScoreSignature = '';

  const triggerWallScoreboardUpdate = (force = false) => {
    const sig = `${matchState.playerScore}-${matchState.botScore}-${matchState.playerGames}-${matchState.botGames}-${matchState.rallyCount}-${matchState.ballSpeedKmh}-${matchState.lastCallText}-${matchState.gameMode}-${matchState.tacticalTactic}-${isFireballActive ? '1' : '0'}`;
    if (force || sig !== lastScoreSignature) {
      lastScoreSignature = sig;
      renderWallScoreboard(matchState);
    }
  };

  const checkTennisScoring = () => {
    if (matchState.playerScore >= 4 && matchState.playerScore - matchState.botScore >= 2) {
      matchState.playerGames++;
      matchState.playerScore = 0;
      matchState.botScore = 0;
      matchState.lastCallText = '🎉 GAME PLAYER!';
      if (matchState.playerGames >= 6) {
        matchState.playerSets++;
        matchState.playerGames = 0;
        matchState.botGames = 0;
        matchState.lastCallText = '🏆 SET PLAYER!';
      }
    } else if (matchState.botScore >= 4 && matchState.botScore - matchState.playerScore >= 2) {
      matchState.botGames++;
      matchState.playerScore = 0;
      matchState.botScore = 0;
      matchState.lastCallText = '🤖 GAME DOLLY BOT!';
      if (matchState.botGames >= 6) {
        matchState.botSets++;
        matchState.playerGames = 0;
        matchState.botGames = 0;
        matchState.lastCallText = '⚡ SET DOLLY BOT!';
      }
    }
    triggerWallScoreboardUpdate(true);
  };

  // Main match tick loop
  const updateTennisMatch = (
    delta: number,
    time: number,
    playerPos?: { x: number; y: number; z: number },
    isPlayerSwinging?: boolean,
    swingType: 'forehand' | 'backhand' | 'smash' | 'serve' = 'forehand',
    isJumping = false,
    isFireballSmash = false
  ): TennisMatchState => {
    if (isFireballSmash) {
      isFireballSmashQueued = true;
    }

    const isPlayerNearCourt = !!playerPos &&
      Math.hypot(playerPos.x - COURT_CENTER_X, playerPos.z - COURT_CENTER_Z) < 22.0 &&
      Math.abs(playerPos.y - FLOOR_Y) < 4.0;

    const dt = Math.min(delta, 0.04);
    const GRAVITY = -9.81;

    // Aerodynamic Drag & Spin Trajectory Effect
    let spinGravity = GRAVITY;
    if (isFireballActive) {
      spinGravity = -4.5; // Fireball laser flat speed dive
    } else if (currentSpin === 'topspin') {
      spinGravity -= 2.5; // Topspin causes downward dipping Magnus effect
    } else if (currentSpin === 'slice') {
      spinGravity += 1.8; // Slice causes floating lift
    }

    ballVel.y += spinGravity * dt;
    ballPos.x += ballVel.x * dt;
    ballPos.y += ballVel.y * dt;
    ballPos.z += ballVel.z * dt;

    // Animate & update trailing comet flame particles
    if (isFireballActive) {
      tennisBallMesh.material = fireballBallMat;
      fireballAuraMesh.visible = true;
      const pulse = 1 + Math.sin(time * 25) * 0.25;
      fireballAuraMesh.scale.set(pulse, pulse, pulse);

      flameSpawnTimer += dt;
      if (flameSpawnTimer > 0.015) {
        flameSpawnTimer = 0;
        spawnFlameParticle(ballPos.x, ballPos.y, ballPos.z, 1.4);
      }
    } else {
      tennisBallMesh.material = standardBallMat;
      fireballAuraMesh.visible = false;
    }

    // Update active flame particles in pool
    flameParticles.forEach((fp) => {
      if (fp.life > 0) {
        fp.life -= dt;
        const prog = 1 - fp.life / fp.maxLife;
        fp.mesh.position.y += fp.velY * dt;
        fp.mesh.position.z += fp.velZ * dt;
        const currentScale = fp.size * (1 - prog * 0.8);
        fp.mesh.scale.set(currentScale, currentScale, currentScale);
        (fp.mesh.material as THREE.MeshBasicMaterial).opacity = Math.max(0, 0.95 * (1 - prog));
        if (fp.life <= 0) fp.mesh.visible = false;
      }
    });

    // Decay smash visual shockwave
    if (smashRingLife > 0) {
      smashRingLife -= dt;
      const progress = 1 - smashRingLife / 0.32;
      const s = 1 + progress * 3.0;
      smashRingMesh.scale.set(s, s, s);
      (smashRingMesh.material as THREE.MeshBasicMaterial).opacity = 0.95 * (1 - progress);
      if (smashRingLife <= 0) smashRingMesh.visible = false;
    }

    // Floor Bounce on Tennis Court (Y = FLOOR_Y + 0.12)
    if (ballPos.y <= FLOOR_Y + 0.12) {
      ballPos.y = FLOOR_Y + 0.12;
      ballVel.y = Math.abs(ballVel.y) * (isFireballActive ? 0.85 : 0.80);
      bounceCount++;

      // Trigger fiery bounce visual when fireball bounces on Dolly's side
      if (isFireballActive) {
        triggerSmashVisual(ballPos.x, ballPos.y, ballPos.z, 0xff4500, 1.4);
        for (let k = 0; k < 6; k++) {
          spawnFlameParticle(ballPos.x, ballPos.y + 0.2, ballPos.z, 1.8);
        }
      }

      // Double bounce point scoring
      if (bounceCount >= 2) {
        if (lastHitBy === 'player' && ballPos.x > NET_X) {
          matchState.playerScore++;
          matchState.lastCallText = isFireballActive
            ? '🔥 FIREBALL POINT FOR PLAYER!'
            : '🏆 POINT FOR PLAYER! (Double Bounce)';
        } else if (lastHitBy === 'bot' && ballPos.x < NET_X) {
          matchState.botScore++;
          matchState.lastCallText = '🤖 POINT FOR DOLLY BOT!';
        }
        checkTennisScoring();
        resetServe();
      }
    }

    // Net Collision (X = 29.0, height = FLOOR_Y + 0.95, width = Z: -6.0 to 6.0)
    // Fireball smashes blast cleanly across the net
    if (!isFireballActive && Math.abs(ballPos.x - NET_X) < 0.35 && ballPos.y < FLOOR_Y + 0.95 && Math.abs(ballPos.z) < 6.0) {
      ballVel.x = -ballVel.x * 0.35;
      ballVel.y = 2.2;
      matchState.lastCallText = '⚠️ NET!';
    }

    // =======================================================================
    // 1. AUTO PLAYER LOCOMOTION ENGINE (Same intelligent movement as Dolly Bot!)
    // =======================================================================
    if (ballVel.x < 0) {
      // Ball moving toward player side: predict intercept trajectory at player hitting plane (X ~ 22.2)
      const timeToReachPlayer = Math.max(0.04, (ballPos.x - 22.2) / Math.max(0.1, -ballVel.x));
      const predictedPlayerZ = THREE.MathUtils.clamp(ballPos.z + ballVel.z * timeToReachPlayer, -4.8, 4.8);
      autoPlayerTargetZ = predictedPlayerZ;
      // Step in for short balls, stay deep behind baseline for fast deep balls
      autoPlayerTargetX = -ballVel.x < 11.5 ? 23.6 : 21.8;
    } else {
      // Ball on bot side: recover smoothly to central baseline ready position
      autoPlayerTargetZ = THREE.MathUtils.lerp(autoPlayerTargetZ, 0.0, 0.08);
      autoPlayerTargetX = THREE.MathUtils.lerp(autoPlayerTargetX, 22.5, 0.08);
    }

    // =======================================================================
    // 2. PLAYER HIT DETECTION & AUTO-PLAY RACQUET STRIKE (Player Side: X: 16.0 to 29.0)
    // =======================================================================
    const effectivePlayerX = playerPos && isPlayerNearCourt ? playerPos.x : autoPlayerTargetX;
    const effectivePlayerY = playerPos && isPlayerNearCourt ? playerPos.y : FLOOR_Y;
    const effectivePlayerZ = playerPos && isPlayerNearCourt ? playerPos.z : autoPlayerTargetZ;

    const distPlayerToBall = Math.hypot(ballPos.x - effectivePlayerX, ballPos.z - effectivePlayerZ);
    const heightDiff = Math.abs(ballPos.y - (effectivePlayerY + 1.2));
    const inPlayerZone = ballPos.x <= NET_X && ballPos.x >= 16.0;

    // Automatic hit trigger when ball reaches player zone and travelling towards player (-X)
    const isInHitWindow = inPlayerZone && ballPos.x <= 24.4 && ballPos.x >= 20.0 && lastHitBy === 'bot' && ballVel.x < 0;
    const maxReach = isJumping ? 4.0 : 3.4;
    const canHit = inPlayerZone && (lastHitBy === 'bot' || matchState.gameMode === 'competition') &&
      (distPlayerToBall < maxReach && heightDiff < 2.6);

    autoPlayerSwingTrigger = null;

    if (isInHitWindow || ((isPlayerSwinging || canHit) && (distPlayerToBall < maxReach || isPlayerSwinging))) {
      if (inPlayerZone && lastHitBy === 'bot') {
        const doFireball = isFireballSmashQueued || swingType === 'smash' && isFireballActive;
        const isSmash = doFireball || swingType === 'smash' || isJumping || (ballPos.y > FLOOR_Y + 1.8);
        const determinedSwing: 'forehand' | 'backhand' | 'smash' = isSmash
          ? 'smash'
          : (effectivePlayerZ < 0 ? 'forehand' : 'backhand');

        if (isPlayerNearCourt) {
          autoPlayerSwingTrigger = determinedSwing;
        }

        if (doFireball) {
          // --- FIREBALL SMASH LAUNCH ---
          isFireballActive = true;
          isFireballSmashQueued = false;
          matchState.isFireballActive = true;
          matchState.isFireballQueued = false;
          matchState.lastHitType = 'fireball';

          // Blistering Supersonic Velocity (215 - 245 KM/H)
          const fireSpeed = 22.5 + Math.random() * 3.5;
          matchState.ballSpeedKmh = Math.round(fireSpeed * 3.6 * 2.2);

          ballVel.x = fireSpeed;
          ballVel.y = 1.3 + Math.random() * 0.4; // Laser flat skimming drive
          // Crosscourt laser angle
          ballVel.z = THREE.MathUtils.clamp(-effectivePlayerZ * 0.65 + (Math.random() - 0.5) * 1.5, -4.6, 4.6);
          currentSpin = 'flat';

          matchState.lastCallText = `🔥 ULTRA FIREBALL SMASH! (${matchState.ballSpeedKmh} KM/H • Rally ${matchState.rallyCount + 1})`;
          triggerSmashVisual(ballPos.x, ballPos.y, ballPos.z, 0xff2200, 1.8);

          // Burst fiery particles from racquet impact
          for (let k = 0; k < 10; k++) {
            spawnFlameParticle(ballPos.x, ballPos.y, ballPos.z, 2.0);
          }
        } else {
          // --- STANDARD / AUTO PROFESSIONAL RETURN ---
          isFireballActive = false;
          matchState.isFireballActive = false;
          matchState.lastHitType = isSmash ? 'smash' : determinedSwing;

          const baseSpeed = isSmash ? (14.5 + Math.random() * 3.2) : (11.0 + Math.random() * 2.4);
          const rallySpeedBonus = Math.min(4.5, matchState.rallyCount * 0.25);
          const totalSpeed = baseSpeed + rallySpeedBonus;

          matchState.ballSpeedKmh = Math.round(totalSpeed * 3.6 * 2.2);
          ballVel.x = totalSpeed;
          ballVel.y = isSmash ? (2.0 + Math.random() * 0.8) : (3.5 + Math.random() * 0.9);

          const targetCrosscourtZ = -effectivePlayerZ * 0.55 + (Math.random() - 0.5) * 2.4;
          ballVel.z = THREE.MathUtils.clamp(targetCrosscourtZ, -4.5, 4.5);
          currentSpin = isSmash ? 'flat' : 'topspin';

          matchState.lastCallText = isSmash
            ? `💥 POWER SMASH! (${matchState.ballSpeedKmh} KM/H • Rally ${matchState.rallyCount + 1})`
            : `🎾 ${determinedSwing.toUpperCase()} TOPSPIN! (${matchState.ballSpeedKmh} KM/H • Rally ${matchState.rallyCount + 1})`;

          triggerSmashVisual(ballPos.x, ballPos.y, ballPos.z, isSmash ? 0xfacc15 : 0x38bdf8);
        }

        lastHitBy = 'player';
        bounceCount = 0;
        matchState.rallyCount++;
      }
    }

    // =======================================================================
    // 3. DOLLY BOT AGENTIC TACTICAL AI (Training Mode)
    // =======================================================================
    if (matchState.gameMode === 'training') {
      tennisBotGroup.group.visible = true;

      // Positioning Code & Intercept Trajectory Prediction
      if (ballVel.x > 0) {
        const timeToReachBot = Math.max(0.05, (36.5 - ballPos.x) / Math.max(0.1, ballVel.x));
        const predictedZ = ballPos.z + ballVel.z * timeToReachBot;
        botTargetZ = THREE.MathUtils.clamp(predictedZ, -4.8, 4.8);
        botTargetX = ballVel.x < 12.0 ? 35.0 : 37.4;
      } else {
        botTargetZ = THREE.MathUtils.lerp(botTargetZ, 0.0, 0.08);
        botTargetX = THREE.MathUtils.lerp(botTargetX, 37.0, 0.08);
      }

      // Smooth locomotion toward intercept spot (competitive pro speed)
      tennisBotGroup.group.position.z += (botTargetZ - tennisBotGroup.group.position.z) * 0.42;
      tennisBotGroup.group.position.x += (botTargetX - tennisBotGroup.group.position.x) * 0.35;

      // Dolly Bot Hit Trigger (Ball reaches X: 34.0 to 38.2 and travelling +X)
      if (ballPos.x >= 34.0 && ballPos.x <= 38.4 && lastHitBy === 'player' && ballVel.x > 0) {
        const isShortBall = ballPos.x < 35.5 && ballPos.y < FLOOR_Y + 1.2;
        const isHighBall = ballPos.y > FLOOR_Y + 1.6;
        const playerIsLeft = effectivePlayerZ < -1.0;
        const playerIsRight = effectivePlayerZ > 1.0;

        let tacticalChoice: string;
        let botSpeed: number;
        let targetAngleZ: number;
        let smash = false;

        if (isFireballActive) {
          // Dolly bot pro emergency block against the fiery meteor!
          tacticalChoice = 'Meteor Fireball Pro Block & Counter!';
          botSpeed = 16.0 + Math.random() * 3.0;
          targetAngleZ = (Math.random() - 0.5) * 4.8;
          smash = false;
          currentSpin = 'topspin';
          isFireballActive = false; // Extinguish on return
          matchState.isFireballActive = false;
        } else if (isHighBall || Math.random() < 0.35) {
          tacticalChoice = 'Pro Zone Smash';
          smash = true;
          botSpeed = 17.5 + Math.random() * 3.5;
          targetAngleZ = (Math.random() - 0.5) * 4.8;
          currentSpin = 'flat';
        } else if (playerIsLeft && Math.random() < 0.8) {
          tacticalChoice = 'Sharp Down-the-Line Winner';
          botSpeed = 14.5 + Math.random() * 2.8;
          targetAngleZ = 4.2 + (Math.random() - 0.5) * 0.8;
          currentSpin = 'topspin';
        } else if (playerIsRight && Math.random() < 0.8) {
          tacticalChoice = 'Sharp Down-the-Line Winner';
          botSpeed = 14.5 + Math.random() * 2.8;
          targetAngleZ = -4.2 + (Math.random() - 0.5) * 0.8;
          currentSpin = 'topspin';
        } else if (isShortBall) {
          tacticalChoice = 'Lethal Drop Angle';
          botSpeed = 13.5 + Math.random() * 2.5;
          targetAngleZ = -botTargetZ * 0.95;
          currentSpin = 'slice';
        } else {
          tacticalChoice = 'Aggressive Crosscourt Drive';
          botSpeed = 14.0 + Math.random() * 2.5;
          targetAngleZ = -botTargetZ * 0.85;
          currentSpin = 'topspin';
        }

        matchState.tacticalTactic = tacticalChoice;
        matchState.ballSpeedKmh = Math.round(botSpeed * 3.6 * 2.2);

        ballVel.x = -botSpeed;
        ballVel.y = smash ? (1.8 + Math.random() * 0.6) : (3.0 + Math.random() * 0.8);
        ballVel.z = THREE.MathUtils.clamp(targetAngleZ, -5.2, 5.2);

        lastHitBy = 'bot';
        tennisBotGroup.triggerTennisSwing(smash ? 'smash' : 'forehand');
        bounceCount = 0;
        matchState.rallyCount++;

        matchState.lastCallText = smash
          ? `⚡ DOLLY BOT SMASH! (${matchState.ballSpeedKmh} KM/H • ${tacticalChoice})`
          : `🤖 DOLLY RETURN! (${matchState.ballSpeedKmh} KM/H • ${tacticalChoice})`;

        triggerSmashVisual(ballPos.x, ballPos.y, ballPos.z, smash ? 0xef4444 : 0x00e5ff);
      }

      tennisBotGroup.updateAnimation(time, false, false, false, true, false);
    } else {
      tennisBotGroup.group.visible = false;
    }

    // =======================================================================
    // 4. OUT-OF-BOUNDS & SCORING RESET LOGIC
    // =======================================================================
    if (ballPos.x < 15.5 || ballPos.x > 44.0 || Math.abs(ballPos.z) > 7.2) {
      if (lastHitBy === 'player') {
        matchState.botScore++;
        matchState.lastCallText = matchState.gameMode === 'training'
          ? '🔴 OUT! Point to Dolly Bot'
          : '🔴 OUT! Point to Opponent';
      } else {
        matchState.playerScore++;
        matchState.lastCallText = '🟢 OUT! Point to Player';
      }
      checkTennisScoring();
      resetServe();
    }

    // Update 3D ball mesh position & spin rotation
    tennisBallMesh.position.set(ballPos.x, ballPos.y, ballPos.z);
    tennisBallMesh.rotation.x += ballVel.z * delta * 8.0;
    tennisBallMesh.rotation.z -= ballVel.x * delta * 8.0;

    // Export current auto player position and action
    matchState.autoPlayerPos = {
      x: autoPlayerTargetX,
      z: autoPlayerTargetZ,
      swingAction: autoPlayerSwingTrigger,
      isFireball: isFireballActive,
    };
    matchState.isFireballActive = isFireballActive;
    matchState.isFireballQueued = isFireballSmashQueued;

    triggerWallScoreboardUpdate();

    return matchState;
  };

  const setGameMode = (mode: 'training' | 'competition') => {
    matchState.gameMode = mode;
    matchState.playerScore = 0;
    matchState.botScore = 0;
    matchState.rallyCount = 0;
    matchState.lastCallText = mode === 'training'
      ? '🎾 Training Mode: Battle vs Dolly Bot!'
      : '👥 Competition Mode: Ready for Multiplayer Friends!';
    resetServe();
    triggerWallScoreboardUpdate(true);
  };

  return {
    courtGroup,
    tennisBallMesh,
    tennisBotGroup,
    interactiveObjects: [botClickMesh, courtGroundMesh],
    updateTennisMatch,
    triggerFireballSmash,
    resetServe,
    setGameMode,
    getMatchState: () => matchState,
  };
}
