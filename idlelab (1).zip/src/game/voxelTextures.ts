import * as THREE from 'three';
import { AvatarSkin, DeskTheme } from '../types';

// Helper to create smooth anti-aliased CanvasTexture for high-definition indie character rendering
function createSmoothCanvasTexture(
  width: number,
  height: number,
  drawFn: (ctx: CanvasRenderingContext2D) => void
): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d');
  if (ctx) {
    ctx.imageSmoothingEnabled = true;
    ctx.imageSmoothingQuality = 'high';
    drawFn(ctx);
  }
  const texture = new THREE.CanvasTexture(canvas);
  texture.magFilter = THREE.LinearFilter;
  texture.minFilter = THREE.LinearMipmapLinearFilter;
  texture.generateMipmaps = true;
  texture.wrapS = THREE.ClampToEdgeWrapping;
  texture.wrapT = THREE.ClampToEdgeWrapping;
  return texture;
}

// Helper to create pixel CanvasTexture with NearestFilter for sharp voxel rendering
function createPixelCanvasTexture(
  width: number,
  height: number,
  drawFn: (ctx: CanvasRenderingContext2D) => void
): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d');
  if (ctx) {
    ctx.imageSmoothingEnabled = false;
    drawFn(ctx);
  }
  const texture = new THREE.CanvasTexture(canvas);
  texture.magFilter = THREE.NearestFilter;
  texture.minFilter = THREE.NearestFilter;
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.RepeatWrapping;
  return texture;
}

// 1. Cobblestone / Polished Stone Table texture (as in reference image)
export function getStoneTexture(): THREE.CanvasTexture {
  return createPixelCanvasTexture(16, 16, (ctx) => {
    ctx.fillStyle = '#737373';
    ctx.fillRect(0, 0, 16, 16);
    // Draw noise pixel blocks
    for (let x = 0; x < 16; x++) {
      for (let y = 0; y < 16; y++) {
        const rand = Math.random();
        if (rand > 0.7) {
          ctx.fillStyle = '#a3a3a3';
          ctx.fillRect(x, y, 1, 1);
        } else if (rand < 0.3) {
          ctx.fillStyle = '#525252';
          ctx.fillRect(x, y, 1, 1);
        }
      }
    }
    // Subtle grid border
    ctx.fillStyle = '#404040';
    ctx.fillRect(0, 0, 16, 1);
    ctx.fillRect(0, 0, 1, 16);
  });
}

// 2. Wood Plank Textures for Desks & Floor
export function getWoodTexture(theme: DeskTheme | 'carpet' | 'floor_wood'): THREE.CanvasTexture {
  let primaryColor = '#78350f';
  let altColor = '#92400e';
  let darkColor = '#451a03';

  if (theme === 'spruce') {
    primaryColor = '#5c3d2e'; altColor = '#734b38'; darkColor = '#3b251a';
  } else if (theme === 'cherry') {
    primaryColor = '#881337'; altColor = '#9f1239'; darkColor = '#4c0519';
  } else if (theme === 'white_marble') {
    primaryColor = '#e2e8f0'; altColor = '#f8fafc'; darkColor = '#cbd5e1';
  } else if (theme === 'cyber_neon') {
    primaryColor = '#0f172a'; altColor = '#1e1b4b'; darkColor = '#06b6d4';
  } else if (theme === 'carpet') {
    primaryColor = '#334155'; altColor = '#475569'; darkColor = '#1e293b';
  } else if (theme === 'floor_wood') {
    primaryColor = '#b45309'; altColor = '#d97706'; darkColor = '#78350f';
  }

  return createPixelCanvasTexture(16, 16, (ctx) => {
    ctx.fillStyle = primaryColor;
    ctx.fillRect(0, 0, 16, 16);

    // Horizontal plank lines
    for (let y = 0; y < 16; y += 4) {
      ctx.fillStyle = darkColor;
      ctx.fillRect(0, y, 16, 1);
    }

    // Wood grain detail pixels
    for (let x = 0; x < 16; x++) {
      for (let y = 0; y < 16; y++) {
        if (Math.random() > 0.75) {
          ctx.fillStyle = altColor;
          ctx.fillRect(x, y, 1, 1);
        }
      }
    }
  });
}

// Dedicated Oakland Oak Hardwood Floor Tile Texture
export function getOaklandWoodFloorTilesTexture(): THREE.CanvasTexture {
  return createPixelCanvasTexture(64, 64, (ctx) => {
    // Warm Oakland Golden Oak Base Palette
    const baseOak = '#c28136';
    const lightOak = '#d99b50';
    const darkOak = '#9a5e1d';
    const seamColor = '#5c350d';
    const highlightOak = '#e8b874';

    ctx.fillStyle = baseOak;
    ctx.fillRect(0, 0, 64, 64);

    // Staggered 4-tile parquet / plank grid (each plank 32x16 or 64x16 with seams)
    const plankHeight = 16;
    for (let row = 0; row < 4; row++) {
      const y = row * plankHeight;
      const xOffset = (row % 2 === 0) ? 0 : 32;

      // Draw two planks per row
      for (let p = 0; p < 3; p++) {
        const px = ((p * 32 - xOffset + 64) % 64);
        const plankHueShift = (row * 7 + p * 13) % 4;

        // Subtly vary base tone between planks
        ctx.fillStyle = plankHueShift === 0 ? baseOak : plankHueShift === 1 ? lightOak : plankHueShift === 2 ? '#b8772e' : '#cd8e43';
        ctx.fillRect(px, y, 32, plankHeight);

        // Individual wood grain streaks along horizontal axis
        for (let gy = 2; gy < plankHeight - 2; gy += 3) {
          ctx.fillStyle = darkOak;
          ctx.fillRect(px, y + gy, 32, 1);
          // Grain knot / organic variation
          for (let gx = 0; gx < 32; gx += 4) {
            if ((gx + gy * 3 + p * 5) % 7 === 0) {
              ctx.fillStyle = highlightOak;
              ctx.fillRect(px + gx, y + gy, 3, 1);
            }
          }
        }

        // Vertical plank seam
        ctx.fillStyle = seamColor;
        ctx.fillRect(px, y, 1, plankHeight);
      }

      // Horizontal plank seam & bevel shadow
      ctx.fillStyle = seamColor;
      ctx.fillRect(0, y, 64, 1);
      ctx.fillStyle = highlightOak;
      ctx.fillRect(0, y + 1, 64, 1);
    }

    // Outer tile boundary bevel
    ctx.fillStyle = seamColor;
    ctx.fillRect(0, 0, 64, 1);
    ctx.fillRect(0, 0, 1, 64);
    ctx.fillRect(63, 0, 1, 64);
    ctx.fillRect(0, 63, 64, 1);
  });
}

// Scandinavian Vertical Acoustic Wood Slat Wall Paneling Texture
export function getScandinavianWoodSlatTexture(): THREE.CanvasTexture {
  return createPixelCanvasTexture(64, 64, (ctx) => {
    // Dark Charcoal / Anthracite Acoustic Felt Recessed Backing
    ctx.fillStyle = '#18181b';
    ctx.fillRect(0, 0, 64, 64);

    // Warm Natural Nordic Light Oak Vertical Slats (each slat 6px wide, 2px gap)
    const slatWidth = 6;
    const gapWidth = 2;
    const period = slatWidth + gapWidth; // 8px

    for (let x = 0; x < 64; x += period) {
      // Slat Body
      ctx.fillStyle = '#e5b882'; // Natural light oak
      ctx.fillRect(x + 1, 0, slatWidth - 1, 64);

      // Slat Left Edge Highlight (3D Chamfer)
      ctx.fillStyle = '#fae0b8';
      ctx.fillRect(x + 1, 0, 1, 64);

      // Slat Right Edge Shadow (Depth)
      ctx.fillStyle = '#b58652';
      ctx.fillRect(x + slatWidth - 1, 0, 1, 64);

      // Vertical subtle wood grain fibers
      for (let y = 0; y < 64; y += 4) {
        if ((x + y * 2) % 6 === 0) {
          ctx.fillStyle = '#c79761';
          ctx.fillRect(x + 2, y, 2, 3);
        }
      }
    }
  });
}

// 3. Bookshelf Texture (matching reference image!)
export function getBookshelfTexture(): THREE.CanvasTexture {
  return createPixelCanvasTexture(16, 16, (ctx) => {
    // Wood frame
    ctx.fillStyle = '#78350f';
    ctx.fillRect(0, 0, 16, 16);

    // Shelves cutout
    ctx.fillStyle = '#451a03';
    ctx.fillRect(1, 1, 14, 6);
    ctx.fillRect(1, 9, 14, 6);

    // Shelf divider lines
    ctx.fillStyle = '#92400e';
    ctx.fillRect(0, 0, 16, 1);
    ctx.fillRect(0, 7, 16, 2);
    ctx.fillRect(0, 15, 16, 1);

    // Book spines on Top Shelf
    const colorsTop = ['#ef4444', '#3b82f6', '#10b981', '#f59e0b', '#8b5cf6', '#ec4899', '#3b82f6', '#ef4444'];
    let x = 2;
    for (let i = 0; i < colorsTop.length; i++) {
      const bookWidth = Math.random() > 0.5 ? 2 : 1;
      ctx.fillStyle = colorsTop[i];
      ctx.fillRect(x, 2, bookWidth, 5);
      x += bookWidth + 1;
      if (x >= 14) break;
    }

    // Book spines on Bottom Shelf
    const colorsBottom = ['#10b981', '#f59e0b', '#ec4899', '#ef4444', '#3b82f6', '#8b5cf6', '#10b981'];
    x = 2;
    for (let i = 0; i < colorsBottom.length; i++) {
      const bookWidth = Math.random() > 0.5 ? 2 : 1;
      ctx.fillStyle = colorsBottom[i];
      ctx.fillRect(x, 10, bookWidth, 5);
      x += bookWidth + 1;
      if (x >= 14) break;
    }
  });
}

// 4. Chalkboard / Blackboard Texture (matching screenshot handwritten TODO list!)
export function getChalkboardTexture(): THREE.CanvasTexture {
  return createPixelCanvasTexture(64, 32, (ctx) => {
    // Dark chalkboard green background
    ctx.fillStyle = '#143823';
    ctx.fillRect(0, 0, 64, 32);

    // Wooden border frame
    ctx.fillStyle = '#5c3d2e';
    ctx.fillRect(0, 0, 64, 2);
    ctx.fillRect(0, 30, 64, 2);
    ctx.fillRect(0, 0, 2, 32);
    ctx.fillRect(62, 0, 2, 32);

    // Chalk dust & text lines
    ctx.fillStyle = '#e2e8f0';
    ctx.font = '7px monospace';
    ctx.fillText('⚡ Minecraft VR', 4, 8);
    ctx.font = '5px monospace';
    ctx.fillStyle = '#cbd5e1';
    ctx.fillText('TODO:', 6, 14);
    ctx.fillText('- Print report', 10, 19);
    ctx.fillText('- Report prints', 10, 24);
    ctx.fillText('- Shelve purchases', 10, 29);
  });
}

// 5. Ceiling Light Tile (matching screenshot recessed grid lights!)
export function getCeilingTexture(): THREE.CanvasTexture {
  return createPixelCanvasTexture(16, 16, (ctx) => {
    ctx.fillStyle = '#e2e8f0';
    ctx.fillRect(0, 0, 16, 16);

    // Tile border grid
    ctx.fillStyle = '#cbd5e1';
    ctx.fillRect(0, 0, 16, 1);
    ctx.fillRect(0, 0, 1, 16);

    // Recessed LED lights grid (4 squares)
    ctx.fillStyle = '#fef08a'; // bright warm light
    ctx.fillRect(3, 3, 4, 4);
    ctx.fillRect(9, 3, 4, 4);
    ctx.fillRect(3, 9, 4, 4);
    ctx.fillRect(9, 9, 4, 4);

    ctx.fillStyle = '#ffffff';
    ctx.fillRect(4, 4, 2, 2);
    ctx.fillRect(10, 4, 2, 2);
    ctx.fillRect(4, 10, 2, 2);
    ctx.fillRect(10, 10, 2, 2);
  });
}

// 6. Wall Glass Window Texture
export function getGlassWindowTexture(): THREE.CanvasTexture {
  return createPixelCanvasTexture(16, 16, (ctx) => {
    ctx.fillStyle = 'rgba(186, 230, 253, 0.6)';
    ctx.fillRect(0, 0, 16, 16);

    // Metallic frame
    ctx.fillStyle = '#475569';
    ctx.fillRect(0, 0, 16, 1);
    ctx.fillRect(0, 15, 16, 1);
    ctx.fillRect(0, 0, 1, 16);
    ctx.fillRect(15, 0, 1, 16);

    // Diagonal glass reflections
    ctx.fillStyle = 'rgba(255, 255, 255, 0.4)';
    ctx.fillRect(3, 3, 2, 2);
    ctx.fillRect(5, 5, 2, 2);
    ctx.fillRect(10, 10, 2, 2);
  });
}

// 7. Avatar Skin Textures
export function getAvatarFaceTexture(skin: AvatarSkin): THREE.CanvasTexture {
  if (skin === 'college_dev_f') {
    return createSmoothCanvasTexture(256, 256, (ctx) => {
      // 1. Radiant Porcelain Peachy Skin Gradient
      const skinGrad = ctx.createRadialGradient(128, 128, 20, 128, 128, 140);
      skinGrad.addColorStop(0, '#fff4ed');
      skinGrad.addColorStop(0.7, '#fed7c2');
      skinGrad.addColorStop(1, '#f8be9e');
      ctx.fillStyle = skinGrad;
      ctx.fillRect(0, 0, 256, 256);

      // 2. Soft Cheek Blush (Radiant Joyous Glow)
      const lBlush = ctx.createRadialGradient(68, 150, 5, 68, 150, 42);
      lBlush.addColorStop(0, 'rgba(251, 113, 133, 0.42)');
      lBlush.addColorStop(1, 'rgba(251, 113, 133, 0)');
      ctx.fillStyle = lBlush;
      ctx.beginPath(); ctx.arc(68, 150, 42, 0, Math.PI * 2); ctx.fill();

      const rBlush = ctx.createRadialGradient(188, 150, 5, 188, 150, 42);
      rBlush.addColorStop(0, 'rgba(251, 113, 133, 0.42)');
      rBlush.addColorStop(1, 'rgba(251, 113, 133, 0)');
      ctx.fillStyle = rBlush;
      ctx.beginPath(); ctx.arc(188, 150, 42, 0, Math.PI * 2); ctx.fill();

      // 3. Hairline Root Gradient & Soft Fringe at Forehead
      const hairGrad = ctx.createLinearGradient(0, 0, 0, 50);
      hairGrad.addColorStop(0, '#24140a');
      hairGrad.addColorStop(0.7, '#3d200e');
      hairGrad.addColorStop(1, 'rgba(61, 32, 14, 0)');
      ctx.fillStyle = hairGrad;
      ctx.fillRect(0, 0, 256, 50);

      // 4. Refined Arched Eyebrows
      ctx.strokeStyle = '#2a160c';
      ctx.lineWidth = 4.5;
      ctx.lineCap = 'round';

      // Left Brow
      ctx.beginPath();
      ctx.moveTo(46, 92);
      ctx.quadraticCurveTo(68, 78, 96, 88);
      ctx.stroke();

      // Right Brow
      ctx.beginPath();
      ctx.moveTo(160, 88);
      ctx.quadraticCurveTo(188, 78, 210, 92);
      ctx.stroke();

      // 5. Sparkling Indie Female Almond Eyes
      const drawEye = (cx: number, cy: number, isRight: boolean) => {
        // Eye Sclera (White)
        ctx.fillStyle = '#ffffff';
        ctx.beginPath();
        ctx.ellipse(cx, cy, 24, 16, 0, 0, Math.PI * 2);
        ctx.fill();

        // Upper Eyelid Shadow
        ctx.fillStyle = 'rgba(203, 150, 120, 0.25)';
        ctx.beginPath();
        ctx.ellipse(cx, cy - 6, 22, 9, 0, 0, Math.PI);
        ctx.fill();

        // Large Luminous Iris (Pure Solid Black)
        ctx.fillStyle = '#000000';
        ctx.beginPath();
        ctx.arc(cx, cy, 13, 0, Math.PI * 2);
        ctx.fill();

        // Jet Pupil (Pure Solid Black)
        ctx.fillStyle = '#000000';
        ctx.beginPath();
        ctx.arc(cx, cy, 6, 0, Math.PI * 2);
        ctx.fill();

        // Multiple Brilliant Catchlights (Anime/Indie Sparkle)
        ctx.fillStyle = '#ffffff';
        ctx.beginPath();
        ctx.arc(cx - 4, cy - 4, 3.5, 0, Math.PI * 2);
        ctx.fill();
        ctx.beginPath();
        ctx.arc(cx + 4, cy + 3, 2.0, 0, Math.PI * 2);
        ctx.fill();

        // Delicate Double Eyelid Crease
        ctx.strokeStyle = '#c68461';
        ctx.lineWidth = 2.0;
        ctx.beginPath();
        ctx.ellipse(cx, cy - 20, 20, 6, 0, Math.PI * 0.9, Math.PI * 2.1);
        ctx.stroke();

        // Upper Lash Line with subtle winged tip
        ctx.strokeStyle = '#1a0d06';
        ctx.lineWidth = 3.8;
        ctx.beginPath();
        if (isRight) {
          ctx.moveTo(cx - 24, cy + 2);
          ctx.quadraticCurveTo(cx, cy - 17, cx + 26, cy - 3);
          ctx.stroke();
        } else {
          ctx.moveTo(cx + 24, cy + 2);
          ctx.quadraticCurveTo(cx, cy - 17, cx - 26, cy - 3);
          ctx.stroke();
        }
      };

      drawEye(70, 115, false);
      drawEye(186, 115, true);

      // 6. Cute Subtle Nose Tip & Shading
      ctx.fillStyle = 'rgba(198, 120, 85, 0.4)';
      ctx.beginPath();
      ctx.ellipse(128, 156, 7, 4, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#ffffff';
      ctx.beginPath();
      ctx.arc(128, 154, 2, 0, Math.PI * 2);
      ctx.fill();

      // 7. Radiant Joyous Open Smile (Beaming White Teeth & Rosy Peach Lips)
      // Lip Base Fill
      ctx.fillStyle = '#f43f5e';
      ctx.beginPath();
      ctx.ellipse(128, 196, 30, 18, 0, 0, Math.PI * 2);
      ctx.fill();

      // Mouth Cavity
      ctx.fillStyle = '#881337';
      ctx.beginPath();
      ctx.ellipse(128, 196, 26, 14, 0, 0, Math.PI * 2);
      ctx.fill();

      // Clean White Teeth Arc
      ctx.fillStyle = '#ffffff';
      ctx.beginPath();
      ctx.moveTo(105, 192);
      ctx.quadraticCurveTo(128, 195, 151, 192);
      ctx.lineTo(149, 199);
      ctx.quadraticCurveTo(128, 203, 107, 199);
      ctx.closePath();
      ctx.fill();

      // Rosy Lip Outline & Corners
      ctx.strokeStyle = '#e11d48';
      ctx.lineWidth = 2.5;
      ctx.beginPath();
      ctx.moveTo(98, 192);
      ctx.quadraticCurveTo(128, 182, 158, 192);
      ctx.quadraticCurveTo(128, 218, 98, 192);
      ctx.stroke();

      // Lip Gloss Highlight
      ctx.fillStyle = 'rgba(255, 255, 255, 0.65)';
      ctx.beginPath();
      ctx.ellipse(128, 208, 10, 3, 0, 0, Math.PI * 2);
      ctx.fill();
    });
  }

  if (skin === 'college_dev_m' || skin === 'human_dev') {
    return createSmoothCanvasTexture(256, 256, (ctx) => {
      // 1. Golden Sunset Warm Skin Gradient (Beach Golden Hour reference)
      const skinGrad = ctx.createRadialGradient(128, 128, 30, 128, 128, 145);
      skinGrad.addColorStop(0, '#fedcb5');
      skinGrad.addColorStop(0.65, '#fbc396');
      skinGrad.addColorStop(1, '#f4a974');
      ctx.fillStyle = skinGrad;
      ctx.fillRect(0, 0, 256, 256);

      // 2. Sunset Golden Hour Glow & Subtle Jawline Contour
      const sunGlow = ctx.createRadialGradient(50, 130, 10, 50, 130, 90);
      sunGlow.addColorStop(0, 'rgba(251, 146, 60, 0.25)');
      sunGlow.addColorStop(1, 'rgba(251, 146, 60, 0)');
      ctx.fillStyle = sunGlow;
      ctx.fillRect(0, 0, 256, 256);

      // 3. Hairline Root Gradient at Forehead
      const hairGrad = ctx.createLinearGradient(0, 0, 0, 48);
      hairGrad.addColorStop(0, '#1c120c');
      hairGrad.addColorStop(0.8, '#321c10');
      hairGrad.addColorStop(1, 'rgba(50, 28, 16, 0)');
      ctx.fillStyle = hairGrad;
      ctx.fillRect(0, 0, 256, 48);

      // 4. Masculine Natural Dark Eyebrows
      ctx.strokeStyle = '#1e1109';
      ctx.lineWidth = 6.0;
      ctx.lineCap = 'round';

      // Left Brow
      ctx.beginPath();
      ctx.moveTo(42, 88);
      ctx.quadraticCurveTo(68, 76, 98, 84);
      ctx.stroke();

      // Right Brow
      ctx.beginPath();
      ctx.moveTo(158, 84);
      ctx.quadraticCurveTo(188, 76, 214, 88);
      ctx.stroke();

      // 5. Handsome Almond Asian Eyes
      const drawMaleEye = (cx: number, cy: number) => {
        // Sclera
        ctx.fillStyle = '#fbf8f5';
        ctx.beginPath();
        ctx.ellipse(cx, cy, 24, 13, 0, 0, Math.PI * 2);
        ctx.fill();

        // Upper Eyelid Soft Shadow
        ctx.fillStyle = 'rgba(180, 110, 70, 0.25)';
        ctx.beginPath();
        ctx.ellipse(cx, cy - 5, 22, 7, 0, 0, Math.PI);
        ctx.fill();

        // Pure Solid Black Iris
        ctx.fillStyle = '#000000';
        ctx.beginPath();
        ctx.arc(cx, cy, 11.5, 0, Math.PI * 2);
        ctx.fill();

        // Pure Solid Black Pupil
        ctx.fillStyle = '#000000';
        ctx.beginPath();
        ctx.arc(cx, cy, 5.5, 0, Math.PI * 2);
        ctx.fill();

        // Catchlight Reflection
        ctx.fillStyle = '#ffffff';
        ctx.beginPath();
        ctx.arc(cx - 3.5, cy - 3.5, 3.0, 0, Math.PI * 2);
        ctx.fill();

        // Double Eyelid Crease
        ctx.strokeStyle = '#bb7952';
        ctx.lineWidth = 1.8;
        ctx.beginPath();
        ctx.ellipse(cx, cy - 16, 18, 5, 0, Math.PI * 0.9, Math.PI * 2.1);
        ctx.stroke();

        // Masculine Upper Lash Line
        ctx.strokeStyle = '#180d06';
        ctx.lineWidth = 3.6;
        ctx.beginPath();
        ctx.moveTo(cx - 24, cy + 1);
        ctx.quadraticCurveTo(cx, cy - 13, cx + 24, cy + 1);
        ctx.stroke();
      };

      drawMaleEye(70, 112);
      drawMaleEye(186, 112);

      // 6. Sculpted Natural Nose Bridge & Nostril Shading
      ctx.fillStyle = 'rgba(175, 95, 55, 0.35)';
      ctx.beginPath();
      ctx.ellipse(128, 154, 8, 4.5, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = 'rgba(255, 255, 255, 0.4)';
      ctx.beginPath();
      ctx.arc(128, 152, 2.5, 0, Math.PI * 2);
      ctx.fill();

      // 7. Friendly Confident Natural Smile
      // Lip Base
      ctx.fillStyle = '#c56b5c';
      ctx.beginPath();
      ctx.ellipse(128, 192, 26, 11, 0, 0, Math.PI * 2);
      ctx.fill();

      // Mouth Separation / Smile Line
      ctx.strokeStyle = '#7c2d12';
      ctx.lineWidth = 2.4;
      ctx.beginPath();
      ctx.moveTo(104, 190);
      ctx.quadraticCurveTo(128, 198, 152, 190);
      ctx.stroke();

      // Lower Lip Highlight
      ctx.fillStyle = 'rgba(255, 230, 215, 0.5)';
      ctx.beginPath();
      ctx.ellipse(128, 198, 12, 3, 0, 0, Math.PI * 2);
      ctx.fill();
    });
  }

  return createPixelCanvasTexture(16, 16, (ctx) => {
    if (skin === 'fox_suit') {
      // Orange Fox Head (matching screenshot foreground fox!)
      ctx.fillStyle = '#ea580c'; // Fox orange
      ctx.fillRect(0, 0, 16, 16);
      // White snout & cheeks
      ctx.fillStyle = '#f8fafc';
      ctx.fillRect(3, 9, 10, 7);
      // Black nose
      ctx.fillStyle = '#0f172a';
      ctx.fillRect(7, 9, 2, 2);
      // Eyes
      ctx.fillStyle = '#0f172a';
      ctx.fillRect(3, 6, 2, 2);
      ctx.fillRect(11, 6, 2, 2);
      // Ears
      ctx.fillStyle = '#7c2d12';
      ctx.fillRect(1, 0, 3, 2);
      ctx.fillRect(12, 0, 3, 2);
    } else if (skin === 'zombie_suit') {
      // Green Zombie Head (matching screenshot zombie!)
      ctx.fillStyle = '#416335';
      ctx.fillRect(0, 0, 16, 16);
      // Dark zombie eyes & mouth
      ctx.fillStyle = '#1c2e17';
      ctx.fillRect(3, 5, 3, 3);
      ctx.fillRect(10, 5, 3, 3);
      ctx.fillRect(5, 11, 6, 2);
    } else if (skin === 'skeleton_suit') {
      // Skeleton Skull Head (matching screenshot skeleton!)
      ctx.fillStyle = '#e2e8f0';
      ctx.fillRect(0, 0, 16, 16);
      // Eye sockets
      ctx.fillStyle = '#0f172a';
      ctx.fillRect(3, 5, 3, 4);
      ctx.fillRect(10, 5, 3, 4);
      // Teeth
      ctx.fillRect(5, 12, 6, 2);
    } else if (skin === 'villager_suit') {
      // Villager Head (matching screenshot villager with big nose!)
      ctx.fillStyle = '#b48160';
      ctx.fillRect(0, 0, 16, 16);
      // Big nose
      ctx.fillStyle = '#946043';
      ctx.fillRect(6, 7, 4, 6);
      // Unibrow & Eyes
      ctx.fillStyle = '#2d1810';
      ctx.fillRect(3, 5, 10, 1);
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(3, 6, 2, 2);
      ctx.fillRect(11, 6, 2, 2);
      ctx.fillStyle = '#1e3a8a'; // Green/blue pupils
      ctx.fillRect(4, 6, 1, 2);
      ctx.fillRect(11, 6, 1, 2);
    } else if (skin === 'executive_bear') {
      // Brown Bear
      ctx.fillStyle = '#78350f';
      ctx.fillRect(0, 0, 16, 16);
      ctx.fillStyle = '#fef08a';
      ctx.fillRect(4, 8, 8, 6);
      ctx.fillStyle = '#0f172a';
      ctx.fillRect(7, 8, 2, 2);
      ctx.fillRect(3, 5, 2, 2);
      ctx.fillRect(11, 5, 2, 2);
    } else if (skin === 'cyber_robot') {
      // Cyber Metallic Robot
      ctx.fillStyle = '#475569';
      ctx.fillRect(0, 0, 16, 16);
      ctx.fillStyle = '#06b6d4'; // Cyan glowing visor
      ctx.fillRect(2, 5, 12, 3);
      ctx.fillStyle = '#64748b';
      ctx.fillRect(6, 11, 4, 2);
    } else if (skin === 'business_cat') {
      // Calico Cat
      ctx.fillStyle = '#f97316';
      ctx.fillRect(0, 0, 16, 16);
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(0, 8, 16, 8);
      ctx.fillStyle = '#10b981'; // Green cat eyes
      ctx.fillRect(3, 5, 3, 2);
      ctx.fillRect(10, 5, 3, 2);
      ctx.fillStyle = '#ec4899'; // Pink nose
      ctx.fillRect(7, 8, 2, 1);
    } else if (skin === 'pumpkin_suit') {
      // Halloween Pumpkin / Jack-o-Lantern Face
      ctx.fillStyle = '#ea580c';
      ctx.fillRect(0, 0, 16, 16);
      ctx.fillStyle = '#15803d'; // Stem at top
      ctx.fillRect(6, 0, 4, 2);
      ctx.fillStyle = '#0f172a'; // Carved triangle eyes & mouth
      ctx.fillRect(3, 5, 3, 3);
      ctx.fillRect(10, 5, 3, 3);
      ctx.fillRect(7, 8, 2, 2);
      ctx.fillRect(3, 11, 10, 3);
      ctx.fillStyle = '#fef08a'; // Glowing yellow inside
      ctx.fillRect(4, 6, 1, 1);
      ctx.fillRect(11, 6, 1, 1);
      ctx.fillRect(4, 12, 8, 1);
    } else if (skin === 'wizard_robe') {
      // Sorcerer / Wizard face with starry hat trim
      ctx.fillStyle = '#fde047';
      ctx.fillRect(0, 0, 16, 16);
      ctx.fillStyle = '#581c87'; // Purple hat rim
      ctx.fillRect(0, 0, 16, 4);
      ctx.fillStyle = '#eab308'; // Gold stars
      ctx.fillRect(2, 1, 2, 2);
      ctx.fillRect(12, 1, 2, 2);
      ctx.fillStyle = '#0f172a'; // Wise eyes & long white beard
      ctx.fillRect(3, 6, 2, 2);
      ctx.fillRect(11, 6, 2, 2);
      ctx.fillStyle = '#ffffff'; // Long beard
      ctx.fillRect(4, 9, 8, 7);
    } else if (skin === 'vampire_suit') {
      // Dracula Vampire Face
      ctx.fillStyle = '#e2e8f0'; // Pale skin
      ctx.fillRect(0, 0, 16, 16);
      ctx.fillStyle = '#0f172a'; // Widow's peak hair
      ctx.fillRect(0, 0, 16, 4);
      ctx.fillRect(7, 4, 2, 2);
      ctx.fillStyle = '#dc2626'; // Glowing red eyes
      ctx.fillRect(3, 6, 3, 2);
      ctx.fillRect(10, 6, 3, 2);
      ctx.fillStyle = '#0f172a'; // Smirk
      ctx.fillRect(6, 11, 4, 1);
      ctx.fillStyle = '#ffffff'; // Vampire fangs
      ctx.fillRect(6, 12, 1, 2);
      ctx.fillRect(9, 12, 1, 2);
    } else if (skin === 'superhero_suit') {
      // Superhero Heroic Mask
      ctx.fillStyle = '#fed7aa';
      ctx.fillRect(0, 0, 16, 16);
      ctx.fillStyle = '#1e3a8a'; // Blue domino mask
      ctx.fillRect(1, 4, 14, 5);
      ctx.fillStyle = '#ffffff'; // Glowing white eyes
      ctx.fillRect(3, 5, 3, 2);
      ctx.fillRect(10, 5, 3, 2);
      ctx.fillStyle = '#ea580c'; // Confident smile
      ctx.fillRect(6, 11, 4, 1);
    } else if (skin === 'cosplay_astronaut') {
      // Astronaut Gold Visor Helmet
      ctx.fillStyle = '#cbd5e1';
      ctx.fillRect(0, 0, 16, 16);
      ctx.fillStyle = '#fbbf24'; // Golden reflective visor
      ctx.fillRect(2, 3, 12, 8);
      ctx.fillStyle = '#ffffff'; // Reflection glare
      ctx.fillRect(3, 4, 2, 2);
    }
  });
}

// Side and back head texture (NO face eyes/mouth) so head has ONLY ONE face
export function getAvatarSideHeadTexture(skin: AvatarSkin): THREE.CanvasTexture {
  if (skin === 'college_dev_f') {
    return createSmoothCanvasTexture(256, 256, (ctx) => {
      // Sleek pulled-back dark chestnut hair for female dev
      ctx.fillStyle = '#24140a';
      ctx.fillRect(0, 0, 256, 256);

      // Hair strand flow lines towards high ponytail
      ctx.strokeStyle = '#3e2212';
      ctx.lineWidth = 4;
      for (let y = 30; y < 240; y += 22) {
        ctx.beginPath();
        ctx.moveTo(10, y);
        ctx.quadraticCurveTo(128, y - 20, 246, 60);
        ctx.stroke();
      }

      // Soft skin tone near ear/temple
      const earSkin = ctx.createRadialGradient(70, 160, 5, 70, 160, 45);
      earSkin.addColorStop(0, '#fcd4c0');
      earSkin.addColorStop(1, 'rgba(252, 212, 192, 0)');
      ctx.fillStyle = earSkin;
      ctx.beginPath(); ctx.arc(70, 160, 45, 0, Math.PI * 2); ctx.fill();

      // Delicate sculpted ear with pearl stud
      ctx.fillStyle = '#f8be9e';
      ctx.beginPath();
      ctx.ellipse(70, 160, 18, 28, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = '#d97d52';
      ctx.lineWidth = 3;
      ctx.stroke();

      // Pearl earring stud gleam
      ctx.fillStyle = '#ffffff';
      ctx.beginPath();
      ctx.arc(70, 178, 5, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = 'rgba(255, 255, 255, 0.8)';
      ctx.beginPath();
      ctx.arc(69, 177, 2, 0, Math.PI * 2);
      ctx.fill();
    });
  }

  if (skin === 'college_dev_m' || skin === 'human_dev') {
    return createSmoothCanvasTexture(256, 256, (ctx) => {
      // Natural dark layered hair for male dev
      ctx.fillStyle = '#1c120c';
      ctx.fillRect(0, 0, 256, 256);

      // Hair strands and volume highlights
      ctx.strokeStyle = '#321d10';
      ctx.lineWidth = 5;
      for (let y = 20; y < 200; y += 24) {
        ctx.beginPath();
        ctx.moveTo(10, y);
        ctx.quadraticCurveTo(128, y + 10, 246, y - 10);
        ctx.stroke();
      }

      // Sideburns and skin tone near ear
      const earSkin = ctx.createRadialGradient(75, 160, 10, 75, 160, 50);
      earSkin.addColorStop(0, '#fbc396');
      earSkin.addColorStop(1, 'rgba(251, 195, 150, 0)');
      ctx.fillStyle = earSkin;
      ctx.beginPath(); ctx.arc(75, 160, 50, 0, Math.PI * 2); ctx.fill();

      // Sculpted ear
      ctx.fillStyle = '#f4a974';
      ctx.beginPath();
      ctx.ellipse(75, 160, 20, 32, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = '#c67848';
      ctx.lineWidth = 3.5;
      ctx.stroke();
    });
  }

  return createPixelCanvasTexture(16, 16, (ctx) => {
    if (skin === 'fox_suit') {
      ctx.fillStyle = '#ea580c';
      ctx.fillRect(0, 0, 16, 16);
      ctx.fillStyle = '#7c2d12';
      ctx.fillRect(2, 0, 12, 3);
    } else if (skin === 'zombie_suit') {
      ctx.fillStyle = '#416335';
      ctx.fillRect(0, 0, 16, 16);
    } else if (skin === 'skeleton_suit') {
      ctx.fillStyle = '#e2e8f0';
      ctx.fillRect(0, 0, 16, 16);
    } else if (skin === 'villager_suit') {
      ctx.fillStyle = '#b48160';
      ctx.fillRect(0, 0, 16, 16);
      ctx.fillStyle = '#2d1810';
      ctx.fillRect(0, 0, 16, 3);
    } else if (skin === 'executive_bear') {
      ctx.fillStyle = '#78350f';
      ctx.fillRect(0, 0, 16, 16);
    } else if (skin === 'cyber_robot') {
      ctx.fillStyle = '#475569';
      ctx.fillRect(0, 0, 16, 16);
      ctx.fillStyle = '#334155';
      ctx.fillRect(0, 6, 16, 2);
    } else if (skin === 'business_cat') {
      ctx.fillStyle = '#f97316';
      ctx.fillRect(0, 0, 16, 16);
    } else {
      ctx.fillStyle = '#451a03';
      ctx.fillRect(0, 0, 16, 16);
    }
  });
}

// 8. Suit / Hoodie Outfit Texture
export function getSuitTexture(skin: AvatarSkin): THREE.CanvasTexture {
  if (skin === 'college_dev_f') {
    // High-Definition Electric Cyan & Magenta Pink Indie Hoodie
    return createSmoothCanvasTexture(256, 256, (ctx) => {
      // 1. Electric Cyan Base Gradient
      const cyanGrad = ctx.createLinearGradient(0, 0, 0, 256);
      cyanGrad.addColorStop(0, '#06b6d4');
      cyanGrad.addColorStop(0.5, '#0891b2');
      cyanGrad.addColorStop(1, '#0e7490');
      ctx.fillStyle = cyanGrad;
      ctx.fillRect(0, 0, 256, 256);

      // 2. Magenta Pink Collar & Inner Hood Trim
      ctx.fillStyle = '#ec4899';
      ctx.beginPath();
      ctx.moveTo(40, 0);
      ctx.lineTo(216, 0);
      ctx.quadraticCurveTo(128, 42, 40, 0);
      ctx.closePath();
      ctx.fill();

      // Inner hood depth shadow
      ctx.fillStyle = '#be185d';
      ctx.beginPath();
      ctx.moveTo(60, 0);
      ctx.lineTo(196, 0);
      ctx.quadraticCurveTo(128, 30, 60, 0);
      ctx.closePath();
      ctx.fill();

      // 3. Pink & White Drawstring Cords & Chrome Eyelets
      ctx.fillStyle = '#ffffff';
      ctx.beginPath(); ctx.arc(80, 36, 4.5, 0, Math.PI * 2); ctx.fill();
      ctx.beginPath(); ctx.arc(176, 36, 4.5, 0, Math.PI * 2); ctx.fill();

      // Drawstring Cords (Pink with white accents)
      ctx.strokeStyle = '#f472b6';
      ctx.lineWidth = 4;
      ctx.lineCap = 'round';

      ctx.beginPath();
      ctx.moveTo(80, 38);
      ctx.quadraticCurveTo(85, 80, 78, 122);
      ctx.stroke();

      ctx.beginPath();
      ctx.moveTo(176, 38);
      ctx.quadraticCurveTo(171, 80, 178, 122);
      ctx.stroke();

      // Chrome Aglet Tips
      ctx.fillStyle = '#f8fafc';
      ctx.fillRect(75, 118, 6, 12);
      ctx.fillRect(175, 118, 6, 12);

      // 4. Center Indie Minimalist Graphic / Pink Heart & Wave Emblem
      ctx.fillStyle = '#fbcfe8';
      ctx.beginPath();
      ctx.roundRect(96, 75, 64, 28, 8);
      ctx.fill();

      ctx.fillStyle = '#db2777';
      ctx.font = 'bold 15px sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('⚡ DEV', 128, 94);

      // 5. Kangaroo Pouch Pocket with Pink Top Trim
      ctx.fillStyle = '#0891b2';
      ctx.beginPath();
      ctx.moveTo(35, 168);
      ctx.lineTo(80, 148);
      ctx.lineTo(176, 148);
      ctx.lineTo(221, 168);
      ctx.lineTo(221, 225);
      ctx.lineTo(35, 225);
      ctx.closePath();
      ctx.fill();

      // Pink Pocket Trim
      ctx.strokeStyle = '#ec4899';
      ctx.lineWidth = 3.5;
      ctx.beginPath();
      ctx.moveTo(35, 168);
      ctx.lineTo(80, 148);
      ctx.lineTo(176, 148);
      ctx.lineTo(221, 168);
      ctx.stroke();

      // 6. Elastic Ribbed Waistband Hem
      ctx.fillStyle = '#0e7490';
      ctx.fillRect(0, 228, 256, 28);
      ctx.fillStyle = '#ec4899';
      ctx.fillRect(0, 226, 256, 3);
      for (let x = 4; x < 256; x += 8) {
        ctx.fillStyle = '#155e75';
        ctx.fillRect(x, 228, 2, 28);
      }
    });
  }

  if (skin === 'college_dev_m' || skin === 'human_dev') {
    // High-Definition Warm Sunset Orange Indie Developer Hoodie
    return createSmoothCanvasTexture(256, 256, (ctx) => {
      // 1. Rich Warm Vibrant Orange Base
      const orangeGrad = ctx.createLinearGradient(0, 0, 0, 256);
      orangeGrad.addColorStop(0, '#f97316');
      orangeGrad.addColorStop(0.5, '#ea580c');
      orangeGrad.addColorStop(1, '#c2410c');
      ctx.fillStyle = orangeGrad;
      ctx.fillRect(0, 0, 256, 256);

      // 2. Collar & Neckline Trim with inner shadow
      ctx.fillStyle = '#9a3412';
      ctx.beginPath();
      ctx.moveTo(40, 0);
      ctx.lineTo(216, 0);
      ctx.quadraticCurveTo(128, 40, 40, 0);
      ctx.closePath();
      ctx.fill();

      // 3. Crisp White Collegiate / Indie Emblem: "SF // DEV"
      ctx.save();
      ctx.fillStyle = '#ffffff';
      ctx.textAlign = 'center';
      ctx.font = '900 24px system-ui, -apple-system, sans-serif';
      ctx.fillText('IDLE LAB', 128, 76);

      ctx.fillStyle = '#ffedd5';
      ctx.font = 'bold 13px monospace';
      ctx.fillText('// SF BAY DEV //', 128, 96);
      ctx.restore();

      // 4. White Hoodie Drawstring Cords & Eyelets
      ctx.fillStyle = '#ffffff';
      ctx.beginPath(); ctx.arc(80, 34, 4.5, 0, Math.PI * 2); ctx.fill();
      ctx.beginPath(); ctx.arc(176, 34, 4.5, 0, Math.PI * 2); ctx.fill();

      // Drawstring Cords
      ctx.strokeStyle = '#ffffff';
      ctx.lineWidth = 4;
      ctx.lineCap = 'round';

      ctx.beginPath();
      ctx.moveTo(80, 36);
      ctx.quadraticCurveTo(85, 80, 78, 122);
      ctx.stroke();

      ctx.beginPath();
      ctx.moveTo(176, 36);
      ctx.quadraticCurveTo(171, 80, 178, 122);
      ctx.stroke();

      // Metallic Silver Aglet Tips
      ctx.fillStyle = '#cbd5e1';
      ctx.fillRect(75, 118, 6, 12);
      ctx.fillRect(175, 118, 6, 12);

      // 5. Kangaroo Pouch Pocket
      ctx.fillStyle = '#c2410c';
      ctx.beginPath();
      ctx.moveTo(35, 168);
      ctx.lineTo(80, 148);
      ctx.lineTo(176, 148);
      ctx.lineTo(221, 168);
      ctx.lineTo(221, 225);
      ctx.lineTo(35, 225);
      ctx.closePath();
      ctx.fill();

      ctx.strokeStyle = '#9a3412';
      ctx.lineWidth = 2.5;
      ctx.stroke();

      // 6. Elastic Ribbed Waistband Hem
      ctx.fillStyle = '#9a3412';
      ctx.fillRect(0, 228, 256, 28);
      for (let x = 4; x < 256; x += 8) {
        ctx.fillStyle = '#7c2d12';
        ctx.fillRect(x, 228, 2, 28);
      }
    });
  }

  return createPixelCanvasTexture(16, 16, (ctx) => {
    if (skin === 'pumpkin_suit') {
      // Pumpkin / Jack-o-Lantern Cosplay Suit
      ctx.fillStyle = '#f97316';
      ctx.fillRect(0, 0, 16, 16);
      ctx.fillStyle = '#15803d'; // Green leaf collar & belt
      ctx.fillRect(0, 0, 16, 3);
      ctx.fillRect(0, 12, 16, 2);
      ctx.fillStyle = '#0f172a'; // Pumpkin ribs
      ctx.fillRect(4, 3, 1, 9);
      ctx.fillRect(8, 3, 1, 9);
      ctx.fillRect(12, 3, 1, 9);
      return;
    } else if (skin === 'wizard_robe') {
      // Sorcerer Wizard Starry Robe
      ctx.fillStyle = '#581c87';
      ctx.fillRect(0, 0, 16, 16);
      ctx.fillStyle = '#eab308'; // Gold trim & magic stars
      ctx.fillRect(0, 0, 16, 2);
      ctx.fillRect(7, 2, 2, 14);
      ctx.fillRect(3, 5, 2, 2);
      ctx.fillRect(11, 8, 2, 2);
      return;
    } else if (skin === 'vampire_suit') {
      // Dracula Vampire Tuxedo with Crimson Vest
      ctx.fillStyle = '#0f172a';
      ctx.fillRect(0, 0, 16, 16);
      ctx.fillStyle = '#991b1b'; // Red satin vest
      ctx.beginPath();
      ctx.moveTo(5, 0); ctx.lineTo(11, 0); ctx.lineTo(8, 12);
      ctx.closePath();
      ctx.fill();
      ctx.fillStyle = '#ffffff'; // White high collar V
      ctx.fillRect(6, 0, 4, 3);
      ctx.fillStyle = '#eab308'; // Gold Vampire medallion
      ctx.fillRect(7, 4, 2, 2);
      return;
    } else if (skin === 'superhero_suit') {
      // Superhero Suit with Emblem & Cape
      ctx.fillStyle = '#1e3a8a';
      ctx.fillRect(0, 0, 16, 16);
      ctx.fillStyle = '#dc2626'; // Red chest plate & shoulders
      ctx.fillRect(0, 0, 16, 4);
      ctx.fillStyle = '#eab308'; // Gold crest logo
      ctx.beginPath();
      ctx.moveTo(8, 5); ctx.lineTo(12, 8); ctx.lineTo(8, 11); ctx.lineTo(4, 8);
      ctx.closePath();
      ctx.fill();
      return;
    } else if (skin === 'cosplay_astronaut') {
      // NASA Astronaut Spacesuit
      ctx.fillStyle = '#f8fafc';
      ctx.fillRect(0, 0, 16, 16);
      ctx.fillStyle = '#0284c7'; // Blue NASA chest patch
      ctx.fillRect(3, 4, 4, 3);
      ctx.fillStyle = '#dc2626'; // Mission badge stripe
      ctx.fillRect(10, 4, 3, 3);
      ctx.fillStyle = '#334155'; // Utility belt & harness
      ctx.fillRect(0, 10, 16, 2);
      return;
    }

    // Formal Suit jacket colors for corporate skins
    let jacketColor = '#1e3a8a'; // Dark blue suit
    let tieColor = '#dc2626';    // Red tie

    if (skin === 'fox_suit') {
      jacketColor = '#14532d'; // Forest green suit
      tieColor = '#f59e0b';
    } else if (skin === 'zombie_suit') {
      jacketColor = '#1e1b4b'; // Deep purple/indigo suit
      tieColor = '#06b6d4';
    } else if (skin === 'skeleton_suit') {
      jacketColor = '#0f172a'; // Black tuxedo
      tieColor = '#e2e8f0';
    } else if (skin === 'villager_suit') {
      jacketColor = '#451a03'; // Dark brown suit
      tieColor = '#dc2626';
    } else if (skin === 'cyber_robot') {
      jacketColor = '#0284c7';
      tieColor = '#38bdf8';
    }

    ctx.fillStyle = jacketColor;
    ctx.fillRect(0, 0, 16, 16);

    // White dress shirt collar V-neck
    ctx.fillStyle = '#ffffff';
    ctx.beginPath();
    ctx.moveTo(5, 0);
    ctx.lineTo(11, 0);
    ctx.lineTo(8, 7);
    ctx.closePath();
    ctx.fill();

    // Tie
    ctx.fillStyle = tieColor;
    ctx.fillRect(7, 2, 2, 8);
    ctx.beginPath();
    ctx.moveTo(7, 10);
    ctx.lineTo(9, 10);
    ctx.lineTo(8, 12);
    ctx.closePath();
    ctx.fill();

    // Suit buttons
    ctx.fillStyle = '#e2e8f0';
    ctx.fillRect(8, 13, 1, 1);
  });
}

// Fine Art Painting Canvas Textures (Mona Lisa, Starry Night, Great Wave, Girl with Pearl Earring)
export function getFineArtTexture(artType: 'mona_lisa' | 'starry_night' | 'great_wave' | 'pearl_earring'): THREE.CanvasTexture {
  return createPixelCanvasTexture(32, 40, (ctx) => {
    if (artType === 'mona_lisa') {
      // Mona Lisa by Leonardo da Vinci
      ctx.fillStyle = '#2d3a28';
      ctx.fillRect(0, 0, 32, 40);
      ctx.fillStyle = '#3a4b35';
      ctx.fillRect(0, 10, 32, 12);
      ctx.fillStyle = '#1c2818';
      ctx.fillRect(0, 0, 10, 22);

      // Hair & Veil
      ctx.fillStyle = '#1c1917';
      ctx.beginPath();
      ctx.arc(16, 18, 9, 0, Math.PI * 2);
      ctx.fill();

      // Face skin tone
      ctx.fillStyle = '#e2b887';
      ctx.fillRect(12, 14, 8, 10);

      // Eyes & Mysterious Smile
      ctx.fillStyle = '#44281d';
      ctx.fillRect(13, 17, 2, 1);
      ctx.fillRect(17, 17, 2, 1);
      ctx.fillRect(14, 21, 4, 1);

      // Dress & Golden neckline
      ctx.fillStyle = '#3f311c';
      ctx.fillRect(8, 22, 16, 18);
      ctx.fillStyle = '#d97706';
      ctx.fillRect(11, 22, 10, 4);
      ctx.fillStyle = '#291e0e';
      ctx.fillRect(6, 26, 20, 14);
    } else if (artType === 'starry_night') {
      // Starry Night by Vincent van Gogh
      ctx.fillStyle = '#1e3a8a';
      ctx.fillRect(0, 0, 32, 40);
      ctx.fillStyle = '#1d4ed8';
      ctx.fillRect(0, 0, 32, 24);

      // Swirls & Moon
      ctx.fillStyle = '#60a5fa';
      ctx.fillRect(6, 6, 20, 4);
      ctx.fillRect(10, 10, 16, 4);
      ctx.fillStyle = '#fde047';
      ctx.fillRect(24, 4, 5, 5);
      ctx.fillRect(4, 4, 3, 3);
      ctx.fillRect(12, 4, 3, 3);

      // Cypress tree
      ctx.fillStyle = '#064e3b';
      ctx.beginPath();
      ctx.moveTo(4, 40);
      ctx.lineTo(8, 12);
      ctx.lineTo(12, 40);
      ctx.fill();

      // Village
      ctx.fillStyle = '#0f172a';
      ctx.fillRect(0, 26, 32, 14);
    } else if (artType === 'great_wave') {
      // The Great Wave off Kanagawa by Hokusai
      ctx.fillStyle = '#fef3c7';
      ctx.fillRect(0, 0, 32, 40);

      // Mount Fuji
      ctx.fillStyle = '#1e293b';
      ctx.beginPath();
      ctx.moveTo(12, 32);
      ctx.lineTo(16, 24);
      ctx.lineTo(20, 32);
      ctx.fill();
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(15, 24, 2, 2);

      // Great Wave
      ctx.fillStyle = '#1e40af';
      ctx.beginPath();
      ctx.moveTo(0, 40);
      ctx.quadraticCurveTo(20, 35, 28, 10);
      ctx.quadraticCurveTo(22, 18, 0, 28);
      ctx.fill();

      // White foam
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(26, 8, 4, 4);
      ctx.fillRect(22, 12, 4, 3);
    } else {
      // Girl with a Pearl Earring by Johannes Vermeer
      ctx.fillStyle = '#09090b';
      ctx.fillRect(0, 0, 32, 40);

      // Blue & Yellow Turban
      ctx.fillStyle = '#1d4ed8';
      ctx.fillRect(10, 8, 14, 8);
      ctx.fillStyle = '#eab308';
      ctx.fillRect(18, 12, 6, 12);

      // Face
      ctx.fillStyle = '#fde047';
      ctx.fillRect(12, 14, 8, 10);

      // Pearl Earring
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(11, 23, 3, 3);

      // Coat
      ctx.fillStyle = '#78350f';
      ctx.fillRect(8, 24, 16, 16);
    }
  });
}
