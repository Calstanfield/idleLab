import * as THREE from 'three';

export interface LofiSceneryController {
  sceneryGroup: THREE.Group;
  updateLofiScenery: (time: number, delta: number) => void;
}

interface AmazonDrone {
  mesh: THREE.Group;
  propellers: THREE.Mesh[];
  startX: number;
  endX: number;
  altitude: number;
  speed: number;
  zPos: number;
  bobOffset: number;
}

export function buildLofiScenery(sceneGroup: THREE.Group): LofiSceneryController {
  const sceneryGroup = new THREE.Group();
  sceneryGroup.name = 'Lofi3FOutsideScenery';

  // 1. AMAZON FOOD DELIVERY DRONES FLYING OUTSIDE OVER THE GOLDEN GATE BRIDGE
  const drones: AmazonDrone[] = [];
  const droneMat = new THREE.MeshStandardMaterial({ color: 0x1e293b, metalness: 0.8, roughness: 0.2 });
  const amazonPrimeMat = new THREE.MeshStandardMaterial({ color: 0xf59e0b, emissive: 0xd97706, emissiveIntensity: 0.8 }); // Amazon Prime Orange
  const foodBoxMat = new THREE.MeshStandardMaterial({ color: 0xd97706, roughness: 0.7 }); // Cardboard delivery box
  const propMat = new THREE.MeshStandardMaterial({ color: 0x94a3b8, metalness: 0.9, roughness: 0.1 });
  const ledLightMat = new THREE.MeshStandardMaterial({ color: 0x22c55e, emissive: 0x22c55e, emissiveIntensity: 1.0 });

  // Spawn 5 Amazon Delivery Drones at varying altitudes and speeds
  for (let i = 0; i < 5; i++) {
    const droneGroup = new THREE.Group();

    // Quadcopter Body
    const body = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.15, 0.5), droneMat);
    body.position.y = 0;

    // Amazon Prime Logo Stripe
    const logoStripe = new THREE.Mesh(new THREE.BoxGeometry(0.52, 0.08, 0.2), amazonPrimeMat);
    logoStripe.position.y = 0.02;

    // 4 Quadcopter Arms
    const armMat = new THREE.MeshStandardMaterial({ color: 0x475569 });
    const arm1 = new THREE.Mesh(new THREE.BoxGeometry(1.2, 0.05, 0.08), armMat);
    arm1.rotation.y = Math.PI / 4;
    const arm2 = new THREE.Mesh(new THREE.BoxGeometry(1.2, 0.05, 0.08), armMat);
    arm2.rotation.y = -Math.PI / 4;

    // 4 Spinning Propellers
    const propellers: THREE.Mesh[] = [];
    const propOffsets = [
      { x: -0.42, z: -0.42 },
      { x: 0.42, z: -0.42 },
      { x: -0.42, z: 0.42 },
      { x: 0.42, z: 0.42 },
    ];

    propOffsets.forEach((po) => {
      const motor = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.06, 0.1, 8), droneMat);
      motor.position.set(po.x, 0.05, po.z);

      const prop = new THREE.Mesh(new THREE.BoxGeometry(0.35, 0.01, 0.04), propMat);
      prop.position.set(po.x, 0.11, po.z);

      // Green LED light
      const led = new THREE.Mesh(new THREE.SphereGeometry(0.03, 6, 6), ledLightMat);
      led.position.set(po.x, -0.06, po.z);

      droneGroup.add(motor, prop, led);
      propellers.push(prop);
    });

    // Hanging Amazon Food Delivery Box / Paper Bag
    const packageCable = new THREE.Mesh(new THREE.CylinderGeometry(0.008, 0.008, 0.6, 6), armMat);
    packageCable.position.y = -0.3;

    const foodBox = new THREE.Mesh(new THREE.BoxGeometry(0.35, 0.3, 0.28), foodBoxMat);
    foodBox.position.y = -0.65;

    // Smile Logo on box
    const smileBadge = new THREE.Mesh(new THREE.BoxGeometry(0.2, 0.1, 0.02), amazonPrimeMat);
    smileBadge.position.set(0, -0.65, 0.15);

    droneGroup.add(body, logoStripe, arm1, arm2, packageCable, foodBox, smileBadge);

    // Initial position outside window
    const alt = 12.5 + (i % 3) * 1.8;
    const zPos = -12 + i * 5.0;
    const speed = 2.5 + Math.random() * 1.5;

    droneGroup.position.set(-16.0, alt, zPos);
    sceneryGroup.add(droneGroup);

    drones.push({
      mesh: droneGroup,
      propellers,
      startX: -18,
      endX: 18,
      altitude: alt,
      speed,
      zPos,
      bobOffset: i * 1.2,
    });
  }

  sceneGroup.add(sceneryGroup);

  return {
    sceneryGroup,
    updateLofiScenery: (time: number, delta: number) => {
      // Animate Amazon Delivery Drones flying across the sunset sky
      drones.forEach((d) => {
        // Fly along Z-axis outside window
        d.mesh.position.z += d.speed * delta;

        // Hover bobbing motion
        d.mesh.position.y = d.altitude + Math.sin(time * 3 + d.bobOffset) * 0.15;
        d.mesh.rotation.z = Math.sin(time * 2 + d.bobOffset) * 0.05;

        // Spin Propellers fast
        d.propellers.forEach((p) => {
          p.rotation.y += delta * 25.0;
        });

        // Loop back
        if (d.mesh.position.z > 16) {
          d.mesh.position.z = -16;
        }
      });
    },
  };
}
