import * as THREE from 'three';
import { UserState, GestureType, AvatarSkin, ScooterConfig } from '../types';
import { getAvatarFaceTexture, getAvatarSideHeadTexture, getSuitTexture } from './voxelTextures';
import { createScooterMesh, ScooterMeshGroup } from './scooterBuilder';

export interface AvatarMeshGroup {
  group: THREE.Group;
  headMesh: THREE.Mesh | THREE.Group;
  leftArmMesh: THREE.Mesh | THREE.Group;
  rightArmMesh: THREE.Mesh | THREE.Group;
  leftForearmMesh?: THREE.Group;
  rightForearmMesh?: THREE.Group;
  leftUpperArmMesh?: THREE.Group;
  rightUpperArmMesh?: THREE.Group;
  leftLegMesh: THREE.Mesh | THREE.Group;
  rightLegMesh: THREE.Mesh | THREE.Group;
  leftShinMesh?: THREE.Group;
  rightShinMesh?: THREE.Group;
  leftThighMesh?: THREE.Group;
  rightThighMesh?: THREE.Group;
  paddleMesh: THREE.Group;
  tennisRacquetMesh: THREE.Group;
  scooterMeshGroup?: ScooterMeshGroup;
  speechBubbleSprite: THREE.Sprite | null;
  audioWaveMesh: THREE.Mesh;
  badgeSprite: THREE.Sprite;
  videoScreenMesh: THREE.Mesh;
  videoScreenGroup: THREE.Group;
  setVideoTexture: (texture: THREE.Texture | null) => void;
  setScreenHovered: (hovered: boolean) => void;
  updateScooterColors?: (config: ScooterConfig) => void;
  updateAnimation: (
    time: number,
    isMoving: boolean,
    isAtPingPongTable?: boolean,
    isSeated?: boolean,
    isAtTennisCourt?: boolean,
    isSwingingTennis?: boolean,
    smashType?: 'forehand' | 'backhand' | 'smash',
    isSpeaking?: boolean,
    lookTargetPos?: { x: number; y: number; z: number },
    isRidingScooter?: boolean,
    scooterTurnAngle?: number,
    scooterSpeed?: number,
    dt?: number
  ) => void;
  updateBadge: (user: UserState) => void;
  showSpeechBubble: (text: string) => void;
  triggerGesture: (gesture: GestureType, durationMs?: number) => void;
  triggerEmojiParticle: (emoji: string) => void;
  triggerTennisSwing: (type?: 'forehand' | 'backhand' | 'smash') => void;
}

// Diverse Pixar Hair Color Palette representing San Francisco American Demographics
export interface HairPaletteEntry {
  name: string;
  main: number;
  highlight: number;
}

const SF_HAIR_PALETTE: HairPaletteEntry[] = [
  { name: 'Jet Espresso', main: 0x0f0f11, highlight: 0x27272a },
  { name: 'Dark Chestnut', main: 0x1c120c, highlight: 0x3d2010 },
  { name: 'Honey Brunette', main: 0x2b1810, highlight: 0x54331e },
  { name: 'Caramel Brown', main: 0x5c2b0e, highlight: 0x854317 },
  { name: 'Golden Blonde', main: 0xc89849, highlight: 0xfde047 },
  { name: 'Strawberry Blonde', main: 0xbd623c, highlight: 0xea7a4f },
  { name: 'Auburn Copper', main: 0x882e10, highlight: 0xc2410c },
  { name: 'Pastel Lilac Tech', main: 0x9333ea, highlight: 0xd8b4fe },
  { name: 'Cyber Rose Tech', main: 0xdb2777, highlight: 0xf472b6 },
  { name: 'Platinum Silver', main: 0x94a3b8, highlight: 0xf1f5f9 },
];

// Authentic San Francisco American Demographics Skin Tone Palette
// (Representing Asian American, Caucasian, Hispanic/Latino, South Asian, African American, and Multiracial)
export interface DemographicsSkinTone {
  id: string;
  name: string;
  skinColor: number;
  lipColor: number;
  irisColor: number;
}

const SF_DEMOGRAPHICS_SKIN_TONES: DemographicsSkinTone[] = [
  // 1. East Asian / Southeast Asian American (Warm Peach Ivory)
  { id: 'east_asian_1', name: 'Fair Ivory Peach', skinColor: 0xfde2cd, lipColor: 0xf43f5e, irisColor: 0x27170c },
  // 2. East Asian / Filipino American (Warm Golden Beige)
  { id: 'east_asian_2', name: 'Golden Beige', skinColor: 0xf6cb9e, lipColor: 0xe11d48, irisColor: 0x1f140e },
  // 3. Caucasian / European American (Porcelain Rose)
  { id: 'caucasian_1', name: 'Porcelain Rose', skinColor: 0xffd8c9, lipColor: 0xf43f5e, irisColor: 0x0284c7 },
  // 4. Caucasian / European American (Warm Sand Beige)
  { id: 'caucasian_2', name: 'Warm Sand', skinColor: 0xf5c3a3, lipColor: 0xdb2777, irisColor: 0x15803d },
  // 5. Hispanic / Latino American (Golden Olive)
  { id: 'latino_1', name: 'Golden Olive', skinColor: 0xe2a26f, lipColor: 0xbe123c, irisColor: 0x451a03 },
  // 6. Hispanic / Latino American (Warm Honey Tan)
  { id: 'latino_2', name: 'Warm Honey Tan', skinColor: 0xc67f4b, lipColor: 0xb91c1c, irisColor: 0x27170c },
  // 7. South Asian American (Warm Caramel)
  { id: 'south_asian_1', name: 'Warm Caramel', skinColor: 0xb06c3b, lipColor: 0x9f1239, irisColor: 0x170d06 },
  // 8. South Asian American (Deep Cinnamon)
  { id: 'south_asian_2', name: 'Deep Cinnamon', skinColor: 0x884920, lipColor: 0x881337, irisColor: 0x0f0702 },
  // 9. African American / Black (Rich Bronze Espresso)
  { id: 'black_1', name: 'Rich Bronze', skinColor: 0x603417, lipColor: 0x7c2d12, irisColor: 0x1a0d05 },
  // 10. African American / Black (Deep Obsidian Cocoa)
  { id: 'black_2', name: 'Deep Obsidian Cocoa', skinColor: 0x3c1e0c, lipColor: 0x581c0c, irisColor: 0x0f0702 },
  // 11. Multiracial / Pacific Islander (Amber Tan)
  { id: 'mixed_1', name: 'Amber Tan', skinColor: 0xd9945c, lipColor: 0xbe185d, irisColor: 0x381806 },
];

function getCharacterSkinAndFacialTone(user: UserState, isFemale: boolean): DemographicsSkinTone {
  const rawTone = user.skinTone || user.ethnicity;

  if (rawTone) {
    // 1. Check if rawTone is a hex string (e.g., "#fde2cd" or "0xfde2cd")
    if (typeof rawTone === 'string' && (rawTone.startsWith('#') || rawTone.startsWith('0x'))) {
      const hexStr = rawTone.replace('#', '0x');
      const parsed = parseInt(hexStr, 16);
      if (!isNaN(parsed)) {
        return {
          id: 'custom',
          name: 'Custom User',
          skinColor: parsed,
          lipColor: isFemale ? 0xf43f5e : 0xc26a5a,
          irisColor: 0x451a03,
        };
      }
    }
    if (typeof rawTone === 'number') {
      return {
        id: 'custom',
        name: 'Custom User',
        skinColor: rawTone,
        lipColor: isFemale ? 0xf43f5e : 0xc26a5a,
        irisColor: 0x451a03,
      };
    }

    // 2. Check if matches SF_DEMOGRAPHICS_SKIN_TONES by ID or name
    const match = SF_DEMOGRAPHICS_SKIN_TONES.find(
      (d) =>
        d.id.toLowerCase() === rawTone.toLowerCase() ||
        d.name.toLowerCase().includes(rawTone.toLowerCase()) ||
        rawTone.toLowerCase().includes(d.id.toLowerCase())
    );
    if (match) return match;

    // 3. Fallback map for UI preset IDs
    const presetColors: Record<string, { skin: number; lip: number; iris: number }> = {
      east_asian_1: { skin: 0xfde2cd, lip: 0xf43f5e, iris: 0x27170c },
      east_asian_2: { skin: 0xf6cb9e, lip: 0xe11d48, iris: 0x1f140e },
      caucasian_1: { skin: 0xffd8c9, lip: 0xf43f5e, iris: 0x0284c7 },
      caucasian_2: { skin: 0xf5c3a3, lip: 0xdb2777, iris: 0x15803d },
      latino_1: { skin: 0xe2a26f, lip: 0xbe123c, iris: 0x451a03 },
      latino_2: { skin: 0xc67f4b, lip: 0xb91c1c, iris: 0x27170c },
      south_asian_1: { skin: 0xb06c3b, lip: 0x9f1239, iris: 0x170d06 },
      south_asian_2: { skin: 0x884920, lip: 0x881337, iris: 0x0f0702 },
      black_1: { skin: 0x603417, lip: 0x7c2d12, iris: 0x1a0d05 },
      black_2: { skin: 0x3c1e0c, lip: 0x581c0c, iris: 0x0f0702 },
      mixed_1: { skin: 0xd9945c, lip: 0xbe185d, iris: 0x381806 },
    };
    if (presetColors[rawTone]) {
      return {
        id: rawTone,
        name: rawTone,
        skinColor: presetColors[rawTone].skin,
        lipColor: presetColors[rawTone].lip,
        irisColor: presetColors[rawTone].iris,
      };
    }
  }

  // If specific ethnicity or demographic ID was set
  if (user.ethnicity) {
    const match = SF_DEMOGRAPHICS_SKIN_TONES.find((d) => d.id === user.ethnicity || d.name.toLowerCase().includes(user.ethnicity!.toLowerCase()));
    if (match) return match;
  }

  // If NPC or remote colleague, deterministically assign representative SF demographic
  if (user.id.startsWith('npc_') || user.id.startsWith('bot_') || user.isNPC) {
    let hash = 0;
    const str = user.name + user.id;
    for (let i = 0; i < str.length; i++) {
      hash = (hash << 5) - hash + str.charCodeAt(i);
      hash |= 0;
    }
    const idx = Math.abs(hash) % SF_DEMOGRAPHICS_SKIN_TONES.length;
    return SF_DEMOGRAPHICS_SKIN_TONES[idx];
  }

  // Default Player: Warm natural tone
  return isFemale ? SF_DEMOGRAPHICS_SKIN_TONES[0] : SF_DEMOGRAPHICS_SKIN_TONES[1];
}

function getCharacterHairColor(user: UserState, isFemale: boolean, skinTone: DemographicsSkinTone): HairPaletteEntry {
  // If user explicitly provides hairColor hex
  if (user.hairColor) {
    const parsed = typeof user.hairColor === 'string' && user.hairColor.startsWith('#')
      ? parseInt(user.hairColor.replace('#', '0x'), 16)
      : typeof user.hairColor === 'number'
      ? user.hairColor
      : 0x1c120c;
    return {
      name: 'Custom Hair',
      main: parsed,
      highlight: parsed,
    };
  }

  // If NPC or remote user, assign diverse SF hair palette based on name/demographics
  if (user.id.startsWith('npc_') || user.id.startsWith('bot_') || user.isNPC) {
    let hash = 0;
    const str = user.id + user.name + 'hair';
    for (let i = 0; i < str.length; i++) {
      hash = (hash << 5) - hash + str.charCodeAt(i);
      hash |= 0;
    }
    const idx = Math.abs(hash) % SF_HAIR_PALETTE.length;
    return SF_HAIR_PALETTE[idx];
  }

  // Default main character hair colors
  return isFemale ? SF_HAIR_PALETTE[1] : SF_HAIR_PALETTE[0];
}

export function createVoxelAvatarMesh(user: UserState): AvatarMeshGroup {
  let headphoneAccentMat: THREE.MeshStandardMaterial | null = null;
  const avatarGroup = new THREE.Group();
  avatarGroup.name = `Avatar_${user.id}`;
  avatarGroup.userData = {
    isAvatar: true,
    userId: user.id,
    isNPC: user.isNPC || user.id.startsWith('npc_'),
    name: user.name,
    user: user,
  };

  const faceTex = getAvatarFaceTexture(user.skin);
  const suitTex = getSuitTexture(user.skin);

  // Classification: All human dev styles use full organic Pixar sculpt
  const isFemale = user.skin === 'college_dev_f';
  const isMaleDev = user.skin === 'college_dev_m' || user.skin === 'human_dev';
  const isHumanDev = true;

  // Authentic San Francisco American demographic skin tone & hair color
  const skinInfo = getCharacterSkinAndFacialTone(user, isFemale);
  const skinMat = new THREE.MeshStandardMaterial({
    color: skinInfo.skinColor,
    roughness: 0.44,
    metalness: 0.02,
  });

  // Check if character is Lofi Girl
  const isLofiGirl = user.id === 'npc_lofi_girl' || (user.name && user.name.toLowerCase().includes('lofi'));

  // Customizable Hoodie Color Resolution:
  let resolvedHoodieHex = isFemale ? 0x06b6d4 : 0xea580c;
  if (user.hoodieColor) {
    try {
      resolvedHoodieHex = parseInt(user.hoodieColor.replace('#', '0x'), 16);
    } catch {
      resolvedHoodieHex = isFemale ? 0x06b6d4 : 0xea580c;
    }
  } else if (user.color && user.color.startsWith('#')) {
    try {
      resolvedHoodieHex = parseInt(user.color.replace('#', '0x'), 16);
    } catch {
      resolvedHoodieHex = isFemale ? 0x06b6d4 : 0xea580c;
    }
  }

  // Clothing Color Scheme:
  // Custom or Default Hoodie Mat with polygonOffset to prevent any body/skin clipping
  const customHoodieMat = new THREE.MeshStandardMaterial({
    color: isLofiGirl ? 0x15803d : resolvedHoodieHex,
    roughness: 0.72,
    metalness: 0.02,
    polygonOffset: true,
    polygonOffsetFactor: -1,
    polygonOffsetUnits: -1,
  });
  const orangeHoodieMat = customHoodieMat;
  const cyanHoodieMat = customHoodieMat;
  const greenLofiHoodieMat = new THREE.MeshStandardMaterial({
    color: 0x15803d,
    roughness: 0.72,
    metalness: 0.02,
    polygonOffset: true,
    polygonOffsetFactor: -1,
    polygonOffsetUnits: -1,
  });
  // Custom Scarf Material resolution (Default cozy knitted scarf)
  let parsedScarfColor: number | null = null;
  if (user.scarfColor && user.scarfColor !== 'none' && user.scarfColor !== 'transparent') {
    if (typeof user.scarfColor === 'string' && user.scarfColor.startsWith('#')) {
      const sc = parseInt(user.scarfColor.replace('#', '0x'), 16);
      if (!isNaN(sc)) parsedScarfColor = sc;
    } else if (typeof user.scarfColor === 'number') {
      parsedScarfColor = user.scarfColor;
    }
  } else if (isLofiGirl) {
    parsedScarfColor = 0xdc2626; // Default classic crimson red for lofi girl
  }

  const customScarfMat = parsedScarfColor !== null
    ? new THREE.MeshStandardMaterial({
        color: parsedScarfColor,
        roughness: 0.82,
        metalness: 0.02,
        polygonOffset: true,
        polygonOffsetFactor: -1,
        polygonOffsetUnits: -1,
      })
    : null;
  const redScarfMat = customScarfMat || new THREE.MeshStandardMaterial({
    color: 0xdc2626,
    roughness: 0.85,
    metalness: 0.02,
    polygonOffset: true,
    polygonOffsetFactor: -1,
    polygonOffsetUnits: -1,
  });
  const pinkAccentMat = isFemale && !user.hoodieColor
    ? new THREE.MeshStandardMaterial({
        color: 0xec4899,
        roughness: 0.65,
        metalness: 0.02,
        polygonOffset: true,
        polygonOffsetFactor: -1,
        polygonOffsetUnits: -1,
      })
    : customHoodieMat;
  
  const blueJeansMat = new THREE.MeshStandardMaterial({ color: 0x1d4ed8, roughness: 0.85, metalness: 0.02 });
  const blackJeansMat = new THREE.MeshStandardMaterial({ color: 0x18181b, roughness: 0.78, metalness: 0.02 });
  
  const redSneakerMat = new THREE.MeshStandardMaterial({ color: 0xdc2626, roughness: 0.55, metalness: 0.05 });
  const whiteSneakerMat = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.55, metalness: 0.05 });
  const sneakerRubberMat = new THREE.MeshStandardMaterial({ color: 0xf8fafc, roughness: 0.8, metalness: 0.0 });
  // Custom Baseball Cap Material resolution (Defaults to crisp white)
  let parsedCapColor = 0xffffff;
  if (user.capColor) {
    if (typeof user.capColor === 'string' && user.capColor.startsWith('#')) {
      const c = parseInt(user.capColor.replace('#', '0x'), 16);
      if (!isNaN(c)) parsedCapColor = c;
    } else if (typeof user.capColor === 'number') {
      parsedCapColor = user.capColor;
    }
  }
  const customCapMat = new THREE.MeshStandardMaterial({
    color: parsedCapColor,
    roughness: 0.68,
    metalness: 0.02,
  });

  // Custom Jeans/Pants & Sneakers/Shoes Material resolution
  let parsedPantsColor = isFemale ? 0x18181b : 0x1d4ed8;
  if (user.pantsColor) {
    if (typeof user.pantsColor === 'string' && user.pantsColor.startsWith('#')) {
      const p = parseInt(user.pantsColor.replace('#', '0x'), 16);
      if (!isNaN(p)) parsedPantsColor = p;
    } else if (typeof user.pantsColor === 'number') {
      parsedPantsColor = user.pantsColor;
    }
  }
  const customPantsMat = new THREE.MeshStandardMaterial({
    color: parsedPantsColor,
    roughness: 0.82,
    metalness: 0.02,
  });

  let parsedShoesColor = isFemale ? 0xffffff : 0xdc2626;
  if (user.shoesColor) {
    if (typeof user.shoesColor === 'string' && user.shoesColor.startsWith('#')) {
      const s = parseInt(user.shoesColor.replace('#', '0x'), 16);
      if (!isNaN(s)) parsedShoesColor = s;
    } else if (typeof user.shoesColor === 'number') {
      parsedShoesColor = user.shoesColor;
    }
  }
  const customSneakerMat = new THREE.MeshStandardMaterial({
    color: parsedShoesColor,
    roughness: 0.55,
    metalness: 0.05,
  });

  // Suit material fallback for mascot skins
  const suitMat = customHoodieMat;
  const faceMat = new THREE.MeshStandardMaterial({ map: faceTex, roughness: 0.45 });

  // Hair color selection
  const hairInfo = getCharacterHairColor(user, isFemale, skinInfo);
  const hairMat = new THREE.MeshStandardMaterial({ color: hairInfo.main, roughness: 0.38, metalness: 0.08 });
  const hairHighlightMat = new THREE.MeshStandardMaterial({ color: hairInfo.highlight, roughness: 0.35, metalness: 0.1 });

  // =========================================================================
  // 1. HEAD & PIXAR-INSPIRED FACIAL SCULPT (Smooth Organic Topology, No Voxels)
  // =========================================================================
  const headGroup = new THREE.Group();
  headGroup.position.y = 1.65; // Level aligned with elevated torso
  const eyeGroups: THREE.Group[] = [];
  const browMeshes: THREE.Mesh[] = [];

  if (isHumanDev) {
    // 1a. Cranium / Main Head Sphere (Smooth Organic Proportions)
    const headGeo = new THREE.SphereGeometry(0.34, 32, 24);
    headGeo.scale(0.96, 1.12, 1.04);
    const craniumMesh = new THREE.Mesh(headGeo, skinMat);
    craniumMesh.castShadow = true;
    headGroup.add(craniumMesh);

    // 1b. Soft Contoured Jaw & Chin (Soft organic curves)
    const chinGeo = new THREE.SphereGeometry(0.18, 24, 16);
    chinGeo.scale(0.95, 0.75, 0.95);
    const chinMesh = new THREE.Mesh(chinGeo, skinMat);
    chinMesh.position.set(0, -0.22, 0.1);
    headGroup.add(chinMesh);

    // 1c. Soft Cheekbones & Cheeks
    const cheekGeo = new THREE.SphereGeometry(0.14, 20, 16);
    cheekGeo.scale(0.8, 0.9, 0.8);
    const lCheek = new THREE.Mesh(cheekGeo, skinMat);
    lCheek.position.set(-0.17, -0.07, 0.16);
    const rCheek = new THREE.Mesh(cheekGeo, skinMat);
    rCheek.position.set(0.17, -0.07, 0.16);
    headGroup.add(lCheek, rCheek);

    // 1d. Smooth Organic Neck (Trimmed and contained neatly inside collar)
    const neckGeo = new THREE.CylinderGeometry(0.11, 0.13, 0.24, 24);
    const neckMesh = new THREE.Mesh(neckGeo, skinMat);
    neckMesh.position.set(0, -0.28, -0.02);
    headGroup.add(neckMesh);

    // 1e. Symmetrical Animated Pea-Sized Dark Eyes with Natural Curvature
    const eyeSpacing = isFemale ? 0.125 : 0.13;
    const eyeY = 0.03;
    const eyeZ = 0.315;

    const darkEyeMat = new THREE.MeshStandardMaterial({
      color: 0x111827,
      roughness: 0.2,
      metalness: 0.1,
    });
    const specularHighlightMat = new THREE.MeshBasicMaterial({
      color: 0xffffff,
    });

    [-eyeSpacing, eyeSpacing].forEach((ex, idx) => {
      const isRight = idx === 1;
      const eyeGroup = new THREE.Group();
      eyeGroup.position.set(ex, eyeY, eyeZ);
      // Angle slightly outward so eyes sit naturally along the cranium's sphere surface
      eyeGroup.rotation.y = isRight ? 0.16 : -0.16;
      eyeGroup.rotation.x = -0.04;

      // Small pea-sized dark sphere eye
      const eyeGeo = new THREE.SphereGeometry(0.026, 16, 16);
      eyeGeo.scale(1.0, 1.0, 0.65);
      const eyeMesh = new THREE.Mesh(eyeGeo, darkEyeMat);

      // Specular highlight catchlight
      const catchlightGeo = new THREE.SphereGeometry(0.006, 8, 8);
      const catchlight = new THREE.Mesh(catchlightGeo, specularHighlightMat);
      catchlight.position.set(isRight ? 0.008 : -0.008, 0.008, 0.016);

      eyeGroup.add(eyeMesh, catchlight);
      headGroup.add(eyeGroup);
      eyeGroups.push(eyeGroup);
    });

    // 1f. Sculpted Eyebrows
    const browMat = new THREE.MeshStandardMaterial({ color: hairInfo.main, roughness: 0.6 });
    [-0.13, 0.13].forEach((bx, idx) => {
      const isRight = idx === 1;
      const browGeo = new THREE.CylinderGeometry(0.018, 0.01, 0.13, 12);
      const brow = new THREE.Mesh(browGeo, browMat);
      brow.position.set(bx, 0.12, 0.29);
      brow.rotation.z = isRight ? -0.22 : 0.22;
      brow.rotation.x = -0.2;
      headGroup.add(brow);
      browMeshes.push(brow);
    });

    // 1g. Sculpted 3D Soft Nose Bridge & Rounded Tip
    const noseGroup = new THREE.Group();
    noseGroup.position.set(0, -0.04, 0.32);

    const noseBridge = new THREE.Mesh(
      new THREE.CylinderGeometry(0.022, 0.035, 0.12, 16),
      skinMat
    );
    noseBridge.position.set(0, 0.04, -0.02);
    noseBridge.rotation.x = -0.3;

    const noseTip = new THREE.Mesh(new THREE.SphereGeometry(0.038, 16, 16), skinMat);
    noseTip.position.set(0, -0.02, 0.02);

    const lNostril = new THREE.Mesh(new THREE.SphereGeometry(0.018, 12, 12), skinMat);
    lNostril.position.set(-0.03, -0.03, 0.0);
    const rNostril = new THREE.Mesh(new THREE.SphereGeometry(0.018, 12, 12), skinMat);
    rNostril.position.set(0.03, -0.03, 0.0);

    noseGroup.add(noseBridge, noseTip, lNostril, rNostril);
    headGroup.add(noseGroup);

    // 1h. Soft Contoured Lips with Pixar Smile
    const lipMat = new THREE.MeshStandardMaterial({ color: skinInfo.lipColor, roughness: 0.35, metalness: 0.05 });
    const lipGeo = new THREE.TorusGeometry(0.075, 0.018, 12, 20, Math.PI * 0.75);
    const lips = new THREE.Mesh(lipGeo, lipMat);
    lips.position.set(0, -0.15, 0.27);
    lips.rotation.z = -Math.PI * 0.88;
    headGroup.add(lips);

    // 1i. Smooth Organic Ears (Left & Right)
    [-0.32, 0.32].forEach((ex, idx) => {
      const isRight = idx === 1;
      const earGroup = new THREE.Group();
      earGroup.position.set(ex, -0.02, 0);

      const earHelix = new THREE.Mesh(
        new THREE.TorusGeometry(0.055, 0.018, 12, 18, Math.PI * 1.25),
        skinMat
      );
      earHelix.rotation.y = isRight ? Math.PI / 2 : -Math.PI / 2;
      earHelix.rotation.z = Math.PI / 4;

      const earLobe = new THREE.Mesh(new THREE.SphereGeometry(0.028, 12, 12), skinMat);
      earLobe.position.set(0, -0.05, 0.01);

      earGroup.add(earHelix, earLobe);

      // Female Pearl Stud Earrings
      if (isFemale) {
        const pearlMat = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.15, metalness: 0.4 });
        const pearl = new THREE.Mesh(new THREE.SphereGeometry(0.022, 12, 12), pearlMat);
        pearl.position.set(isRight ? 0.02 : -0.02, -0.05, 0.02);
        earGroup.add(pearl);
      }

      headGroup.add(earGroup);
    });

    // =========================================================================
    // 1j. FULL VOLUMINOUS 3D HAIR (Cleanly sculpted: DOES NOT COVER FACE, EYES, OR CHEEKS)
    // =========================================================================
    const hairGroup = new THREE.Group();

    // 1j-1. Dense Organic Hair Base Shell (Covers back crown, sides behind ears, and nape)
    // Starts at high elevation phi = 0.28 to completely expose forehead, eyes, cheeks, and mouth
    const hairBaseGeo = new THREE.SphereGeometry(0.355, 32, 20, 0, Math.PI * 2, Math.PI * 0.26, Math.PI * 0.58);
    const hairBaseMesh = new THREE.Mesh(hairBaseGeo, hairMat);
    hairBaseMesh.position.set(0, 0.01, -0.02);
    hairGroup.add(hairBaseMesh);

    if (isFemale) {
      // FEMALE INDIE FULL HAIRSTYLE:
      // High swept bangs on upper hairline under cap visor (Cleanly ABOVE eyebrows y: 0.12)
      const fBang1 = new THREE.Mesh(new THREE.CylinderGeometry(0.028, 0.016, 0.22, 12), hairMat);
      fBang1.position.set(-0.12, 0.23, 0.26);
      fBang1.rotation.z = -0.42;
      fBang1.rotation.x = -0.15;

      const fBang2 = new THREE.Mesh(new THREE.CylinderGeometry(0.026, 0.014, 0.20, 12), hairHighlightMat);
      fBang2.position.set(0.10, 0.24, 0.26);
      fBang2.rotation.z = 0.38;
      fBang2.rotation.x = -0.15;

      // Full Side Cascades: Placed laterally behind the cheek line (z <= -0.05) so CHEEKS ARE COMPLETELY CLEAR
      // Left side locks behind ear & jawline
      const lSide1 = new THREE.Mesh(new THREE.CylinderGeometry(0.038, 0.022, 0.44, 12), hairMat);
      lSide1.position.set(-0.35, -0.15, -0.04);
      lSide1.rotation.z = -0.08;

      const lSide2 = new THREE.Mesh(new THREE.CylinderGeometry(0.042, 0.026, 0.48, 12), hairHighlightMat);
      lSide2.position.set(-0.34, -0.22, -0.12);
      lSide2.rotation.z = -0.05;

      // Right side locks behind ear & jawline
      const rSide1 = new THREE.Mesh(new THREE.CylinderGeometry(0.038, 0.022, 0.44, 12), hairMat);
      rSide1.position.set(0.35, -0.15, -0.04);
      rSide1.rotation.z = 0.08;

      const rSide2 = new THREE.Mesh(new THREE.CylinderGeometry(0.042, 0.026, 0.48, 12), hairHighlightMat);
      rSide2.position.set(0.34, -0.22, -0.12);
      rSide2.rotation.z = 0.05;

      // Full Back Hair Volume flowing down neck & shoulders
      const backFlow1 = new THREE.Mesh(new THREE.CylinderGeometry(0.18, 0.22, 0.42, 16), hairMat);
      backFlow1.position.set(0, -0.20, -0.26);
      backFlow1.rotation.x = 0.2;

      const backFlow2 = new THREE.Mesh(new THREE.CylinderGeometry(0.15, 0.08, 0.35, 16), hairHighlightMat);
      backFlow2.position.set(0, -0.38, -0.28);
      backFlow2.rotation.x = 0.12;

      // High Ponytail emerging through rear cap opening
      const scrunchieMat = new THREE.MeshStandardMaterial({ color: 0xec4899, roughness: 0.6 });
      const scrunchie = new THREE.Mesh(new THREE.TorusGeometry(0.065, 0.025, 12, 18), scrunchieMat);
      scrunchie.position.set(0, 0.16, -0.36);
      scrunchie.rotation.x = Math.PI / 3;

      const ponytailGroup = new THREE.Group();
      ponytailGroup.position.set(0, 0.16, -0.36);

      const pBulb1 = new THREE.Mesh(new THREE.SphereGeometry(0.11, 16, 16), hairMat);
      pBulb1.scale.set(0.95, 1.3, 0.85);
      pBulb1.position.set(0, -0.06, -0.04);

      const pLock1 = new THREE.Mesh(new THREE.CylinderGeometry(0.085, 0.05, 0.38, 14), hairMat);
      pLock1.position.set(0, -0.26, -0.08);
      pLock1.rotation.x = 0.18;

      const pLock2 = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.015, 0.32, 12), hairHighlightMat);
      pLock2.position.set(0, -0.52, -0.06);
      pLock2.rotation.x = -0.08;

      ponytailGroup.add(pBulb1, pLock1, pLock2);
      hairGroup.add(
        fBang1, fBang2,
        lSide1, lSide2,
        rSide1, rSide2,
        backFlow1, backFlow2,
        scrunchie, ponytailGroup
      );

    } else {
      // MALE INDIE SCULPTED HAIRSTYLE (Trimmed Cleanly Above Collar Line):
      // Forehead fringe sitting high on hairline under cap visor (well above eyebrows)
      const mbang1 = new THREE.Mesh(new THREE.CylinderGeometry(0.032, 0.016, 0.20, 12), hairMat);
      mbang1.position.set(-0.11, 0.23, 0.26);
      mbang1.rotation.z = -0.38;
      mbang1.rotation.x = -0.18;

      const mbang2 = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.015, 0.18, 12), hairHighlightMat);
      mbang2.position.set(0.09, 0.24, 0.26);
      mbang2.rotation.z = 0.32;
      mbang2.rotation.x = -0.18;

      // Sculpted Side Waves behind ears & temples (Neat taper, cheeks completely clear)
      const lSideWave1 = new THREE.Mesh(new THREE.CylinderGeometry(0.038, 0.022, 0.18, 12), hairMat);
      lSideWave1.position.set(-0.35, -0.06, -0.05);
      lSideWave1.rotation.z = -0.08;

      const lSideWave2 = new THREE.Mesh(new THREE.CylinderGeometry(0.038, 0.024, 0.19, 12), hairHighlightMat);
      lSideWave2.position.set(-0.34, -0.10, -0.12);

      const rSideWave1 = new THREE.Mesh(new THREE.CylinderGeometry(0.038, 0.022, 0.18, 12), hairMat);
      rSideWave1.position.set(0.35, -0.06, -0.05);
      rSideWave1.rotation.z = 0.08;

      const rSideWave2 = new THREE.Mesh(new THREE.CylinderGeometry(0.038, 0.024, 0.19, 12), hairHighlightMat);
      rSideWave2.position.set(0.34, -0.10, -0.12);

      // Trimmed Back / Nape Hair (Scaled down by 50%, sits neatly above collar line)
      const napeMain = new THREE.Mesh(new THREE.CylinderGeometry(0.20, 0.16, 0.16, 16), hairMat);
      napeMain.position.set(0, -0.09, -0.22);
      napeMain.rotation.x = 0.15;

      const napeWisp1 = new THREE.Mesh(new THREE.CylinderGeometry(0.035, 0.015, 0.13, 10), hairHighlightMat);
      napeWisp1.position.set(-0.12, -0.13, -0.21);
      napeWisp1.rotation.z = -0.12;
      napeWisp1.rotation.x = 0.14;

      const napeWisp2 = new THREE.Mesh(new THREE.CylinderGeometry(0.035, 0.015, 0.13, 10), hairHighlightMat);
      napeWisp2.position.set(0.12, -0.13, -0.21);
      napeWisp2.rotation.z = 0.12;
      napeWisp2.rotation.x = 0.14;

      hairGroup.add(
        mbang1, mbang2,
        lSideWave1, lSideWave2,
        rSideWave1, rSideWave2,
        napeMain, napeWisp1, napeWisp2
      );
    }

    headGroup.add(hairGroup);

    // =========================================================================
    // 1k. STYLISH WHITE BASEBALL CAP
    // =========================================================================
    const capGroup = new THREE.Group();
    capGroup.position.set(0, 0.08, 0);

    // Cap Dome (6-panel smooth spherical crown)
    const capDomeGeo = new THREE.SphereGeometry(0.375, 32, 20, 0, Math.PI * 2, 0, Math.PI * 0.52);
    const capDome = new THREE.Mesh(capDomeGeo, customCapMat);
    capDome.position.set(0, 0.06, -0.01);
    capDome.rotation.x = -0.08;
    capGroup.add(capDome);

    // Cap Visor / Curved Bill
    const visorGeo = new THREE.CylinderGeometry(0.40, 0.43, 0.028, 24, 1, false, -Math.PI / 3.2, Math.PI / 1.6);
    const capVisor = new THREE.Mesh(visorGeo, customCapMat);
    capVisor.position.set(0, 0.08, 0.24);
    capVisor.rotation.x = 0.32;
    capVisor.scale.set(1.0, 1.0, 0.65);
    capGroup.add(capVisor);

    // Cap Top Button (Squatchee)
    const capButton = new THREE.Mesh(new THREE.SphereGeometry(0.028, 16, 16), customCapMat);
    capButton.position.set(0, 0.44, -0.02);
    capGroup.add(capButton);

    headGroup.add(capGroup);

    // =========================================================================
    // 1l. PREMIUM OVER-EAR STUDIO HEADPHONES (Worn Ergonomically on Head)
    // =========================================================================
    const headphoneGroup = new THREE.Group();
    headphoneGroup.name = 'AvatarHeadphones';

    // Materials
    const hpBandMat = new THREE.MeshStandardMaterial({ color: 0x1e293b, roughness: 0.35, metalness: 0.3 });
    const hpCushionMat = new THREE.MeshStandardMaterial({ color: 0x090d16, roughness: 0.85 });
    const hpMetalMat = new THREE.MeshStandardMaterial({ color: 0xe2e8f0, roughness: 0.15, metalness: 0.85 });
    const hpAccentColor = isFemale ? 0xec4899 : 0x0284c7;
    const hpAccentMat = new THREE.MeshStandardMaterial({
      color: 0x38bdf8,
      emissive: 0x38bdf8,
      emissiveIntensity: 0.35,
      roughness: 0.2,
    });
    headphoneAccentMat = hpAccentMat;

    // 1. Arched Headband Over Crown / Behind Visor
    const headbandGeo = new THREE.TorusGeometry(0.395, 0.028, 12, 32, Math.PI * 0.86);
    const headband = new THREE.Mesh(headbandGeo, hpBandMat);
    headband.rotation.z = Math.PI * 0.07;
    headband.rotation.y = Math.PI / 2;
    headband.rotation.x = -0.22;
    headband.position.set(0, 0.08, 0.03);
    headphoneGroup.add(headband);

    // Headband Inner Comfort Padding
    const hpPadGeo = new THREE.TorusGeometry(0.38, 0.016, 10, 24, Math.PI * 0.65);
    const hpPad = new THREE.Mesh(hpPadGeo, hpCushionMat);
    hpPad.rotation.z = Math.PI * 0.175;
    hpPad.rotation.y = Math.PI / 2;
    hpPad.rotation.x = -0.22;
    hpPad.position.set(0, 0.08, 0.03);
    headphoneGroup.add(hpPad);

    // 2. Left & Right Over-Ear Cups with Ergonomic Cushions
    [-0.37, 0.37].forEach((hx, idx) => {
      const isRight = idx === 1;
      const cupGroup = new THREE.Group();
      cupGroup.position.set(hx, -0.02, 0.02);

      // Metal Gimbal Yoke Pivot Bracket
      const yokeGeo = new THREE.CylinderGeometry(0.012, 0.012, 0.11, 8);
      const yoke = new THREE.Mesh(yokeGeo, hpMetalMat);
      yoke.position.set(0, 0.06, 0);
      yoke.rotation.z = isRight ? -0.15 : 0.15;

      // Outer Shell Dome
      const cupShellGeo = new THREE.CylinderGeometry(0.092, 0.098, 0.042, 24);
      const cupShell = new THREE.Mesh(cupShellGeo, hpBandMat);
      cupShell.rotation.z = Math.PI / 2;
      cupShell.scale.set(1.0, 1.0, 1.18);

      // Outer Glow Accent Ring & Center Inset
      const accentRing = new THREE.Mesh(new THREE.TorusGeometry(0.093, 0.009, 8, 24), hpAccentMat);
      accentRing.rotation.y = Math.PI / 2;
      accentRing.scale.set(1.0, 1.18, 1.0);

      const centerCap = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.05, 0.046, 16), hpMetalMat);
      centerCap.rotation.z = Math.PI / 2;

      // Ergonomic Plush Leatherette Ear Cushion
      const cushionGeo = new THREE.TorusGeometry(0.075, 0.026, 14, 24);
      const cushion = new THREE.Mesh(cushionGeo, hpCushionMat);
      cushion.rotation.y = Math.PI / 2;
      cushion.position.set(isRight ? -0.022 : 0.022, 0, 0);
      cushion.scale.set(1.0, 1.2, 1.0);

      cupGroup.add(yoke, cupShell, accentRing, centerCap, cushion);
      headphoneGroup.add(cupGroup);
    });

    headGroup.add(headphoneGroup);

  } else {
    // Non-human smooth stylized mascot heads (Fox, Robot, Bear, etc.)
    const mascotHeadGeo = new THREE.SphereGeometry(0.34, 32, 24);
    const mascotMesh = new THREE.Mesh(mascotHeadGeo, faceMat);
    mascotMesh.castShadow = true;
    headGroup.add(mascotMesh);
  }

  avatarGroup.add(headGroup);

  // =========================================================================
  // 2. TORSO & HOODIE (Smooth Organic Topology, Orange for Male, Cyan/Pink for Female, Green/Red for Lofi Girl)
  // =========================================================================
  const torsoGroup = new THREE.Group();
  torsoGroup.position.y = 1.00;

  const torsoRadiusTop = isFemale ? 0.24 : 0.27;
  const torsoRadiusBot = isFemale ? 0.21 : 0.24;
  const torsoHeight = 0.72;

  // Main smooth organic torso cylinder
  const torsoGeo = new THREE.CylinderGeometry(torsoRadiusTop, torsoRadiusBot, torsoHeight, 28);
  torsoGeo.scale(1.0, 1.0, 0.78); // Natural human depth

  const activeHoodieMat = isLofiGirl ? greenLofiHoodieMat : isFemale ? cyanHoodieMat : isMaleDev ? orangeHoodieMat : suitMat;
  const torsoMesh = new THREE.Mesh(torsoGeo, activeHoodieMat);
  torsoMesh.castShadow = true;
  torsoGroup.add(torsoMesh);

  if (customScarfMat) {
    // Iconic Knitted Scarf Wrapped Snugly Around Neck & Flowing Down Chest
    const scarfRingGeo = new THREE.TorusGeometry(0.24, 0.065, 14, 24);
    const scarfRing = new THREE.Mesh(scarfRingGeo, customScarfMat);
    scarfRing.position.set(0, 0.36, -0.02);
    scarfRing.rotation.x = Math.PI / 2.1;
    scarfRing.castShadow = true;
    torsoGroup.add(scarfRing);

    // Cascading Scarf Tails
    const scarfTail1 = new THREE.Mesh(new THREE.BoxGeometry(0.09, 0.32, 0.04), customScarfMat);
    scarfTail1.position.set(-0.08, 0.16, 0.18);
    scarfTail1.rotation.z = 0.14;
    scarfTail1.rotation.y = 0.1;
    scarfTail1.castShadow = true;

    const scarfTail2 = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.25, 0.035), customScarfMat);
    scarfTail2.position.set(0.06, 0.19, 0.17);
    scarfTail2.rotation.z = -0.16;
    scarfTail2.rotation.y = -0.1;
    scarfTail2.castShadow = true;

    torsoGroup.add(scarfTail1, scarfTail2);
  }

  if (isHumanDev) {
    if (isLofiGirl) {

      // Green Kangaroo Pouch Front Pocket
      const pocketGeo = new THREE.SphereGeometry(0.24, 20, 16, 0, Math.PI);
      pocketGeo.scale(1.0, 0.45, 0.35);
      const pocketMesh = new THREE.Mesh(pocketGeo, greenLofiHoodieMat);
      pocketMesh.position.set(0, -0.12, 0.16);
      pocketMesh.rotation.x = Math.PI / 2;
      torsoGroup.add(pocketMesh);

      // Green Waistband Hem at Base
      const hemGeo = new THREE.CylinderGeometry(torsoRadiusBot + 0.015, torsoRadiusBot + 0.015, 0.07, 24);
      hemGeo.scale(1.0, 1.0, 0.8);
      const hemMesh = new THREE.Mesh(hemGeo, greenLofiHoodieMat);
      hemMesh.position.y = -0.34;
      torsoGroup.add(hemMesh);

    } else {
      // 2a. 3D Draped Hood Collar around Neckline
      const hoodCollarMat = isFemale ? pinkAccentMat : orangeHoodieMat;
      const hoodCollarGeo = new THREE.TorusGeometry(0.23, 0.055, 14, 24);
      const hoodCollar = new THREE.Mesh(hoodCollarGeo, hoodCollarMat);
      hoodCollar.position.set(0, 0.35, -0.04);
      hoodCollar.rotation.x = Math.PI / 2.2;
      torsoGroup.add(hoodCollar);

      // 2b. Kangaroo Pouch Front Pocket (Smooth rounded 3D pocket)
      const pocketColorMat = isFemale ? cyanHoodieMat : orangeHoodieMat;
      const pocketGeo = new THREE.SphereGeometry(0.24, 20, 16, 0, Math.PI);
      pocketGeo.scale(1.0, 0.45, 0.35);
      const pocketMesh = new THREE.Mesh(pocketGeo, pocketColorMat);
      pocketMesh.position.set(0, -0.12, 0.16);
      pocketMesh.rotation.x = Math.PI / 2;
      torsoGroup.add(pocketMesh);

      if (isFemale) {
        // Pink accent trim on pocket top
        const pTrim = new THREE.Mesh(new THREE.CylinderGeometry(0.015, 0.015, 0.32, 12), pinkAccentMat);
        pTrim.position.set(0, -0.05, 0.2);
        pTrim.rotation.z = Math.PI / 2;
        torsoGroup.add(pTrim);
      }

      // 2c. 3D Dangling Drawstring Cords with Metallic Chrome Aglets
      const cordColor = isFemale ? 0xf472b6 : 0xffffff;
      const cordMat = new THREE.MeshStandardMaterial({ color: cordColor, roughness: 0.4 });
      const agletMat = new THREE.MeshStandardMaterial({ color: 0xcbd5e1, metalness: 0.85, roughness: 0.15 });

      [-0.09, 0.09].forEach((cx) => {
        const cordGroup = new THREE.Group();
        cordGroup.position.set(cx, 0.15, 0.19);

        const cord = new THREE.Mesh(new THREE.CylinderGeometry(0.01, 0.01, 0.22, 8), cordMat);
        cord.position.y = -0.1;
        cord.rotation.z = cx > 0 ? -0.05 : 0.05;

        const aglet = new THREE.Mesh(new THREE.CylinderGeometry(0.014, 0.014, 0.04, 8), agletMat);
        aglet.position.y = -0.21;

        cordGroup.add(cord, aglet);
        torsoGroup.add(cordGroup);
      });

      // 2d. Elastic Ribbed Waistband Hem at Base
      const hemMat = isFemale ? pinkAccentMat : orangeHoodieMat;
      const hemGeo = new THREE.CylinderGeometry(torsoRadiusBot + 0.015, torsoRadiusBot + 0.015, 0.07, 24);
      hemGeo.scale(1.0, 1.0, 0.8);
      const hemMesh = new THREE.Mesh(hemGeo, hemMat);
      hemMesh.position.y = -0.34;
      torsoGroup.add(hemMesh);
    }
  }

  avatarGroup.add(torsoGroup);

  // =========================================================================
  // 3. ARMS, ELBOWS & HANDS (Articulated Shoulder-UpperArm & Elbow-Forearm Kinematics)
  // =========================================================================
  const armRadius = isFemale ? 0.075 : 0.088;
  const armLength = 0.62;
  const upperArmLength = 0.32;
  const forearmLength = 0.30;
  const armSleeveMat = isLofiGirl ? greenLofiHoodieMat : isFemale ? cyanHoodieMat : isMaleDev ? orangeHoodieMat : suitMat;

  const createArm = (isLeft: boolean) => {
    // 1. Upper Arm Bone Group (Pivots at Shoulder Joint)
    const upperArmGroup = new THREE.Group();
    const xPos = isLeft ? -(torsoRadiusTop + 0.09) : (torsoRadiusTop + 0.09);
    upperArmGroup.position.set(xPos, 1.30, 0);
    upperArmGroup.name = isLeft ? 'LeftUpperArmBone' : 'RightUpperArmBone';

    // Shoulder Deltoid Joint Sphere (Smooth spherical shoulder)
    const shoulder = new THREE.Mesh(new THREE.SphereGeometry(armRadius * 1.08, 16, 16), armSleeveMat);
    shoulder.position.y = 0;
    shoulder.castShadow = true;
    upperArmGroup.add(shoulder);

    // Upper Arm Sleeve Tube (From shoulder y=0 to elbow y=-upperArmLength)
    const upperSleeveGeo = new THREE.CylinderGeometry(armRadius, armRadius * 0.94, upperArmLength, 18);
    upperSleeveGeo.translate(0, -upperArmLength * 0.5, 0);
    const upperSleeve = new THREE.Mesh(upperSleeveGeo, armSleeveMat);
    upperSleeve.castShadow = true;
    upperArmGroup.add(upperSleeve);

    // 2. Forearm Bone Group (Child of Upper Arm Bone, Pivots at Elbow Joint)
    const forearmGroup = new THREE.Group();
    forearmGroup.position.set(0, -upperArmLength, 0);
    forearmGroup.name = isLeft ? 'LeftForearmBone' : 'RightForearmBone';

    // Smooth Elbow Joint Sphere
    const elbowJoint = new THREE.Mesh(new THREE.SphereGeometry(armRadius * 0.94, 16, 14), armSleeveMat);
    elbowJoint.position.y = 0;
    elbowJoint.castShadow = true;
    forearmGroup.add(elbowJoint);

    // Forearm Sleeve Tube
    const foreSleeveGeo = new THREE.CylinderGeometry(armRadius * 0.94, armRadius * 0.88, forearmLength * 0.82, 18);
    foreSleeveGeo.translate(0, -forearmLength * 0.41, 0);
    const foreSleeve = new THREE.Mesh(foreSleeveGeo, armSleeveMat);
    foreSleeve.castShadow = true;
    forearmGroup.add(foreSleeve);

    // Ribbed Wrist Cuff
    const cuffMat = isLofiGirl ? greenLofiHoodieMat : isFemale ? pinkAccentMat : armSleeveMat;
    const cuffGeo = new THREE.CylinderGeometry(armRadius * 0.92, armRadius * 0.92, 0.05, 16);
    const cuff = new THREE.Mesh(cuffGeo, cuffMat);
    cuff.position.y = -forearmLength * 0.82;
    forearmGroup.add(cuff);

    // Smooth Sculpted Hand
    const handGeo = new THREE.SphereGeometry(armRadius * 0.85, 16, 16);
    handGeo.scale(1.0, 1.3, 0.7);
    const hand = new THREE.Mesh(handGeo, skinMat);
    hand.position.y = -forearmLength * 0.96;
    hand.castShadow = true;
    forearmGroup.add(hand);

    upperArmGroup.add(forearmGroup);

    return { upperArmGroup, forearmGroup, handMesh: hand };
  };

  const { upperArmGroup: leftArmMesh, forearmGroup: leftForearmMesh } = createArm(true);
  const { upperArmGroup: rightArmMesh, forearmGroup: rightForearmMesh } = createArm(false);

  // 3b. 3D PING PONG PADDLE (attached to Right Hand / Forearm)
  const paddleMesh = new THREE.Group();
  const padHandleMat = new THREE.MeshStandardMaterial({ color: 0x78350f, roughness: 0.6 });
  const padFaceMat = new THREE.MeshStandardMaterial({ color: 0xdc2626, roughness: 0.4 });
  const pHandle = new THREE.Mesh(new THREE.CylinderGeometry(0.018, 0.018, 0.18, 12), padHandleMat);
  pHandle.position.set(0, -0.05, 0);
  const pFace = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.12, 0.02, 20), padFaceMat);
  pFace.position.set(0, -0.18, 0);
  pFace.rotation.x = Math.PI / 2;
  paddleMesh.add(pHandle, pFace);
  paddleMesh.position.set(0, -forearmLength * 0.95, 0.1);
  paddleMesh.visible = false;
  rightForearmMesh.add(paddleMesh);

  // 3c. 3D PRO GRAPHITE TENNIS RACQUET (attached to Right Hand / Forearm)
  const tennisRacquetMesh = new THREE.Group();
  tennisRacquetMesh.name = 'AvatarTennisRacquet';

  const tGripMat = new THREE.MeshStandardMaterial({ color: 0x0f172a, roughness: 0.6 });
  const tFrameMat = new THREE.MeshStandardMaterial({ color: 0x0284c7, metalness: 0.7, roughness: 0.3 });
  const tAccentMat = new THREE.MeshStandardMaterial({ color: 0xf59e0b, roughness: 0.3 });
  const tStringMat = new THREE.MeshBasicMaterial({ color: 0xffffff, wireframe: true, transparent: true, opacity: 0.7 });

  const rHandle = new THREE.Mesh(new THREE.CylinderGeometry(0.022, 0.025, 0.36, 12), tGripMat);
  rHandle.position.set(0, -0.18, 0);

  const buttCap = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.03, 0.03, 12), tAccentMat);
  buttCap.position.set(0, -0.36, 0);

  const throatL = new THREE.Mesh(new THREE.CylinderGeometry(0.012, 0.012, 0.12, 8), tFrameMat);
  throatL.position.set(-0.04, -0.04, 0);
  throatL.rotation.z = -0.3;
  const throatR = new THREE.Mesh(new THREE.CylinderGeometry(0.012, 0.012, 0.12, 8), tFrameMat);
  throatR.position.set(0.04, -0.04, 0);
  throatR.rotation.z = 0.3;

  const rFrame = new THREE.Mesh(new THREE.TorusGeometry(0.24, 0.022, 10, 28), tFrameMat);
  rFrame.position.set(0, 0.22, 0);
  rFrame.scale.set(0.9, 1.15, 1.0);

  const rAccent = new THREE.Mesh(new THREE.TorusGeometry(0.245, 0.01, 8, 28), tAccentMat);
  rAccent.position.set(0, 0.22, 0);
  rAccent.scale.set(0.9, 1.15, 1.0);

  const rStrings = new THREE.Mesh(new THREE.CircleGeometry(0.23, 20), tStringMat);
  rStrings.position.set(0, 0.22, 0);
  rStrings.scale.set(0.9, 1.15, 1.0);

  tennisRacquetMesh.add(rHandle, buttCap, throatL, throatR, rFrame, rAccent, rStrings);
  tennisRacquetMesh.position.set(0, -forearmLength * 0.85, 0.14);
  tennisRacquetMesh.rotation.x = Math.PI / 2;
  tennisRacquetMesh.visible = false;
  rightForearmMesh.add(tennisRacquetMesh);

  // 3d. 3D LAPTOP (Unfolds when seated at desk)
  const laptopGroup = new THREE.Group();
  const laptopBase = new THREE.Mesh(
    new THREE.BoxGeometry(0.48, 0.02, 0.35),
    new THREE.MeshStandardMaterial({ color: 0x94a3b8, metalness: 0.8, roughness: 0.2 })
  );
  const laptopScreen = new THREE.Mesh(
    new THREE.BoxGeometry(0.48, 0.32, 0.02),
    new THREE.MeshStandardMaterial({ color: 0x0f172a, emissive: 0x38bdf8, emissiveIntensity: 0.5 })
  );
  laptopScreen.position.set(0, 0.16, -0.17);
  laptopScreen.rotation.x = -Math.PI / 12;
  laptopGroup.add(laptopBase, laptopScreen);
  laptopGroup.position.set(0, 0.87, 0.42);
  laptopGroup.visible = false;
  avatarGroup.add(laptopGroup);

  avatarGroup.add(leftArmMesh, rightArmMesh);

  // =========================================================================
  // 4. LEGS, KNEES & SNEAKERS (Articulated Hip-Thigh & Knee-Shin Kinematics)
  // Ground-aligned at Y = 0 (No shoe sinking into floor)
  // Male Dev: Blue Jeans + Red Sneakers
  // Female Dev: Black Jeans + White Sneakers
  // =========================================================================
  const legRadius = isFemale ? 0.095 : 0.108;
  const legLength = 0.58;
  const thighLength = legLength * 0.5; // 0.29
  const shinLength = legLength * 0.5;  // 0.29
  const activeJeansMat = customPantsMat;
  const activeSneakerMat = customSneakerMat;

  const createLeg = (isLeft: boolean) => {
    // 1. Hip/Thigh Bone Group (Root Leg Bone pivoting at hip socket)
    const thighGroup = new THREE.Group();
    const xPos = isLeft ? -0.13 : 0.13;
    thighGroup.position.set(xPos, 0.67, 0); // Positioned so shoe bottom rests precisely at Y = 0
    thighGroup.name = isLeft ? 'LeftThighBone' : 'RightThighBone';

    // Hip Joint Ball (Smooth pivot at hip socket)
    const hipJointGeo = new THREE.SphereGeometry(legRadius * 0.98, 16, 12);
    const hipJoint = new THREE.Mesh(hipJointGeo, activeJeansMat);
    hipJoint.castShadow = true;
    thighGroup.add(hipJoint);

    // Thigh Cylinder (Tapered upper leg cylinder)
    const thighGeo = new THREE.CylinderGeometry(legRadius, legRadius * 0.94, thighLength, 20);
    thighGeo.translate(0, -thighLength * 0.5, 0);
    const thighMesh = new THREE.Mesh(thighGeo, activeJeansMat);
    thighMesh.castShadow = true;
    thighGroup.add(thighMesh);

    // 2. Knee/Shin Bone Group (Child of Thigh Bone, pivots at knee joint)
    const shinGroup = new THREE.Group();
    shinGroup.position.set(0, -thighLength, 0);
    shinGroup.name = isLeft ? 'LeftShinBone' : 'RightShinBone';

    // Knee Joint Ball (Smooth pivot at knee)
    const kneeJointGeo = new THREE.SphereGeometry(legRadius * 0.94, 16, 12);
    const kneeJoint = new THREE.Mesh(kneeJointGeo, activeJeansMat);
    kneeJoint.castShadow = true;
    shinGroup.add(kneeJoint);

    // Shin Cylinder (Tapered lower leg cylinder)
    const shinGeo = new THREE.CylinderGeometry(legRadius * 0.94, legRadius * 0.86, shinLength, 20);
    shinGeo.translate(0, -shinLength * 0.5, 0);
    const shinMesh = new THREE.Mesh(shinGeo, activeJeansMat);
    shinMesh.castShadow = true;
    shinGroup.add(shinMesh);

    // 3. Modern Sculpted 3D Sneaker (Child of Shin Bone)
    const shoeGroup = new THREE.Group();
    shoeGroup.position.set(0, -shinLength, 0.04);
    shoeGroup.name = isLeft ? 'LeftShoeGroup' : 'RightShoeGroup';

    // Sneaker Upper (curved aerodynamic silhouette)
    const shoeUpperGeo = new THREE.SphereGeometry(0.125, 20, 16);
    shoeUpperGeo.scale(0.85, 0.65, 1.35);
    const shoeUpper = new THREE.Mesh(shoeUpperGeo, activeSneakerMat);
    shoeUpper.position.set(0, 0, 0.03);
    shoeUpper.castShadow = true;

    // White Midsole / Foxing Rubber Wall (Resting precisely on level floor plane Y = 0)
    const soleGeo = new THREE.CylinderGeometry(0.115, 0.12, 0.045, 20);
    soleGeo.scale(0.9, 1.0, 1.45);
    const sole = new THREE.Mesh(soleGeo, sneakerRubberMat);
    sole.position.set(0, -0.065, 0.03);

    // Toe Cap Accent
    const toeCap = new THREE.Mesh(new THREE.SphereGeometry(0.075, 16, 16), sneakerRubberMat);
    toeCap.position.set(0, -0.03, 0.14);
    toeCap.scale.set(0.9, 0.6, 0.8);

    shoeGroup.add(shoeUpper, sole, toeCap);
    shinGroup.add(shoeGroup);

    // Attach Shin Bone to Thigh Bone
    thighGroup.add(shinGroup);

    return { thighGroup, shinGroup };
  };

  const leftLeg = createLeg(true);
  const rightLeg = createLeg(false);

  const leftLegMesh = leftLeg.thighGroup;
  const rightLegMesh = rightLeg.thighGroup;
  const leftShinMesh = leftLeg.shinGroup;
  const rightShinMesh = rightLeg.shinGroup;

  avatarGroup.add(leftLegMesh, rightLegMesh);

  // =========================================================================
  // 5. SPATIAL AUDIO REACH RING (Visual circle on floor around character)
  // =========================================================================
  const ringGeo = new THREE.RingGeometry(0.8, 0.9, 32);
  ringGeo.rotateX(-Math.PI / 2);
  const ringMat = new THREE.MeshBasicMaterial({
    color: user.isSpeaking ? 0x22c55e : 0x38bdf8,
    transparent: true,
    opacity: 0.4,
    side: THREE.DoubleSide,
  });
  const audioWaveMesh = new THREE.Mesh(ringGeo, ringMat);
  audioWaveMesh.position.y = 0.02;
  avatarGroup.add(audioWaveMesh);

  // =========================================================================
  // 6. OVERHEAD PLAYER BADGE & LIVE ZOOM WEBCAM SCREEN
  // =========================================================================
  const badgeSprite = createPlayerBadgeSprite(user);
  badgeSprite.position.set(0, 2.30, 0);
  badgeSprite.scale.set(1.9, 0.28, 1);
  avatarGroup.add(badgeSprite);

  // 6b. Live 3D Spatial Video Screen
  const videoScreenGroup = new THREE.Group();
  videoScreenGroup.position.set(0, 2.90, 0);
  videoScreenGroup.name = 'FloatingVideoScreenGroup';
  videoScreenGroup.userData = { isFloatingVideoScreenGroup: true, isFloatingVideoScreen: true };

  const screenBezelMat = new THREE.MeshStandardMaterial({
    color: 0x0f172a,
    roughness: 0.2,
    metalness: 0.8,
    transparent: true,
    opacity: 1.0,
  });

  const screenBezel = new THREE.Mesh(
    new THREE.BoxGeometry(1.2, 0.72, 0.05),
    screenBezelMat
  );
  screenBezel.userData = { isFloatingVideoScreenGroup: true, isFloatingVideoScreen: true };

  const defaultCameraTex = createDefaultCameraTexture(user.name);
  const videoScreenMat = new THREE.MeshBasicMaterial({
    map: defaultCameraTex,
    side: THREE.DoubleSide,
    transparent: true,
    opacity: 1.0,
  });

  // Front plane face
  const videoScreenMesh = new THREE.Mesh(
    new THREE.PlaneGeometry(1.12, 0.64),
    videoScreenMat
  );
  videoScreenMesh.position.z = 0.026;
  videoScreenMesh.userData = { isFloatingVideoScreenGroup: true, isFloatingVideoScreen: true };

  // Back plane face - renders webcam video feed texture on the back side as well
  const videoScreenBackMesh = new THREE.Mesh(
    new THREE.PlaneGeometry(1.12, 0.64),
    videoScreenMat
  );
  videoScreenBackMesh.position.z = -0.026;
  videoScreenBackMesh.rotation.y = Math.PI; // Rotated so video displays right-side-up and correctly oriented from behind
  videoScreenBackMesh.userData = { isFloatingVideoScreenGroup: true, isFloatingVideoScreen: true };

  const camLightMat = new THREE.MeshBasicMaterial({
    color: 0x22c55e,
    transparent: true,
    opacity: 1.0,
  });
  const camLight = new THREE.Mesh(
    new THREE.SphereGeometry(0.03, 8, 8),
    camLightMat
  );
  camLight.position.set(0.52, 0.3, 0.03);
  camLight.userData = { isFloatingVideoScreenGroup: true, isFloatingVideoScreen: true };

  // Invisible hit proxy mesh to maintain steady raycast hit while hovered and faded out
  const hitProxyMat = new THREE.MeshBasicMaterial({
    transparent: true,
    opacity: 0.0001,
    depthWrite: false,
  });
  const hitProxyMesh = new THREE.Mesh(
    new THREE.BoxGeometry(1.30, 0.80, 0.12),
    hitProxyMat
  );
  hitProxyMesh.userData = { isFloatingVideoScreenGroup: true, isFloatingVideoScreen: true };

  videoScreenGroup.add(screenBezel, videoScreenMesh, videoScreenBackMesh, camLight, hitProxyMesh);
  videoScreenGroup.visible = false;
  avatarGroup.add(videoScreenGroup);

  // 🛴 Attached High-Fidelity Customizable E-Scooter
  const scooterMeshGroup = createScooterMesh(user.scooterConfig);
  scooterMeshGroup.group.visible = !!user.isRidingScooter;
  avatarGroup.add(scooterMeshGroup.group);

  let isHasActiveVideo = false;
  let targetScreenOpacity = 1.0;
  let currentScreenOpacity = 1.0;

  const setScreenHovered = (hovered: boolean) => {
    targetScreenOpacity = hovered ? 0.0 : 1.0;
  };

  const setVideoTexture = (texture: THREE.Texture | null) => {
    if (texture) {
      videoScreenMat.map = texture;
      videoScreenMat.needsUpdate = true;
      isHasActiveVideo = true;
      videoScreenGroup.visible = true;
    } else {
      videoScreenMat.map = defaultCameraTex;
      videoScreenMat.needsUpdate = true;
      isHasActiveVideo = false;
      videoScreenGroup.visible = false;
    }
  };

  const updateScooterColors = (newConfig: ScooterConfig) => {
    if (scooterMeshGroup) {
      scooterMeshGroup.updateColors(newConfig);
    }
  };

  // Speech bubble sprite placeholder
  let speechBubbleSprite: THREE.Sprite | null = null;
  let bubbleTimeout: any = null;

  // Active Gestures & Floating Emoji Particles State
  let activeGestureState: { type: GestureType; endTime: number } | null = null;
  let activeTennisSwing: { type: 'forehand' | 'backhand' | 'smash'; startTime: number; duration: number } | null = null;

  const activeEmojiParticles: Array<{
    sprite: THREE.Sprite;
    vx: number;
    vy: number;
    vz: number;
    rotSpeed: number;
    createdAt: number;
    lifeSpan: number;
  }> = [];

  const triggerGesture = (gesture: GestureType, durationMs = 3800) => {
    activeGestureState = { type: gesture, endTime: Date.now() + durationMs };
  };

  const triggerTennisSwing = (type: 'forehand' | 'backhand' | 'smash' = 'smash') => {
    // Racquet swinging is STRICTLY restricted to the tennis court (Basement B1, Y near -6.0)
    const isAtTennisArena = Math.abs(avatarGroup.position.y - (-6.0)) < 3.5;
    if (!isAtTennisArena) {
      activeTennisSwing = null;
      return;
    }
    activeTennisSwing = {
      type,
      startTime: Date.now(),
      duration: type === 'smash' ? 450 : 380,
    };
  };

  const triggerEmojiParticle = (emoji: string) => {
    for (let i = 0; i < 4; i++) {
      const sprite = createEmojiSprite(emoji);
      const startX = (Math.random() - 0.5) * 0.5;
      const startZ = (Math.random() - 0.5) * 0.3;
      sprite.position.set(startX, 2.4, startZ);
      sprite.visible = false;

      avatarGroup.add(sprite);

      activeEmojiParticles.push({
        sprite,
        vx: (Math.random() - 0.5) * 0.015,
        vy: 0.02 + Math.random() * 0.015,
        vz: (Math.random() - 0.5) * 0.015,
        rotSpeed: (Math.random() - 0.5) * 0.1,
        createdAt: Date.now() + i * 80,
        lifeSpan: 2200,
      });
    }
  };

  const showSpeechBubble = (text: string) => {
    if (speechBubbleSprite) {
      avatarGroup.remove(speechBubbleSprite);
      speechBubbleSprite = null;
    }
    if (bubbleTimeout) clearTimeout(bubbleTimeout);

    speechBubbleSprite = createSpeechBubbleSprite(text);
    speechBubbleSprite.position.set(0, 2.7, 0);
    speechBubbleSprite.scale.set(2.2, 0.6, 1);
    avatarGroup.add(speechBubbleSprite);

    bubbleTimeout = setTimeout(() => {
      if (speechBubbleSprite) {
        avatarGroup.remove(speechBubbleSprite);
        speechBubbleSprite = null;
      }
    }, 6000);
  };

  // Walking, Seated, Gesture, Ping Pong & Tennis Animation Loop with Living Micro-Gestures
  const updateAnimation = (
    time: number,
    isMoving: boolean,
    isAtPingPongTable?: boolean,
    isSeated?: boolean,
    isAtTennisCourt?: boolean,
    isSwingingTennis?: boolean,
    smashType?: 'forehand' | 'backhand' | 'smash',
    isSpeaking?: boolean,
    lookTargetPos?: { x: number; y: number; z: number },
    isRidingScooter?: boolean,
    scooterTurnAngle?: number,
    scooterSpeed?: number,
    dt?: number
  ) => {
    const isActuallySpeaking = !!isSpeaking || speechBubbleSprite !== null;
    
    // Ping Pong racquet / paddle MUST ONLY be visible on the main floor (1st floor, Y near 0.0) AND at ping pong table
    const isMainFloor = Math.abs(avatarGroup.position.y - 0.0) < 1.5;
    paddleMesh.visible = isMainFloor && !!isAtPingPongTable;

    // Tennis racquet MUST ONLY be visible at the tennis court (Basement B1, Y near -6.0)
    const isAtTennisArena = !!isAtTennisCourt && Math.abs(avatarGroup.position.y - (-6.0)) < 3.5;
    if (!isAtTennisArena) {
      activeTennisSwing = null;
    }
    tennisRacquetMesh.visible = isAtTennisArena;
    laptopGroup.visible = false;

    // Reset default mesh rotations, positions & scale
    headGroup.rotation.set(0, 0, 0);
    torsoGroup.rotation.set(0, 0, 0);
    leftArmMesh.rotation.set(0, 0, 0);
    rightArmMesh.rotation.set(0, 0, 0);
    leftForearmMesh.rotation.set(0, 0, 0);
    rightForearmMesh.rotation.set(0, 0, 0);
    leftArmMesh.position.set(-(torsoRadiusTop + 0.09), 1.30, 0);
    rightArmMesh.position.set((torsoRadiusTop + 0.09), 1.30, 0);
    leftLegMesh.rotation.set(0, 0, 0);
    rightLegMesh.rotation.set(0, 0, 0);
    leftShinMesh.rotation.set(0, 0, 0);
    rightShinMesh.rotation.set(0, 0, 0);

    // 1. Natural Human Eye Blinking Engine (Pixar 3.5s Cycle with Smooth Ease-In/Out)
    const blinkSeed = user.id.split('').reduce((acc, c) => acc + c.charCodeAt(0), 0) * 0.13;
    const blinkPeriod = 3.6 + Math.sin(time * 0.2 + blinkSeed) * 0.8;
    const blinkPhase = (time + blinkSeed) % blinkPeriod;
    const blinkDuration = 0.16;
    let blinkScaleY = 1.0;
    if (blinkPhase < blinkDuration) {
      const progress = blinkPhase / blinkDuration;
      const blinkDip = Math.sin(progress * Math.PI); // 0 -> 1 -> 0
      blinkScaleY = 1.0 - blinkDip * 0.92; // Smooth 1.0 -> 0.08 -> 1.0
    }

    eyeGroups.forEach((eg) => {
      eg.scale.y = blinkScaleY;
    });

    // 🛴 2. Electric E-Scooter Riding Engine & Stance (Takes Full Priority When Active)
    if (isRidingScooter) {
      if (scooterMeshGroup) {
        scooterMeshGroup.group.visible = true;
        const currentDt = dt || 0.016;
        const effectiveTurn = scooterTurnAngle || 0;
        const effectiveSpeed = scooterSpeed !== undefined ? scooterSpeed : (isMoving ? 8.5 : 0);
        scooterMeshGroup.updateScooter(isMoving, currentDt, effectiveTurn, effectiveSpeed);
      }

      paddleMesh.visible = false;
      tennisRacquetMesh.visible = false;

      // Realistic Micro-mobility rider stance:
      // Left foot forward, right foot rear stabilizer on deck
      leftLegMesh.position.set(-0.06, 0.74, 0.12);
      leftLegMesh.rotation.set(-0.06, 0.08, 0);
      leftShinMesh.rotation.set(0.08, 0, 0);

      rightLegMesh.position.set(0.06, 0.74, -0.16);
      rightLegMesh.rotation.set(0.12, -0.06, 0);
      rightShinMesh.rotation.set(0.10, 0, 0);

      // Steady, stable body with zero shaking/wobble during autoride & riding
      const bankAngle = (scooterTurnAngle || 0) * 0.30;

      torsoGroup.position.set(0, 1.05, 0);
      torsoGroup.rotation.set(0, 0, 0);

      headGroup.position.set(0, 1.70, 0);
      headGroup.rotation.set(
        -0.03,
        0,
        -bankAngle * 0.3
      );

      // Handlebar Reach & Precision Grip Kinematics with steering tracking:
      const armY = 1.34;
      leftArmMesh.position.set(-(torsoRadiusTop + 0.07), armY, 0);
      rightArmMesh.position.set((torsoRadiusTop + 0.07), armY, 0);

      const turnAmt = scooterTurnAngle || 0;
      const leftArmRotY = 0.25 + turnAmt * 0.9;
      const rightArmRotY = -0.25 + turnAmt * 0.9;

      leftArmMesh.rotation.set(-1.06, leftArmRotY, -0.16 - bankAngle * 0.15);
      rightArmMesh.rotation.set(-1.06, rightArmRotY, 0.16 - bankAngle * 0.15);

      leftForearmMesh.rotation.set(-0.76, 0.14 + turnAmt * 0.3, 0);
      rightForearmMesh.rotation.set(-0.76, -0.14 + turnAmt * 0.3, 0);

      // Update badge / speaking audio waves
      if (user.isSpeaking) {
        const pulse = 1 + Math.sin(time * 12) * 0.3;
        audioWaveMesh.scale.set(pulse, 1, pulse);
        (audioWaveMesh.material as THREE.MeshBasicMaterial).color.setHex(0x22c55e);
        (audioWaveMesh.material as THREE.MeshBasicMaterial).opacity = 0.7;
      } else {
        audioWaveMesh.scale.set(1, 1, 1);
        (audioWaveMesh.material as THREE.MeshBasicMaterial).color.setHex(0x38bdf8);
        (audioWaveMesh.material as THREE.MeshBasicMaterial).opacity = 0.25;
      }

      return;
    } else {
      if (scooterMeshGroup) {
        scooterMeshGroup.group.visible = false;
      }
    }

    if (isSwingingTennis && !activeTennisSwing) {
      triggerTennisSwing(smashType || 'smash');
    }

    const now = Date.now();

    // Check if active tennis swing/smash is ongoing
    if (activeTennisSwing) {
      const elapsed = now - activeTennisSwing.startTime;
      const progress = elapsed / activeTennisSwing.duration;

      if (progress >= 1) {
        activeTennisSwing = null;
      } else {
        const sType = activeTennisSwing.type;
        if (sType === 'smash') {
          // Jumping Overhead Tennis Smash!
          const jumpPhase = Math.sin(progress * Math.PI);
          headGroup.position.y = 1.5 + jumpPhase * 0.25;
          torsoGroup.rotation.x = -jumpPhase * 0.2;
          torsoGroup.rotation.y = jumpPhase * 0.35;

          const armPhase = progress < 0.35
            ? -Math.PI * 0.85 + (progress / 0.35) * 0.2
            : -Math.PI * 0.65 + Math.sin((progress - 0.35) / 0.65 * Math.PI) * 1.8;
          
          rightArmMesh.rotation.x = armPhase;
          rightArmMesh.rotation.z = -jumpPhase * 0.4;
          rightArmMesh.rotation.y = jumpPhase * 0.5;
          rightForearmMesh.rotation.x = progress < 0.35 ? -Math.PI * 0.35 : -Math.PI * 0.15;

          leftArmMesh.rotation.x = -Math.PI * 0.4 + jumpPhase * 0.3;
          leftArmMesh.rotation.z = -0.3;
          leftForearmMesh.rotation.x = -Math.PI * 0.25;
          leftLegMesh.rotation.x = jumpPhase * 0.3;
          rightLegMesh.rotation.x = -jumpPhase * 0.2;
          return;
        } else if (sType === 'backhand') {
          const swingPhase = Math.sin(progress * Math.PI);
          torsoGroup.rotation.y = -swingPhase * 0.45;
          rightArmMesh.rotation.x = -Math.PI * 0.45;
          rightArmMesh.rotation.y = -0.8 + progress * 1.6;
          rightArmMesh.rotation.z = swingPhase * 0.5;
          rightForearmMesh.rotation.x = -Math.PI * 0.25;
          leftArmMesh.rotation.x = -Math.PI * 0.2;
          leftForearmMesh.rotation.x = -Math.PI * 0.15;
          return;
        } else {
          const swingPhase = Math.sin(progress * Math.PI);
          torsoGroup.rotation.y = swingPhase * 0.45;
          rightArmMesh.rotation.x = -Math.PI * 0.5;
          rightArmMesh.rotation.y = 0.8 - progress * 1.6;
          rightArmMesh.rotation.z = -swingPhase * 0.5;
          rightForearmMesh.rotation.x = -Math.PI * 0.30;
          leftArmMesh.rotation.x = -Math.PI * 0.2;
          leftForearmMesh.rotation.x = -Math.PI * 0.15;
          return;
        }
      }
    }

    const isGestureActive = activeGestureState && Date.now() < activeGestureState.endTime;

    if (isSeated) {
      // =======================================================================
      // SEATED STATE: ERGONOMIC KEYBOARD TYPING & NATURAL ARM / ELBOW KINEMATICS
      // Overrides any hand-to-head / headphone gestures to keep hands firmly at desk
      // =======================================================================
      // 1. Knees & Hips Bending Angle:
      leftLegMesh.rotation.x = -Math.PI / 2;
      leftLegMesh.rotation.y = 0;
      leftLegMesh.rotation.z = 0;

      rightLegMesh.rotation.x = -Math.PI / 2;
      rightLegMesh.rotation.y = 0;
      rightLegMesh.rotation.z = 0;

      // 90-degree downward rotation to knee/shin bones
      leftShinMesh.rotation.x = Math.PI / 2;
      leftShinMesh.rotation.y = 0;
      leftShinMesh.rotation.z = 0;

      rightShinMesh.rotation.x = Math.PI / 2;
      rightShinMesh.rotation.y = 0;
      rightShinMesh.rotation.z = 0;

      // Lower hip and torso to sit comfortably on chair seat cushion without sinking
      leftLegMesh.position.y = 0.46;
      rightLegMesh.position.y = 0.46;
      torsoGroup.position.y = 0.79;

      // Natural multi-joint seated spine breathing posture & shoulder micro-expansion
      const breath = Math.sin(time * 2.2) * 0.025;
      torsoGroup.rotation.x = 0.04 + breath;
      headGroup.position.y = 1.44 + breath * 0.4;

      // 2. Lower Shoulders & Pull Upper Arms Slightly Back (Natural seated typing posture)
      // Hands rest directly above keyboard/trackpad rather than reaching straight forward or stiffly floating
      const seatedArmY = 1.18;
      const seatedArmZ = -0.06;
      leftArmMesh.position.set(-(torsoRadiusTop + 0.08), seatedArmY, seatedArmZ);
      rightArmMesh.position.set((torsoRadiusTop + 0.08), seatedArmY, seatedArmZ);

      // Upper arm hangs down and slightly forward/inward toward keyboard center
      leftArmMesh.rotation.x = -0.22;
      leftArmMesh.rotation.y = 0.22;
      leftArmMesh.rotation.z = -0.08;

      rightArmMesh.rotation.x = -0.22;
      rightArmMesh.rotation.y = -0.22;
      rightArmMesh.rotation.z = 0.08;

      if (isActuallySpeaking) {
        // Expressive conversational gestures while seated (Chest & desk level, NEVER touching head/headphones)
        const talkTime = time * 4.5;
        const talkWave = Math.sin(talkTime);
        const talkAlt = Math.cos(talkTime * 0.8);

        leftArmMesh.rotation.x = -0.26 + talkWave * 0.06;
        leftArmMesh.rotation.y = 0.26 + talkAlt * 0.08;
        leftArmMesh.rotation.z = -0.10;

        rightArmMesh.rotation.x = -0.28 - talkAlt * 0.08;
        rightArmMesh.rotation.y = -0.28 - talkWave * 0.08;
        rightArmMesh.rotation.z = 0.12;

        // Forearms flexed ~80-100 deg at chest/desk height with open palm gestures
        leftForearmMesh.rotation.x = -Math.PI * 0.50 + talkWave * 0.12;
        leftForearmMesh.rotation.y = 0.14 + talkAlt * 0.06;
        leftForearmMesh.rotation.z = 0.04;

        rightForearmMesh.rotation.x = -Math.PI * 0.52 - talkAlt * 0.14;
        rightForearmMesh.rotation.y = -0.16 - talkWave * 0.06;
        rightForearmMesh.rotation.z = -0.04;

        // Expressive head nod and conversational tilt
        headGroup.rotation.x = Math.sin(time * 4.8) * 0.06 + 0.02;
        headGroup.rotation.z = Math.sin(time * 2.5) * 0.05;

        // Eyebrows animated with speech emphasis
        browMeshes.forEach((bm) => {
          bm.position.y = 0.12 + Math.abs(Math.sin(time * 4.0)) * 0.015;
        });
      } else {
        // Dynamic desk typing cycle with realistic keystroke bursts, trackpad navigation, and pauses
        const typingCyclePeriod = 14.0;
        const loopTime = (time + blinkSeed) % typingCyclePeriod;

        if (loopTime < 5.5) {
          // Phase 1: Burst Typing (Elbows flexed ~85-95 deg, forearms horizontal over keys)
          const typeSpeed = time * 18.0;
          const keyL = Math.sin(typeSpeed) * 0.05 + Math.cos(typeSpeed * 0.7) * 0.02;
          const keyR = Math.cos(typeSpeed * 1.1 + 0.5) * 0.05 + Math.sin(typeSpeed * 0.8) * 0.02;

          leftForearmMesh.rotation.x = -Math.PI * 0.51 + keyL;
          leftForearmMesh.rotation.y = 0.12;
          leftForearmMesh.rotation.z = 0.04;

          rightForearmMesh.rotation.x = -Math.PI * 0.51 + keyR;
          rightForearmMesh.rotation.y = -0.12;
          rightForearmMesh.rotation.z = -0.04;

          // Focused glance down at screen / keyboard
          headGroup.rotation.x = 0.12 + Math.sin(time * 3.0) * 0.02;
          headGroup.rotation.z = Math.sin(time * 1.0) * 0.02;
        } else if (loopTime < 8.0) {
          // Phase 2: Reading / Inspection Pause with forearms resting horizontally
          leftForearmMesh.rotation.x = -Math.PI * 0.49;
          leftForearmMesh.rotation.y = 0.10;
          leftForearmMesh.rotation.z = 0.03;

          rightForearmMesh.rotation.x = -Math.PI * 0.49;
          rightForearmMesh.rotation.y = -0.10;
          rightForearmMesh.rotation.z = -0.03;

          // Thoughtful glance at display
          headGroup.rotation.x = 0.06 + Math.sin(time * 1.5) * 0.02;
          headGroup.rotation.z = 0.06 + Math.sin(time * 0.8) * 0.03;
        } else if (loopTime < 11.5) {
          // Phase 3: Trackpad / Mouse Navigation
          leftForearmMesh.rotation.x = -Math.PI * 0.49;
          leftForearmMesh.rotation.y = 0.10;
          leftForearmMesh.rotation.z = 0.03;

          const scroll = Math.sin(time * 8.0) * 0.03;
          rightArmMesh.rotation.y = -0.28;
          rightForearmMesh.rotation.x = -Math.PI * 0.46 + scroll;
          rightForearmMesh.rotation.y = -0.18;
          rightForearmMesh.rotation.z = -0.06;

          headGroup.rotation.x = 0.08 + Math.sin(time * 2.0) * 0.02;
          headGroup.rotation.z = -0.04;
        } else {
          // Phase 4: Gentle posture reset & wrist flex
          const stretch = Math.sin((loopTime - 11.5) * Math.PI / 2.5);
          torsoGroup.rotation.x = 0.02 - stretch * 0.04;

          leftForearmMesh.rotation.x = -Math.PI * 0.48 - stretch * 0.04;
          leftForearmMesh.rotation.y = 0.10;
          rightForearmMesh.rotation.x = -Math.PI * 0.48 - stretch * 0.04;
          rightForearmMesh.rotation.y = -0.10;

          headGroup.rotation.x = 0.04 + stretch * 0.05;
          headGroup.rotation.z = Math.sin(time * 1.2) * 0.03;
        }
      }

      // Skeleton matrix update for instant seated render
      avatarGroup.updateMatrixWorld(true);

    } else if (isGestureActive) {
      // Standing Gestures with realistic elbow articulation
      const gType = activeGestureState!.type;

      if (gType === 'wave') {
        rightArmMesh.rotation.x = -Math.PI * 0.60;
        rightArmMesh.rotation.z = -0.15;
        rightForearmMesh.rotation.x = -Math.PI * 0.35;
        rightForearmMesh.rotation.z = Math.sin(time * 12) * 0.35;
        leftForearmMesh.rotation.x = -0.08;
        headGroup.rotation.z = Math.sin(time * 6) * 0.1;
      } else if (gType === 'dance') {
        const t = time * 12;
        rightArmMesh.rotation.x = -Math.PI * 0.45 + Math.sin(t) * 0.2;
        leftArmMesh.rotation.x = -Math.PI * 0.45 - Math.sin(t) * 0.2;
        rightArmMesh.rotation.z = 0.3 + Math.cos(t) * 0.15;
        leftArmMesh.rotation.z = -0.3 - Math.cos(t) * 0.15;
        rightForearmMesh.rotation.x = -Math.PI * 0.40 + Math.cos(t) * 0.2;
        leftForearmMesh.rotation.x = -Math.PI * 0.40 - Math.cos(t) * 0.2;
        torsoGroup.rotation.z = Math.sin(t * 0.5) * 0.15;
        headGroup.position.y = 1.5 + Math.abs(Math.sin(t)) * 0.12;
      } else if (gType === 'clap') {
        const t = time * 18;
        leftArmMesh.rotation.x = -Math.PI * 0.25;
        rightArmMesh.rotation.x = -Math.PI * 0.25;
        leftArmMesh.rotation.y = 0.35 + Math.sin(t) * 0.2;
        rightArmMesh.rotation.y = -0.35 - Math.sin(t) * 0.2;
        leftForearmMesh.rotation.x = -Math.PI * 0.45;
        rightForearmMesh.rotation.x = -Math.PI * 0.45;
      } else if (gType === 'bow') {
        torsoGroup.rotation.x = 0.45;
        headGroup.rotation.x = 0.35;
        leftArmMesh.rotation.x = 0.20;
        rightArmMesh.rotation.x = 0.20;
        leftForearmMesh.rotation.x = -0.10;
        rightForearmMesh.rotation.x = -0.10;
      } else if (gType === 'think') {
        rightArmMesh.rotation.x = -Math.PI * 0.35;
        rightArmMesh.rotation.y = -0.30;
        rightForearmMesh.rotation.x = -Math.PI * 0.55;
        leftForearmMesh.rotation.x = -0.08;
        headGroup.rotation.z = 0.2;
        headGroup.rotation.x = 0.15;
      } else if (gType === 'cheer') {
        const t = time * 8;
        leftArmMesh.rotation.x = -Math.PI * 0.85;
        rightArmMesh.rotation.x = -Math.PI * 0.85;
        leftArmMesh.rotation.z = -0.25 + Math.sin(t) * 0.15;
        rightArmMesh.rotation.z = 0.25 - Math.sin(t) * 0.15;
        leftForearmMesh.rotation.x = -Math.PI * 0.25;
        rightForearmMesh.rotation.x = -Math.PI * 0.25;
        headGroup.position.y = 1.65 + Math.abs(Math.sin(t)) * 0.08;
      } else if (gType === 'heart') {
        leftArmMesh.rotation.x = -Math.PI * 0.35;
        rightArmMesh.rotation.x = -Math.PI * 0.35;
        leftArmMesh.rotation.y = 0.45;
        rightArmMesh.rotation.y = -0.45;
        leftForearmMesh.rotation.x = -Math.PI * 0.50;
        rightForearmMesh.rotation.x = -Math.PI * 0.50;
        headGroup.rotation.x = -0.1;
      } else if (gType === 'facepalm') {
        rightArmMesh.rotation.x = -Math.PI * 0.45;
        rightArmMesh.rotation.y = -0.25;
        rightForearmMesh.rotation.x = -Math.PI * 0.60;
        leftForearmMesh.rotation.x = -0.08;
        headGroup.rotation.x = 0.25;
      }
    } else if (isAtTennisCourt) {
      const bounce = Math.sin(time * 6) * 0.04;
      headGroup.position.y = 1.61 + bounce;
      torsoGroup.position.y = 1.00;
      torsoGroup.rotation.x = 0.08;
      leftLegMesh.rotation.x = 0.08;
      rightLegMesh.rotation.x = -0.08;
      leftLegMesh.position.y = 0.67;
      rightLegMesh.position.y = 0.67;
      
      rightArmMesh.rotation.x = -Math.PI * 0.28;
      rightArmMesh.rotation.y = -0.20;
      rightArmMesh.rotation.z = 0.15;
      rightForearmMesh.rotation.x = -Math.PI * 0.35 + Math.sin(time * 6) * 0.1;
      
      leftArmMesh.rotation.x = -Math.PI * 0.15;
      leftArmMesh.rotation.y = 0.2;
      leftForearmMesh.rotation.x = -Math.PI * 0.25;
    } else if (isAtPingPongTable) {
      torsoGroup.position.y = 1.00;
      leftArmMesh.rotation.x = -Math.PI * 0.12;
      leftForearmMesh.rotation.x = -Math.PI * 0.25;
      rightArmMesh.rotation.x = -Math.PI * 0.20;
      rightArmMesh.rotation.y = -0.20 + Math.cos(time * 8) * 0.15;
      rightForearmMesh.rotation.x = -Math.PI * 0.40 + Math.sin(time * 8) * 0.3;
      leftLegMesh.rotation.x = 0;
      rightLegMesh.rotation.x = 0;
      leftLegMesh.position.y = 0.67;
      rightLegMesh.position.y = 0.67;
      headGroup.position.y = 1.65 + Math.abs(Math.sin(time * 8)) * 0.03;
    } else if (isMoving) {
      torsoGroup.position.y = 1.00;
      rightArmMesh.rotation.y = 0;
      leftArmMesh.rotation.z = 0;
      rightArmMesh.rotation.z = 0;
      torsoGroup.rotation.x = 0.05;
      torsoGroup.rotation.z = Math.sin(time * 10) * 0.04;
      const swing = Math.sin(time * 10) * 0.6;
      leftArmMesh.rotation.x = swing;
      rightArmMesh.rotation.x = -swing;
      leftForearmMesh.rotation.x = -0.15 - Math.abs(swing) * 0.18;
      rightForearmMesh.rotation.x = -0.15 - Math.abs(swing) * 0.18;
      leftLegMesh.rotation.x = -swing;
      rightLegMesh.rotation.x = swing;
      leftLegMesh.position.y = 0.67;
      rightLegMesh.position.y = 0.67;
      headGroup.position.y = 1.65 + Math.abs(Math.sin(time * 10)) * 0.05;
      headGroup.rotation.x = 0;
      headGroup.rotation.z = 0;
    } else {
      // Dynamic idle standing animation with subtle breathing & weight shift
      torsoGroup.position.y = 1.00;
      const breath = Math.sin(time * 2.0) * 0.02;
      const weightShift = Math.sin(time * 0.9) * 0.03;

      torsoGroup.rotation.z = weightShift;
      torsoGroup.rotation.x = breath * 0.5;
      headGroup.position.y = 1.65 + breath;
      leftLegMesh.rotation.x = weightShift * 0.5;
      rightLegMesh.rotation.x = -weightShift * 0.5;
      leftLegMesh.position.y = 0.67;
      rightLegMesh.position.y = 0.67;

      if (isActuallySpeaking) {
        // Expressive talking standing gesture (hands at chest level)
        const gTime = time * 4.0;
        leftArmMesh.rotation.x = -Math.PI * 0.22 + Math.sin(gTime) * 0.1;
        leftArmMesh.rotation.y = 0.24;
        leftArmMesh.rotation.z = -0.10;
        leftForearmMesh.rotation.x = -Math.PI * 0.40 + Math.sin(gTime * 1.1) * 0.12;

        rightArmMesh.rotation.x = -Math.PI * 0.24 + Math.cos(gTime * 0.9) * 0.12;
        rightArmMesh.rotation.y = -0.24;
        rightArmMesh.rotation.z = 0.12;
        rightForearmMesh.rotation.x = -Math.PI * 0.44 + Math.cos(gTime * 1.0) * 0.14;

        headGroup.rotation.x = Math.sin(time * 4.5) * 0.05;
        headGroup.rotation.z = Math.sin(time * 2.2) * 0.05;
      } else {
        leftArmMesh.rotation.x = Math.sin(time * 1.5) * 0.04;
        rightArmMesh.rotation.x = -Math.sin(time * 1.5) * 0.04;
        leftArmMesh.rotation.y = 0;
        rightArmMesh.rotation.y = 0;
        leftArmMesh.rotation.z = 0;
        rightArmMesh.rotation.z = 0;
        leftForearmMesh.rotation.x = -0.08;
        rightForearmMesh.rotation.x = -0.08;
        leftForearmMesh.rotation.y = 0;
        rightForearmMesh.rotation.y = 0;
        leftForearmMesh.rotation.z = 0;
        rightForearmMesh.rotation.z = 0;
        headGroup.rotation.x = Math.sin(time * 1.2) * 0.02;
        headGroup.rotation.z = Math.sin(time * 0.8) * 0.02;
      }
    }

    // Active Eye & Head Tracking towards lookTargetPos (Player Camera or Player Avatar)
    if (lookTargetPos) {
      const dx = lookTargetPos.x - avatarGroup.position.x;
      const dy = lookTargetPos.y - (avatarGroup.position.y + 1.35);
      const dz = lookTargetPos.z - avatarGroup.position.z;
      const dist = Math.hypot(dx, dz);

      if (dist < 10.0 && dist > 0.3) {
        const worldAngle = Math.atan2(dx, dz);
        const relAngle = worldAngle - avatarGroup.rotation.y;
        const normAngle = Math.atan2(Math.sin(relAngle), Math.cos(relAngle));

        // Clamp yaw (+/- 55 degrees) and pitch (+/- 25 degrees)
        const clampedYaw = Math.max(-0.95, Math.min(0.95, normAngle));
        const targetPitch = -Math.atan2(dy, Math.max(1.0, dist));
        const clampedPitch = Math.max(-0.45, Math.min(0.45, targetPitch));

        headGroup.rotation.y = THREE.MathUtils.lerp(headGroup.rotation.y, clampedYaw * 0.85, 0.15);
        headGroup.rotation.x = THREE.MathUtils.lerp(headGroup.rotation.x, clampedPitch * 0.7, 0.12);
      }
    }

    // Update floating emoji particles
    for (let i = activeEmojiParticles.length - 1; i >= 0; i--) {
      const p = activeEmojiParticles[i];
      if (now < p.createdAt) {
        p.sprite.visible = false;
        continue;
      }
      p.sprite.visible = true;

      const age = now - p.createdAt;
      const progress = age / p.lifeSpan;

      if (progress >= 1) {
        avatarGroup.remove(p.sprite);
        activeEmojiParticles.splice(i, 1);
      } else {
        p.sprite.position.y += p.vy;
        p.sprite.position.x += p.vx;
        p.sprite.position.z += p.vz;

        const scale = 0.5 + Math.sin(progress * Math.PI) * 0.5;
        p.sprite.scale.set(scale, scale, 1);
        (p.sprite.material as THREE.SpriteMaterial).opacity = 1 - progress;
      }
    }

    // Pulsing audio ring when speaking and tiny blinking blue light on headphones
    if (user.isSpeaking) {
      const pulse = 1 + Math.sin(time * 12) * 0.3;
      audioWaveMesh.scale.set(pulse, 1, pulse);
      (audioWaveMesh.material as THREE.MeshBasicMaterial).color.setHex(0x22c55e);
      (audioWaveMesh.material as THREE.MeshBasicMaterial).opacity = 0.7;
      if (headphoneAccentMat) {
        headphoneAccentMat.emissiveIntensity = 3.5 + Math.sin(time * 24) * 2.5;
      }
    } else {
      audioWaveMesh.scale.set(1, 1, 1);
      (audioWaveMesh.material as THREE.MeshBasicMaterial).color.setHex(0x38bdf8);
      (audioWaveMesh.material as THREE.MeshBasicMaterial).opacity = 0.25;
      if (headphoneAccentMat) {
        headphoneAccentMat.emissiveIntensity = 0.35;
      }
    }

    // Smooth lerp screen opacity towards targetScreenOpacity (0.0 when hovered, 1.0 when unhovered)
    if (isHasActiveVideo) {
      if (Math.abs(currentScreenOpacity - targetScreenOpacity) > 0.005) {
        currentScreenOpacity = THREE.MathUtils.lerp(currentScreenOpacity, targetScreenOpacity, 0.22);
      } else {
        currentScreenOpacity = targetScreenOpacity;
      }

      videoScreenMat.opacity = currentScreenOpacity;
      screenBezelMat.opacity = currentScreenOpacity * 0.95;
      camLightMat.opacity = currentScreenOpacity;

      // Maintain Raycast Hit Detection While Hidden:
      // Keep group & children visible = true at all times so Three.js Raycaster can continuously detect pointer hover/exit even when opacity = 0
      videoScreenGroup.visible = true;
      screenBezel.visible = true;
      videoScreenMesh.visible = true;
      videoScreenBackMesh.visible = true;
      camLight.visible = true;
      hitProxyMesh.visible = true;
    } else {
      videoScreenGroup.visible = false;
    }
  };

  const updateBadge = (updatedUser: UserState) => {
    const newBadge = createPlayerBadgeSprite(updatedUser);
    badgeSprite.material.map = newBadge.material.map;
    badgeSprite.material.needsUpdate = true;
  };

  return {
    group: avatarGroup,
    headMesh: headGroup as any,
    leftArmMesh: leftArmMesh as any,
    rightArmMesh: rightArmMesh as any,
    leftForearmMesh,
    rightForearmMesh,
    leftUpperArmMesh: leftArmMesh,
    rightUpperArmMesh: rightArmMesh,
    leftLegMesh: leftLegMesh as any,
    rightLegMesh: rightLegMesh as any,
    leftShinMesh,
    rightShinMesh,
    leftThighMesh: leftLegMesh,
    rightThighMesh: rightLegMesh,
    paddleMesh,
    tennisRacquetMesh,
    scooterMeshGroup,
    speechBubbleSprite,
    audioWaveMesh,
    badgeSprite,
    videoScreenMesh,
    videoScreenGroup,
    setVideoTexture,
    setScreenHovered,
    updateScooterColors,
    updateAnimation,
    updateBadge,
    showSpeechBubble,
    triggerGesture,
    triggerEmojiParticle,
    triggerTennisSwing,
  };
}

// Generates canvas sprite for 3D floating emoji particles
export function createEmojiSprite(emoji: string): THREE.Sprite {
  const canvas = document.createElement('canvas');
  canvas.width = 128;
  canvas.height = 128;
  const ctx = canvas.getContext('2d')!;
  ctx.font = '80px sans-serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText(emoji, 64, 64);

  const texture = new THREE.CanvasTexture(canvas);
  texture.magFilter = THREE.LinearFilter;
  const spriteMat = new THREE.SpriteMaterial({ map: texture, transparent: true, opacity: 1 });
  const sprite = new THREE.Sprite(spriteMat);
  sprite.scale.set(0.6, 0.6, 1);
  return sprite;
}

// Fallback texture when camera is initialized
function createDefaultCameraTexture(name: string): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 256;
  canvas.height = 144;
  const ctx = canvas.getContext('2d')!;

  ctx.fillStyle = '#1e293b';
  ctx.fillRect(0, 0, 256, 144);

  ctx.fillStyle = '#0f172a';
  ctx.beginPath();
  ctx.arc(128, 60, 32, 0, Math.PI * 2);
  ctx.fill();

  ctx.fillStyle = '#38bdf8';
  ctx.font = 'bold 24px sans-serif';
  ctx.textAlign = 'center';
  ctx.fillText(name.charAt(0).toUpperCase(), 128, 68);

  ctx.fillStyle = '#94a3b8';
  ctx.font = '12px sans-serif';
  ctx.fillText('Zoom HD Video', 128, 120);

  const texture = new THREE.CanvasTexture(canvas);
  texture.magFilter = THREE.LinearFilter;
  return texture;
}

// Generates canvas sprite for player name badge with clean single line: [Name] • [Role]
function createPlayerBadgeSprite(user: UserState): THREE.Sprite {
  const canvas = document.createElement('canvas');
  // Ultra-crisp horizontal pill canvas
  canvas.width = 512;
  canvas.height = 72;
  const ctx = canvas.getContext('2d')!;

  const isChloe = user.id === 'npc_b1_chloe' || (user.name && user.name.toLowerCase().includes('chloe'));
  const isBenz = user.name && (user.name.toLowerCase().includes('benz') || user.name.toLowerCase().includes('carlton'));
  const isNPC = user.isNPC || user.id.startsWith('npc_') || user.id.startsWith('bot_');

  // Background rounded pill with subtle translucent dark glass backdrop
  ctx.fillStyle = 'rgba(15, 23, 42, 0.88)';
  ctx.beginPath();
  ctx.roundRect(6, 6, 500, 60, 30);
  ctx.fill();

  // Subtle border
  ctx.lineWidth = 2.5;
  if (user.isSpeaking) {
    ctx.strokeStyle = '#22c55e'; // Green pulse when speaking
  } else if (isChloe) {
    ctx.strokeStyle = 'rgba(56, 189, 248, 0.6)'; // Sky blue for Chloe
  } else if (isBenz) {
    ctx.strokeStyle = 'rgba(245, 158, 11, 0.6)'; // Amber for Benz
  } else {
    ctx.strokeStyle = user.color ? `${user.color}80` : 'rgba(99, 102, 241, 0.5)';
  }
  ctx.stroke();

  // Left status dot
  ctx.fillStyle = user.isSpeaking
    ? '#22c55e'
    : isChloe
    ? '#38bdf8'
    : isBenz
    ? '#f59e0b'
    : '#10b981';
  ctx.beginPath();
  ctx.arc(28, 36, 6, 0, Math.PI * 2);
  ctx.fill();

  // Single-line text: [Name] • [Role]
  const roleText = isChloe
    ? 'AI Lead'
    : isBenz
    ? 'Admin / Host'
    : user.department || user.statusText || (isNPC ? 'AI Colleague' : 'Member');

  ctx.textAlign = 'left';
  ctx.textBaseline = 'middle';

  // Name portion (Bold white)
  ctx.fillStyle = '#ffffff';
  ctx.font = 'bold 22px -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif';
  ctx.fillText(user.name, 46, 36);

  const nameWidth = ctx.measureText(user.name).width;

  // Bullet separator & Role portion (Subtle slate)
  ctx.fillStyle = isChloe ? '#7dd3fc' : isBenz ? '#fde68a' : '#94a3b8';
  ctx.font = 'normal 19px -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif';

  let roleString = ` • ${roleText}`;
  if (nameWidth + ctx.measureText(roleString).width > 440) {
    while (roleString.length > 5 && nameWidth + ctx.measureText(roleString + '...').width > 440) {
      roleString = roleString.slice(0, -1);
    }
    roleString += '...';
  }
  ctx.fillText(roleString, 46 + nameWidth, 36);

  const texture = new THREE.CanvasTexture(canvas);
  texture.magFilter = THREE.LinearFilter;
  texture.minFilter = THREE.LinearFilter;
  const spriteMat = new THREE.SpriteMaterial({ map: texture });
  return new THREE.Sprite(spriteMat);
}

// Generates canvas sprite for speech bubble above head
function createSpeechBubbleSprite(text: string): THREE.Sprite {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 128;
  const ctx = canvas.getContext('2d')!;

  ctx.fillStyle = '#ffffff';
  ctx.beginPath();
  ctx.roundRect(8, 8, 496, 100, 20);
  ctx.fill();

  ctx.lineWidth = 4;
  ctx.strokeStyle = '#0284c7';
  ctx.stroke();

  // Bubble tail
  ctx.beginPath();
  ctx.moveTo(240, 108);
  ctx.lineTo(256, 126);
  ctx.lineTo(272, 108);
  ctx.closePath();
  ctx.fillStyle = '#ffffff';
  ctx.fill();

  ctx.fillStyle = '#0f172a';
  ctx.font = 'bold 22px sans-serif';
  ctx.textAlign = 'center';
  ctx.fillText(text.length > 40 ? text.substring(0, 38) + '...' : text, 256, 62);

  const texture = new THREE.CanvasTexture(canvas);
  texture.magFilter = THREE.NearestFilter;
  const spriteMat = new THREE.SpriteMaterial({ map: texture });
  return new THREE.Sprite(spriteMat);
}
