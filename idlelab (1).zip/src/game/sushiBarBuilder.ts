import * as THREE from 'three';
import { UserState, AvatarSkin } from '../types';
import { createVoxelAvatarMesh } from './avatarBuilder';
import { buildLofiScenery } from './lofiScenery';
import { audioManager } from '../lib/audioManager';

export interface SushiBarController {
  sushiGroup: THREE.Group;
  cafeScreenMesh: THREE.Mesh;
  updateSushiBar: (time: number, delta: number, isPlayerSeated?: boolean, seatedPos?: { x: number; y: number; z: number }) => void;
}

interface ConveyorItem {
  mesh: THREE.Group;
  progress: number;
}

export function buildSushiBar(sceneGroup: THREE.Group, interactiveObjects: THREE.Object3D[]): SushiBarController {
  const roomGroup = new THREE.Group();
  roomGroup.name = 'LofiStudyCafe3F';

  // 3rd Floor Dimensions: (24m x 20m x 5m at Y = 11.0m)
  const CENTER_X = 0;
  const CENTER_Z = 0;
  const FLOOR_Y = 11.0;
  const WIDTH = 24;
  const DEPTH = 20;
  const HEIGHT = 5.0;

  // Architectural Minimalist Cafe Materials (Apple Visitor Center Style)
  const terrazzoFloorMat = new THREE.MeshStandardMaterial({ color: 0xf8fafc, roughness: 0.12, metalness: 0.05 }); // Pristine White Terrazzo
  const blondeOakMat = new THREE.MeshStandardMaterial({ color: 0xddb892, roughness: 0.35 }); // Natural Blonde Oak Wood
  const darkOakTrimMat = new THREE.MeshStandardMaterial({ color: 0xb08968, roughness: 0.4 });
  const pristineWhiteWallMat = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.85 }); // Clean White Wall
  const warmNicheOakMat = new THREE.MeshStandardMaterial({ color: 0xc69c6d, roughness: 0.4 }); // Warm Wood Niche Accent
  const whiteMarbleCounterMat = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.1, metalness: 0.1 }); // White Polished Marble
  const blackTrackLightingMat = new THREE.MeshStandardMaterial({ color: 0x1e293b, metalness: 0.8, roughness: 0.2 }); // Black Track Rails
  const spotLightLensMat = new THREE.MeshStandardMaterial({ color: 0xfffbe1, emissive: 0xfef08a, emissiveIntensity: 1.0 });
  const ultraClearGlassMat = new THREE.MeshStandardMaterial({ color: 0xf8fafc, transparent: true, opacity: 0.08, roughness: 0.05 });

  // Foliage Materials
  const darkLeafMat = new THREE.MeshStandardMaterial({ color: 0x15803d, roughness: 0.7 });
  const brightLeafMat = new THREE.MeshStandardMaterial({ color: 0x22c55e, roughness: 0.6 });
  const oliveLeafMat = new THREE.MeshStandardMaterial({ color: 0x166534, roughness: 0.8 });
  const hangingVineMat = new THREE.MeshStandardMaterial({ color: 0x4ade80, roughness: 0.5 });

  // Initialize Lofi Sunset Scenery & Flying Amazon Delivery Drones Outside Window
  const lofiScenery = buildLofiScenery(sceneGroup);

  // 1. PRISTINE WHITE TERRAZZO FLOOR (24m x 20m at Y = 11.0m)
  const floorMesh = new THREE.Mesh(new THREE.PlaneGeometry(WIDTH, DEPTH), terrazzoFloorMat);
  floorMesh.rotation.x = -Math.PI / 2;
  floorMesh.position.set(CENTER_X, FLOOR_Y, CENTER_Z);
  floorMesh.receiveShadow = true;
  roomGroup.add(floorMesh);

  // Subtle Light Blonde Wood Rug Accent under main central study area
  const oakFloorAccent = new THREE.Mesh(new THREE.PlaneGeometry(16.0, 12.0), blondeOakMat);
  oakFloorAccent.rotation.x = -Math.PI / 2;
  oakFloorAccent.position.set(-2.0, FLOOR_Y + 0.005, 0);
  roomGroup.add(oakFloorAccent);

  // 2. ARCHITECTURAL LIGHT BLONDE WOOD SLATTED CEILING & BLACK TRACK LIGHTING
  const ceilingBase = new THREE.Mesh(new THREE.PlaneGeometry(WIDTH, DEPTH), blondeOakMat);
  ceilingBase.rotation.x = Math.PI / 2;
  ceilingBase.position.set(CENTER_X, FLOOR_Y + HEIGHT, CENTER_Z);
  roomGroup.add(ceilingBase);

  // Linear Wood Ceiling Slats (Horizontal slats creating acoustic depth)
  for (let sz = -DEPTH / 2 + 0.3; sz <= DEPTH / 2 - 0.3; sz += 0.4) {
    const slat = new THREE.Mesh(new THREE.BoxGeometry(WIDTH - 0.2, 0.06, 0.12), darkOakTrimMat);
    slat.position.set(0, FLOOR_Y + HEIGHT - 0.03, sz);
    roomGroup.add(slat);
  }

  // Linear Black Track Light Rails (Running North-South across the ceiling)
  const trackPositionsX = [-8.0, -3.0, 2.0, 7.0];
  trackPositionsX.forEach((tx) => {
    const trackRail = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.08, DEPTH - 2.0), blackTrackLightingMat);
    trackRail.position.set(tx, FLOOR_Y + HEIGHT - 0.08, 0);
    roomGroup.add(trackRail);

    // Spotlights along each track
    for (let tz = -8.0; tz <= 8.0; tz += 3.2) {
      const spotHousing = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.05, 0.12, 12), blackTrackLightingMat);
      spotHousing.position.set(tx, FLOOR_Y + HEIGHT - 0.14, tz);

      const spotLens = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.04, 0.02, 12), spotLightLensMat);
      spotLens.position.set(tx, FLOOR_Y + HEIGHT - 0.2, tz);

      const spotLight = new THREE.SpotLight(0xfffbe1, 1.2, 12, Math.PI / 3, 0.4);
      spotLight.position.set(tx, FLOOR_Y + HEIGHT - 0.21, tz);
      spotLight.target.position.set(tx, FLOOR_Y, tz);
      roomGroup.add(spotHousing, spotLens, spotLight, spotLight.target);
    }
  });

  // BRIGHT OVERHEAD CAFETERIA AMBIENT LIGHTING
  const mainAmbientLight1 = new THREE.PointLight(0xfff8eb, 2.5, 28);
  mainAmbientLight1.position.set(-5.0, FLOOR_Y + HEIGHT - 0.8, -4.0);
  const mainAmbientLight2 = new THREE.PointLight(0xfff8eb, 2.5, 28);
  mainAmbientLight2.position.set(3.0, FLOOR_Y + HEIGHT - 0.8, -4.0);
  const mainAmbientLight3 = new THREE.PointLight(0xfff8eb, 2.5, 28);
  mainAmbientLight3.position.set(-5.0, FLOOR_Y + HEIGHT - 0.8, 4.0);
  const mainAmbientLight4 = new THREE.PointLight(0xfff8eb, 2.5, 28);
  mainAmbientLight4.position.set(3.0, FLOOR_Y + HEIGHT - 0.8, 4.0);
  roomGroup.add(mainAmbientLight1, mainAmbientLight2, mainAmbientLight3, mainAmbientLight4);

  // WARM NATURAL SUNLIGHT STREAMING THROUGH THE WEST GLASS WINDOW
  const windowSunlight = new THREE.PointLight(0xffedd5, 3.5, 32);
  windowSunlight.position.set(-WIDTH / 2 + 0.5, FLOOR_Y + HEIGHT - 1.2, 0);
  roomGroup.add(windowSunlight);

  // DESIGNER HANGING PENDANT LAMPS ABOVE TABLES & ESPRESSO BAR
  const pendantLocations = [
    { x: -7.0, z: -5.5 }, { x: -2.0, z: -5.5 }, { x: 3.0, z: -5.5 },
    { x: -7.0, z: 0.0 },  { x: -2.0, z: 0.0 },  { x: 3.0, z: 0.0 },
    { x: -7.0, z: 5.5 },  { x: -2.0, z: 5.5 },  { x: 3.0, z: 5.5 },
    { x: 10.2, z: -3.5 }, { x: 10.2, z: 0.0 },  { x: 10.2, z: 3.5 },
  ];

  const brassMat = new THREE.MeshStandardMaterial({ color: 0xd97706, metalness: 0.8, roughness: 0.2 });
  pendantLocations.forEach((pl) => {
    // Cord
    const cord = new THREE.Mesh(new THREE.CylinderGeometry(0.01, 0.01, 1.8, 8), blackTrackLightingMat);
    cord.position.set(pl.x, FLOOR_Y + HEIGHT - 0.9, pl.z);

    // Brass Shade
    const shade = new THREE.Mesh(new THREE.ConeGeometry(0.22, 0.18, 16, 1, true), brassMat);
    shade.position.set(pl.x, FLOOR_Y + HEIGHT - 1.8, pl.z);

    // Glowing Filament Bulb
    const bulb = new THREE.Mesh(new THREE.SphereGeometry(0.06, 12, 12), spotLightLensMat);
    bulb.position.set(pl.x, FLOOR_Y + HEIGHT - 1.85, pl.z);

    // Downward warm point light
    const pendantLight = new THREE.PointLight(0xfff0c2, 1.4, 7);
    pendantLight.position.set(pl.x, FLOOR_Y + HEIGHT - 1.9, pl.z);

    roomGroup.add(cord, shade, bulb, pendantLight);
  });

  // SUSPENDED GREEN CANOPY (CEILING HANGING PLANTERS WITH OVERFLOWING VINES & IVY)
  const canopyPlanterPositions = [
    { x: -7.0, z: -3.0 }, { x: -2.0, z: -3.0 }, { x: 3.0, z: -3.0 },
    { x: -7.0, z: 3.0 },  { x: -2.0, z: 3.0 },  { x: 3.0, z: 3.0 },
    { x: 0.0, z: -7.0 },   { x: 0.0, z: 7.0 },   { x: 6.0, z: -6.0 }, { x: 6.0, z: 6.0 }
  ];

  canopyPlanterPositions.forEach((cp, idx) => {
    const canopyGroup = new THREE.Group();
    canopyGroup.position.set(cp.x, FLOOR_Y + HEIGHT - 0.6, cp.z);

    // Suspended Oak Wooden Trough
    const trough = new THREE.Mesh(new THREE.BoxGeometry(2.4, 0.25, 0.6), blondeOakMat);
    canopyGroup.add(trough);

    // Support Wires
    for (const wx of [-1.0, 1.0]) {
      const wire = new THREE.Mesh(new THREE.CylinderGeometry(0.008, 0.008, 0.6, 6), blackTrackLightingMat);
      wire.position.set(wx, 0.3, 0);
      canopyGroup.add(wire);
    }

    // Dense Green Canopy Foliage inside Trough (Flush top greenery, no hanging ivy blocking scenery)
    const soilMesh = new THREE.Mesh(new THREE.BoxGeometry(2.3, 0.1, 0.5), darkLeafMat);
    soilMesh.position.y = 0.1;

    const microGreenMesh = new THREE.Mesh(new THREE.BoxGeometry(2.2, 0.12, 0.42), brightLeafMat);
    microGreenMesh.position.y = 0.18;

    canopyGroup.add(soilMesh, microGreenMesh);

    // Subtle neat foliage puffs inside the trough
    for (let vx = -0.9; vx <= 0.9; vx += 0.45) {
      const puff = new THREE.Mesh(new THREE.DodecahedronGeometry(0.18, 1), brightLeafMat);
      puff.position.set(vx, 0.22, (Math.sin(vx * 5) * 0.08));
      canopyGroup.add(puff);
    }

    roomGroup.add(canopyGroup);
  });

  // 3. WALLS & GIANT SUNSET VIEW WINDOW
  // West Wall (X = -12): Floor-to-Ceiling Ultra-Clear Glass Wall overlooking Golden Gate Bridge & Drones
  const westGlass = new THREE.Mesh(new THREE.BoxGeometry(0.1, HEIGHT, DEPTH), ultraClearGlassMat);
  westGlass.position.set(-WIDTH / 2, FLOOR_Y + HEIGHT / 2, 0);

  // Black Modern Architectural Mullion Pillars
  for (let mz = -9.0; mz <= 9.0; mz += 3.0) {
    const mullionPillar = new THREE.Mesh(new THREE.BoxGeometry(0.12, HEIGHT, 0.08), blackTrackLightingMat);
    mullionPillar.position.set(-WIDTH / 2 + 0.06, FLOOR_Y + HEIGHT / 2, mz);
    roomGroup.add(mullionPillar);
  }
  roomGroup.add(westGlass);

  // North & South Walls (Crisp Pristine White Architecture)
  const northWall = new THREE.Mesh(new THREE.BoxGeometry(WIDTH, HEIGHT, 0.3), pristineWhiteWallMat);
  northWall.position.set(0, FLOOR_Y + HEIGHT / 2, -DEPTH / 2);
  const southWall = new THREE.Mesh(new THREE.BoxGeometry(WIDTH, HEIGHT, 0.3), pristineWhiteWallMat);
  southWall.position.set(0, FLOOR_Y + HEIGHT / 2, DEPTH / 2);
  roomGroup.add(northWall, southWall);

  // East Wall (X = 12): Pristine White Feature Wall with Recessed Oak Niche & White Espresso Counter
  const eastWall = new THREE.Mesh(new THREE.BoxGeometry(0.3, HEIGHT, DEPTH), pristineWhiteWallMat);
  eastWall.position.set(WIDTH / 2, FLOOR_Y + HEIGHT / 2, 0);
  roomGroup.add(eastWall);

  // 4. EMBEDDED OAK RECESSED NICHE & WHITE MARBLE REFRESHMENT COUNTER (EAST WALL)
  const nicheGroup = new THREE.Group();
  nicheGroup.position.set(WIDTH / 2 - 0.6, FLOOR_Y + 2.2, 0);

  // Backing warm oak wall inside the niche
  const nicheBack = new THREE.Mesh(new THREE.BoxGeometry(0.1, 2.2, 12.0), warmNicheOakMat);
  nicheBack.position.set(0.4, 0, 0);

  // Top & Bottom warm oak frame for the alcove
  const nicheTop = new THREE.Mesh(new THREE.BoxGeometry(1.0, 0.1, 12.0), warmNicheOakMat);
  nicheTop.position.set(-0.05, 1.1, 0);
  const nicheBottom = new THREE.Mesh(new THREE.BoxGeometry(1.0, 0.1, 12.0), warmNicheOakMat);
  nicheBottom.position.set(-0.05, -1.1, 0);
  nicheGroup.add(nicheBack, nicheTop, nicheBottom);

  // Warm LED Strip Light along the top of the niche
  const nicheLight = new THREE.PointLight(0xffedd5, 1.2, 10);
  nicheLight.position.set(-0.2, 0.9, 0);
  nicheGroup.add(nicheLight);

  roomGroup.add(nicheGroup);

  // Sleek White Marble Espresso Counter (Fronting the Niche)
  const counterGroup = new THREE.Group();
  const COUNTER_X = WIDTH / 2 - 1.8; // X = 10.2
  counterGroup.position.set(COUNTER_X, FLOOR_Y, 0);

  const mainCounterBody = new THREE.Mesh(
    new THREE.BoxGeometry(1.2, 0.95, 13.0),
    whiteMarbleCounterMat
  );
  mainCounterBody.position.y = 0.475;

  // Commercial Double-Group Espresso Machines & Grinders
  const espressoMachine1 = new THREE.Mesh(
    new THREE.BoxGeometry(0.7, 0.55, 0.9),
    new THREE.MeshStandardMaterial({ color: 0x334155, metalness: 0.9, roughness: 0.1 })
  );
  espressoMachine1.position.set(-0.1, 1.22, -3.5);

  const espressoMachine2 = new THREE.Mesh(
    new THREE.BoxGeometry(0.7, 0.55, 0.9),
    new THREE.MeshStandardMaterial({ color: 0x334155, metalness: 0.9, roughness: 0.1 })
  );
  espressoMachine2.position.set(-0.1, 1.22, 3.5);

  const grinder1 = new THREE.Mesh(
    new THREE.CylinderGeometry(0.12, 0.15, 0.5, 16),
    blackTrackLightingMat
  );
  grinder1.position.set(-0.1, 1.2, -2.2);

  const grinder2 = new THREE.Mesh(
    new THREE.CylinderGeometry(0.12, 0.15, 0.5, 16),
    blackTrackLightingMat
  );
  grinder2.position.set(-0.1, 1.2, 2.2);

  // Pastry & Refreshment Glass Display Counter
  const glassDisplayCase = new THREE.Mesh(
    new THREE.BoxGeometry(0.8, 0.45, 3.2),
    new THREE.MeshStandardMaterial({ color: 0xffffff, transparent: true, opacity: 0.3 })
  );
  glassDisplayCase.position.set(-0.05, 1.17, 0);

  // Pastries inside display
  for (let pz = -1.1; pz <= 1.1; pz += 0.55) {
    const pastryPlate = new THREE.Mesh(
      new THREE.CylinderGeometry(0.16, 0.14, 0.02, 16),
      pristineWhiteWallMat
    );
    pastryPlate.position.set(-0.05, 0.97, pz);

    const croissant = new THREE.Mesh(
      new THREE.TorusGeometry(0.07, 0.025, 8, 12),
      new THREE.MeshStandardMaterial({ color: 0xd97706, roughness: 0.6 })
    );
    croissant.rotation.x = Math.PI / 2;
    croissant.position.set(-0.05, 1.01, pz);
    counterGroup.add(pastryPlate, croissant);
  }

  counterGroup.add(mainCounterBody, espressoMachine1, espressoMachine2, grinder1, grinder2, glassDisplayCase);
  roomGroup.add(counterGroup);

  // 5. CAFE & STUDY MENU CHALKBOARD/DIGITAL BOARD
  const menuCanvas = document.createElement('canvas');
  menuCanvas.width = 512;
  menuCanvas.height = 256;
  const mCtx = menuCanvas.getContext('2d')!;
  mCtx.fillStyle = '#0f172a';
  mCtx.fillRect(0, 0, 512, 256);
  mCtx.strokeStyle = '#38bdf8';
  mCtx.lineWidth = 6;
  mCtx.strokeRect(8, 8, 496, 240);

  mCtx.fillStyle = '#fef08a';
  mCtx.font = 'bold 34px sans-serif';
  mCtx.textAlign = 'center';
  mCtx.fillText('☕ VISITOR CENTER CAFE 🌿', 256, 65);
  mCtx.fillStyle = '#ffffff';
  mCtx.font = '22px monospace';
  mCtx.fillText('• Pour Over • Flat White • Matcha Latte', 256, 120);
  mCtx.fillText('• Organic Pastries • Cold Brew', 256, 160);
  mCtx.fillStyle = '#4ade80';
  mCtx.font = '20px sans-serif';
  mCtx.fillText('🎧 24/7 Lofi Beats & Olive Grove View', 256, 210);

  const menuTex = new THREE.CanvasTexture(menuCanvas);
  menuTex.magFilter = THREE.NearestFilter;
  const menuSignMesh = new THREE.Mesh(
    new THREE.PlaneGeometry(4.8, 2.4),
    new THREE.MeshBasicMaterial({ map: menuTex })
  );
  menuSignMesh.userData = { idleTexture: menuTex, isScreen: true };
  menuSignMesh.position.set(COUNTER_X + 0.6, FLOOR_Y + 3.0, 0);
  menuSignMesh.rotation.y = -Math.PI / 2;
  interactiveObjects.push(menuSignMesh);
  roomGroup.add(menuSignMesh);

  // 6. ARCHITECTURAL BLONDE OAK STUDY & DINING TABLES (LIKE THE REFERENCE PHOTO)
  // Grid of Scandinavian Light Oak Square/Rectangular Tables
  const tablePositions = [
    { x: -7.0, z: -5.5 }, { x: -2.0, z: -5.5 }, { x: 3.0, z: -5.5 },
    { x: -7.0, z: 0.0 },  { x: -2.0, z: 0.0 },  { x: 3.0, z: 0.0 },
    { x: -7.0, z: 5.5 },  { x: -2.0, z: 5.5 },  { x: 3.0, z: 5.5 },
  ];

  tablePositions.forEach((pos, index) => {
    const tableGroup = new THREE.Group();
    tableGroup.position.set(pos.x, FLOOR_Y, pos.z);

    // Natural Blonde Oak Table Top
    const tableTop = new THREE.Mesh(
      new THREE.BoxGeometry(2.2, 0.08, 1.8),
      blondeOakMat
    );
    tableTop.position.y = 0.74;

    // 4 Slim Wooden Legs
    for (const [lx, lz] of [[-0.9, -0.7], [0.9, -0.7], [-0.9, 0.7], [0.9, 0.7]]) {
      const leg = new THREE.Mesh(
        new THREE.CylinderGeometry(0.04, 0.03, 0.7, 12),
        blondeOakMat
      );
      leg.position.set(lx, 0.35, lz);
      tableGroup.add(leg);
    }
    tableGroup.add(tableTop);

    // Coffee Mug / Laptop / Notes on Tables
    if (index % 2 === 0) {
      const laptop = new THREE.Mesh(
        new THREE.BoxGeometry(0.45, 0.02, 0.32),
        new THREE.MeshStandardMaterial({ color: 0xe2e8f0, metalness: 0.9, roughness: 0.1 })
      );
      laptop.position.set(-0.3, 0.79, 0);
      tableGroup.add(laptop);
    }

    const coffeeMug = new THREE.Mesh(
      new THREE.CylinderGeometry(0.06, 0.05, 0.1, 12),
      pristineWhiteWallMat
    );
    coffeeMug.position.set(0.4, 0.83, 0.2);
    tableGroup.add(coffeeMug);

    roomGroup.add(tableGroup);

    // Matching Blonde Oak Chairs around each table
    const chairOffsets = [
      { dx: -1.4, dz: 0, rotY: Math.PI / 2 },
      { dx: 1.4, dz: 0, rotY: -Math.PI / 2 },
      { dx: 0, dz: -1.1, rotY: 0 },
      { dx: 0, dz: 1.1, rotY: Math.PI },
    ];

    chairOffsets.forEach((co, cIdx) => {
      const chairSeat = new THREE.Mesh(
        new THREE.BoxGeometry(0.5, 0.05, 0.5),
        blondeOakMat
      );
      const chairX = pos.x + co.dx;
      const chairZ = pos.z + co.dz;
      chairSeat.position.set(chairX, FLOOR_Y + 0.42, chairZ);
      chairSeat.rotation.y = co.rotY;

      // Curved Backrest
      const backrest = new THREE.Mesh(
        new THREE.BoxGeometry(0.5, 0.4, 0.05),
        blondeOakMat
      );
      backrest.position.set(0, 0.22, -0.22);
      chairSeat.add(backrest);

      // Chair Legs
      for (const [clx, clz] of [[-0.2, -0.2], [0.2, -0.2], [-0.2, 0.2], [0.2, 0.2]]) {
        const chairLeg = new THREE.Mesh(
          new THREE.CylinderGeometry(0.025, 0.02, 0.4, 8),
          blondeOakMat
        );
        chairLeg.position.set(clx, -0.2, clz);
        chairSeat.add(chairLeg);
      }

      // Make chairs clickable for sitting
      chairSeat.userData = {
        isMeetingChair: true,
        seatPos: { x: chairX, y: FLOOR_Y, z: chairZ },
        rotY: co.rotY,
      };
      interactiveObjects.push(chairSeat);
      roomGroup.add(chairSeat);
    });

    // Potted Succulent / Fern on each study table
    const tablePlantPot = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.06, 0.1, 12), pristineWhiteWallMat);
    tablePlantPot.position.set(-0.4, 0.83, 0.2);
    const tablePlantLeaves = new THREE.Mesh(new THREE.DodecahedronGeometry(0.12, 1), brightLeafMat);
    tablePlantLeaves.position.set(-0.4, 0.92, 0.2);
    tableGroup.add(tablePlantPot, tablePlantLeaves);
  });

  // 6.5. ARCHITECTURAL OLIVE GROVE TREES & GREEN HEDGE PLANTER DIVIDERS
  // Tall Olive / Ficus Trees along the west window wall and room corners
  const treePositions = [
    { x: -11.0, z: -8.0 }, { x: -11.0, z: -2.5 }, { x: -11.0, z: 2.5 }, { x: -11.0, z: 8.0 },
    { x: 7.5, z: -8.0 },  { x: 7.5, z: 8.0 },   { x: -4.5, z: -8.5 }, { x: -4.5, z: 8.5 }
  ];

  treePositions.forEach((tp) => {
    const treeGroup = new THREE.Group();
    treeGroup.position.set(tp.x, FLOOR_Y, tp.z);

    // Modern White Ceramic Pot
    const ceramicPot = new THREE.Mesh(new THREE.CylinderGeometry(0.45, 0.35, 0.9, 16), pristineWhiteWallMat);
    ceramicPot.position.y = 0.45;

    // Soil
    const soil = new THREE.Mesh(new THREE.CylinderGeometry(0.42, 0.4, 0.05, 16), darkLeafMat);
    soil.position.y = 0.88;

    // Wooden Trunk
    const trunk = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.12, 1.8, 10), darkOakTrimMat);
    trunk.position.y = 1.6;

    // Multi-layered Lush Leafy Canopy
    const leafCanopy1 = new THREE.Mesh(new THREE.DodecahedronGeometry(0.9, 2), oliveLeafMat);
    leafCanopy1.position.y = 2.6;

    const leafCanopy2 = new THREE.Mesh(new THREE.DodecahedronGeometry(0.7, 2), brightLeafMat);
    leafCanopy2.position.set(0.2, 3.1, -0.1);

    const leafCanopy3 = new THREE.Mesh(new THREE.DodecahedronGeometry(0.65, 2), darkLeafMat);
    leafCanopy3.position.set(-0.25, 2.8, 0.2);

    treeGroup.add(ceramicPot, soil, trunk, leafCanopy1, leafCanopy2, leafCanopy3);
    roomGroup.add(treeGroup);
  });

  // Green Hedge Planter Dividers (Low wooden troughs with lush foliage between seating rows)
  const dividerPositions = [
    { x: -4.5, z: -2.8, w: 7.0, d: 0.5 },
    { x: -4.5, z: 2.8, w: 7.0, d: 0.5 },
    { x: 0.5, z: -2.8, w: 5.0, d: 0.5 },
    { x: 0.5, z: 2.8, w: 5.0, d: 0.5 }
  ];

  dividerPositions.forEach((dp) => {
    const dividerGroup = new THREE.Group();
    dividerGroup.position.set(dp.x, FLOOR_Y, dp.z);

    // Oak Planter Box
    const box = new THREE.Mesh(new THREE.BoxGeometry(dp.w, 0.6, dp.d), blondeOakMat);
    box.position.y = 0.3;

    // Dense Green Hedge Bush
    const hedge = new THREE.Mesh(new THREE.BoxGeometry(dp.w - 0.1, 0.5, dp.d - 0.1), brightLeafMat);
    hedge.position.y = 0.75;

    // Leafy Top Texture
    for (let hx = -dp.w / 2 + 0.4; hx <= dp.w / 2 - 0.4; hx += 0.6) {
      const puff = new THREE.Mesh(new THREE.DodecahedronGeometry(0.32, 1), darkLeafMat);
      puff.position.set(hx, 0.9, 0);
      dividerGroup.add(puff);
    }

    dividerGroup.add(box, hedge);
    roomGroup.add(dividerGroup);
  });

  // 7. ICONIC LOFI GIRL NPC AT HER FAVORITE WINDOW STUDY TABLE
  const lofiTableX = -7.0;
  const lofiTableZ = 0.0;

  // LOFI GIRL USER STATE & AVATAR (East Asian American demographic, chestnut hair, stylish green aesthetic)
  const lofiUser: UserState = {
    id: 'npc_lofi_girl',
    name: 'Lofi Girl',
    skin: 'college_dev_f',
    department: 'Design',
    ethnicity: 'east_asian_1',
    hairColor: '#2b1810',
    position: { x: lofiTableX - 1.4, y: FLOOR_Y, z: lofiTableZ },
    rotationY: Math.PI / 2,
    isMoving: false,
    isSpeaking: false,
    isMuted: true,
    isScreenSharing: false,
    claimedDeskId: null,
    statusText: 'Studying 24/7 Lofi Beats 🎧',
    color: '#16a34a',
  };

  const lofiAvatar = createVoxelAvatarMesh(lofiUser);
  lofiAvatar.group.position.set(lofiTableX - 1.4, FLOOR_Y, lofiTableZ);
  lofiAvatar.group.rotation.y = Math.PI / 2;

  // Seated Posture with 90-degree Hips & Knees
  lofiAvatar.updateAnimation(0, false, false, true);
  lofiAvatar.group.updateMatrixWorld(true);

  // Orange Tabby Cat sitting on table next to Lofi Girl
  const lofiCatGroup = new THREE.Group();
  lofiCatGroup.position.set(lofiTableX - 0.3, FLOOR_Y + 0.78, lofiTableZ + 0.4);

  const catBodyMesh = new THREE.Mesh(new THREE.BoxGeometry(0.24, 0.14, 0.18), new THREE.MeshStandardMaterial({ color: 0xf97316 }));
  catBodyMesh.position.y = 0.07;
  const catHeadMesh = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.14, 0.14), new THREE.MeshStandardMaterial({ color: 0xf97316 }));
  catHeadMesh.position.set(-0.12, 0.16, 0);
  const catTailMesh = new THREE.Mesh(new THREE.BoxGeometry(0.18, 0.04, 0.04), new THREE.MeshStandardMaterial({ color: 0xea580c }));
  catTailMesh.position.set(0.14, 0.08, 0.08);

  lofiCatGroup.add(catBodyMesh, catHeadMesh, catTailMesh);
  roomGroup.add(lofiCatGroup);

  // Single clean overhead nameplate badge automatically created by createVoxelAvatarMesh
  roomGroup.add(lofiAvatar.group);

  // 8. MASTER BARISTA ALEX RODRIGUEZ NPC AT THE MARBLE ESPRESSO COUNTER (Latino American demographic)
  const chefUser: UserState = {
    id: 'npc_barista_alex',
    name: 'Alex Rodriguez',
    skin: 'college_dev_m',
    department: 'Operations',
    ethnicity: 'latino_2',
    hairColor: '#1c120c',
    position: { x: COUNTER_X - 0.8, y: FLOOR_Y, z: 0 },
    rotationY: -Math.PI / 2,
    isMoving: false,
    isSpeaking: false,
    isMuted: true,
    isScreenSharing: false,
    claimedDeskId: null,
    statusText: 'Brewing Artisanal Coffee ☕',
    color: '#16a34a',
  };

  const baristaAvatar = createVoxelAvatarMesh(chefUser);
  baristaAvatar.group.position.set(COUNTER_X - 0.8, FLOOR_Y, 0);
  baristaAvatar.group.rotation.y = -Math.PI / 2;

  // Single clean overhead nameplate badge automatically created by createVoxelAvatarMesh
  roomGroup.add(baristaAvatar.group);

  // 9. POPULATED EMPLOYEES & GUEST NPCS SITTING AT CAFE TABLES (English first name + native surname, blondes & brunettes)
  const dinerConfigs: Array<{ name: string; role: string; skin: AvatarSkin; ethnicity: string; hairColor: string; x: number; z: number; rotY: number; color: string }> = [
    { name: 'Emma Schneider', role: 'Creative Director 🎨', skin: 'college_dev_f', ethnicity: 'caucasian_1', hairColor: '#c89849', x: -2.0 + 1.4, z: -5.5, rotY: -Math.PI / 2, color: '#f97316' },
    { name: 'David Tanaka', role: 'Senior AI Researcher 🤖', skin: 'college_dev_m', ethnicity: 'east_asian_1', hairColor: '#0f0f11', x: 3.0 - 1.4, z: -5.5, rotY: Math.PI / 2, color: '#a855f7' },
    { name: 'Sophie Laurent', role: 'UX Architect 💡', skin: 'college_dev_f', ethnicity: 'caucasian_2', hairColor: '#5c2b0e', x: -2.0 + 1.4, z: 5.5, rotY: -Math.PI / 2, color: '#f43f5e' },
    { name: 'Ryan Patel', role: 'Staff Cloud Engineer ⚡', skin: 'college_dev_m', ethnicity: 'south_asian_1', hairColor: '#0f0f11', x: 3.0 - 1.4, z: 5.5, rotY: Math.PI / 2, color: '#eab308' },
  ];

  dinerConfigs.forEach((npc, index) => {
    const dinerUser: UserState = {
      id: `npc_student_${index}`,
      name: npc.name,
      skin: npc.skin,
      department: 'Design',
      ethnicity: npc.ethnicity,
      hairColor: npc.hairColor,
      position: { x: npc.x, y: FLOOR_Y, z: npc.z },
      rotationY: npc.rotY,
      isMoving: false,
      isSpeaking: false,
      isMuted: true,
      isScreenSharing: false,
      claimedDeskId: null,
      statusText: npc.role,
      color: npc.color,
    };

    const dinerAvatar = createVoxelAvatarMesh(dinerUser);
    dinerAvatar.group.position.set(npc.x, FLOOR_Y, npc.z);
    dinerAvatar.group.rotation.y = npc.rotY;

    // Seated Posture with 90-degree Hips & Knees
    dinerAvatar.updateAnimation(0, false, false, true);
    dinerAvatar.group.updateMatrixWorld(true);

    // Single clean overhead nameplate badge automatically created by createVoxelAvatarMesh
    roomGroup.add(dinerAvatar.group);
  });

  // 10. ROOFTOP TERRACE GARDEN (Y = 16.0m)
  const roofGroup = new THREE.Group();
  roofGroup.position.set(0, FLOOR_Y + HEIGHT, 0);

  const roofDeck = new THREE.Mesh(
    new THREE.PlaneGeometry(WIDTH, DEPTH),
    blondeOakMat
  );
  roofDeck.rotation.x = -Math.PI / 2;
  roofGroup.add(roofDeck);

  const glassRailMat = new THREE.MeshStandardMaterial({ color: 0x38bdf8, transparent: true, opacity: 0.25 });
  const railNorth = new THREE.Mesh(new THREE.BoxGeometry(WIDTH, 1.1, 0.08), glassRailMat);
  railNorth.position.set(0, 0.55, -DEPTH / 2);
  const railSouth = new THREE.Mesh(new THREE.BoxGeometry(WIDTH, 1.1, 0.08), glassRailMat);
  railSouth.position.set(0, 0.55, DEPTH / 2);
  const railWest = new THREE.Mesh(new THREE.BoxGeometry(0.08, 1.1, DEPTH), glassRailMat);
  railWest.position.set(-WIDTH / 2, 0.55, 0);
  roofGroup.add(railNorth, railSouth, railWest);

  for (const [tx, tz] of [[-9, -6], [-9, 6], [9, -6], [9, 6]]) {
    const gardenGroup = new THREE.Group();
    gardenGroup.position.set(tx, 0, tz);

    const pot = new THREE.Mesh(new THREE.CylinderGeometry(0.4, 0.3, 0.8, 12), pristineWhiteWallMat);
    pot.position.y = 0.4;

    const plant = new THREE.Mesh(new THREE.DodecahedronGeometry(1.2, 1), new THREE.MeshStandardMaterial({ color: 0x15803d }));
    plant.position.y = 1.6;

    gardenGroup.add(pot, plant);
    roofGroup.add(gardenGroup);
  }

  roomGroup.add(roofGroup);
  sceneGroup.add(roomGroup);

  return {
    sushiGroup: roomGroup,
    cafeScreenMesh: menuSignMesh,
    updateSushiBar: (time: number, delta: number) => {
      // 1. Animate Cat Tail & Barista
      if (catTailMesh) {
        catTailMesh.rotation.y = 0.4 + Math.sin(time * 3) * 0.2;
      }

      if (baristaAvatar) {
        baristaAvatar.rightArmMesh.rotation.x = -Math.PI * 0.25 + Math.sin(time * 6) * 0.15;
        if (baristaAvatar.rightForearmMesh) {
          baristaAvatar.rightForearmMesh.rotation.x = -Math.PI * 0.40 + Math.sin(time * 6) * 0.20;
        }
      }

      // 2. Update Lofi Scenery & Flying Amazon Delivery Drones Outside Window
      lofiScenery.updateLofiScenery(time, delta);
    },
  };
}
