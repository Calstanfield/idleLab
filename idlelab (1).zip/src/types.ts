export type AvatarSkin = 
  | 'college_dev_m'     // Indie Male Developer Mascot (Orange/Customizable Hoodie)
  | 'college_dev_f'     // Indie Female Developer Mascot (Cyan/Customizable Hoodie)
  | 'human_dev';        // Developer Mascot Alias

export type Department = 'Engineering' | 'Design' | 'Product' | 'Marketing' | 'Executive' | 'Operations';

export interface Position3D {
  x: number;
  y: number;
  z: number;
}

export interface ScooterConfig {
  frameColor: string; // E.g., #84cc16 (Lime), #18181b (Stealth), #06b6d4 (Cyan), #ef4444 (Red), #eab308 (Solar)
  gripColor?: string;  // E.g., #ef4444 (Flame Red as in photo), #84cc16 (Lime), #06b6d4 (Cyan), #18181b (Black)
  accentColor?: string;
  underglowColor?: string; // E.g., #84cc16 (Lime), #06b6d4 (Cyan), #ec4899 (Magenta), #eab308 (Gold), none
  underglowEnabled?: boolean;
  deckColor?: string;
  deckMatColor?: string;
  rimColor?: string;
  gripTapeColor?: string;
  decalText?: string;
  style?: string;
  modelName?: string;
}

export interface UserState {
  id: string;
  name: string;
  skin: AvatarSkin;
  department: Department;
  position: Position3D;
  rotationY: number;
  isMoving: boolean;
  isSpeaking: boolean;
  isMuted: boolean;
  isScreenSharing: boolean;
  claimedDeskId: string | null;
  statusText: string;
  color: string;
  hoodieColor?: string;
  hairColor?: string;
  skinTone?: string;
  ethnicity?: string;
  pantsColor?: string;
  shoesColor?: string;
  capColor?: string;
  scarfColor?: string;
  isNPC?: boolean;
  isRidingScooter?: boolean;
  isAutoRiding?: boolean;
  scooterConfig?: ScooterConfig;
}

export type DeskTheme = 'dark_oak' | 'spruce' | 'cherry' | 'white_marble' | 'cyber_neon';
export type DeskGear = 'dual_monitors' | 'pixel_laptop' | 'coffee_plant' | 'retro_arcade' | 'designer_tablet';

export interface DeskData {
  id: string;
  x: number;
  z: number;
  label: string;
  ownerId: string | null;
  ownerName: string | null;
  theme: DeskTheme;
  gear: DeskGear;
  customStatus: string;
}

export interface StickyNote {
  id: string;
  text: string;
  color: string;
  position: { x: number; y: number };
  connectedTo?: string[]; // Target Sticky Note IDs
  bgHex?: string;
  author?: string;
  isRefining?: boolean;
}

export interface WhiteboardStroke {
  id: string;
  userId: string;
  userName: string;
  color: string;
  width: number;
  points: Array<{ x: number; y: number }>;
  type?: 'pen' | 'text' | 'sticky' | 'line' | 'rect' | 'circle';
  text?: string;
}

export interface ChatMessage {
  id: string;
  senderId: string;
  senderName: string;
  senderSkin: AvatarSkin;
  text: string;
  timestamp: number;
  isProximity: boolean;
  position?: Position3D;
  isPrivate?: boolean;
  recipientId?: string;
  recipientName?: string;
  curatedMedia?: CuratedMediaItem[];
  suggestedActions?: string[];
  activeSubAgent?: string;
}

export interface ChecklistItem {
  id: string;
  text: string;
  completed: boolean;
  category: 'Task' | 'Feature' | 'Bug' | 'Note';
  assignedTo?: string;
  color: string;
}

export interface SavedContactNote {
  id: string;
  name: string;
  role: string;
  department: string;
  email: string;
  phone: string;
  note: string;
  color: string;
  createdAt: string;
}

export type GestureType = 'wave' | 'dance' | 'clap' | 'bow' | 'think' | 'cheer' | 'heart' | 'facepalm';

export type WebRTCSignalType = 'offer' | 'answer' | 'ice-candidate' | 'screen-offer' | 'screen-answer' | 'screen-candidate';

export interface WebRTCSignalPayload {
  fromUserId: string;
  toUserId: string;
  type: WebRTCSignalType;
  sdp?: RTCSessionDescriptionInit;
  candidate?: RTCIceCandidateInit;
  cameraStreamId?: string;
  screenStreamId?: string;
}

export interface DataCenterBookmark {
  id: string;
  title: string;
  url: string;
  category: 'Production' | 'Staging & Dev' | 'Monitoring & Logs' | 'Design & Figma' | 'Documentation' | 'Cloud & Infra' | 'General';
  description?: string;
  tags?: string[];
  createdAt: number;
  createdBy?: string;
  pinned?: boolean;
}

export interface LibraryBook {
  id: string;
  title: string;
  author: string;
  category: string;
  summary: string;
  keyTakeaway: string;
  color: string;
  pages: number;
  rating: number;
  readUrl?: string;
}

export interface CoffeeOrder {
  id: string;
  name: string;
  tagline: string;
  roast: 'Dark' | 'Medium' | 'Blonde' | 'Nitro';
  temp: 'Hot' | 'Iced' | 'Nitro Cold';
  milk: 'Whole' | 'Oat' | 'Almond' | 'None';
  caffeineMg: number;
  brewTimeSec: number;
  color: string;
  emoji: string;
  buffDescription: string;
}

// ==========================================
// Healthcare Pomodoro Companion Types
// ==========================================

export type HealthPomodoroMode = 'screen_break' | 'hydration' | 'workout' | 'sleep';

export interface HealthPomodoro {
  id: string;
  activeMode: HealthPomodoroMode;
  timerDurationMinutes: number; // Screen Break (25m), Hydration (45m), Workout (60m), Sleep Schedule (480m)
  remainingSeconds: number;
  isRunning: boolean;
  autoRepeat: boolean;
  soundEnabled: boolean;
  customMessage?: string;
  completedCycles?: number;
  lastCompletedTimestamp?: number;
}

// ==========================================
// Smart AI Meeting Agent & Simulator Types
// ==========================================

export type MeetingStatus = 'idle' | 'in_progress' | 'paused' | 'ended';

export interface MeetingAgendaItem {
  id: string;
  title: string;
  durationMinutes: number;
  completed: boolean;
  status: 'pending' | 'active' | 'completed' | 'overtime';
  elapsedSeconds?: number;
  notes?: string;
}

export interface MeetingActionItem {
  id: string;
  task: string;
  assignee: string;
  priority: 'low' | 'medium' | 'high' | 'urgent';
  deadline: string;
  status: 'open' | 'in_progress' | 'completed';
  category: string;
  suggestedByAgent?: boolean;
}

export interface MeetingDecision {
  id: string;
  title: string;
  context: string;
  consensusScore: number; // 0 - 100%
  timestamp: string;
}

export type InterventionType = 
  | 'time_check' 
  | 'topic_drift' 
  | 'speaking_equity' 
  | 'consensus_prompt' 
  | 'clarification' 
  | 'summarize'
  | 'devil_advocate';

export interface MeetingIntervention {
  id: string;
  type: InterventionType;
  title: string;
  message: string;
  suggestedAction: string;
  timestamp: number;
  urgency: 'low' | 'medium' | 'high';
  dismissed?: boolean;
  executed?: boolean;
}

export interface MeetingHealthMetrics {
  engagementScore: number; // 0 - 100
  sentimentScore: number;  // -1 to +1
  sentimentLabel: 'Positive' | 'Neutral' | 'Constructive / Tense' | 'High Energy';
  pacingScore: number;     // 0 - 100
  topicAdherence: number;  // 0 - 100
  speakingBalance: { [participantName: string]: number }; // percentage 0-100
}

export interface SimulatedAgentPersona {
  id: string;
  name: string;
  role: string;
  department: Department;
  avatarSkin: AvatarSkin;
  personalityPrompt: string;
  speakingFrequency: 'high' | 'medium' | 'low';
  color: string;
  hoodieColor: string;
  position?: Position3D;
}

export interface MeetingSimulationScenario {
  id: string;
  title: string;
  description: string;
  category: 'Product & Strategy' | 'Architecture & Tech' | 'Incident & Ops' | 'Agile & Retro';
  defaultDurationMin: number;
  participants: SimulatedAgentPersona[];
  agenda: MeetingAgendaItem[];
  contextPrompt: string;
  potentialBlockers: string[];
}

export interface MeetingSessionState {
  title: string;
  status: MeetingStatus;
  startTime: number | null;
  durationSec: number;
  currentAgendaIndex: number;
  agenda: MeetingAgendaItem[];
  actionItems: MeetingActionItem[];
  decisions: MeetingDecision[];
  interventions: MeetingIntervention[];
  health: MeetingHealthMetrics;
  isSimulatorActive: boolean;
  currentScenarioId?: string;
  autoModerate: boolean;
}

export interface MeetingExecutiveSummary {
  overview: string;
  keyDecisions: string[];
  actionItemsMatrix: MeetingActionItem[];
  takeaways: string[];
  followUpEmail: string;
  meetingScore: number;
  metricsSummary: string;
}

// Chloe Becker Executive Collaborative Partner Types
export type ChloePillar = 'report_audit' | 'project_planning' | 'travel_logistics' | 'intellectual_sparring' | 'research_enrichment';

export interface ChloeDocumentAuditResult {
  fileName: string;
  executiveScore: number;
  signOffStatus: 'Ready for Leadership' | 'Revisions Required' | 'Critical Blocker';
  summary: string;
  strengths: string[];
  logicalVulnerabilities: Array<{
    issue: string;
    severity: 'low' | 'medium' | 'high' | 'critical';
    recommendation: string;
    redlineBefore?: string;
    redlineAfter?: string;
  }>;
  complianceAndSafetyFlags: Array<{
    rule: string;
    risk: string;
    fix: string;
  }>;
  missingDataPoints: string[];
  toneAssessment: {
    tone: string;
    polishScore: number;
    feedback: string;
  };
  chloeVerdict: string;
}

export interface ChloeSparringResult {
  topic: string;
  intensity: 'constructive' | 'sharp_colleague' | 'ruthless_devil';
  corePremise: string;
  blindSpots: string[];
  failureModes: Array<{
    scenario: string;
    probability: 'Low' | 'Medium' | 'High';
    impact: 'Moderate' | 'Severe' | 'Catastrophic';
    countermeasure: string;
  }>;
  leadershipObjections: Array<{
    stakeholder: string;
    objection: string;
    winningResponse: string;
  }>;
  stressTestedRecommendation: string;
  chloeDirectFeedback: string;
}

export interface ChloeTravelItinerary {
  destination: string;
  dates: string;
  purpose: string;
  weatherForecast: {
    temp: string;
    condition: string;
    advisory: string;
    rainChance?: string;
  };
  flightOptions: Array<{
    airline: string;
    route: string;
    departure: string;
    arrival: string;
    estCost: string;
    recommendation: string;
  }>;
  hotelRecommendations: Array<{
    name: string;
    proximity: string;
    nightlyRate: string;
    perks: string;
  }>;
  executiveSchedule: Array<{
    time: string;
    activity: string;
    location: string;
    notes: string;
  }>;
  packingAndPrepChecklist: string[];
  expenseEstimate: {
    flights: number;
    lodging: number;
    mealsAndTransfers: number;
    total: number;
    currency: string;
  };
  chloeTravelTips: string[];
}

export interface ChloeResearchEnrichment {
  topic: string;
  newsArticles: Array<{
    title: string;
    source: string;
    url: string;
    publishedAt: string;
    snippet: string;
    relevance: string;
  }>;
  youtubeVideos: Array<{
    id: string;
    title: string;
    channelTitle: string;
    url: string;
    thumbnail: string;
    description: string;
    duration?: string;
  }>;
  podcasts: Array<{
    title: string;
    podcastName: string;
    audioUrl?: string;
    thumbnail: string;
    description: string;
    listenUrl: string;
  }>;
  webInsights: Array<{
    title: string;
    link: string;
    snippet: string;
  }>;
  chloeSynthesis: string;
}

export type CulturalCategory =
  | 'Gaming & Creator Culture'
  | 'Internet Culture & Tech News'
  | 'Cozy Escapes & Ambient Media'
  | 'Cinematic & Pop Culture Clips';

export interface CuratedMediaItem {
  id: string;
  title: string;
  videoId: string;
  url: string;
  category: CulturalCategory | string;
  description: string;
  tag?: string;
  channel?: string;
  creator?: string;
  duration?: string;
  thumbnailUrl?: string;
  isLive?: boolean;
}

export interface ChloeChatMessage {
  id: string;
  role: 'user' | 'chloe';
  text: string;
  timestamp: number;
  pillar?: ChloePillar;
  suggestedActions?: string[];
  curatedMedia?: CuratedMediaItem[];
  auditData?: ChloeDocumentAuditResult;
  sparData?: ChloeSparringResult;
  travelData?: ChloeTravelItinerary;
  researchData?: ChloeResearchEnrichment;
}

export interface OfficeProjectionState {
  active: boolean;
  videoId: string;
  title: string;
  category?: string;
  channel?: string;
  description?: string;
  startedAt: number;
  isPlaying: boolean;
  playbackTimeSec?: number;
  projectorName: string;
  isProactive?: boolean;
  contextReason?: string;
  errorCode?: number | string;
  errorMessage?: string;
  errorFallback?: boolean;
}

export type ChloeNpcState = 'IDLE' | 'NAVIGATING_TO_DESK' | 'FACILITATING_HUDDLE' | 'EXECUTING_WORKFLOW';

export type SpatialZone =
  | '#1F Open Workstations'
  | '#2F Executive Boardroom'
  | '#3F Visitor Center Cafe'
  | '#B1 Corporate Office'
  | 'Tennis Arena';

export type OfficeInteractiveObjectId =
  | 'Idleboard HUB'
  | 'Assessment SUBMIT'
  | 'Healthcare Pomodoro COMPANION'
  | 'Leaderboard RANKS';

export interface ChloeFsmStatus {
  currentState: ChloeNpcState;
  targetZone?: SpatialZone;
  activeObject?: OfficeInteractiveObjectId;
  lastAction?: string;
  updatedAt: number;
}

export type ServerEvent =
  | { type: 'INIT_STATE'; userId: string; users: UserState[]; desks: DeskData[]; whiteboard: WhiteboardStroke[]; screenShareUser: string | null; checklist: ChecklistItem[]; contacts: SavedContactNote[]; projectionState?: OfficeProjectionState | null; chloeFsm?: ChloeFsmStatus }
  | { type: 'USER_JOINED'; user: UserState }
  | { type: 'USER_LEFT'; userId: string }
  | { type: 'USER_MOVED'; userId: string; position: Position3D; rotationY: number; isMoving: boolean }
  | { type: 'USER_STATUS_UPDATED'; userId: string; isSpeaking?: boolean; isMuted?: boolean; isScreenSharing?: boolean; statusText?: string }
  | { type: 'USER_AVATAR_UPDATED'; userId: string; skin?: AvatarSkin; hoodieColor?: string; hairColor?: string; ethnicity?: string; skinTone?: string; pantsColor?: string; shoesColor?: string; capColor?: string; scarfColor?: string; isRidingScooter?: boolean; scooterConfig?: ScooterConfig }
  | { type: 'USER_GESTURE'; userId: string; gesture: GestureType }
  | { type: 'EMOJI_REACTION'; userId: string; emoji: string; gesture?: GestureType }
  | { type: 'DESK_UPDATED'; desk: DeskData }
  | { type: 'WHITEBOARD_STROKE'; stroke: WhiteboardStroke }
  | { type: 'WHITEBOARD_CLEARED' }
  | { type: 'CHECKLIST_UPDATED'; checklist: ChecklistItem[] }
  | { type: 'CONTACTS_UPDATED'; contacts: SavedContactNote[] }
  | { type: 'CHAT_MESSAGE'; message: ChatMessage }
  | { type: 'SIGNAL'; signal: WebRTCSignalPayload }
  | { type: 'SCREEN_SHARE_CHANGED'; presenterUserId: string | null }
  | { type: 'PROJECTION_STATE_CHANGED'; projectionState: OfficeProjectionState | null }
  | { type: 'REMOTE_VIDEO_FRAME'; userId: string; frameData: string }
  | { type: 'REMOTE_SCREEN_FRAME'; userId: string; frameData: string }
  | { type: 'BOOKMARKS_UPDATED'; bookmarks: DataCenterBookmark[] }
  | { type: 'CHLOE_FSM_UPDATED'; fsm: ChloeFsmStatus }
  | { type: 'TRIGGER_OFFICE_OBJECT'; objectId: OfficeInteractiveObjectId; action?: string; triggeredBy?: string };

// Client -> Server Events
export type ClientEvent =
  | { type: 'JOIN_ROOM'; name: string; skin: AvatarSkin; department: Department; roomId?: string; ethnicity?: string; hairColor?: string; skinTone?: string; hoodieColor?: string; pantsColor?: string; shoesColor?: string; capColor?: string; scarfColor?: string; userId?: string; initialPosition?: Position3D; initialRotationY?: number; isRidingScooter?: boolean; scooterConfig?: ScooterConfig }
  | { type: 'UPDATE_AVATAR'; skin?: AvatarSkin; hoodieColor?: string; hairColor?: string; ethnicity?: string; skinTone?: string; pantsColor?: string; shoesColor?: string; capColor?: string; scarfColor?: string; isRidingScooter?: boolean; scooterConfig?: ScooterConfig }
  | { type: 'MOVE'; position: Position3D; rotationY: number; isMoving: boolean }
  | { type: 'UPDATE_STATUS'; isSpeaking?: boolean; isMuted?: boolean; isScreenSharing?: boolean; statusText?: string }
  | { type: 'PERFORM_GESTURE'; gesture: GestureType }
  | { type: 'SEND_EMOJI_REACTION'; emoji: string; gesture?: GestureType }
  | { type: 'CLAIM_DESK'; deskId: string; theme?: DeskTheme; gear?: DeskGear; customStatus?: string }
  | { type: 'UNCLAIM_DESK'; deskId: string }
  | { type: 'ADD_WHITEBOARD_STROKE'; stroke: WhiteboardStroke }
  | { type: 'CLEAR_WHITEBOARD' }
  | { type: 'UPDATE_CHECKLIST'; checklist: ChecklistItem[] }
  | { type: 'UPDATE_CONTACTS'; contacts: SavedContactNote[] }
  | { type: 'SEND_CHAT'; text: string; isProximity: boolean; isPrivate?: boolean; recipientId?: string; recipientName?: string }
  | { type: 'SIGNAL'; signal: WebRTCSignalPayload }
  | { type: 'TOGGLE_SCREEN_SHARE'; isSharing: boolean; hasAudio?: boolean; presenterName?: string }
  | { type: 'SET_PROJECTION_STATE'; projectionState: OfficeProjectionState | null }
  | { type: 'CONTROL_PROJECTION'; action: 'play' | 'pause' | 'stop' | 'toggle' | 'seek' | 'change_video' | 'error'; videoId?: string; title?: string; category?: string; seekTime?: number; errorCode?: number | string; errorMessage?: string }
  | { type: 'BROADCAST_VIDEO_FRAME'; frameData: string }
  | { type: 'BROADCAST_SCREEN_FRAME'; frameData: string }
  | { type: 'UPDATE_BOOKMARKS'; bookmarks: DataCenterBookmark[] }
  | { type: 'CHLOE_NAVIGATE_ZONE'; targetZone: SpatialZone }
  | { type: 'CHLOE_TRIGGER_OBJECT'; objectId: OfficeInteractiveObjectId; action?: string };



