// Web Audio API Sound Effects Synthesizer for IdleLab V6
// Pure client-side synthesis: retro block-game pops, two-tone notification chimes, and virtual office interactions.

export type SoundEffectType =
  | 'pop'
  | 'confirm'
  | 'chime'
  | 'chatIncoming'
  | 'chatOutgoing'
  | 'mention'
  | 'teleport'
  | 'interact'
  | 'emote'
  | 'deskClaim'
  | 'coffeeBrew'
  | 'taskToggle';

type MuteChangeListener = (isMuted: boolean) => void;

class SoundEffectsManager {
  private audioCtx: AudioContext | null = null;
  private muted: boolean = false;
  private volume: number = 0.7;
  private muteListeners: Set<MuteChangeListener> = new Set();
  private storageKey = 'idlelab_v6_sfx_muted';
  private volumeStorageKey = 'idlelab_v6_sfx_volume';

  constructor() {
    if (typeof window !== 'undefined') {
      try {
        const savedMute = localStorage.getItem(this.storageKey);
        if (savedMute !== null) {
          this.muted = savedMute === 'true';
        }
        const savedVol = localStorage.getItem(this.volumeStorageKey);
        if (savedVol !== null) {
          const parsed = parseFloat(savedVol);
          if (!isNaN(parsed)) {
            this.volume = Math.max(0, Math.min(1, parsed));
          }
        }
      } catch (e) {
        console.warn('Could not read sound FX settings from localStorage:', e);
      }
    }
  }

  /**
   * Lazily initialize or resume AudioContext upon user gesture
   */
  private getAudioContext(): AudioContext | null {
    if (typeof window === 'undefined') return null;

    try {
      if (!this.audioCtx) {
        const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
        if (!AudioContextClass) return null;
        this.audioCtx = new AudioContextClass();
      }

      if (this.audioCtx.state === 'suspended') {
        this.audioCtx.resume().catch(() => {});
      }

      return this.audioCtx;
    } catch {
      return null;
    }
  }

  public isMuted(): boolean {
    return this.muted;
  }

  public setMuted(mute: boolean): void {
    this.muted = mute;
    if (typeof window !== 'undefined') {
      try {
        localStorage.setItem(this.storageKey, mute ? 'true' : 'false');
      } catch (e) {
        console.warn('Could not save sound FX mute setting:', e);
      }
    }
    this.notifyMuteListeners();
  }

  public toggleMute(): boolean {
    this.setMuted(!this.muted);
    // If unmuted, play a crisp confirmation pop as audio feedback
    if (!this.muted) {
      this.playPop();
    }
    return this.muted;
  }

  public getVolume(): number {
    return this.volume;
  }

  public setVolume(vol: number): void {
    this.volume = Math.max(0, Math.min(1, vol));
    if (typeof window !== 'undefined') {
      try {
        localStorage.setItem(this.volumeStorageKey, this.volume.toString());
      } catch (e) {
        console.warn('Could not save sound FX volume:', e);
      }
    }
  }

  public onMuteChange(listener: MuteChangeListener): () => void {
    this.muteListeners.add(listener);
    return () => {
      this.muteListeners.delete(listener);
    };
  }

  private notifyMuteListeners(): void {
    this.muteListeners.forEach((fn) => {
      try {
        fn(this.muted);
      } catch (err) {
        console.error('Error in mute change listener:', err);
      }
    });
  }

  /**
   * Retro, block-game style high-pitched confirmation pop.
   * Snappy ascending frequency burst (e.g. 750Hz -> 1650Hz in 50ms) with snappy decay.
   */
  public playPop(pitchVariation: number = 0): void {
    if (this.muted) return;
    const ctx = this.getAudioContext();
    if (!ctx) return;

    try {
      const now = ctx.currentTime;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      const filter = ctx.createBiquadFilter();

      // Softened square/triangle blend via lowpass for that authentic voxel/block click
      osc.type = 'triangle';

      const baseStartFreq = 800 + pitchVariation;
      const baseEndFreq = 1600 + pitchVariation * 1.5;

      osc.frequency.setValueAtTime(baseStartFreq, now);
      osc.frequency.exponentialRampToValueAtTime(baseEndFreq, now + 0.045);

      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(3200, now);

      const targetGain = 0.25 * this.volume;
      gain.gain.setValueAtTime(0.001, now);
      gain.gain.linearRampToValueAtTime(targetGain, now + 0.006);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.065);

      osc.connect(filter);
      filter.connect(gain);
      gain.connect(ctx.destination);

      osc.start(now);
      osc.stop(now + 0.07);
    } catch {
      // Ignore audio synthesis errors gracefully
    }
  }

  /**
   * Crisp, melodic two-tone notification chime (e.g. 659Hz [E5] -> 987Hz [B5]).
   */
  public playChime(highPitch: boolean = false): void {
    if (this.muted) return;
    const ctx = this.getAudioContext();
    if (!ctx) return;

    try {
      const now = ctx.currentTime;
      const f1 = highPitch ? 784 : 659.25; // G5 or E5
      const f2 = highPitch ? 1046.5 : 987.77; // C6 or B5

      // Note 1
      const osc1 = ctx.createOscillator();
      const gain1 = ctx.createGain();
      osc1.type = 'sine';
      osc1.frequency.setValueAtTime(f1, now);

      gain1.gain.setValueAtTime(0.001, now);
      gain1.gain.linearRampToValueAtTime(0.22 * this.volume, now + 0.02);
      gain1.gain.exponentialRampToValueAtTime(0.0001, now + 0.35);

      osc1.connect(gain1);
      gain1.connect(ctx.destination);
      osc1.start(now);
      osc1.stop(now + 0.36);

      // Note 2 (slightly offset for two-tone chime effect)
      const note2Start = now + 0.11;
      const osc2 = ctx.createOscillator();
      const gain2 = ctx.createGain();
      osc2.type = 'sine';
      osc2.frequency.setValueAtTime(f2, note2Start);

      gain2.gain.setValueAtTime(0.001, note2Start);
      gain2.gain.linearRampToValueAtTime(0.25 * this.volume, note2Start + 0.02);
      gain2.gain.exponentialRampToValueAtTime(0.0001, note2Start + 0.42);

      osc2.connect(gain2);
      gain2.connect(ctx.destination);
      osc2.start(note2Start);
      osc2.stop(note2Start + 0.45);
    } catch {
      // Graceful fallback
    }
  }

  /**
   * Crisp feedback when receiving an incoming chat message.
   */
  public playChatIncoming(): void {
    if (this.muted) return;
    const ctx = this.getAudioContext();
    if (!ctx) return;

    try {
      const now = ctx.currentTime;
      // High-pitched retro double-pop
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';

      osc.frequency.setValueAtTime(700, now);
      osc.frequency.exponentialRampToValueAtTime(1400, now + 0.05);

      gain.gain.setValueAtTime(0.001, now);
      gain.gain.linearRampToValueAtTime(0.2 * this.volume, now + 0.01);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.12);

      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now);
      osc.stop(now + 0.13);

      // Tone 2
      const osc2 = ctx.createOscillator();
      const gain2 = ctx.createGain();
      osc2.type = 'triangle';
      osc2.frequency.setValueAtTime(1100, now + 0.08);
      osc2.frequency.exponentialRampToValueAtTime(1760, now + 0.14);

      gain2.gain.setValueAtTime(0.001, now + 0.08);
      gain2.gain.linearRampToValueAtTime(0.18 * this.volume, now + 0.09);
      gain2.gain.exponentialRampToValueAtTime(0.0001, now + 0.22);

      osc2.connect(gain2);
      gain2.connect(ctx.destination);
      osc2.start(now + 0.08);
      osc2.stop(now + 0.23);
    } catch {
      // Fallback
    }
  }

  /**
   * Crisp feedback when sending a chat message.
   */
  public playChatOutgoing(): void {
    this.playPop(120);
  }

  /**
   * Special chime for direct messages or @mentions
   */
  public playMentionAlert(): void {
    this.playChime(true);
  }

  /**
   * Teleport / Floor Elevator transition sound (smooth retro sci-fi warp sweep)
   */
  public playTeleport(): void {
    if (this.muted) return;
    const ctx = this.getAudioContext();
    if (!ctx) return;

    try {
      const now = ctx.currentTime;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(320, now);
      osc.frequency.exponentialRampToValueAtTime(1280, now + 0.16);

      gain.gain.setValueAtTime(0.001, now);
      gain.gain.linearRampToValueAtTime(0.2 * this.volume, now + 0.03);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.22);

      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now);
      osc.stop(now + 0.24);
    } catch {}
  }

  /**
   * General virtual office click / interact feedback
   */
  public playInteract(): void {
    this.playPop(0);
  }

  /**
   * Fun 3-note high-pitch arpeggio for emote & gesture reactions
   */
  public playEmote(): void {
    if (this.muted) return;
    const ctx = this.getAudioContext();
    if (!ctx) return;

    try {
      const now = ctx.currentTime;
      const notes = [880, 1108.73, 1318.51]; // A5, C#6, E6

      notes.forEach((freq, idx) => {
        const startTime = now + idx * 0.045;
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();

        osc.type = 'triangle';
        osc.frequency.setValueAtTime(freq, startTime);

        gain.gain.setValueAtTime(0.001, startTime);
        gain.gain.linearRampToValueAtTime(0.18 * this.volume, startTime + 0.008);
        gain.gain.exponentialRampToValueAtTime(0.0001, startTime + 0.1);

        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(startTime);
        osc.stop(startTime + 0.11);
      });
    } catch {}
  }

  /**
   * Desk claim confirmation
   */
  public playDeskClaim(): void {
    this.playPop(200);
  }

  /**
   * Coffee robot brew buff chime
   */
  public playCoffeeBrew(): void {
    if (this.muted) return;
    const ctx = this.getAudioContext();
    if (!ctx) return;

    try {
      const now = ctx.currentTime;
      // Warm chord: C5 + E5 + G5
      [523.25, 659.25, 783.99].forEach((freq) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, now);

        gain.gain.setValueAtTime(0.001, now);
        gain.gain.linearRampToValueAtTime(0.12 * this.volume, now + 0.04);
        gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.45);

        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(now);
        osc.stop(now + 0.48);
      });
    } catch {}
  }

  /**
   * Level up / score boost fanfare
   */
  public playLevelUp(): void {
    if (this.muted) return;
    const ctx = this.getAudioContext();
    if (!ctx) return;

    try {
      const now = ctx.currentTime;
      const notes = [523.25, 659.25, 783.99, 1046.5]; // C5, E5, G5, C6
      notes.forEach((freq, idx) => {
        const startTime = now + idx * 0.06;
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(freq, startTime);

        gain.gain.setValueAtTime(0.001, startTime);
        gain.gain.linearRampToValueAtTime(0.2 * this.volume, startTime + 0.01);
        gain.gain.exponentialRampToValueAtTime(0.0001, startTime + 0.2);

        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(startTime);
        osc.stop(startTime + 0.22);
      });
    } catch {}
  }

  /**
   * Soothing Singing Bowl / Mindful Harmonic Chime for Healthcare Pomodoro alerts
   */
  public playPomodoroChime(): void {
    if (this.muted) return;
    const ctx = this.getAudioContext();
    if (!ctx) return;

    try {
      const frequencies = [528, 792, 1056, 1584]; // 528 Hz "Transformation & Miracles / Solfeggio" harmonic series
      const startTime = ctx.currentTime;

      frequencies.forEach((freq, idx) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();

        osc.type = idx === 0 ? 'sine' : 'triangle';
        osc.frequency.setValueAtTime(freq, startTime);

        const decay = 2.5 + idx * 0.4;
        const initialVol = (0.28 / (idx + 1)) * this.volume;

        gain.gain.setValueAtTime(0.0001, startTime);
        gain.gain.linearRampToValueAtTime(initialVol, startTime + 0.05);
        gain.gain.exponentialRampToValueAtTime(0.00001, startTime + decay);

        osc.connect(gain);
        gain.connect(ctx.destination);

        osc.start(startTime);
        osc.stop(startTime + decay);
      });
    } catch {}
  }

  /**
   * Electric E-Scooter power-on and mount activation chime
   */
  public playScooterMount(): void {
    if (this.muted) return;
    const ctx = this.getAudioContext();
    if (!ctx) return;

    try {
      const startTime = ctx.currentTime;
      // High tech rising dual-tone beep (Lime scooter unlock sound)
      const osc1 = ctx.createOscillator();
      const gain1 = ctx.createGain();
      osc1.type = 'sine';
      osc1.frequency.setValueAtTime(880, startTime); // A5
      osc1.frequency.exponentialRampToValueAtTime(1760, startTime + 0.12); // A6

      gain1.gain.setValueAtTime(0.001, startTime);
      gain1.gain.linearRampToValueAtTime(0.25 * this.volume, startTime + 0.02);
      gain1.gain.exponentialRampToValueAtTime(0.0001, startTime + 0.22);

      osc1.connect(gain1);
      gain1.connect(ctx.destination);
      osc1.start(startTime);
      osc1.stop(startTime + 0.25);

      // Harmonious second beep
      const osc2 = ctx.createOscillator();
      const gain2 = ctx.createGain();
      osc2.type = 'triangle';
      osc2.frequency.setValueAtTime(1320, startTime + 0.1);
      osc2.frequency.exponentialRampToValueAtTime(2640, startTime + 0.22);

      gain2.gain.setValueAtTime(0.001, startTime + 0.1);
      gain2.gain.linearRampToValueAtTime(0.2 * this.volume, startTime + 0.12);
      gain2.gain.exponentialRampToValueAtTime(0.0001, startTime + 0.32);

      osc2.connect(gain2);
      gain2.connect(ctx.destination);
      osc2.start(startTime + 0.1);
      osc2.stop(startTime + 0.35);
    } catch {}
  }

  /**
   * E-Scooter dismount and standby power-down tone
   */
  public playScooterDismount(): void {
    if (this.muted) return;
    const ctx = this.getAudioContext();
    if (!ctx) return;

    try {
      const startTime = ctx.currentTime;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(1200, startTime);
      osc.frequency.exponentialRampToValueAtTime(440, startTime + 0.18);

      gain.gain.setValueAtTime(0.001, startTime);
      gain.gain.linearRampToValueAtTime(0.18 * this.volume, startTime + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.0001, startTime + 0.2);

      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(startTime);
      osc.stop(startTime + 0.22);
    } catch {}
  }

  /**
   * Auto-Ride Autonomous Cruise Control Engage / Disengage Chime
   */
  public playScooterCruise(active = true): void {
    if (this.muted) return;
    const ctx = this.getAudioContext();
    if (!ctx) return;

    try {
      const startTime = ctx.currentTime;
      const notes = active ? [587.33, 739.99, 880, 1174.66] : [880, 587.33]; // D5, F#5, A5, D6
      notes.forEach((freq, i) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        const noteStart = startTime + i * 0.06;

        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, noteStart);

        gain.gain.setValueAtTime(0.001, noteStart);
        gain.gain.linearRampToValueAtTime(0.18 * this.volume, noteStart + 0.015);
        gain.gain.exponentialRampToValueAtTime(0.0001, noteStart + 0.18);

        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(noteStart);
        osc.stop(noteStart + 0.2);
      });
    } catch {}
  }

  /**
   * Crisp brass handlebar bicycle/scooter bell ding-ding
   */
  public playScooterBell(): void {
    if (this.muted) return;
    const ctx = this.getAudioContext();
    if (!ctx) return;

    try {
      const startTime = ctx.currentTime;
      [0, 0.12].forEach((offset) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        const ringTime = startTime + offset;

        osc.type = 'sine';
        osc.frequency.setValueAtTime(2093, ringTime); // C7

        gain.gain.setValueAtTime(0.001, ringTime);
        gain.gain.linearRampToValueAtTime(0.3 * this.volume, ringTime + 0.005);
        gain.gain.exponentialRampToValueAtTime(0.00001, ringTime + 0.35);

        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(ringTime);
        osc.stop(ringTime + 0.38);
      });
    } catch {}
  }

  /**
   * Quick success chime
   */
  public playSuccess(): void {
    this.playChime(true);
  }

  /**
   * Generic trigger method by sound type
   */
  public play(type: SoundEffectType): void {
    switch (type) {
      case 'pop':
      case 'confirm':
        this.playPop();
        break;
      case 'chime':
        this.playChime();
        break;
      case 'chatIncoming':
        this.playChatIncoming();
        break;
      case 'chatOutgoing':
        this.playChatOutgoing();
        break;
      case 'mention':
        this.playMentionAlert();
        break;
      case 'teleport':
        this.playTeleport();
        break;
      case 'interact':
      case 'taskToggle':
        this.playInteract();
        break;
      case 'emote':
        this.playEmote();
        break;
      case 'deskClaim':
        this.playDeskClaim();
        break;
      case 'coffeeBrew':
        this.playCoffeeBrew();
        break;
      default:
        this.playPop();
        break;
    }
  }
}

export const soundEffects = new SoundEffectsManager();
