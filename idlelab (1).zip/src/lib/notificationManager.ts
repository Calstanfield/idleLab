// Web Browser Notification & Background Alert Manager

export type NotificationPermissionState = 'granted' | 'denied' | 'default' | 'unsupported';

class NotificationManager {
  private originalTitle: string = typeof document !== 'undefined' ? document.title || 'Pixel Office VR' : 'Pixel Office VR';
  private titleBlinkInterval: number | null = null;
  private audioCtx: AudioContext | null = null;
  private onNotificationClickHandlers: Array<() => void> = [];

  constructor() {
    if (typeof window !== 'undefined') {
      window.addEventListener('focus', () => {
        this.stopTitleBlink();
      });
      document.addEventListener('visibilitychange', () => {
        if (!document.hidden) {
          this.stopTitleBlink();
        }
      });
    }
  }

  public isSupported(): boolean {
    return typeof window !== 'undefined' && 'Notification' in window;
  }

  public getPermission(): NotificationPermissionState {
    if (!this.isSupported()) return 'unsupported';
    return Notification.permission as NotificationPermissionState;
  }

  public async requestPermission(): Promise<NotificationPermissionState> {
    if (!this.isSupported()) return 'unsupported';
    try {
      const result = await Notification.requestPermission();
      return result as NotificationPermissionState;
    } catch (err) {
      console.warn('Error requesting notification permission:', err);
      return this.getPermission();
    }
  }

  public registerClickListener(handler: () => void) {
    this.onNotificationClickHandlers.push(handler);
    return () => {
      this.onNotificationClickHandlers = this.onNotificationClickHandlers.filter((h) => h !== handler);
    };
  }

  /**
   * Pleasant, soft dual-tone Web Audio chime for incoming notification
   */
  public playNotificationChime() {
    try {
      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioContextClass) return;

      if (!this.audioCtx) {
        this.audioCtx = new AudioContextClass();
      }

      if (this.audioCtx.state === 'suspended') {
        this.audioCtx.resume();
      }

      const now = this.audioCtx.currentTime;
      const osc1 = this.audioCtx.createOscillator();
      const osc2 = this.audioCtx.createOscillator();
      const gainNode = this.audioCtx.createGain();

      osc1.type = 'sine';
      osc2.type = 'triangle';

      // Chime notes: F#5 (739.99Hz) then A#5 (932.33Hz)
      osc1.frequency.setValueAtTime(739.99, now);
      osc1.frequency.exponentialRampToValueAtTime(932.33, now + 0.12);

      osc2.frequency.setValueAtTime(369.99, now);
      osc2.frequency.exponentialRampToValueAtTime(466.16, now + 0.12);

      gainNode.gain.setValueAtTime(0.001, now);
      gainNode.gain.linearRampToValueAtTime(0.18, now + 0.03);
      gainNode.gain.exponentialRampToValueAtTime(0.0001, now + 0.45);

      osc1.connect(gainNode);
      osc2.connect(gainNode);
      gainNode.connect(this.audioCtx.destination);

      osc1.start(now);
      osc2.start(now);
      osc1.stop(now + 0.5);
      osc2.stop(now + 0.5);
    } catch {
      // Audio playback fails gracefully if policy blocked before interaction
    }
  }

  /**
   * Flash browser tab title to alert the user even if they are in another tab or application window
   */
  public startTitleBlink(alertText: string) {
    this.stopTitleBlink();
    let toggle = false;
    this.originalTitle = document.title || 'Pixel Office VR';

    this.titleBlinkInterval = window.setInterval(() => {
      document.title = toggle ? alertText : this.originalTitle;
      toggle = !toggle;
    }, 1100);
  }

  public stopTitleBlink() {
    if (this.titleBlinkInterval !== null) {
      clearInterval(this.titleBlinkInterval);
      this.titleBlinkInterval = null;
    }
    if (typeof document !== 'undefined' && this.originalTitle) {
      document.title = this.originalTitle;
    }
  }

  /**
   * Show a system browser notification with fallback to title flashing & audio
   */
  public notify({
    title,
    body,
    tag,
    onClick,
  }: {
    title: string;
    body: string;
    tag?: string;
    onClick?: () => void;
  }) {
    // 1. Play soft audio chime
    this.playNotificationChime();

    // 2. If tab is in background / hidden, flash the document title
    if (typeof document !== 'undefined' && (document.hidden || !document.hasFocus())) {
      this.startTitleBlink(`💬 ${title}`);
    }

    // 3. Trigger Native Browser Notification
    if (this.isSupported() && Notification.permission === 'granted') {
      try {
        const options: NotificationOptions = {
          body,
          tag: tag || `msg_${Date.now()}`,
          icon: '/favicon.ico',
        };
        // Add optional extended browser notification flags
        (options as Record<string, unknown>).renotify = true;
        (options as Record<string, unknown>).silent = false;

        const notification = new Notification(title, options);

        notification.onclick = (e) => {
          e.preventDefault();
          window.focus();
          this.stopTitleBlink();
          if (onClick) {
            onClick();
          }
          this.onNotificationClickHandlers.forEach((h) => h());
          notification.close();
        };
      } catch (err) {
        console.warn('Native notification failed:', err);
      }
    }
  }

  /**
   * Helper to check if text contains an explicit @mention for a given user or broadcast (@all, @everyone, @here)
   */
  public isMentioned(text: string, userName: string): boolean {
    if (!text || !userName) return false;
    
    // Broadcast mentions
    const broadcastPattern = /@(all|everyone|here|team|channel)\b/i;
    if (broadcastPattern.test(text)) return true;

    // Full name mention: e.g. @Fortune Cookie or @Californian Roll
    const cleanName = userName.trim();
    if (!cleanName) return false;

    // Escape regex special chars in user name
    const escapedName = cleanName.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const nameRegex = new RegExp(`@${escapedName}\\b`, 'i');
    if (nameRegex.test(text)) return true;

    // First name mention: e.g. "Fortune" from "Fortune Cookie"
    const firstName = cleanName.split(' ')[0];
    if (firstName && firstName.length >= 2) {
      const escapedFirst = firstName.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      const firstRegex = new RegExp(`@${escapedFirst}\\b`, 'i');
      if (firstRegex.test(text)) return true;
    }

    return false;
  }
}

export const notificationManager = new NotificationManager();
