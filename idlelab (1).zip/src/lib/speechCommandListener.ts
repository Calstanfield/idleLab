import { socketClient } from './socketClient';
import { simulatorEngine } from './simulatorEngine';
import { chloeAgentClient } from './chloeAgentClient';
import { chloeVoice } from './chloeVoice';
import { soundEffects } from './soundEffects';
import { SpatialZone, OfficeInteractiveObjectId } from '../types';

export interface ParsedChloeIntent {
  isChloeCommand: boolean;
  spatialZone?: SpatialZone;
  interactiveObject?: OfficeInteractiveObjectId;
  action?: string;
  cleanPrompt: string;
}

/**
 * Intelligent Intent Parser for Chloe Becker's FSM & Spatial Engine
 * Handles voice transcripts and chat inputs identically.
 */
export function parseChloeIntent(text: string, userZone?: SpatialZone): ParsedChloeIntent {
  const raw = text.trim();
  const lower = raw.toLowerCase();

  // Spatial Zones mapping
  let spatialZone: SpatialZone | undefined;
  if (
    lower.includes('2f') ||
    lower.includes('second floor') ||
    lower.includes('boardroom') ||
    lower.includes('executive boardroom') ||
    lower.includes('conference room')
  ) {
    spatialZone = '#2F Executive Boardroom';
  } else if (
    lower.includes('1f') ||
    lower.includes('first floor') ||
    lower.includes('open workstation') ||
    lower.includes('workstations') ||
    lower.includes('engineering floor') ||
    lower.includes('open floor')
  ) {
    spatialZone = '#1F Open Workstations';
  } else if (
    lower.includes('3f') ||
    lower.includes('third floor') ||
    lower.includes('cafe') ||
    lower.includes('visitor center') ||
    lower.includes('lounge')
  ) {
    spatialZone = '#3F Visitor Center Cafe';
  } else if (
    lower.includes('tennis') ||
    lower.includes('court') ||
    lower.includes('arena') ||
    lower.includes('recreation')
  ) {
    spatialZone = 'Tennis Arena';
  } else if (
    lower.includes('b1') ||
    lower.includes('basement') ||
    lower.includes('corporate office') ||
    lower.includes('desk') ||
    lower.includes('back to desk') ||
    lower.includes('return home')
  ) {
    spatialZone = '#B1 Corporate Office';
  } else if (
    userZone &&
    (lower.includes('come here') ||
      lower.includes('come to me') ||
      lower.includes('meet me') ||
      lower.includes('over here'))
  ) {
    spatialZone = userZone;
  }

  // Interactive Office Objects mapping
  let interactiveObject: OfficeInteractiveObjectId | undefined;
  let action = 'open';

  if (
    lower.includes('pomodoro') ||
    lower.includes('screen break') ||
    lower.includes('hydration') ||
    lower.includes('wellness') ||
    lower.includes('companion')
  ) {
    interactiveObject = 'Healthcare Pomodoro COMPANION';
    action = 'start_break';
  } else if (
    lower.includes('idleboard') ||
    lower.includes('whiteboard') ||
    lower.includes('drawing board') ||
    lower.includes('sticky note') ||
    lower.includes('canvas')
  ) {
    interactiveObject = 'Idleboard HUB';
    action = 'open';
  } else if (
    lower.includes('assessment') ||
    lower.includes('checklist') ||
    lower.includes('grade submission') ||
    lower.includes('audit report') ||
    lower.includes('grading')
  ) {
    interactiveObject = 'Assessment SUBMIT';
    action = 'open';
  } else if (
    lower.includes('leaderboard') ||
    lower.includes('ranks') ||
    lower.includes('rankings') ||
    lower.includes('standings')
  ) {
    interactiveObject = 'Leaderboard RANKS';
    action = 'view_ranks';
  }

  const isNavigationVerb =
    lower.includes('walk') ||
    lower.includes('go to') ||
    lower.includes('head to') ||
    lower.includes('navigate') ||
    lower.includes('teleport') ||
    lower.includes('move to') ||
    lower.includes('run to');

  const isTriggerVerb =
    lower.includes('trigger') ||
    lower.includes('open') ||
    lower.includes('start') ||
    lower.includes('launch') ||
    lower.includes('show') ||
    lower.includes('view');

  const mentionsChloe =
    lower.includes('chloe') ||
    lower.includes('@chloe') ||
    lower.startsWith('walk') ||
    lower.startsWith('trigger') ||
    lower.startsWith('go to');

  const isChloeCommand =
    mentionsChloe ||
    Boolean(spatialZone && isNavigationVerb) ||
    Boolean(interactiveObject && isTriggerVerb);

  return {
    isChloeCommand,
    spatialZone: isNavigationVerb || mentionsChloe ? spatialZone : undefined,
    interactiveObject: isTriggerVerb || mentionsChloe ? interactiveObject : undefined,
    action,
    cleanPrompt: raw.replace(/@chloe/gi, '').trim(),
  };
}

class SpeechCommandListener {
  private recognition: any = null;
  private isListening = false;
  private shouldBeListening = false;
  private userName = 'Colleague';
  private currentUserZone?: SpatialZone;
  private onTranscriptCallbacks: Set<(text: string, isFinal: boolean) => void> = new Set();
  private onStateChangeCallbacks: Set<(isListening: boolean) => void> = new Set();
  private lastProcessedTranscript = '';
  private lastProcessedTimestamp = 0;

  constructor() {
    this.initRecognition();
  }

  private initRecognition() {
    if (typeof window === 'undefined') return;
    const SpeechRec = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRec) {
      console.warn('[SpeechCommandListener]: Web Speech API not supported in this browser.');
      return;
    }

    try {
      this.recognition = new SpeechRec();
      this.recognition.continuous = true;
      this.recognition.interimResults = true;
      this.recognition.lang = 'en-US';

      this.recognition.onstart = () => {
        this.isListening = true;
        this.notifyStateChange(true);
      };

      this.recognition.onresult = (event: any) => {
        let interimTranscript = '';
        let finalTranscript = '';

        for (let i = event.resultIndex; i < event.results.length; ++i) {
          const transcript = event.results[i][0].transcript;
          if (event.results[i].isFinal) {
            finalTranscript += transcript;
          } else {
            interimTranscript += transcript;
          }
        }

        const candidate = (finalTranscript || interimTranscript).trim();
        if (candidate) {
          this.onTranscriptCallbacks.forEach((cb) => cb(candidate, Boolean(finalTranscript)));
        }

        if (finalTranscript.trim()) {
          this.handleSpeechInput(finalTranscript.trim());
        }
      };

      this.recognition.onerror = (event: any) => {
        if (event.error !== 'no-speech') {
          console.warn('[SpeechCommandListener] recognition error:', event.error);
        }
      };

      this.recognition.onend = () => {
        this.isListening = false;
        this.notifyStateChange(false);
        // Auto-restart if Mic remains unmuted and active
        if (this.shouldBeListening) {
          setTimeout(() => {
            if (this.shouldBeListening && !this.isListening) {
              try {
                this.recognition?.start();
              } catch (e) {
                // Ignore start collision
              }
            }
          }, 300);
        }
      };
    } catch (err) {
      console.warn('[SpeechCommandListener] Init error:', err);
    }
  }

  public setUserName(name: string) {
    this.userName = name || 'Colleague';
  }

  public setCurrentZone(zone?: SpatialZone) {
    this.currentUserZone = zone;
  }

  public startListening(userName?: string) {
    if (userName) this.userName = userName;
    this.shouldBeListening = true;

    if (!this.recognition) {
      this.initRecognition();
    }

    if (this.recognition && !this.isListening) {
      try {
        this.recognition.start();
      } catch (err) {
        // already started
      }
    }
  }

  public stopListening() {
    this.shouldBeListening = false;
    if (this.recognition && this.isListening) {
      try {
        this.recognition.stop();
      } catch (err) {
        // already stopped
      }
    }
    this.isListening = false;
    this.notifyStateChange(false);
  }

  public getIsListening(): boolean {
    return this.isListening;
  }

  public onTranscript(cb: (text: string, isFinal: boolean) => void): () => void {
    this.onTranscriptCallbacks.add(cb);
    return () => this.onTranscriptCallbacks.delete(cb);
  }

  public onStateChange(cb: (isListening: boolean) => void): () => void {
    this.onStateChangeCallbacks.add(cb);
    cb(this.isListening);
    return () => this.onStateChangeCallbacks.delete(cb);
  }

  private notifyStateChange(active: boolean) {
    this.onStateChangeCallbacks.forEach((cb) => cb(active));
  }

  /**
   * Process voice transcript and route to orchestrator, FSM, and chat
   */
  public async handleSpeechInput(transcript: string) {
    const text = transcript.trim();
    if (!text) return;

    // If Chloe is toggled off, ignore voice input
    if (!chloeVoice.isChloeEnabled()) {
      return;
    }

    // Debounce duplicate utterances
    const now = Date.now();
    if (this.lastProcessedTranscript === text && now - this.lastProcessedTimestamp < 2500) {
      return;
    }
    this.lastProcessedTranscript = text;
    this.lastProcessedTimestamp = now;

    console.log(`[SpeechCommandListener] Heard voice: "${text}"`);
    soundEffects.playPop();

    const lower = text.toLowerCase();
    // User requirement: When using voice chat, ensure Chloe does not perceive it as a request for her to respond unless user says "hi Chloe" (or hello/hey/chloe/@chloe)
    const hasExplicitChloe = /hi\s+chloe|hello\s+chloe|hey\s+chloe|@chloe|\bchloe\b/.test(lower);

    // Always broadcast user speech to Chat so colleagues hear the voice chat
    socketClient.send({
      type: 'SEND_CHAT',
      text: `🎤 ${text}`,
      isProximity: false,
    });

    if (!hasExplicitChloe) {
      return; // Chloe does not respond unless explicitly addressed with hi Chloe
    }

    // Parse Intent
    const intent = parseChloeIntent(text, this.currentUserZone);

    // 1. Dispatch Socket FSM Events if matching spatial or object commands
    if (intent.spatialZone) {
      console.log(`[Chloe FSM]: Triggering spatial navigation via voice -> ${intent.spatialZone}`);
      simulatorEngine.logFsmStateChange('NAVIGATING_TO_DESK', intent.spatialZone, undefined, `Voice command: "${text}"`);
      socketClient.send({
        type: 'CHLOE_NAVIGATE_ZONE',
        targetZone: intent.spatialZone,
      });
    }

    if (intent.interactiveObject) {
      console.log(`[Chloe FSM]: Triggering interactive object via voice -> ${intent.interactiveObject}`);
      simulatorEngine.logFsmStateChange('EXECUTING_WORKFLOW', undefined, intent.interactiveObject, `Voice command: "${text}"`);
      socketClient.send({
        type: 'CHLOE_TRIGGER_OBJECT',
        objectId: intent.interactiveObject,
        action: intent.action || 'open',
      });
    }

    // 2. Execute Autonomous Command & Auto-Response Speech
    try {
      const response = await simulatorEngine.executeAutonomousCommand(
        text,
        this.userName,
        () => {
          socketClient.send({
            type: 'UPDATE_STATUS',
            isSpeaking: true,
            statusText: 'Speaking...',
          });
        },
        () => {
          socketClient.send({
            type: 'UPDATE_STATUS',
            isSpeaking: false,
          });
        }
      );

      // Speak response aloud via neural/browser TTS
      if (response && response.text) {
        chloeVoice.speak(response.speech || response.text, 'chloe_voice_pipeline');
      }
    } catch (err: any) {
      console.warn('[SpeechCommandListener] Autonomous execution fallback:', err);
    }
  }
}

export const speechCommandListener = new SpeechCommandListener();
