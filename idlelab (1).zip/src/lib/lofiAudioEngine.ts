// High-Quality Web Audio Lo-Fi & Acoustic Engine & Ambient Audio Controller
// Featuring HTML5 Audio stream pipeline, Pixabay Acoustic & Lo-Fi Playlists,
// Master Gain Node with 300ms crossfades, and interactive 1200Hz Low-Pass Filter ("Muffled Radio Effect").

export interface AmbientTrack {
  id: string;
  name: string;
  artist?: string;
  genre: string;
  category: 'vocal' | 'acoustic' | 'piano' | 'lofi' | 'ambient' | 'pop' | 'country' | string;
  instrument: string;
  bpm: number;
  description: string;
  streamUrl: string;
  fallbackProgression: number[][]; // MIDI chords if streaming blocked
}

export const AMBIENT_TRACKS: AmbientTrack[] = [
  {
    id: 'indie_venture_jonas',
    name: 'Indie Venture',
    artist: 'Jonas Blakewood',
    genre: 'Indie Pop',
    category: 'ambient',
    instrument: 'Bass Guitar/SynthBass ',
    bpm: 105,
    description: 'Source: Jonas Blakewood Pixabay',
    streamUrl: 'https://cdn.pixabay.com/audio/2026/08/10/audio_039794c91e.mp3',
    fallbackProgression: [
      [261.63, 329.63, 392.0, 523.25], // C
      [196.0, 246.94, 293.66, 392.0],  // G
      [220.0, 261.63, 329.63, 440.0],  // Am
      [174.61, 220.0, 261.63, 349.23], // F
    ],
  },
  {
    id: 'instrumental_lost_in_night',
    name: 'Lost in the Night',
    artist: 'Serkan Demirel',
    genre: 'Retro Electronic',
    category: 'pop',
    instrument: 'Sync Keyboard',
    bpm: 65,
    description: 'Source: Serqandemirel Pixabay',
    streamUrl: 'https://cdn.pixabay.com/audio/2025/01/10/audio_a7948996d4.mp3',
    fallbackProgression: [
      [174.61, 261.63, 329.63, 392.0], // Fmaj7
      [196.0, 293.66, 369.99, 440.0],  // G7
      [220.0, 261.63, 329.63, 440.0],  // Am9
      [164.81, 246.94, 329.63, 392.0], // Em7
    ],
  },
  {
    id: 'kpop_acoustic_janakena',
    name: '썸인지, 똥인지 말해',
    artist: 'JANAKENA',
    genre: 'Pop',
    category: 'lofi',
    instrument: 'Guitar & Bass',
    bpm: 74,
    description: 'Source: JANAKENA Pixabay',
    streamUrl: 'https://cdn.pixabay.com/audio/2025/11/10/audio_d023935a9a.mp3',
    fallbackProgression: [
      [261.63, 329.63, 392.0, 493.88], // Cmaj7
      [220.0, 261.63, 329.63, 392.0],  // Am7
      [174.61, 220.0, 261.63, 329.63], // Fmaj7
      [196.0, 246.94, 293.66, 349.23], // G7
    ],
  },
  {
    id: 'smooth_jazz_ambient',
    name: '愛の欠片',
    artist: 'TAVC City Pop',
    genre: 'Lofi & Pop',
    category: 'lofi',
    instrument: 'Synthesizer & Bass',
    bpm: 68,
    description: 'Sophisticated velvet jazz chords and warm basslines tailored for Chloe Becker strategy sessions in B1.',
    streamUrl: 'https://cdn.pixabay.com/audio/2025/07/02/audio_4946014da4.mp3',
    fallbackProgression: [
      [207.65, 261.63, 311.13, 392.0], // Abmaj7
      [233.08, 293.66, 349.23, 440.0], // Bb9
      [261.63, 311.13, 392.0, 466.16], // Cm7
      [174.61, 220.0, 261.63, 349.23], // Fm7
    ],
  },
  {
    id: 'deep_focus_alpha',
    name: 'Enlighting Indie',
    artist: 'Jonas Blakewood',
    genre: 'Indie Pop',
    category: 'ambient',
    instrument: 'Bass Guitar/SynthBass',
    bpm: 56,
    description: 'Source: Jonas Blakeword on Pixabay.',
    streamUrl: 'https://cdn.pixabay.com/audio/2026/07/24/audio_a4719ef22f.mp3',
    fallbackProgression: [
      [130.81, 196.0, 293.66, 392.0],  // Csus2
      [146.83, 220.0, 329.63, 440.0],  // Dsus2
      [110.0, 164.81, 261.63, 329.63], // Amin
      [123.47, 185.0, 293.66, 369.99], // Bmin
    ],
  },
  {
    id: 'country_standin_taller',
    name: 'Standin Taller',
    artist: 'Mother Daughter Country',
    genre: 'Country',
    category: 'ambient',
    instrument: 'Guitar/SynthBass',
    bpm: 56,
    description: 'Source: OpenMindAudio on Pixabay.',
    streamUrl: 'https://cdn.pixabay.com/audio/2026/06/04/audio_1a2a7d658b.mp3',
    fallbackProgression: [
      [130.81, 196.0, 293.66, 392.0],  // Csus2
      [146.83, 220.0, 329.63, 440.0],  // Dsus2
      [110.0, 164.81, 261.63, 329.63], // Amin
      [123.47, 185.0, 293.66, 369.99], // Bmin
    ],
  },
  {
    id: 'fiesta_no_puedes_conmigo',
    name: 'No Puedes Conmigo',
    artist: 'María Isabel García López',
    genre: 'Espanol Pop',
    category: 'ambient',
    instrument: 'Bass Guitar/SynthBass',
    bpm: 56,
    description: 'Source: Jakob Welib on Pixabay.',
    streamUrl: 'https://cdn.pixabay.com/audio/2025/09/25/audio_507dce26a4.mp3',
    fallbackProgression: [
      [130.81, 196.0, 293.66, 392.0],  // Csus2
      [146.83, 220.0, 329.63, 440.0],  // Dsus2
      [110.0, 164.81, 261.63, 329.63], // Amin
      [123.47, 185.0, 293.66, 369.99], // Bmin
    ],
  },
];

export type AudioEngineListener = (
  isPlaying: boolean,
  track: AmbientTrack,
  volume: number,
  isMuffled: boolean,
  isStreaming: boolean
) => void;

class LofiAudioEngine {
  private ctx: AudioContext | null = null;
  private masterGain: GainNode | null = null;
  private lowPassFilter: BiquadFilterNode | null = null;
  private audioElement: HTMLAudioElement | null = null;
  private mediaSourceNode: MediaElementAudioSourceNode | null = null;

  private isPlaying: boolean = false;
  private isMuffled: boolean = false;
  private isStreaming: boolean = false;
  private currentTrackIndex: number = 0;
  private volume: number = 0.55;
  private isCrossfading: boolean = false;

  // Procedural synthesizer fallback
  private fallbackTimer: number | null = null;
  private activeOscillators: OscillatorNode[] = [];

  private listeners: Set<AudioEngineListener> = new Set();
  private storagePrefix = 'idlelab_lofi_';

  constructor() {
    if (typeof window !== 'undefined') {
      try {
        const savedMuffled = localStorage.getItem(`${this.storagePrefix}muffled`);
        if (savedMuffled !== null) {
          this.isMuffled = savedMuffled === 'true';
        }
        const savedVol = localStorage.getItem(`${this.storagePrefix}volume`);
        if (savedVol !== null) {
          const parsed = parseFloat(savedVol);
          if (!isNaN(parsed)) this.volume = Math.max(0, Math.min(1, parsed));
        }
        const savedTrack = localStorage.getItem(`${this.storagePrefix}track_idx`);
        if (savedTrack !== null) {
          const parsed = parseInt(savedTrack, 10);
          if (!isNaN(parsed) && parsed >= 0 && parsed < AMBIENT_TRACKS.length) {
            this.currentTrackIndex = parsed;
          }
        }
      } catch (e) {
        console.warn('Could not read Lo-Fi audio settings:', e);
      }
    }
  }

  /**
   * Initializes Web Audio Context, Low-Pass Filter, and Master Gain Node
   */
  private initAudioGraph() {
    if (typeof window === 'undefined') return;

    if (!this.ctx || this.ctx.state === 'closed') {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioCtx) return;
      this.ctx = new AudioCtx();

      // Master Gain Node for volume control and smooth crossfades
      this.masterGain = this.ctx.createGain();
      const currentGain = this.volume * 0.45;
      this.masterGain.gain.setValueAtTime(currentGain, this.ctx.currentTime);

      // Low-Pass Filter Node for "Muffled Radio Effect"
      this.lowPassFilter = this.ctx.createBiquadFilter();
      this.lowPassFilter.type = 'lowpass';
      const cutoffFreq = this.isMuffled ? 1200 : 20000;
      this.lowPassFilter.frequency.setValueAtTime(cutoffFreq, this.ctx.currentTime);
      this.lowPassFilter.Q.setValueAtTime(this.isMuffled ? 2.2 : 0.7, this.ctx.currentTime);

      // Connect: Filter -> Master Gain -> Destination
      this.lowPassFilter.connect(this.masterGain);
      this.masterGain.connect(this.ctx.destination);
    }

    if (this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }

    // Initialize HTML5 Audio Element if not yet created
    if (!this.audioElement) {
      this.audioElement = new Audio();
      this.audioElement.crossOrigin = 'anonymous';
      this.audioElement.loop = false; // Auto advance playlist
      this.audioElement.preload = 'auto';

      try {
        if (this.ctx && !this.mediaSourceNode) {
          this.mediaSourceNode = this.ctx.createMediaElementSource(this.audioElement);
          this.mediaSourceNode.connect(this.lowPassFilter!);
        }
      } catch (err) {
        console.warn('Could not pipe HTML5 Audio to Web Audio node, using direct connection:', err);
      }

      this.audioElement.addEventListener('playing', () => {
        this.isStreaming = true;
        this.notify();
      });

      this.audioElement.addEventListener('ended', () => {
        // Automatically cycle to the next acoustic track in the playlist
        if (this.isPlaying) {
          this.nextTrack();
        }
      });

      this.audioElement.addEventListener('error', (e) => {
        console.warn('Audio stream fallback to procedural synth:', e);
        this.isStreaming = false;
        if (this.isPlaying) {
          this.startProceduralFallback();
        }
      });
    }
  }

  public subscribe(fn: AudioEngineListener): () => void {
    this.listeners.add(fn);
    fn(
      this.isPlaying,
      AMBIENT_TRACKS[this.currentTrackIndex],
      this.volume,
      this.isMuffled,
      this.isStreaming
    );
    return () => this.listeners.delete(fn);
  }

  private notify() {
    this.listeners.forEach((fn) =>
      fn(
        this.isPlaying,
        AMBIENT_TRACKS[this.currentTrackIndex],
        this.volume,
        this.isMuffled,
        this.isStreaming
      )
    );
  }

  /**
   * Sets Master Volume with smooth exponential ramp
   */
  public setVolume(val: number) {
    this.volume = Math.max(0, Math.min(1, val));
    if (this.masterGain && this.ctx) {
      const targetGain = this.volume * 0.45;
      this.masterGain.gain.setTargetAtTime(targetGain, this.ctx.currentTime, 0.05);
    }
    if (this.audioElement) {
      // Fallback volume if media source node is bypassed
      this.audioElement.volume = Math.max(0, Math.min(1, this.volume));
    }
    try {
      localStorage.setItem(`${this.storagePrefix}volume`, this.volume.toString());
    } catch {}
    this.notify();
  }

  public getVolume(): number {
    return this.volume;
  }

  public getIsPlaying(): boolean {
    return this.isPlaying;
  }

  public getIsMuffled(): boolean {
    return this.isMuffled;
  }

  public getTrack(): AmbientTrack {
    return AMBIENT_TRACKS[this.currentTrackIndex];
  }

  /**
   * Toggles Interactive Low-Pass Filter ("Muffled Radio Effect" / Warm Lo-Fi Filter)
   * Cuts off frequencies above 1200 Hz for authentic vintage cassette / muffled room warmth.
   */
  public toggleMuffledRadio(): boolean {
    this.isMuffled = !this.isMuffled;
    this.initAudioGraph();

    if (this.lowPassFilter && this.ctx) {
      const now = this.ctx.currentTime;
      const targetFreq = this.isMuffled ? 1200 : 20000;
      const targetQ = this.isMuffled ? 2.2 : 0.7;

      this.lowPassFilter.frequency.cancelScheduledValues(now);
      this.lowPassFilter.Q.cancelScheduledValues(now);

      this.lowPassFilter.frequency.setTargetAtTime(targetFreq, now, 0.08);
      this.lowPassFilter.Q.setTargetAtTime(targetQ, now, 0.08);
    }

    try {
      localStorage.setItem(`${this.storagePrefix}muffled`, this.isMuffled ? 'true' : 'false');
    } catch {}
    this.notify();
    return this.isMuffled;
  }

  /**
   * Switches track with smooth 300ms crossfade
   * (300ms gain ramp down -> swap src -> 300ms gain ramp up)
   */
  public selectTrack(index: number) {
    const nextIndex = (index + AMBIENT_TRACKS.length) % AMBIENT_TRACKS.length;
    if (nextIndex === this.currentTrackIndex && this.isPlaying) return;

    this.currentTrackIndex = nextIndex;
    try {
      localStorage.setItem(`${this.storagePrefix}track_idx`, this.currentTrackIndex.toString());
    } catch {}

    if (this.isPlaying) {
      this.executeCrossfadeTrackChange();
    } else {
      this.notify();
    }
  }

  public nextTrack() {
    this.selectTrack(this.currentTrackIndex + 1);
  }

  public prevTrack() {
    this.selectTrack(this.currentTrackIndex - 1);
  }

  /**
   * Crossfade algorithm: 300ms gain ramp down -> swap src -> 300ms gain ramp up
   */
  private executeCrossfadeTrackChange() {
    this.initAudioGraph();
    if (!this.ctx || !this.masterGain) {
      this.play();
      return;
    }

    if (this.isCrossfading) return;
    this.isCrossfading = true;

    const now = this.ctx.currentTime;
    const currentGain = this.volume * 0.45;
    const fadeTime = 0.3; // 300ms

    // 1. Smooth Ramp Down to ~0
    this.masterGain.gain.cancelScheduledValues(now);
    this.masterGain.gain.setValueAtTime(this.masterGain.gain.value, now);
    this.masterGain.gain.linearRampToValueAtTime(0.0001, now + fadeTime);

    // 2. Swap Source after 300ms
    setTimeout(() => {
      if (!this.isPlaying) {
        this.isCrossfading = false;
        return;
      }

      this.stopProceduralFallback();
      const track = AMBIENT_TRACKS[this.currentTrackIndex];

      if (this.audioElement) {
        this.audioElement.src = track.streamUrl;
        this.audioElement.load();
        const playPromise = this.audioElement.play();

        if (playPromise !== undefined) {
          playPromise
            .then(() => {
              this.isStreaming = true;
            })
            .catch(() => {
              // Fallback to procedural synth if streaming blocked
              this.isStreaming = false;
              this.startProceduralFallback();
            });
        }
      } else {
        this.startProceduralFallback();
      }

      // 3. Smooth Ramp Up to Target Gain over 300ms
      if (this.masterGain && this.ctx) {
        const resumeNow = this.ctx.currentTime;
        this.masterGain.gain.cancelScheduledValues(resumeNow);
        this.masterGain.gain.setValueAtTime(0.0001, resumeNow);
        this.masterGain.gain.linearRampToValueAtTime(currentGain, resumeNow + fadeTime);
      }

      this.isCrossfading = false;
      this.notify();
    }, fadeTime * 1000);
  }

  public toggle() {
    if (this.isPlaying) {
      this.stop();
    } else {
      this.play();
    }
  }

  public play() {
    this.initAudioGraph();
    this.isPlaying = true;
    this.notify();

    const track = AMBIENT_TRACKS[this.currentTrackIndex];

    if (this.ctx && this.masterGain) {
      const now = this.ctx.currentTime;
      const targetGain = this.volume * 0.45;
      this.masterGain.gain.cancelScheduledValues(now);
      this.masterGain.gain.setValueAtTime(0.0001, now);
      this.masterGain.gain.linearRampToValueAtTime(targetGain, now + 0.3);
    }

    if (this.audioElement) {
      if (this.audioElement.src !== track.streamUrl) {
        this.audioElement.src = track.streamUrl;
        this.audioElement.load();
      }
      const playPromise = this.audioElement.play();
      if (playPromise !== undefined) {
        playPromise
          .then(() => {
            this.isStreaming = true;
            this.notify();
          })
          .catch((err) => {
            console.warn('HTML5 audio playback blocked/failed, starting procedural engine:', err);
            this.isStreaming = false;
            this.startProceduralFallback();
          });
      }
    } else {
      this.startProceduralFallback();
    }
  }

  public stop() {
    this.isPlaying = false;
    this.isStreaming = false;

    if (this.ctx && this.masterGain) {
      const now = this.ctx.currentTime;
      this.masterGain.gain.cancelScheduledValues(now);
      this.masterGain.gain.setValueAtTime(this.masterGain.gain.value, now);
      this.masterGain.gain.linearRampToValueAtTime(0.0001, now + 0.2);
    }

    if (this.audioElement) {
      try {
        this.audioElement.pause();
      } catch {}
    }

    this.stopProceduralFallback();
    this.notify();
  }

  /**
   * High quality procedural synthesizer fallback for offline or stream interruptions
   */
  private startProceduralFallback() {
    this.stopProceduralFallback();
    if (!this.isPlaying || !this.ctx || !this.lowPassFilter) return;

    const track = AMBIENT_TRACKS[this.currentTrackIndex];
    let chordIdx = 0;
    const chordDuration = (60 / track.bpm) * 4;

    const playNextChord = () => {
      if (!this.isPlaying || !this.ctx || !this.lowPassFilter) return;

      const chord = track.fallbackProgression[chordIdx % track.fallbackProgression.length];
      chordIdx++;
      const now = this.ctx.currentTime;

      chord.forEach((freq, idx) => {
        if (!this.ctx || !this.lowPassFilter) return;
        const osc = this.ctx.createOscillator();
        const noteGain = this.ctx.createGain();

        osc.type = idx % 2 === 0 ? 'triangle' : 'sine';
        const detuneCents = (Math.random() - 0.5) * 6;
        osc.frequency.setValueAtTime(freq, now);
        osc.detune.setValueAtTime(detuneCents, now);

        noteGain.gain.setValueAtTime(0.0001, now);
        noteGain.gain.linearRampToValueAtTime(0.08 / (idx + 1), now + 0.3);
        noteGain.gain.exponentialRampToValueAtTime(0.0001, now + chordDuration - 0.1);

        osc.connect(noteGain);
        noteGain.connect(this.lowPassFilter);

        osc.start(now);
        osc.stop(now + chordDuration);
        this.activeOscillators.push(osc);

        osc.onended = () => {
          this.activeOscillators = this.activeOscillators.filter((o) => o !== osc);
        };
      });

      this.fallbackTimer = window.setTimeout(playNextChord, (chordDuration - 0.05) * 1000);
    };

    playNextChord();
  }

  private stopProceduralFallback() {
    if (this.fallbackTimer) {
      clearTimeout(this.fallbackTimer);
      this.fallbackTimer = null;
    }
    this.activeOscillators.forEach((osc) => {
      try {
        osc.stop();
        osc.disconnect();
      } catch {}
    });
    this.activeOscillators = [];
  }
}

export const lofiAudioEngine = new LofiAudioEngine();
