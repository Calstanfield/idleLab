// High-Fidelity Audio Player for Gemini Neural TTS & Web Audio PCM Streams

let activeAudioSource: AudioBufferSourceNode | null = null;
let sharedAudioCtx: AudioContext | null = null;

function getAudioContext(): AudioContext {
  if (!sharedAudioCtx || sharedAudioCtx.state === 'closed') {
    const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
    sharedAudioCtx = new AudioContextClass();
  }
  if (sharedAudioCtx.state === 'suspended') {
    sharedAudioCtx.resume().catch(() => {});
  }
  return sharedAudioCtx;
}

export function stopActiveGeminiAudio() {
  if (activeAudioSource) {
    try {
      activeAudioSource.stop();
      activeAudioSource.disconnect();
    } catch {
      // Ignored if already stopped
    }
    activeAudioSource = null;
  }
}

/**
 * Plays base64-encoded audio returned from Gemini Neural TTS (24kHz 16-bit PCM or WAV container).
 */
export async function playGeminiAudio(
  base64Data: string,
  mimeType = 'audio/pcm;rate=24000',
  onStart?: () => void,
  onEnd?: () => void
): Promise<boolean> {
  try {
    stopActiveGeminiAudio();
    const audioCtx = getAudioContext();

    const binaryString = window.atob(base64Data);
    const len = binaryString.length;
    const bytes = new Uint8Array(len);
    for (let i = 0; i < len; i++) {
      bytes[i] = binaryString.charCodeAt(i);
    }

    // If payload is already a WAV/MP3 container (starts with RIFF or ID3)
    if (len > 4 && binaryString.startsWith('RIFF')) {
      const buffer = await audioCtx.decodeAudioData(bytes.buffer.slice(0));
      const source = audioCtx.createBufferSource();
      source.buffer = buffer;
      source.connect(audioCtx.destination);
      activeAudioSource = source;

      source.onended = () => {
        activeAudioSource = null;
        if (onEnd) onEnd();
      };

      if (onStart) onStart();
      source.start(0);
      return true;
    }

    // Default: 16-bit linear PCM at 24000 Hz
    let sampleRate = 24000;
    const rateMatch = mimeType.match(/rate=(\d+)/i);
    if (rateMatch && rateMatch[1]) {
      sampleRate = parseInt(rateMatch[1], 10) || 24000;
    }

    const int16Array = new Int16Array(bytes.buffer);
    const float32Array = new Float32Array(int16Array.length);
    for (let i = 0; i < int16Array.length; i++) {
      float32Array[i] = int16Array[i] / 32768.0;
    }

    const audioBuffer = audioCtx.createBuffer(1, float32Array.length, sampleRate);
    audioBuffer.getChannelData(0).set(float32Array);

    const source = audioCtx.createBufferSource();
    source.buffer = audioBuffer;
    source.connect(audioCtx.destination);
    activeAudioSource = source;

    source.onended = () => {
      activeAudioSource = null;
      if (onEnd) onEnd();
    };

    if (onStart) onStart();
    source.start(0);
    return true;
  } catch (err) {
    console.warn('Gemini Audio Player decode error:', err);
    if (onEnd) onEnd();
    return false;
  }
}
