import { CuratedMediaItem } from '../types';

export interface YouTubeSearchResult {
  videoId: string;
  title: string;
  channelTitle?: string;
  description?: string;
  category: string;
  tag: string;
  isLive?: boolean;
  thumbnailUrl?: string;
}

/**
 * Robustly parses YouTube URLs or raw video IDs.
 * Supports youtube.com/watch?v=, youtu.be/, youtube.com/embed/, youtube.com/shorts/, youtube.com/live/
 */
export function extractYouTubeVideoId(input: string): string | null {
  if (!input) return null;
  const trimmed = input.trim();

  // If already an 11-char alphanumeric ID (with - and _)
  if (/^[a-zA-Z0-9_-]{11}$/.test(trimmed)) {
    return trimmed;
  }

  // Regex capturing various YouTube link structures
  const patterns = [
    /(?:youtu\.be\/|youtube\.com\/(?:embed\/|v\/|watch\?v=|watch\?.+&v=|shorts\/|live\/))([a-zA-Z0-9_-]{11})/,
    /^[a-zA-Z0-9_-]{11}$/,
  ];

  for (const pattern of patterns) {
    const match = trimmed.match(pattern);
    if (match && match[1]) {
      return match[1];
    }
  }

  // Parameter check
  try {
    const url = new URL(trimmed.startsWith('http') ? trimmed : `https://${trimmed}`);
    const v = url.searchParams.get('v');
    if (v && /^[a-zA-Z0-9_-]{11}$/.test(v)) {
      return v;
    }
  } catch (_) {
    // Ignore URL parse error
  }

  return null;
}

/**
 * Builds the strict, embed-safe YouTube iframe URL as required:
 * https://www.youtube.com/embed/{VIDEO_ID}?autoplay=1&enablejsapi=1&playsinline=1&origin=${window.location.origin}
 */
export function buildEmbedSafeYouTubeUrl(
  videoId: string,
  options: {
    autoplay?: boolean;
    start?: number;
    mute?: boolean;
    origin?: string;
  } = {}
): string {
  const { autoplay = true, start = 0, mute = false, origin } = options;
  const cleanId = extractYouTubeVideoId(videoId) || videoId;

  let computedOrigin = origin;
  if (!computedOrigin && typeof window !== 'undefined' && window.location) {
    computedOrigin = window.location.origin;
  }

  const params = new URLSearchParams();
  if (autoplay) params.set('autoplay', '1');
  params.set('enablejsapi', '1');
  params.set('playsinline', '1');
  if (mute) params.set('mute', '1');
  if (start > 0) params.set('start', String(Math.floor(start)));
  if (computedOrigin) params.set('origin', computedOrigin);
  params.set('rel', '0');

  return `https://www.youtube.com/embed/${cleanId}?${params.toString()}`;
}

/**
 * Returns human-readable error descriptions and recovery recommendations for YouTube Player error codes.
 */
export function getYouTubeErrorExplanation(errorCode: number | string): {
  title: string;
  message: string;
  isEmbedBlocked: boolean;
} {
  const codeNum = typeof errorCode === 'number' ? errorCode : parseInt(errorCode, 10);
  switch (codeNum) {
    case 2:
      return {
        title: 'Invalid Video Parameter',
        message: 'The requested YouTube video ID contains invalid parameters or malformed syntax.',
        isEmbedBlocked: false,
      };
    case 5:
      return {
        title: 'HTML5 Player Error',
        message: 'The requested content cannot be played in the current HTML5 player container.',
        isEmbedBlocked: false,
      };
    case 100:
      return {
        title: 'Video Not Found / Removed',
        message: 'The requested YouTube video has been removed, made private, or is unavailable.',
        isEmbedBlocked: false,
      };
    case 101:
    case 150:
      return {
        title: 'Embed-Restricted by Owner',
        message: 'The content creator or copyright owner has restricted third-party embedded playback.',
        isEmbedBlocked: true,
      };
    default:
      return {
        title: 'Playback Stream Issue',
        message: `An unexpected stream error (code ${errorCode}) occurred while loading the video.`,
        isEmbedBlocked: false,
      };
  }
}

/**
 * Categorizes a query or title into one of the 5 standard office buckets.
 */
export function categorizeMediaTopic(query: string): {
  category: string;
  tag: string;
} {
  const q = query.toLowerCase();

  if (q.includes('three') || q.includes('webgl') || q.includes('react') || q.includes('tutorial') || q.includes('code') || q.includes('css') || q.includes('shader') || q.includes('system design')) {
    return {
      category: 'Engineering Tutorials & Dev',
      tag: '💻 Dev Guide',
    };
  }

  if (q.includes('lofi') || q.includes('lo-fi') || q.includes('ambient') || q.includes('relax') || q.includes('synthwave') || q.includes('jazz') || q.includes('rain') || q.includes('study') || q.includes('focus') || q.includes('nasa') || q.includes('space')) {
    return {
      category: 'Cozy Escapes & Ambient Media',
      tag: '🎧 Ambient Focus',
    };
  }

  if (q.includes('gemini') || q.includes('google') || q.includes('fireship') || q.includes('news') || q.includes('cleo') || q.includes('tech') || q.includes('ai') || q.includes('hardware')) {
    return {
      category: 'Internet Culture & Tech News',
      tag: '⚡ Tech Culture',
    };
  }

  if (q.includes('game') || q.includes('gaming') || q.includes('speedrun') || q.includes('gdq') || q.includes('noclip') || q.includes('gmtk') || q.includes('devlog')) {
    return {
      category: 'Gaming & Creator Culture',
      tag: '🎮 Gaming & Craft',
    };
  }

  if (q.includes('cinema') || q.includes('movie') || q.includes('film') || q.includes('ghibli') || q.includes('essay') || q.includes('every frame') || q.includes('directing')) {
    return {
      category: 'Cinematic & Pop Culture Clips',
      tag: '🎬 Cinema & Arts',
    };
  }

  return {
    category: 'Internet Culture & Tech News',
    tag: '📺 Office Stream',
  };
}

/**
 * Verified high-reliability fallback streams guaranteed to support embed playback without copyright blocks.
 */
export const VERIFIED_EMBED_SAFE_PRESETS: CuratedMediaItem[] = [
  {
    id: 'preset-lofi-girl',
    videoId: 'jfKfPfyJRdk',
    url: 'https://www.youtube.com/watch?v=jfKfPfyJRdk',
    title: 'Lofi Girl 📚 - 24/7 Beats to Relax/Study to',
    category: 'Cozy Escapes & Ambient Media',
    channel: 'Lofi Girl',
    description: 'Continuous 24/7 lo-fi hip hop stream for coding, deep focus, and office relaxation.',
    tag: '🎧 24/7 Lo-Fi Beats',
  },
  {
    id: 'preset-synthwave-radio',
    videoId: '4xDzrJKXOOY',
    url: 'https://www.youtube.com/watch?v=4xDzrJKXOOY',
    title: 'Synthwave Radio 🌌 - Chill Electronic Synth Beats',
    category: 'Cozy Escapes & Ambient Media',
    channel: 'Lofi Girl - Synthwave',
    description: 'Retro futuristic downtempo synthwave soundscapes for evening development.',
    tag: '🌆 Neon Synthwave',
  },
  {
    id: 'preset-react-19-dev',
    videoId: 'd_S4K3YQ2Qc',
    url: 'https://www.youtube.com/watch?v=d_S4K3YQ2Qc',
    title: 'React 19 & Next-Gen Frontend Engineering',
    category: 'Engineering Tutorials & Dev',
    channel: 'Fireship',
    description: 'Full overview of React 19 Actions, Server Components, useActionState, and compiler features.',
    tag: '💻 React 19 Tutorial',
  },
  {
    id: 'preset-threejs-webgl',
    videoId: '3NEsPjQn0V4',
    url: 'https://www.youtube.com/watch?v=3NEsPjQn0V4',
    title: 'Three.js & WebGL 3D Interactive Spatial Guide',
    category: 'Engineering Tutorials & Dev',
    channel: 'Frontend Masters / Three.js',
    description: 'Building immersive 3D interactive graphics, shaders, and spatial canvas simulations in the browser.',
    tag: '🌐 3D WebGL Guide',
  },
  {
    id: 'preset-nasa-earth-live',
    videoId: 'xRPjKOmvk1s',
    url: 'https://www.youtube.com/watch?v=xRPjKOmvk1s',
    title: 'NASA Live 🚀 - Earth Views from ISS Orbit',
    category: 'Cozy Escapes & Ambient Media',
    channel: 'NASA',
    description: 'Awe-inspiring real-time orbital video stream of planet Earth from 250 miles above.',
    tag: '🚀 NASA Earth Live',
  },
  {
    id: 'preset-google-gemini-agentic',
    videoId: 'yIdnI3167bA',
    url: 'https://www.youtube.com/watch?v=yIdnI3167bA',
    title: 'Google Gemini 3.5 & Agentic Multimodal Reasoning',
    category: 'Internet Culture & Tech News',
    channel: 'Google Cloud Tech',
    description: 'Deep dive into next-generation Gemini 3.5 multimodal reasoning and autonomous agent architectures.',
    tag: '⚡ Google Gemini 3.5',
  },
  {
    id: 'preset-cozy-cafe-jazz',
    videoId: 'lTRiuFIWV54',
    url: 'https://www.youtube.com/watch?v=lTRiuFIWV54',
    title: 'Cozy Coffee Shop ☕ - Warm Acoustic Jazz & Rain Ambience',
    category: 'Cozy Escapes & Ambient Media',
    channel: 'Coffee Jazz Ambience',
    description: 'Warm cafe acoustics, rainy window soundscapes, and acoustic piano chords.',
    tag: '☕ Cozy Cafe Jazz',
  },
  {
    id: 'preset-cinema-quiet-moments',
    videoId: '5qap5aO4i9A',
    url: 'https://www.youtube.com/watch?v=5qap5aO4i9A',
    title: 'The Art of Quiet Moments in Cinema Animation',
    category: 'Cinematic & Pop Culture Clips',
    channel: 'Cinema Essays',
    description: 'Dissecting visual serenity, pacing, and intentional breathing room in cinematic classics.',
    tag: '🎬 Cinema Essay',
  },
];
