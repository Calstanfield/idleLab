import { chloeVoice } from './chloeVoice';
import { chloeAgentClient, ChloeAgentResponse } from './chloeAgentClient';

export interface ToolExecutionStep {
  id: string;
  type: 'thought' | 'action' | 'observation' | 'summary';
  title: string;
  detail: string;
  timestamp: number;
  status: 'pending' | 'running' | 'success' | 'failed';
  payload?: any;
}

export interface ActiveToolTrace {
  toolName: 'execute_workflow_action' | 'query_session_memory' | 'validate_gateway_policy' | 'tts_audio_streamer';
  actionType: string;
  status: 'IDLE' | 'RUNNING' | 'SUCCESS' | 'FAILED';
  startedAt: number;
  completedAt?: number;
  durationMs?: number;
  inputPayload: Record<string, any>;
  outputPayload?: Record<string, any>;
  steps: ToolExecutionStep[];
}

export interface SessionMemoryStore {
  activeContext: string;
  sessionId: string;
  iamIdentity: {
    userId: string;
    role: string;
    token: string;
    verified: boolean;
    tier: string;
    expiresAt: string;
  };
  memoryBank: Record<string, any>;
  lastSyncedAt: number;
  lastFsmState?: string;
  lastFsmTarget?: string;
  lastFsmAction?: string;
}

const STORAGE_KEY = 'idlelab_simulator_memory_v1';

export class SimulatorEngine {
  private memory: SessionMemoryStore;
  private currentTrace: ActiveToolTrace | null = null;
  private listeners: Set<(trace: ActiveToolTrace | null, memory: SessionMemoryStore) => void> = new Set();

  constructor() {
    this.memory = this.loadInitialMemory();
  }

  private eventHooks: Set<(event: { type: string; payload: any; timestamp: number }) => void> = new Set();

  private loadInitialMemory(): SessionMemoryStore {
    if (typeof window !== 'undefined') {
      try {
        const saved = localStorage.getItem(STORAGE_KEY);
        if (saved) {
          return JSON.parse(saved);
        }
      } catch (e) {
        console.warn('Failed to parse saved session memory, using dynamic defaults:', e);
      }
    }

    const currentTimestamp = Date.now();
    return {
      activeContext: 'IdleLab Distributed Spatial Workspace & Autonomous Orchestration',
      sessionId: `sess_idlelab_9948_${currentTimestamp.toString(36)}`,
      iamIdentity: {
        userId: 'usr_lead_architect_9948',
        role: 'Autonomous Coordinator',
        token: 'eyJhZ2VudCI6ImNobG9lIiwidG9rZW4iOiJ6ZXJvLXRydXN0LWF1dGgtOTk0OCJ9',
        verified: true,
        tier: 'Level-3 (Executive Governance)',
        expiresAt: new Date(currentTimestamp + 86400000).toISOString(),
      },
      memoryBank: {
        system_status: 'ONLINE_ACTIVE',
        active_fsm_state: 'IDLE',
        active_spatial_zone: '#B1 Corporate Office',
        zero_trust_policy_status: 'IAM_VERIFIED_LEVEL_3',
        audio_stream_pipeline: 'TTS_STREAMER_ASYNC',
        last_event_synced: new Date(currentTimestamp).toISOString(),
      },
      lastSyncedAt: currentTimestamp,
    };
  }

  public onEventHook(listener: (event: { type: string; payload: any; timestamp: number }) => void): () => void {
    this.eventHooks.add(listener);
    return () => this.eventHooks.delete(listener);
  }

  private triggerEventHook(type: string, payload: any) {
    const event = { type, payload, timestamp: Date.now() };
    this.eventHooks.forEach((cb) => cb(event));
  }

  public getMemory(): SessionMemoryStore {
    return { ...this.memory };
  }

  public getCurrentTrace(): ActiveToolTrace | null {
    return this.currentTrace;
  }

  public subscribe(listener: (trace: ActiveToolTrace | null, memory: SessionMemoryStore) => void): () => void {
    this.listeners.add(listener);
    listener(this.currentTrace, this.memory);
    return () => this.listeners.delete(listener);
  }

  private notify() {
    this.listeners.forEach((l) => l(this.currentTrace, this.memory));
    if (typeof window !== 'undefined') {
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(this.memory));
      } catch (e) {}
    }
  }

  public updateMemoryKey(key: string, value: any) {
    this.memory.memoryBank = {
      ...this.memory.memoryBank,
      [key]: value,
    };
    this.memory.lastSyncedAt = Date.now();
    this.triggerEventHook('MEMORY_UPDATED', { key, value });
    this.notify();
  }

  public removeMemoryKey(key: string) {
    const updated = { ...this.memory.memoryBank };
    delete updated[key];
    this.memory.memoryBank = updated;
    this.memory.lastSyncedAt = Date.now();
    this.triggerEventHook('MEMORY_DELETED', { key });
    this.notify();
  }

  public setActiveContext(context: string) {
    this.memory.activeContext = context;
    this.memory.lastSyncedAt = Date.now();
    this.notify();
  }

  public resetMemory() {
    localStorage.removeItem(STORAGE_KEY);
    this.memory = this.loadInitialMemory();
    this.notify();
  }

  /**
   * Visual Debugger & State Monitor for Chloe's FSM State Machine
   * Prints "[Chloe FSM]: State changed to -> {state}" and triggers HUD toast feedback
   */
  public logFsmStateChange(
    newState: string,
    targetZone?: string,
    activeObject?: string,
    details?: string
  ) {
    const banner = `[Chloe FSM]: State changed to -> ${newState}${
      targetZone ? ` (${targetZone})` : ''
    }${activeObject ? ` [${activeObject}]` : ''}`;

    console.log(`%c${banner}`, 'background: #1e1b4b; color: #a5b4fc; font-weight: bold; padding: 2px 6px; border-radius: 4px;', details ? `| ${details}` : '');

    this.memory.lastFsmState = newState;
    this.memory.lastFsmTarget = targetZone;
    this.memory.lastFsmAction = details || activeObject;

    this.updateMemoryKey('active_fsm_state', newState);
    if (targetZone) this.updateMemoryKey('active_spatial_zone', targetZone);
    if (activeObject) this.updateMemoryKey('active_office_object', activeObject);

    this.notify();

    this.triggerEventHook('FSM_STATE_CHANGED', {
      newState,
      targetZone,
      activeObject,
      details,
      banner,
      timestamp: Date.now(),
    });
  }

  /**
   * Tool 1: validate_gateway_policy (Security/Governance)
   * Intercepts prompts for safety and verifies token identity permissions before executing downstream requests.
   */
  public async validateGatewayPolicy(prompt: string, targetAction: string): Promise<{
    allowed: boolean;
    policyVerdict: string;
    tokenStatus: string;
    riskScore: number;
  }> {
    const trace: ActiveToolTrace = {
      toolName: 'validate_gateway_policy',
      actionType: targetAction || 'policy_inspection',
      status: 'RUNNING',
      startedAt: Date.now(),
      inputPayload: {
        prompt,
        targetAction,
        iamToken: this.memory.iamIdentity.token,
        userId: this.memory.iamIdentity.userId,
      },
      steps: [
        {
          id: 'step-1',
          type: 'thought',
          title: 'Thinking',
          detail: `Verifying zero-trust IAM token signature & rate policy for action "${targetAction}"...`,
          timestamp: Date.now(),
          status: 'running',
        },
      ],
    };

    this.currentTrace = trace;
    this.notify();

    await new Promise((r) => setTimeout(r, 380));

    trace.steps[0].status = 'success';
    trace.steps.push({
      id: 'step-2',
      type: 'action',
      title: 'Calling Security Gateway',
      detail: 'POST /v1/gateway/policy/evaluate (Zero-Trust IAM Level-3 Policy Engine)',
      timestamp: Date.now(),
      status: 'running',
      payload: { policyRules: ['no_pii_leak', 'idempotent_mutation_only', 'valid_iam_signature'] },
    });
    this.notify();

    await new Promise((r) => setTimeout(r, 420));

    trace.steps[1].status = 'success';
    const output = {
      allowed: true,
      policyVerdict: 'PASSED_CLEAN',
      tokenStatus: 'ACTIVE_VALID_SIGNATURE',
      riskScore: 0.02,
      evaluatedAt: new Date().toISOString(),
    };

    trace.steps.push({
      id: 'step-3',
      type: 'observation',
      title: 'Observation',
      detail: 'Gateway Policy passed. No prompt injection or PII vulnerability detected. Authorization signed.',
      timestamp: Date.now(),
      status: 'success',
      payload: output,
    });

    trace.status = 'SUCCESS';
    trace.completedAt = Date.now();
    trace.durationMs = trace.completedAt - trace.startedAt;
    trace.outputPayload = output;

    this.notify();
    return output;
  }

  /**
   * Tool 2: query_session_memory (State Tool)
   * Fetches historical context and past conversation variables across sessions.
   */
  public async querySessionMemory(queryKey?: string): Promise<{
    sessionContext: string;
    retrievedVariables: Record<string, any>;
    lastSynced: string;
  }> {
    const trace: ActiveToolTrace = {
      toolName: 'query_session_memory',
      actionType: 'fetch_cross_session_state',
      status: 'RUNNING',
      startedAt: Date.now(),
      inputPayload: {
        sessionId: this.memory.sessionId,
        filterKey: queryKey || 'ALL',
      },
      steps: [
        {
          id: 'step-1',
          type: 'thought',
          title: 'Thinking',
          detail: `Querying persistent memory bank for session #${this.memory.sessionId}...`,
          timestamp: Date.now(),
          status: 'running',
        },
      ],
    };

    this.currentTrace = trace;
    this.notify();

    await new Promise((r) => setTimeout(r, 320));

    trace.steps[0].status = 'success';
    trace.steps.push({
      id: 'step-2',
      type: 'action',
      title: 'Calling Memory Cache',
      detail: 'READ /v1/session/memory/lookup (IndexedDB & State Cache)',
      timestamp: Date.now(),
      status: 'running',
      payload: { keysRequested: queryKey ? [queryKey] : Object.keys(this.memory.memoryBank) },
    });
    this.notify();

    await new Promise((r) => setTimeout(r, 360));

    trace.steps[1].status = 'success';
    const output = {
      sessionContext: this.memory.activeContext,
      retrievedVariables: queryKey ? { [queryKey]: this.memory.memoryBank[queryKey] } : this.memory.memoryBank,
      lastSynced: new Date(this.memory.lastSyncedAt).toLocaleTimeString(),
    };

    trace.steps.push({
      id: 'step-3',
      type: 'observation',
      title: 'Observation',
      detail: `Successfully hydrated ${Object.keys(output.retrievedVariables).length} persistent cross-session keys.`,
      timestamp: Date.now(),
      status: 'success',
      payload: output,
    });

    trace.status = 'SUCCESS';
    trace.completedAt = Date.now();
    trace.durationMs = trace.completedAt - trace.startedAt;
    trace.outputPayload = output;

    this.notify();
    return output;
  }

  /**
   * Tool 3: execute_workflow_action (Core Agent Tool)
   * Triggers multi-step backend operations (e.g., parsing transcripts or processing e-commerce desyncs).
   */
  public async executeWorkflowAction(
    actionType: 'patch_inventory' | 'run_pm_pipeline' | 'audit_project_blindspots' | 'parse_meeting_transcript',
    params: Record<string, any>
  ): Promise<{
    success: boolean;
    result: string;
    affectedEntities: number;
    mutationSummary: Record<string, any>;
  }> {
    const trace: ActiveToolTrace = {
      toolName: 'execute_workflow_action',
      actionType,
      status: 'RUNNING',
      startedAt: Date.now(),
      inputPayload: params,
      steps: [
        {
          id: 'step-1',
          type: 'thought',
          title: 'Thinking',
          detail: `Analyzing workflow execution plan for action: "${actionType}"...`,
          timestamp: Date.now(),
          status: 'running',
        },
      ],
    };

    this.currentTrace = trace;
    this.notify();

    await new Promise((r) => setTimeout(r, 450));

    trace.steps[0].status = 'success';
    trace.steps.push({
      id: 'step-2',
      type: 'action',
      title: 'Executing Action Pipeline',
      detail: `POST /v1/workflows/${actionType} (Orchestrator Backend Cluster)`,
      timestamp: Date.now(),
      status: 'running',
      payload: params,
    });
    this.notify();

    await new Promise((r) => setTimeout(r, 650));

    trace.steps[1].status = 'success';

    let resultSummary = '';
    let affected = 1;
    let mutation: Record<string, any> = {};

    switch (actionType) {
      case 'patch_inventory':
        resultSummary = `SKU desync resolved. Reconciled inventory records across Shopify & NetSuite node #4. Delta: 0 anomalies.`;
        affected = 48;
        mutation = {
          skuTarget: params.sku || 'SKU-8821-V4',
          recordsUpdated: 48,
          reconciliationStatus: 'IN_SYNC',
          warehouseCluster: 'US-Central-1B',
        };
        this.updateMemoryKey('sku_desync_history', `Resolved SKU ${params.sku || 'SKU-8821-V4'} desync on ${new Date().toLocaleTimeString()}`);
        break;

      case 'run_pm_pipeline':
        resultSummary = `PM release roadmap verified. Automated pipeline parsed 12 sprint tickets, resolved 2 blocker dependencies.`;
        affected = 12;
        mutation = {
          pipelineStatus: 'GREEN',
          blockersMitigated: 2,
          nextMilestone: 'Production Rollout Stage 1',
        };
        this.updateMemoryKey('last_audit_verdict', 'PM Pipeline Stage 1 Passed 100%');
        break;

      case 'audit_project_blindspots':
        resultSummary = `Full project blind spot audit completed. Single points of failure eliminated; verified fallback routing.`;
        affected = 6;
        mutation = {
          riskRating: 'LOW',
          complianceScore: '98.5%',
          auditLogId: `AUDIT-${Date.now().toString().slice(-4)}`,
        };
        this.updateMemoryKey('last_audit_verdict', 'Architecture Blindspots Cleared');
        break;

      case 'parse_meeting_transcript':
      default:
        resultSummary = `Parsed meeting transcript. 4 actionable items extracted and synchronized with workspace checklist.`;
        affected = 4;
        mutation = {
          itemsCreated: 4,
          sentiment: 'Collaborative / High Efficiency',
        };
        break;
    }

    trace.steps.push({
      id: 'step-3',
      type: 'observation',
      title: 'Observation',
      detail: resultSummary,
      timestamp: Date.now(),
      status: 'success',
      payload: mutation,
    });

    const output = {
      success: true,
      result: resultSummary,
      affectedEntities: affected,
      mutationSummary: mutation,
    };

    trace.status = 'SUCCESS';
    trace.completedAt = Date.now();
    trace.durationMs = trace.completedAt - trace.startedAt;
    trace.outputPayload = output;

    this.notify();
    return output;
  }

  /**
   * Tool 4: tts_audio_streamer (Voice Output)
   * Converts text responses into real-time audio streams for voice assistant persona playback.
   */
  public async ttsAudioStreamer(
    text: string,
    onStart?: () => void,
    onEnd?: () => void
  ): Promise<void> {
    const trace: ActiveToolTrace = {
      toolName: 'tts_audio_streamer',
      actionType: 'stream_elevenlabs_neural_audio',
      status: 'RUNNING',
      startedAt: Date.now(),
      inputPayload: {
        voiceId: chloeVoice.getConfig().voice_id || '21m00Tcm4TlvDq8ikWAM',
        model: 'eleven_multilingual_v2',
        stability: 0.5,
        similarity_boost: 0.75,
        textPreview: text.slice(0, 80) + '...',
      },
      steps: [
        {
          id: 'step-1',
          type: 'thought',
          title: 'Thinking',
          detail: 'Preparing neural audio stream parameters for Chloe Becker persona...',
          timestamp: Date.now(),
          status: 'running',
        },
      ],
    };

    this.currentTrace = trace;
    this.notify();

    trace.steps[0].status = 'success';
    trace.steps.push({
      id: 'step-2',
      type: 'action',
      title: 'Streaming Audio Buffer',
      detail: `POST https://api.elevenlabs.io/v1/text-to-speech/${chloeVoice.getConfig().voice_id || '21m00Tcm4TlvDq8ikWAM'} (audio/mpeg stream)`,
      timestamp: Date.now(),
      status: 'running',
    });
    this.notify();

    if (onStart) onStart();

    chloeVoice.speak(
      text,
      'simulator_engine',
      () => {
        trace.steps[1].status = 'success';
        trace.steps.push({
          id: 'step-3',
          type: 'observation',
          title: 'Observation',
          detail: 'Neural voice stream completed playback successfully.',
          timestamp: Date.now(),
          status: 'success',
        });
        trace.status = 'SUCCESS';
        trace.completedAt = Date.now();
        trace.durationMs = trace.completedAt - trace.startedAt;
        this.notify();
        if (onEnd) onEnd();
      },
      () => {
        trace.steps[1].status = 'failed';
        trace.status = 'FAILED';
        this.notify();
        if (onEnd) onEnd();
      }
    );
  }

  /**
   * Autonomous Full-Cycle Command Runner
   * Orchestrates: Gateway Policy Validation -> Autonomous Tool Execution -> Memory Sync -> TTS Summary
   */
  public async executeAutonomousCommand(
    prompt: string,
    userName: string = 'Colleague',
    onSpeechStart?: () => void,
    onSpeechEnd?: () => void
  ): Promise<ChloeAgentResponse> {
    const clean = prompt.trim();
    if (!clean) {
      throw new Error('Prompt cannot be empty');
    }

    const lower = clean.toLowerCase();

    // 1. Step 1: Validate Security Gateway Policy
    await this.validateGatewayPolicy(clean, lower.includes('desync') || lower.includes('sku') ? 'patch_inventory' : 'orchestration_query');

    let toolResultText = '';

    // 2. Step 2: Determine if Tool execution is needed
    if (lower.includes('desync') || lower.includes('sku') || lower.includes('inventory')) {
      const toolRes = await this.executeWorkflowAction('patch_inventory', {
        sku: 'SKU-8821-V4',
        systemA: 'Shopify Storefront API',
        systemB: 'NetSuite ERP Cluster #4',
        requestedBy: userName,
      });
      toolResultText = ` ${toolRes.result}`;
    } else if (lower.includes('pm') || lower.includes('pipeline') || lower.includes('roadmap') || lower.includes('sprint')) {
      const toolRes = await this.executeWorkflowAction('run_pm_pipeline', {
        sprintCycle: 'Sprint-42',
        targetBranch: 'main-production',
        requestedBy: userName,
      });
      toolResultText = ` ${toolRes.result}`;
    } else if (lower.includes('blindspot') || lower.includes('audit') || lower.includes('risk')) {
      const toolRes = await this.executeWorkflowAction('audit_project_blindspots', {
        scope: 'Full Distributed Stack',
        requestedBy: userName,
      });
      toolResultText = ` ${toolRes.result}`;
    } else if (lower.includes('memory') || lower.includes('recall') || lower.includes('context') || lower.includes('session')) {
      const memRes = await this.querySessionMemory();
      toolResultText = ` Retrieved ${Object.keys(memRes.retrievedVariables).length} active memory context variables for session #${this.memory.sessionId}.`;
    }

    // 3. Step 3: Run Cognitive Agent Synthesis
    let replyText = '';
    try {
      const cognitiveRes = await chloeAgentClient.sendQuery(clean, {
        userName,
        history: [],
        pillar: 'report_audit',
        targetLanguage: 'auto',
      });
      replyText = cognitiveRes.text || `Workflow executed with zero-trust validation.${toolResultText}`;
    } catch {
      replyText = `Workflow operation executed successfully under zero-trust governance.${toolResultText} What's our next objective?`;
    }

    // 4. Step 4: TTS Neural Voice Streaming
    this.ttsAudioStreamer(replyText, onSpeechStart, onSpeechEnd);

    return {
      success: true,
      text: replyText,
      speech: replyText,
      suggestedActions: [
        '📦 Fix SKU Desync',
        '🔄 Run PM Pipeline',
        '🛡️ Validate Gateway Policy',
        '🧠 Query Session Memory',
      ],
      activeSubAgent: 'chloe_general',
      languageCode: 'en-US',
      isExternalEndpoint: Boolean(chloeAgentClient.getCloudEndpoint()),
    };
  }
}

export const simulatorEngine = new SimulatorEngine();
