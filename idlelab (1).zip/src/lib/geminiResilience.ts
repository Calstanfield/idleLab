import { GoogleGenAI, GenerateContentResponse } from '@google/genai';

/**
 * Resilient Gemini Content Generation with Smart Model Fallbacks & Retry Backoff
 * Handles temporary 503 ("model experiencing high demand") and 429 errors gracefully.
 */
export async function generateContentWithResilience(
  ai: GoogleGenAI,
  params: {
    contents: any;
    model?: string;
    config?: any;
  },
  options: {
    primaryModel?: string;
    fallbackModel?: string;
    maxRetries?: number;
  } = {}
): Promise<GenerateContentResponse> {
  const primaryModel = params.model || options.primaryModel || 'gemini-3.5-flash';
  const fallbackModel = options.fallbackModel || 'gemini-2.5-flash';
  const maxRetries = options.maxRetries ?? 2;

  // 1. Try Primary Model with immediate retry on 503/429
  for (let attempt = 0; attempt < maxRetries; attempt++) {
    try {
      const response = await ai.models.generateContent({
        model: primaryModel,
        contents: params.contents,
        config: params.config,
      });
      return response;
    } catch (err: any) {
      const errMsg = err?.message || String(err);
      const isTransient =
        errMsg.includes('503') ||
        errMsg.includes('429') ||
        errMsg.includes('high demand') ||
        errMsg.includes('UNAVAILABLE') ||
        errMsg.includes('RESOURCE_EXHAUSTED');

      if (isTransient && attempt < maxRetries - 1) {
        // Small backoff before retrying
        await new Promise((r) => setTimeout(r, 300 * (attempt + 1)));
        continue;
      }

      // If primary failed all attempts or is transient, attempt fallback model
      if (fallbackModel && fallbackModel !== primaryModel) {
        try {
          console.warn(
            `Primary model ${primaryModel} busy/unavailable. Switching to resilient fallback ${fallbackModel}...`
          );
          const fallbackResponse = await ai.models.generateContent({
            model: fallbackModel,
            contents: params.contents,
            config: params.config,
          });
          return fallbackResponse;
        } catch (fallbackErr: any) {
          const fbMsg = fallbackErr?.message || String(fallbackErr);
          if (!fbMsg.includes('429') && !fbMsg.includes('RESOURCE_EXHAUSTED')) {
            console.warn(`Fallback model ${fallbackModel} also encountered error:`, fbMsg);
          }
        }
      }

      // Re-throw original error if all retries and fallbacks failed
      throw err;
    }
  }

  throw new Error(`Failed to generate content after ${maxRetries} attempts.`);
}
