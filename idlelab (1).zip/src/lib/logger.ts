export interface LogEntry {
  id: string;
  timestamp: string;
  level: 'info' | 'warn' | 'error' | 'success';
  source: string;
  message: string;
  details?: string;
}

class SystemLogger {
  private logs: LogEntry[] = [];
  private listeners: (() => void)[] = [];

  constructor() {
    // Load persisted logs if any
    try {
      const saved = localStorage.getItem('idlelab_system_logs');
      if (saved) {
        this.logs = JSON.parse(saved);
      }
    } catch {
      this.logs = [];
    }

    // Intercept console.error and console.warn
    const originalError = console.error;
    console.error = (...args: any[]) => {
      originalError.apply(console, args);
      this.addLog('error', 'Console', args.map(a => typeof a === 'object' ? JSON.stringify(a) : String(a)).join(' '));
    };

    const originalWarn = console.warn;
    console.warn = (...args: any[]) => {
      originalWarn.apply(console, args);
      this.addLog('warn', 'Console', args.map(a => typeof a === 'object' ? JSON.stringify(a) : String(a)).join(' '));
    };

    // Global error listener
    window.addEventListener('error', (event) => {
      this.addLog('error', 'Runtime', event.message, `${event.filename}:${event.lineno}:${event.colno}`);
    });

    window.addEventListener('unhandledrejection', (event) => {
      this.addLog('error', 'Promise', String(event.reason?.message || event.reason));
    });
  }

  public addLog(level: 'info' | 'warn' | 'error' | 'success', source: string, message: string, details?: string) {
    const entry: LogEntry = {
      id: `log_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
      level,
      source,
      message,
      details,
    };
    this.logs.unshift(entry);
    if (this.logs.length > 100) {
      this.logs = this.logs.slice(0, 100);
    }
    try {
      localStorage.setItem('idlelab_system_logs', JSON.stringify(this.logs));
    } catch {
      // storage quota fallback
    }
    this.notifyListeners();
  }

  public getLogs(): LogEntry[] {
    return this.logs;
  }

  public clearLogs() {
    this.logs = [];
    localStorage.removeItem('idlelab_system_logs');
    this.notifyListeners();
  }

  public subscribe(listener: () => void) {
    this.listeners.push(listener);
    return () => {
      this.listeners = this.listeners.filter(l => l !== listener);
    };
  }

  private notifyListeners() {
    this.listeners.forEach(l => l());
  }
}

export const systemLogger = new SystemLogger();
