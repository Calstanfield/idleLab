import { GestureType } from '../types';

export interface SmartReactionResult {
  gesture: GestureType;
  emoji: string;
}

export const GESTURE_CONFIGS: Record<
  GestureType,
  { label: string; icon: string; description: string; defaultEmoji: string }
> = {
  wave: { label: 'Wave', icon: '👋', description: 'Wave hello to colleagues', defaultEmoji: '👋' },
  dance: { label: 'Dance', icon: '💃', description: 'Joyful office dance moves', defaultEmoji: '💃' },
  clap: { label: 'Clap', icon: '👏', description: 'Applaud & congratulate team', defaultEmoji: '👏' },
  bow: { label: 'Bow', icon: '🙇‍♂️', description: 'Respectful bow of thanks', defaultEmoji: '🙏' },
  think: { label: 'Think', icon: '🤔', description: 'Deep in thought / brainstorming', defaultEmoji: '💡' },
  cheer: { label: 'Cheer', icon: '🙌', description: 'Celebratory hands in the air', defaultEmoji: '🎉' },
  heart: { label: 'Heart', icon: '❤️', description: 'Send love & appreciation', defaultEmoji: '❤️' },
  facepalm: { label: 'Oops', icon: '🤦‍♂️', description: 'Facepalm / Oops moment', defaultEmoji: '🤦‍♂️' },
};

export const POPULAR_REACTIONS = [
  { emoji: '👋', label: 'Wave', gesture: 'wave' as GestureType },
  { emoji: '👍', label: 'Thrumbs Up', gesture: 'clap' as GestureType },
  { emoji: '❤️', label: 'Heart', gesture: 'heart' as GestureType },
  { emoji: '🔥', label: 'Awesome', gesture: 'cheer' as GestureType },
  { emoji: '🎉', label: 'Party', gesture: 'dance' as GestureType },
  { emoji: '👏', label: 'Clap', gesture: 'clap' as GestureType },
  { emoji: '💡', label: 'Idea', gesture: 'think' as GestureType },
  { emoji: '☕', label: 'Coffee', gesture: 'wave' as GestureType },
  { emoji: '🚀', label: 'Ship It', gesture: 'cheer' as GestureType },
  { emoji: '😂', label: 'Haha', gesture: 'dance' as GestureType },
  { emoji: '🤦‍♂️', label: 'Oops', gesture: 'facepalm' as GestureType },
];

/**
  Smart NLP analysis to detect avatar gesture & floating emoji reaction
  from chat text or status updates!
 */
export function detectSmartReaction(text: string): SmartReactionResult | null {
  const lower = text.toLowerCase().trim();
  if (!lower) return null;

  // 1. Direct Emoji Presence Check
  if (lower.includes('👋')) return { gesture: 'wave', emoji: '👋' };
  if (lower.includes('💃') || lower.includes('🕺') || lower.includes('🎉') || lower.includes('🥳')) return { gesture: 'dance', emoji: lower.includes('🎉') ? '🎉' : '💃' };
  if (lower.includes('👏') || lower.includes('👍') || lower.includes('🙌')) return { gesture: 'clap', emoji: lower.includes('👏') ? '👏' : '👍' };
  if (lower.includes('🙇') || lower.includes('🙏')) return { gesture: 'bow', emoji: '🙏' };
  if (lower.includes('🤔') || lower.includes('💡') || lower.includes('❓')) return { gesture: 'think', emoji: lower.includes('💡') ? '💡' : '🤔' };
  if (lower.includes('🚀') || lower.includes('🔥') || lower.includes('💯') || lower.includes('🍻')) return { gesture: 'cheer', emoji: lower.includes('🔥') ? '🔥' : '🚀' };
  if (lower.includes('❤️') || lower.includes('💖') || lower.includes('😍')) return { gesture: 'heart', emoji: '❤️' };
  if (lower.includes('☕')) return { gesture: 'wave', emoji: '☕' };
  if (lower.includes('😂') || lower.includes('🤣')) return { gesture: 'dance', emoji: '😂' };
  if (lower.includes('🤦')) return { gesture: 'facepalm', emoji: '🤦‍♂️' };

  // 2. Keyword Sentiment Matching
  if (/^(hi|hello|hey|yo|greetings|morning|afternoon|welcome)\b/.test(lower)) {
    return { gesture: 'wave', emoji: '👋' };
  }
  if (/\b(thanks|thank you|thx|grateful|appreciate|ty)\b/.test(lower)) {
    return { gesture: 'bow', emoji: '🙏' };
  }
  if (/\b(great|awesome|amazing|ship|shipped|congrats|congratulations|woohoo|party|celebrate)\b/.test(lower)) {
    return { gesture: 'cheer', emoji: '🎉' };
  }
  if (/\b(lgtm|nice|good job|bravo|approved|sweet|rock)\b/.test(lower)) {
    return { gesture: 'clap', emoji: '👏' };
  }
  if (/\b(idea|think|thinking|brainstorm|question|curious|wonder|hmm)\b/.test(lower)) {
    return { gesture: 'think', emoji: '💡' };
  }
  if (/\b(love|heart|kudos|favorite)\b/.test(lower)) {
    return { gesture: 'heart', emoji: '❤️' };
  }
  if (/\b(lol|haha|lmao|funny|hilarious|rofl)\b/.test(lower)) {
    return { gesture: 'dance', emoji: '😂' };
  }
  if (/\b(coffee|tea|cafe|drink|break|lunch)\b/.test(lower)) {
    return { gesture: 'wave', emoji: '☕' };
  }
  if (/\b(oops|sorry|my bad|bug|error|whoops)\b/.test(lower)) {
    return { gesture: 'facepalm', emoji: '🤦‍♂️' };
  }

  return null;
}
