import { CuratedMediaItem, OfficeProjectionState } from '../types';

export interface ChloeAgentPayload {
  prompt?: string;
  userName?: string;
  eventType: 'prompt' | 'action' | 'afk' | 'ping';
  actionName?: string;
  actionDetails?: any;
  idleDurationMs?: number;
  history?: Array<{ role: 'user' | 'chloe'; text: string }>;
  pillar?: string;
  targetLanguage?: string;
  autoRefine?: boolean;
  timestamp: number;
  tone?: string;
  context?: string;
}

export interface ChloeAgentResponse {
  success: boolean;
  text: string;
  speech?: string;
  action?: string;
  suggestedActions?: string[];
  activeSubAgent?: 'task_gov' | 'culture_match' | 'tech_fix' | 'wisdom_well' | 'workspace_automator' | 'chloe_general';
  subAgentInsights?: Record<string, string>;
  grammarTip?: string;
  detectedLanguage?: string;
  languageCode?: string;
  checklistItems?: Array<{ text: string; done: boolean }>;
  curatedMedia?: CuratedMediaItem[];
  projectionState?: OfficeProjectionState | null;
  isExternalEndpoint?: boolean;
  error?: string;
}

type AgentResponseListener = (response: ChloeAgentResponse) => void;
type AgentLoadingListener = (isLoading: boolean, statusText?: string) => void;
type ScreenShareTriggerListener = (start: boolean, options?: { preferTab?: boolean; topic?: string }) => void;
type CastProjectionTriggerListener = (videoId: string, title?: string, category?: string) => void;
type ProjectionStateListener = (state: OfficeProjectionState | null) => void;
type ChecklistSyncListener = (items: Array<{ text: string; done: boolean }>) => void;

class ChloeAgentClient {
  private endpointKey = 'userCloudEndpoint';
  private orchestratorEnabledKey = 'chloe_multi_agent_orchestrator_enabled';
  private defaultEndpoint = ''; // Default to native local Multi-Agent Orchestrator
  private listeners: Set<AgentResponseListener> = new Set();
  private loadingListeners: Set<AgentLoadingListener> = new Set();
  private screenShareListeners: Set<ScreenShareTriggerListener> = new Set();
  private castProjectionListeners: Set<CastProjectionTriggerListener> = new Set();
  private projectionStateListeners: Set<ProjectionStateListener> = new Set();
  private checklistSyncListeners: Set<ChecklistSyncListener> = new Set();
  private currentProjectionState: OfficeProjectionState | null = null;
  private lastAfkTriggerTime = 0;
  private lastActionTriggerTime = 0;
  private sessionId: string = '';

  public getSessionId(): string {
    if (!this.sessionId) {
      if (typeof window !== 'undefined') {
        const stored = sessionStorage.getItem('chloe_cloud_session_id');
        if (stored) {
          this.sessionId = stored;
        } else {
          const generated = `session_chloe_${Date.now()}_${Math.random().toString(36).substring(2, 8)}`;
          sessionStorage.setItem('chloe_cloud_session_id', generated);
          this.sessionId = generated;
        }
      } else {
        this.sessionId = `session_chloe_${Date.now()}`;
      }
    }
    return this.sessionId;
  }

  public isOrchestratorEnabled(): boolean {
    if (typeof window === 'undefined') return true;
    const val = localStorage.getItem(this.orchestratorEnabledKey);
    return val === null ? true : val === 'true';
  }

  public setOrchestratorEnabled(enabled: boolean): void {
    if (typeof window === 'undefined') return;
    localStorage.setItem(this.orchestratorEnabledKey, enabled ? 'true' : 'false');
  }

  public getCloudEndpoint(): string {
    if (typeof window === 'undefined') return this.defaultEndpoint;
    return localStorage.getItem(this.endpointKey) || this.defaultEndpoint;
  }

  public setCloudEndpoint(url: string): void {
    if (typeof window === 'undefined') return;
    const cleanUrl = url.trim();
    if (cleanUrl) {
      localStorage.setItem(this.endpointKey, cleanUrl);
    } else {
      localStorage.removeItem(this.endpointKey);
    }
  }

  public subscribe(listener: AgentResponseListener): () => void {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  public onLoadingChange(listener: AgentLoadingListener): () => void {
    this.loadingListeners.add(listener);
    return () => this.loadingListeners.delete(listener);
  }

  private notifyLoading(isLoading: boolean, statusText?: string) {
    this.loadingListeners.forEach((listener) => {
      try {
        listener(isLoading, statusText);
      } catch (err) {
        console.error('Error in agent loading listener:', err);
      }
    });
  }

  public onScreenShareTrigger(listener: ScreenShareTriggerListener): () => void {
    this.screenShareListeners.add(listener);
    return () => this.screenShareListeners.delete(listener);
  }

  public onCastProjectionTrigger(listener: CastProjectionTriggerListener): () => void {
    this.castProjectionListeners.add(listener);
    return () => this.castProjectionListeners.delete(listener);
  }

  public onProjectionStateChanged(listener: ProjectionStateListener): () => void {
    this.projectionStateListeners.add(listener);
    return () => this.projectionStateListeners.delete(listener);
  }

  public onChecklistSync(listener: ChecklistSyncListener): () => void {
    this.checklistSyncListeners.add(listener);
    return () => this.checklistSyncListeners.delete(listener);
  }

  public getProjectionState(): OfficeProjectionState | null {
    return this.currentProjectionState;
  }

  public notifyProjectionState(state: OfficeProjectionState | null) {
    this.currentProjectionState = state;
    this.projectionStateListeners.forEach((listener) => {
      try {
        listener(state);
      } catch (err) {
        console.error('Error in projection state listener:', err);
      }
    });
  }

  public triggerScreenShare(start: boolean, options?: { preferTab?: boolean; topic?: string }) {
    this.screenShareListeners.forEach((listener) => {
      try {
        listener(start, options);
      } catch (err) {
        console.error('Error in screen share trigger listener:', err);
      }
    });
  }

  public triggerCastProjection(videoId: string, title?: string, category?: string) {
    this.castProjectionListeners.forEach((listener) => {
      try {
        listener(videoId, title, category);
      } catch (err) {
        console.error('Error in cast projection trigger listener:', err);
      }
    });
  }

  private notifyListeners(response: ChloeAgentResponse) {
    // Check if the response includes a screen sharing command/action
    const act = (response.action || '').toLowerCase();
    const txt = (response.text || '').toLowerCase();

    if (
      act.includes('start_screen_share') ||
      act.includes('share_screen') ||
      act.includes('start_tab_share') ||
      act.includes('share_tab') ||
      act.includes('stream_view') ||
      act.includes('present_report') ||
      act.includes('present_roadmap')
    ) {
      this.triggerScreenShare(true, {
        preferTab: act.includes('tab'),
        topic: response.text?.slice(0, 50),
      });
    } else if (
      act.includes('stop_screen_share') ||
      act.includes('stop_sharing') ||
      act.includes('unshare') ||
      txt.includes('stopped sharing screen')
    ) {
      this.triggerScreenShare(false);
    }

    if (response.curatedMedia && response.curatedMedia.length > 0 && (act.includes('cast') || act.includes('projection'))) {
      const topMedia = response.curatedMedia[0];
      this.triggerCastProjection(topMedia.videoId, topMedia.title, topMedia.category);
    }

    // Check if response contains checklist items to sync
    if (response.checklistItems && response.checklistItems.length > 0) {
      this.checklistSyncListeners.forEach((listener) => {
        try {
          listener(response.checklistItems!);
        } catch (err) {
          console.error('Error syncing checklist items:', err);
        }
      });
    }

    this.listeners.forEach((listener) => {
      try {
        listener(response);
      } catch (err) {
        console.error('Error in agent response listener:', err);
      }
    });
  }

  public async testEndpoint(endpointUrl: string): Promise<{ success: boolean; latencyMs: number; message: string }> {
    const startTime = Date.now();
    try {
      const isExternal = endpointUrl && endpointUrl.startsWith('http') && !endpointUrl.includes('localhost') && !endpointUrl.includes('127.0.0.1');
      const url = isExternal ? '/api/chloe/external-agent' : '/api/chloe/orchestrator';

      const res = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          endpointUrl,
          eventType: 'ping',
          prompt: 'Ping test from VR Office Inspector',
          userName: 'System Inspector',
          timestamp: Date.now(),
        }),
      });

      const latencyMs = Date.now() - startTime;
      if (!res.ok) {
        return {
          success: false,
          latencyMs,
          message: `Endpoint returned HTTP ${res.status} (${res.statusText})`,
        };
      }

      const data = await res.json();
      if (data.success) {
        return {
          success: true,
          latencyMs,
          message: data.text || 'Chloe Multi-Agent Orchestrator is online and active!',
        };
      }

      return {
        success: false,
        latencyMs,
        message: data.error || data.text || 'Agent returned an error response.',
      };
    } catch (err: any) {
      return {
        success: false,
        latencyMs: Date.now() - startTime,
        message: err.message || 'Failed to reach endpoint.',
      };
    }
  }

  public async sendCloudAgentMessage(
    userMessage: string,
    customSessionId?: string,
    options: {
      userName?: string;
      history?: Array<{ role: 'user' | 'chloe'; text: string }>;
      pillar?: string;
      targetLanguage?: string;
    } = {}
  ): Promise<ChloeAgentResponse> {
    const sessionId = customSessionId || this.getSessionId();
    this.notifyLoading(true, 'Connecting to Cloud Agent...');

    try {
      const res = await fetch('/api/chloe/cloud-agent', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: userMessage,
          session_id: sessionId,
          userName: options.userName || 'Colleague',
          history: options.history || [],
          pillar: options.pillar || 'report_audit',
          targetLanguage: options.targetLanguage || 'auto',
        }),
      });

      this.notifyLoading(false);

      if (res.ok) {
        const data = await res.json();
        const cognitiveResponse = data.response || data.text || data.message || '';
        if (cognitiveResponse) {
          const formatted: ChloeAgentResponse = {
            success: true,
            text: cognitiveResponse,
            speech: data.speech || cognitiveResponse,
            action: data.action,
            suggestedActions: data.suggestedActions || ['Audit document logic', 'Stress-test roadmap', 'Plan travel'],
            activeSubAgent: data.activeSubAgent || 'chloe_general',
            subAgentInsights: data.subAgentInsights,
            grammarTip: data.grammarTip,
            detectedLanguage: data.detectedLanguage || 'English',
            languageCode: data.languageCode || 'en-US',
            checklistItems: data.checklistItems,
            curatedMedia: data.curatedMedia,
            isExternalEndpoint: Boolean(data.isCloudAgent),
          };
          this.notifyListeners(formatted);
          return formatted;
        }
      }
    } catch (err: any) {
      console.warn('Direct Cloud Agent request failed, engaging local fallback:', err);
    }

    this.notifyLoading(false);

    // Fallback response if fetch completely fails
    const fallbackText = `I'm analyzing your request regarding "${userMessage.slice(0, 40)}...". Let's review the milestones and clarify any blockers.`;
    const fallback: ChloeAgentResponse = {
      success: true,
      text: fallbackText,
      speech: fallbackText,
      suggestedActions: ['Audit document logic', 'Stress-test timeline', 'Review technical architecture'],
      activeSubAgent: 'chloe_general',
      languageCode: 'en-US',
      isExternalEndpoint: false,
    };
    this.notifyListeners(fallback);
    return fallback;
  }

  public async sendQuery(
    prompt: string,
    options: {
      userName?: string;
      history?: Array<{ role: 'user' | 'chloe'; text: string }>;
      pillar?: string;
      targetLanguage?: string;
      autoRefine?: boolean;
      sessionId?: string;
      tone?: string;
      context?: string;
    } = {}
  ): Promise<ChloeAgentResponse> {
    const sessionId = options.sessionId || this.getSessionId();
    this.notifyLoading(true, 'Chloe is analyzing...');

    // First attempt: Dedicated Cloud Agent endpoint with payload { message, session_id }
    try {
      const res = await fetch('/api/chloe/cloud-agent', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: prompt,
          session_id: sessionId,
          userName: options.userName || 'Colleague',
          history: options.history || [],
          pillar: options.pillar || 'report_audit',
          targetLanguage: options.targetLanguage || 'auto',
          tone: options.tone,
          context: options.context,
        }),
      });

      if (res.ok) {
        const data = await res.json();
        const cognitiveResponse = data.response || data.text || data.message || '';
        if (cognitiveResponse) {
          this.notifyLoading(false);
          const formatted: ChloeAgentResponse = {
            success: true,
            text: cognitiveResponse,
            speech: data.speech || cognitiveResponse,
            action: data.action,
            suggestedActions: data.suggestedActions || ['Audit document logic', 'Stress-test roadmap', 'Plan travel'],
            activeSubAgent: data.activeSubAgent || 'chloe_general',
            subAgentInsights: data.subAgentInsights,
            grammarTip: data.grammarTip,
            detectedLanguage: data.detectedLanguage || 'English',
            languageCode: data.languageCode || 'en-US',
            checklistItems: data.checklistItems,
            curatedMedia: data.curatedMedia,
            isExternalEndpoint: Boolean(data.isCloudAgent),
          };
          this.notifyListeners(formatted);
          return formatted;
        }
      }
    } catch (err) {
      console.warn('Cloud agent call failed, attempting fallback orchestrator:', err);
    }

    // Secondary fallback: Native Multi-Agent Orchestrator
    const endpoint = this.getCloudEndpoint();
    const isCustomExternal = endpoint && endpoint.startsWith('http') && !endpoint.includes('localhost');

    const payload: ChloeAgentPayload = {
      prompt,
      userName: options.userName || 'Colleague',
      eventType: 'prompt',
      history: options.history || [],
      pillar: options.pillar || 'report_audit',
      targetLanguage: options.targetLanguage || 'auto',
      autoRefine: options.autoRefine ?? true,
      timestamp: Date.now(),
      tone: options.tone,
      context: options.context,
    };

    if (isCustomExternal) {
      try {
        const res = await fetch('/api/chloe/external-agent', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            endpointUrl: endpoint,
            message: prompt,
            session_id: sessionId,
            payload,
          }),
        });

        if (res.ok) {
          const data = await res.json();
          const cognitiveResponse = data.response || data.text || data.message || '';
          if (cognitiveResponse) {
            this.notifyLoading(false);
            const formatted: ChloeAgentResponse = {
              success: true,
              text: cognitiveResponse,
              speech: data.speech || cognitiveResponse,
              action: data.action,
              suggestedActions: data.suggestedActions || ['Audit document logic', 'Stress-test roadmap', 'Plan travel'],
              activeSubAgent: data.activeSubAgent,
              subAgentInsights: data.subAgentInsights,
              grammarTip: data.grammarTip,
              detectedLanguage: data.detectedLanguage || 'English',
              languageCode: data.languageCode || 'en-US',
              checklistItems: data.checklistItems,
              curatedMedia: data.curatedMedia,
              isExternalEndpoint: true,
            };
            this.notifyListeners(formatted);
            return formatted;
          }
        }
      } catch (err) {
        console.warn('Custom external agent failed, using native Multi-Agent Orchestrator:', err);
      }
    }

    // Native Orchestrator fallback
    try {
      const res = await fetch('/api/chloe/orchestrator', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      this.notifyLoading(false);
      const data = await res.json();
      const formatted: ChloeAgentResponse = {
        success: data.success !== false,
        text: data.text || `I've analyzed your input, ${options.userName || 'Colleague'}. Let's lock in clear milestone ownership.`,
        speech: data.speech || data.text,
        action: data.action,
        suggestedActions: data.suggestedActions || ['Audit document logic', 'Stress-test roadmap', 'Review technical architecture'],
        activeSubAgent: data.activeSubAgent || 'chloe_general',
        subAgentInsights: data.subAgentInsights,
        grammarTip: data.grammarTip,
        detectedLanguage: data.detectedLanguage || 'English',
        languageCode: data.languageCode || 'en-US',
        checklistItems: data.checklistItems,
        curatedMedia: data.curatedMedia,
        isExternalEndpoint: false,
      };
      this.notifyListeners(formatted);
      return formatted;
    } catch (err: any) {
      this.notifyLoading(false);
      const fallback: ChloeAgentResponse = {
        success: true,
        text: `Hey ${options.userName || 'there'}! I'm here. Are we auditing project milestones, reviewing technical architecture, or aligning team culture today?`,
        speech: `Hey there! I'm here. What are we tackling today?`,
        suggestedActions: ['Audit document logic', 'Stress-test timeline', 'Review technical architecture'],
        activeSubAgent: 'chloe_general',
        languageCode: 'en-US',
        isExternalEndpoint: false,
      };
      this.notifyListeners(fallback);
      return fallback;
    }
  }

  public async notifyAction(
    actionName: string,
    actionDetails: any = {},
    userName: string = 'Colleague'
  ): Promise<ChloeAgentResponse | null> {
    const now = Date.now();
    // Throttle action notifications to prevent spamming
    if (now - this.lastActionTriggerTime < 6000) return null;
    this.lastActionTriggerTime = now;

    const payload: ChloeAgentPayload = {
      eventType: 'action',
      actionName,
      actionDetails,
      userName,
      timestamp: now,
    };

    try {
      const res = await fetch('/api/chloe/orchestrator', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      if (res.ok) {
        const data = await res.json();
        if (data.success && data.text) {
          const formatted: ChloeAgentResponse = {
            success: true,
            text: data.text,
            speech: data.speech || data.text,
            action: data.action,
            suggestedActions: data.suggestedActions,
            activeSubAgent: data.activeSubAgent,
            isExternalEndpoint: false,
          };
          this.notifyListeners(formatted);
          return formatted;
        }
      }
    } catch (e) {
      console.warn('Action notification to orchestrator caught non-fatal warning:', e);
    }

    return null;
  }

  public async notifyAFK(
    idleDurationMs: number,
    userName: string = 'Colleague'
  ): Promise<ChloeAgentResponse | null> {
    const now = Date.now();
    // Throttle AFK notifications to at most once per 60 seconds
    if (now - this.lastAfkTriggerTime < 60000) return null;
    this.lastAfkTriggerTime = now;

    const payload: ChloeAgentPayload = {
      eventType: 'afk',
      idleDurationMs,
      userName,
      timestamp: now,
    };

    try {
      const res = await fetch('/api/chloe/orchestrator', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      if (res.ok) {
        const data = await res.json();
        if (data.success && data.text) {
          const formatted: ChloeAgentResponse = {
            success: true,
            text: data.text,
            speech: data.speech || data.text,
            action: data.action,
            suggestedActions: data.suggestedActions,
            activeSubAgent: data.activeSubAgent,
            isExternalEndpoint: false,
          };
          this.notifyListeners(formatted);
          return formatted;
        }
      }
    } catch (e) {
      console.warn('AFK notification to orchestrator caught non-fatal warning:', e);
    }

    return null;
  }

  public async refinePrompt(
    rawPrompt: string,
    userName?: string,
    targetLanguage: string = 'auto'
  ): Promise<{
    success: boolean;
    refinedPrompt?: string;
    grammarTip?: string;
    detectedLanguage?: string;
  }> {
    const clean = rawPrompt.trim();
    if (!clean) return { success: false, refinedPrompt: rawPrompt };

    try {
      const res = await fetch('/api/chloe/refine-prompt', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          rawPrompt: clean,
          userName,
          targetLanguage,
        }),
      });

      if (res.ok) {
        const data = await res.json();
        if (data.success && data.refinedPrompt) {
          return {
            success: true,
            refinedPrompt: data.refinedPrompt,
            grammarTip: data.grammarTip,
            detectedLanguage: data.detectedLanguage,
          };
        }
      }
    } catch (err) {
      console.warn('Error refining prompt via chloeAgentClient:', err);
    }

    return { success: false, refinedPrompt: clean };
  }
}

export const chloeAgentClient = new ChloeAgentClient();
