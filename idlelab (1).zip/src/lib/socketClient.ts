import { ClientEvent, ServerEvent, Position3D } from '../types';

export class SocketClient {
  private ws: WebSocket | null = null;
  private url: string;
  private listeners: Map<string, Array<(data: any) => void>> = new Map();
  private isConnected = false;
  private isConnecting = false;
  private lastJoinEvent: ClientEvent | null = null;
  private reconnectTimer: any = null;
  private pingInterval: any = null;
  private currentUserId: string | null = null;
  private lastPosition: Position3D | null = null;
  private lastRotationY: number = 0;

  constructor() {
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    this.url = `${protocol}//${window.location.host}/ws`;

    if (typeof window !== 'undefined') {
      try {
        const savedPos = localStorage.getItem('idlelab_last_pos');
        if (savedPos) {
          this.lastPosition = JSON.parse(savedPos);
        }
        const savedRot = localStorage.getItem('idlelab_last_roty');
        if (savedRot) {
          this.lastRotationY = parseFloat(savedRot) || 0;
        }
        const savedUid = localStorage.getItem('idlelab_user_id');
        if (savedUid) {
          this.currentUserId = savedUid;
        }
      } catch (_) {}
    }
  }

  public setUserId(id: string) {
    this.currentUserId = id;
    if (typeof window !== 'undefined') {
      try {
        localStorage.setItem('idlelab_user_id', id);
      } catch (_) {}
    }
  }

  public getUserId(): string | null {
    return this.currentUserId;
  }

  public updateLastPosition(pos: Position3D, rotY?: number) {
    this.lastPosition = { ...pos };
    if (rotY !== undefined) this.lastRotationY = rotY;
    if (typeof window !== 'undefined') {
      try {
        localStorage.setItem('idlelab_last_pos', JSON.stringify(this.lastPosition));
        if (rotY !== undefined) {
          localStorage.setItem('idlelab_last_roty', rotY.toString());
        }
      } catch (_) {}
    }
  }

  public getLastPosition(): Position3D | null {
    return this.lastPosition;
  }

  public getLastRotationY(): number {
    return this.lastRotationY;
  }

  public connect(): Promise<void> {
    if (this.isConnected || this.isConnecting) {
      return Promise.resolve();
    }

    this.isConnecting = true;

    if (this.reconnectTimer) {
      clearTimeout(this.reconnectTimer);
      this.reconnectTimer = null;
    }

    return new Promise((resolve) => {
      try {
        this.ws = new WebSocket(this.url);

        this.ws.onopen = () => {
          this.isConnected = true;
          this.isConnecting = false;
          this.emitInternal('connect', null);

          // Re-send last JOIN_ROOM event on reconnect if present, attaching known coordinates & user id
          if (this.lastJoinEvent && this.lastJoinEvent.type === 'JOIN_ROOM') {
            const enrichedJoin: ClientEvent = {
              ...this.lastJoinEvent,
              userId: this.currentUserId || undefined,
              initialPosition: this.lastPosition || undefined,
              initialRotationY: this.lastRotationY,
            };
            this.send(enrichedJoin);
          }

          // Start client keepalive ping
          this.startPing();
          resolve();
        };

        this.ws.onmessage = (event) => {
          try {
            const data: ServerEvent = JSON.parse(event.data);
            if (data.type === 'INIT_STATE' && data.userId) {
              this.setUserId(data.userId);
            }
            this.emitInternal(data.type, data);
            this.emitInternal('*', data);
          } catch (err) {
            console.warn('Failed to parse WebSocket message:', err);
          }
        };

        this.ws.onclose = () => {
          this.cleanup();
          this.emitInternal('disconnect', null);
          this.scheduleReconnect();
        };

        this.ws.onerror = () => {
          console.warn('WebSocket connection status updated (reconnecting)');
          this.cleanup();
          this.scheduleReconnect();
          resolve();
        };
      } catch (e) {
        console.warn('WebSocket init exception:', e);
        this.cleanup();
        this.scheduleReconnect();
        resolve();
      }
    });
  }

  private startPing() {
    this.stopPing();
    this.pingInterval = setInterval(() => {
      if (this.ws && this.ws.readyState === WebSocket.OPEN) {
        try {
          this.ws.send(JSON.stringify({ type: 'PING' }));
        } catch (_) {}
      }
    }, 25000);
  }

  private stopPing() {
    if (this.pingInterval) {
      clearInterval(this.pingInterval);
      this.pingInterval = null;
    }
  }

  private cleanup() {
    this.isConnected = false;
    this.isConnecting = false;
    this.stopPing();
  }

  private scheduleReconnect() {
    if (this.reconnectTimer) return;
    this.reconnectTimer = setTimeout(() => {
      this.reconnectTimer = null;
      this.connect().catch(() => {});
    }, 2500);
  }

  public send(event: ClientEvent) {
    if (event.type === 'JOIN_ROOM') {
      this.lastJoinEvent = event;
      if (event.userId) this.currentUserId = event.userId;
      if (event.initialPosition) this.lastPosition = { ...event.initialPosition };
      if (event.initialRotationY !== undefined) this.lastRotationY = event.initialRotationY;
    } else if (event.type === 'MOVE') {
      this.lastPosition = { ...event.position };
      this.lastRotationY = event.rotationY;
      if (typeof window !== 'undefined') {
        try {
          localStorage.setItem('idlelab_last_pos', JSON.stringify(this.lastPosition));
          localStorage.setItem('idlelab_last_roty', event.rotationY.toString());
        } catch (_) {}
      }
    }

    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      try {
        this.ws.send(JSON.stringify(event));
      } catch (e) {
        console.warn('Failed to send WS message:', e);
      }
    }
  }

  public on(eventType: string, callback: (data: any) => void) {
    if (!this.listeners.has(eventType)) {
      this.listeners.set(eventType, []);
    }
    this.listeners.get(eventType)!.push(callback);
  }

  public off(eventType: string, callback: (data: any) => void) {
    const arr = this.listeners.get(eventType);
    if (arr) {
      this.listeners.set(
        eventType,
        arr.filter((cb) => cb !== callback)
      );
    }
  }

  private emitInternal(type: string, payload: any) {
    const cbs = this.listeners.get(type);
    if (cbs) {
      cbs.forEach((cb) => cb(payload));
    }
  }

  public getIsConnected(): boolean {
    return this.isConnected;
  }
}

export const socketClient = new SocketClient();
