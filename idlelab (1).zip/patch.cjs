const fs = require('fs');
let code = fs.readFileSync('src/components/OfficeCanvas.tsx', 'utf8');

// Replace the space/X/F key down logic
const oldKeyLogic = `      // Tennis Swing Shortcut: Spacebar or KeyX / KeyF
      if (e.code === 'Space' || e.code === 'KeyX' || e.code === 'KeyF') {
        const isNearTennis =
          Math.hypot(myPosRef.current.x - 29.0, myPosRef.current.z) < 22.0 &&
          Math.abs((myPosRef.current.y || 0) - (-6.0)) < 3.5;
        if (isNearTennis) {
          isPlayerSwingingRef.current = true;
          myAvatarGroupRef.current?.triggerTennisSwing('smash');
        }
      }`;

const newKeyLogic = `      // Tennis Swing & Jump Shortcuts
      if (e.code === 'KeyZ' || e.code === 'KeyX' || e.code === 'KeyF' || e.code === 'Space') {
        const isNearTennis =
          Math.hypot(myPosRef.current.x - 29.0, myPosRef.current.z) < 22.0 &&
          Math.abs((myPosRef.current.y || 0) - (-6.0)) < 3.5;
        if (isNearTennis) {
          if (e.code === 'Space') {
             if ((myPosRef.current.y || 0) <= -6.01 || (myPosRef.current.y || 0) >= -6.0) {
                 if (playerVelYRef.current === 0) {
                     playerVelYRef.current = 6.0;
                 }
             }
          } else {
            isPlayerSwingingRef.current = true;
            myAvatarGroupRef.current?.triggerTennisSwing(e.code === 'KeyZ' ? 'smash' : 'forehand');
          }
        }
      }`;

code = code.replace(oldKeyLogic, newKeyLogic);

// Replace UI [Space] with [Z]
code = code.replace('<span className="text-[10px] bg-amber-800/80 px-1 py-0.5 rounded font-mono">[Space]</span>', '<span className="text-[10px] bg-amber-800/80 px-1 py-0.5 rounded font-mono">[Z]</span>');

fs.writeFileSync('src/components/OfficeCanvas.tsx', code);
