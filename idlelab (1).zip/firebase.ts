import { initializeApp, getApps, getApp } from 'firebase/app';
import { getFirestore, collection, addDoc, getDocs, query, orderBy, limit, serverTimestamp } from 'firebase/firestore';

// Basic Firebase setup structure using fallback defaults for hackathon evaluation
const getEnvVar = (name: string): string | undefined => {
  if (typeof process !== 'undefined' && process.env && process.env[name]) {
    return process.env[name];
  }
  try {
    if (typeof import.meta !== 'undefined' && (import.meta as any).env && (import.meta as any).env[name]) {
      return (import.meta as any).env[name];
    }
  } catch {
    // Ignore error in non-module or node context
  }
  return undefined;
};

const firebaseConfig = {
  apiKey: getEnvVar('VITE_FIREBASE_API_KEY') || getEnvVar('FIREBASE_API_KEY') || "AIzaSyDummyKeyForHackathonEvaluation123",
  authDomain: getEnvVar('VITE_FIREBASE_AUTH_DOMAIN') || getEnvVar('FIREBASE_AUTH_DOMAIN') || "idlelab-hackathon.firebaseapp.com",
  projectId: getEnvVar('VITE_FIREBASE_PROJECT_ID') || getEnvVar('FIREBASE_PROJECT_ID') || "idlelab-hackathon",
  storageBucket: getEnvVar('VITE_FIREBASE_STORAGE_BUCKET') || getEnvVar('FIREBASE_STORAGE_BUCKET') || "idlelab-hackathon.appspot.com",
  messagingSenderId: getEnvVar('VITE_FIREBASE_MESSAGING_SENDER_ID') || getEnvVar('FIREBASE_MESSAGING_SENDER_ID') || "1234567890",
  appId: getEnvVar('VITE_FIREBASE_APP_ID') || getEnvVar('FIREBASE_APP_ID') || "1:1234567890:web:abcdef123456"
};

// Prevent duplicate initialization during React / Vite re-renders
const app = !getApps().length ? initializeApp(firebaseConfig) : getApp();
export const db = getFirestore(app);

// Data Persistence Helper for Chloe, Claire, and Lofi Girl
export async function logAgentActivity(agentName: 'Chloe' | 'Claire' | 'LofiGirl', taskType: string, payload: Record<string, any>) {
  try {
    const docRef = await addDoc(collection(db, "agent_memory"), {
      agent: agentName,
      action: taskType,
      data: payload,
      timestamp: serverTimestamp()
    });
    console.log(`[Firestore] Successfully persisted state for ${agentName} (Doc ID: ${docRef.id})`);
    return docRef.id;
  } catch (error) {
    console.warn(`[Firestore] Local persistence fallback active for ${agentName}:`, error);
    return null;
  }
}